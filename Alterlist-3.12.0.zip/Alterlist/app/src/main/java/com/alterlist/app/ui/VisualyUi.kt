package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alterlist.app.data.UiStyle

/** Kartu pilihan satu gaya di Setelan > Visualy: pratinjau mini dengan palet gaya itu sendiri + nama + penjelasan. */
@Composable
fun StyleCard(style: UiStyle, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .clip(shape)
            .background(AlterColors.Surface)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) AlterColors.Red else AlterColors.Divider, shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        StylePreview(style)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(style.label, style = T.title.copy(fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(3.dp))
            Text(style.desc, style = T.small, color = AlterColors.Sub)
            if (style == UiStyle.ALTERLIST) {
                Spacer(Modifier.height(6.dp))
                Text("BAWAAN", style = T.tiny.copy(fontWeight = FontWeight.Bold), color = AlterColors.Muted)
            }
        }
        Spacer(Modifier.width(10.dp))
        // penanda pilihan
        Box(
            Modifier.size(22.dp).clip(CircleShape).border(2.dp, if (selected) AlterColors.Red else AlterColors.Muted, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            if (selected) Box(Modifier.size(11.dp).clip(CircleShape).background(AlterColors.Red))
        }
    }
}

/**
 * Pratinjau layar mini yang digambar dengan palet [style] (bukan palet yang sedang aktif), jadi keempat kartu
 * tampil berbeda berdampingan: daftar lagu, mini player, dan bar navigasi khas tiap gaya.
 */
@Composable
private fun StylePreview(style: UiStyle) {
    val p = Palettes.of(style)
    val frame = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .size(width = 86.dp, height = 124.dp)
            .clip(frame)
            .background(p.bg)
            .border(1.dp, p.divider, frame)
            .padding(7.dp),
    ) {
        // judul layar + titik aksen
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(width = 30.dp, height = 5.dp).clip(RoundedCornerShape(3.dp)).background(p.sub))
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(6.dp).clip(CircleShape).background(p.accent))
        }
        Spacer(Modifier.height(7.dp))
        repeat(2) {
            val rowShape = RoundedCornerShape(if (style == UiStyle.METROLIST) 6.dp else 7.dp)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
                    .then(
                        when (style) {
                            UiStyle.ALTERLIST -> Modifier
                            UiStyle.LIQUID -> Modifier.glassPanel(rowShape, strength = 0.9f)
                            UiStyle.METROLIST -> Modifier.clip(rowShape).background(Color(0xFF211F26))
                            UiStyle.ALDER -> Modifier.clip(rowShape).background(p.surface).border(1.dp, p.divider, rowShape)
                        },
                    )
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(14.dp).clip(RoundedCornerShape(3.dp)).background(p.surface3))
                Spacer(Modifier.width(4.dp))
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(Modifier.size(width = 26.dp, height = 3.dp).clip(RoundedCornerShape(2.dp)).background(p.sub.copy(alpha = 0.85f)))
                    Box(Modifier.size(width = 16.dp, height = 3.dp).clip(RoundedCornerShape(2.dp)).background(p.muted))
                }
            }
        }
        Spacer(Modifier.weight(1f))
        // mini player
        val miniShape = RoundedCornerShape(if (style == UiStyle.METROLIST) 5.dp else 8.dp)
        Box(
            Modifier
                .fillMaxWidth()
                .height(17.dp)
                .then(
                    when (style) {
                        UiStyle.ALTERLIST -> Modifier.clip(miniShape).background(Brush.horizontalGradient(listOf(Color(0xFF4A1013), Color(0xFF1B2540))))
                        UiStyle.LIQUID -> Modifier.glassPanel(miniShape, strength = 1.4f)
                        UiStyle.METROLIST -> Modifier.clip(miniShape).background(Color(0xFF2B2930))
                        UiStyle.ALDER ->
                            Modifier
                                .clip(miniShape)
                                .background(p.surface2)
                                .border(1.dp, Brush.verticalGradient(listOf(p.accent.copy(alpha = 0.6f), p.accent.copy(alpha = 0.1f))), miniShape)
                    },
                ),
        ) {
            Box(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 5.dp, bottom = 2.dp)
                    .size(width = 28.dp, height = 2.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(if (style == UiStyle.ALTERLIST || style == UiStyle.LIQUID) Color.White else p.accent),
            )
        }
        Spacer(Modifier.height(5.dp))
        // bar navigasi
        val navShape = RoundedCornerShape(50)
        Row(
            Modifier
                .fillMaxWidth()
                .height(if (style == UiStyle.LIQUID) 16.dp else 14.dp)
                .then(
                    when (style) {
                        UiStyle.LIQUID -> Modifier.glassPanel(navShape)
                        UiStyle.METROLIST -> Modifier.clip(RoundedCornerShape(3.dp)).background(Color(0xFF211F26))
                        else -> Modifier
                    },
                ),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            repeat(3) { i ->
                val on = i == 0
                Box(contentAlignment = Alignment.Center) {
                    if (style == UiStyle.METROLIST && on) {
                        Box(Modifier.size(width = 16.dp, height = 9.dp).clip(RoundedCornerShape(5.dp)).background(Color(0xFF4A4458)))
                    }
                    if (style == UiStyle.ALDER && on) {
                        Box(Modifier.align(Alignment.TopCenter).size(width = 8.dp, height = 1.5.dp).background(p.accent))
                    }
                    Box(
                        Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (on) (if (style == UiStyle.ALTERLIST) Color.White else p.accent) else p.muted),
                    )
                }
            }
        }
    }
}
