package com.alterlist.app.poster

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Menggambar poster dengan urutan lapisan seperti editor poster Auralys:
 *   foto (grade, blur, redup, cahaya)  ->  kartu lagu kaca 3D  ->  subjek hasil potongan (menimpa kartu)  ->  FX.
 * Satu kode untuk pratinjau, ekspor PNG, dan wallpaper hidup. [tx]/[ty] = kemiringan -1..1, [t] = detik.
 */
class PosterRenderer(private val data: PosterData) {
    private val style get() = data.style

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cam = Camera()
    private val m = Matrix()
    private val inv = Matrix()
    private val sm = Matrix()
    private val photoM = Matrix()
    private val rect = RectF()
    private val star = Path()
    private val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    private val coverShaders = HashMap<Bitmap, BitmapShader>()

    // ---- cache latar (dibangun ulang hanya bila ukuran / pengaturan latar berubah)
    private var cacheKey = ""
    private var base: Bitmap? = null
    private var frost: Bitmap? = null
    private var cut: Bitmap? = null
    private var anchorX = 0f
    private var anchorY = 0f
    private var noise: Bitmap? = null

    fun draw(c: Canvas, w: Int, h: Int, tx: Float, ty: Float, t: Float) {
        val key = "$w x $h|${style.baseKey()}"
        if (key != cacheKey || base == null) {
            build(w, h)
            cacheKey = key
        }
        val width = w.toFloat()
        val height = h.toFloat()
        val bgDx = -tx * width * 0.012f
        val bgDy = -ty * height * 0.008f

        // 1. foto
        c.save()
        c.translate(bgDx, bgDy)
        c.drawBitmap(base!!, 0f, 0f, null)
        c.restore()

        // 2. kartu (bergerak lebih jauh dari foto -> terasa melayang di depan latar)
        drawCards(c, w, h, tx, ty, t)

        // 3. subjek menimpa kartu, bergerak sama dengan foto supaya tetap menempel
        cut?.let {
            c.save()
            c.translate(bgDx, bgDy)
            c.drawBitmap(it, 0f, 0f, null)
            c.restore()
        }

        // 4. efek
        drawFx(c, w, h, tx, ty, t)
    }

    // ------------------------------------------------------------------ latar

    private fun build(w: Int, h: Int) {
        val s = style
        val gradePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(gradeMatrix(s.grade)) }
        val photo = data.photo
        var bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        if (photo != null) {
            val sc = max(w / photo.width.toFloat(), h / photo.height.toFloat()) * s.zoom * 1.06f
            photoM.setScale(sc, sc)
            photoM.postTranslate((w - photo.width * sc) / 2f, (h - photo.height * sc) / 2f)
            canvas.drawBitmap(photo, photoM, gradePaint)
        } else {
            val top = blend(data.accent, 0xFF0A0A0C.toInt(), 0.6f)
            fill.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), intArrayOf(top, 0xFF0B0B0D.toInt()), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill)
            fill.shader = null
            data.songs.firstOrNull { it.cover != null }?.cover?.let {
                rect.set(-w * 0.2f, -h * 0.1f, w * 1.2f, h * 1.1f)
                paint.alpha = 100
                canvas.drawBitmap(Bitmap.createScaledBitmap(it, 24, 24, true), null, rect, paint)
                paint.alpha = 255
            }
        }
        if (s.blur > 0.02f) {
            bmp = blurred(bmp, 1f + s.blur * 16f)
        }
        val bc = Canvas(bmp)
        // redup + cahaya warna aksen + vinyet
        fill.color = Color.argb((s.dim * 190).toInt().coerceIn(0, 255), 0, 0, 0)
        bc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill)
        fill.shader = RadialGradient(w * 0.5f, h * 0.62f, w * 0.95f, intArrayOf(withAlpha(data.accent, (s.glow * 150).toInt()), withAlpha(data.accent, 0)), null, Shader.TileMode.CLAMP)
        fill.xfermode = screen
        bc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill)
        fill.xfermode = null
        fill.shader = RadialGradient(w / 2f, h / 2f, max(w, h) * 0.75f, intArrayOf(Color.TRANSPARENT, Color.argb(110, 0, 0, 0)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
        bc.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fill)
        fill.shader = null
        base = bmp
        frost = blurred(bmp, 22f)

        // subjek: digambar ke lapisan sendiri dengan matriks yang sama dengan foto
        cut = null
        anchorX = w / 2f
        anchorY = h * 0.4f
        val cutout = data.cutout
        if (photo != null && cutout != null) {
            val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cm = Matrix(photoM)
            cm.preScale(photo.width / cutout.width.toFloat(), photo.height / cutout.height.toFloat())
            Canvas(layer).drawBitmap(cutout, cm, gradePaint)
            cut = layer
            val b = alphaBounds(cutout)
            if (b != null) {
                val pts = floatArrayOf((b.left + b.right) / 2f, b.top + (b.bottom - b.top) * 0.18f)
                cm.mapPoints(pts)
                anchorX = pts[0]
                anchorY = pts[1]
            }
        }
    }

    /** Kotak yang berisi piksel subjek (dari contoh piksel, cukup untuk menentukan posisi kepala). */
    private fun alphaBounds(b: Bitmap): RectF? {
        val step = max(1, max(b.width, b.height) / 160)
        var x0 = b.width
        var y0 = b.height
        var x1 = -1
        var y1 = -1
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                if (Color.alpha(b.getPixel(x, y)) > 128) {
                    if (x < x0) x0 = x
                    if (x > x1) x1 = x
                    if (y < y0) y0 = y
                    if (y > y1) y1 = y
                }
                x += step
            }
            y += step
        }
        return if (x1 < 0) null else RectF(x0.toFloat(), y0.toFloat(), x1.toFloat(), y1.toFloat())
    }

    /** Blur murah: perkecil lalu perbesar dengan filter dua tahap (cukup halus untuk latar). */
    private fun blurred(src: Bitmap, k: Float): Bitmap {
        val sw = max(8, (src.width / k).toInt())
        val sh = max(8, (src.height / k).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val mid = Bitmap.createScaledBitmap(small, max(4, sw / 2), max(4, sh / 2), true)
        return Bitmap.createScaledBitmap(mid, src.width, src.height, true)
    }

    private fun gradeMatrix(g: PosterGrade): ColorMatrix {
        val cm = ColorMatrix()
        when (g) {
            PosterGrade.ASLI -> Unit
            PosterGrade.HANGAT -> {
                cm.setSaturation(1.12f)
                cm.postConcat(ColorMatrix(floatArrayOf(1.08f, 0f, 0f, 0f, 6f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 0.9f, 0f, -6f, 0f, 0f, 0f, 1f, 0f)))
            }
            PosterGrade.DINGIN -> {
                cm.setSaturation(1.05f)
                cm.postConcat(ColorMatrix(floatArrayOf(0.92f, 0f, 0f, 0f, -4f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.1f, 0f, 8f, 0f, 0f, 0f, 1f, 0f)))
            }
            PosterGrade.NEON -> {
                cm.setSaturation(1.55f)
                cm.postConcat(ColorMatrix(floatArrayOf(1.18f, 0f, 0f, 0f, -14f, 0f, 1.18f, 0f, 0f, -14f, 0f, 0f, 1.18f, 0f, -14f, 0f, 0f, 0f, 1f, 0f)))
            }
            PosterGrade.FILM -> {
                cm.setSaturation(0.85f)
                cm.postConcat(ColorMatrix(floatArrayOf(0.94f, 0f, 0f, 0f, 14f, 0f, 0.94f, 0f, 0f, 16f, 0f, 0f, 0.92f, 0f, 18f, 0f, 0f, 0f, 1f, 0f)))
            }
        }
        return cm
    }

    // ------------------------------------------------------------------ kartu

    private class Pose(val x: Float, val y: Float, val scale: Float, val rotZ: Float, val rotX: Float, val rotY: Float, val depth: Float)

    private fun poses(n: Int, w: Float, h: Float): List<Pose> {
        val ax = anchorX
        val ay = anchorY
        val out = ArrayList<Pose>(n)
        for (i in 0 until n) {
            val f = if (n == 1) 0.5f else i / (n - 1f)
            when (style.layout) {
                PosterLayout.ORBIT -> {
                    val a = Math.toRadians((-150.0) + 120.0 * f)
                    val x = ax + cos(a).toFloat() * w * 0.34f
                    val y = ay + sin(a).toFloat() * h * 0.17f - h * 0.02f
                    out.add(Pose(x, y, 0.84f + 0.2f * (1f - kotlin.math.abs(f - 0.5f) * 2f), (x - ax) / w * 16f, 6f, -(x - ax) / w * 34f, 0.5f + 0.5f * (1f - kotlin.math.abs(f - 0.5f) * 2f)))
                }
                PosterLayout.TUMPUK -> {
                    val x = ax + (i - (n - 1) / 2f) * w * 0.03f
                    val y = ay - h * 0.1f + i * h * 0.05f
                    out.add(Pose(x, y, 0.9f + 0.03f * i, (if (i % 2 == 0) -1f else 1f) * (4f + 2f * i), 8f, 0f, 0.3f + 0.15f * i))
                }
                PosterLayout.DERET -> {
                    val x = if (n == 1) w / 2f else w * (0.22f + 0.56f * f)
                    val y = ay - h * 0.03f + (if (i % 2 == 0) -1f else 1f) * h * 0.02f
                    out.add(Pose(x, y, 0.82f, (f - 0.5f) * -8f, 4f, 30f - 60f * f, 0.5f + 0.3f * (1f - kotlin.math.abs(f - 0.5f) * 2f)))
                }
                PosterLayout.KOLOM -> {
                    val x = w * 0.68f
                    val y = h * 0.12f + i * h * (0.5f / max(1, n)) + h * 0.04f
                    out.add(Pose(x, y, 0.88f, -4f, 0f, -24f, 0.6f))
                }
            }
        }
        return out
    }

    private fun drawCards(c: Canvas, w: Int, h: Int, tx: Float, ty: Float, t: Float) {
        val songs = data.songs.take(5)
        if (songs.isEmpty()) return
        val width = w.toFloat()
        val height = h.toFloat()
        val cw = width * (0.5f + 0.26f * style.cardSize)
        val ch = cw * 0.34f
        val list = poses(songs.size, width, height)
        // yang paling "dalam" digambar dulu
        val order = list.indices.sortedBy { list[it].depth }
        for (i in order) {
            val p = list[i]
            val bob = sin(t * 0.9f + i * 1.3f) * height * 0.004f
            val cx = p.x + tx * width * 0.05f * p.depth
            val cy = p.y + bob + ty * height * 0.02f * p.depth
            cam.save()
            cam.setLocation(0f, 0f, -(3f + 12f * (1f - style.perspective)) * max(0.25f, width / 1080f))
            cam.rotateX(p.rotX + ty * 9f)
            cam.rotateY(p.rotY + tx * 12f)
            cam.rotateZ(-p.rotZ)
            cam.getMatrix(m)
            cam.restore()
            m.preTranslate(-cw / 2f, -ch / 2f)
            m.postScale(p.scale, p.scale)
            m.postTranslate(cx, cy)
            drawCard(c, songs[i], cw, ch, m, w, h)
        }
    }

    private fun drawCard(c: Canvas, song: PosterSong, cw: Float, ch: Float, mat: Matrix, w: Int, h: Int) {
        val s = style
        val r = ch * (0.16f + 0.34f * s.corner)
        c.save()
        c.concat(mat)

        // bayangan lembut (lapisan bertingkat)
        for (k in 1..7) {
            fill.color = Color.argb(16, 0, 0, 0)
            val g = ch * 0.045f * k
            rect.set(-g, ch * 0.1f - g, cw + g, ch + ch * 0.1f + g)
            c.drawRoundRect(rect, r + g, r + g, fill)
        }

        // kaca: latar yang diburamkan, dipotong mengikuti bentuk kartu 3D
        rect.set(0f, 0f, cw, ch)
        c.save()
        val clip = Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) }
        c.clipPath(clip)
        if (mat.invert(inv)) {
            c.concat(inv)
            frost?.let { c.drawBitmap(it, 0f, 0f, null) }
            c.concat(mat)
        }
        val (tint, tintA) = materialTint(s.material)
        fill.color = withAlpha(tint, (tintA + s.frost * 50f).toInt())
        c.drawRect(rect, fill)
        // kilap diagonal
        fill.shader = LinearGradient(0f, 0f, cw * 0.7f, ch, intArrayOf(Color.argb(70, 255, 255, 255), Color.argb(0, 255, 255, 255)), null, Shader.TileMode.CLAMP)
        c.drawRect(rect, fill)
        fill.shader = null
        c.restore()

        // tepi (rim)
        fill.style = Paint.Style.STROKE
        fill.strokeWidth = max(1.2f, ch * 0.014f)
        fill.color = Color.argb(95, 255, 255, 255)
        c.drawRoundRect(rect, r, r, fill)
        fill.style = Paint.Style.FILL

        // sampul
        val pad = ch * 0.12f
        val cs = ch - pad * 2f
        val cover = song.cover
        if (cover != null) {
            val sh = coverShaders.getOrPut(cover) { BitmapShader(cover, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
            sm.setScale(cs / cover.width, cs / cover.height)
            sm.postTranslate(pad, pad)
            sh.setLocalMatrix(sm)
            paint.shader = sh
            rect.set(pad, pad, pad + cs, pad + cs)
            c.drawRoundRect(rect, r * 0.55f, r * 0.55f, paint)
            paint.shader = null
        }

        // teks
        val tx0 = pad * 2f + cs
        val maxW = cw - tx0 - pad * 1.2f
        text.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        text.textSize = ch * 0.21f
        text.color = Color.WHITE
        c.drawText(fit(song.title, text, maxW), tx0, ch * 0.38f, text)
        text.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        text.textSize = ch * 0.15f
        text.color = Color.argb(185, 255, 255, 255)
        c.drawText(fit(song.artist, text, maxW), tx0, ch * 0.56f, text)
        // bar progres + durasi
        val by = ch * 0.74f
        fill.color = Color.argb(70, 255, 255, 255)
        rect.set(tx0, by, tx0 + maxW, by + ch * 0.04f)
        c.drawRoundRect(rect, ch * 0.02f, ch * 0.02f, fill)
        fill.color = Color.WHITE
        rect.set(tx0, by, tx0 + maxW * 0.38f, by + ch * 0.04f)
        c.drawRoundRect(rect, ch * 0.02f, ch * 0.02f, fill)
        text.textSize = ch * 0.115f
        text.color = Color.argb(160, 255, 255, 255)
        val dur = song.durationSec.coerceAtLeast(0)
        val total = "${dur / 60}:${(dur % 60).toString().padStart(2, '0')}"
        c.drawText(total, tx0 + maxW - text.measureText(total), ch * 0.9f, text)
        c.restore()
    }

    private fun materialTint(mat: CardMaterial): Pair<Int, Int> =
        when (mat) {
            CardMaterial.ASAP -> Color.rgb(12, 12, 14) to 110
            CardMaterial.BENING -> Color.WHITE to 22
            CardMaterial.SUSU -> Color.WHITE to 120
            CardMaterial.GELAP -> Color.BLACK to 190
        }

    private fun fit(textIn: String, p: Paint, maxW: Float): String {
        if (p.measureText(textIn) <= maxW) return textIn
        var n = textIn.length
        val dots = p.measureText("…")
        while (n > 1 && p.measureText(textIn, 0, n) + dots > maxW) n--
        return textIn.substring(0, n).trimEnd() + "…"
    }

    // ------------------------------------------------------------------ efek

    private fun drawFx(c: Canvas, w: Int, h: Int, tx: Float, ty: Float, t: Float) {
        val (bloom, leak, streak, sparkle, grain) =
            when (style.fx) {
                FxPreset.BERSIH -> floatArrayOf(0.10f, 0f, 0f, 0.25f, 0f)
                FxPreset.SINEMA -> floatArrayOf(0.45f, 0.30f, 0.55f, 0.55f, 0.22f)
                FxPreset.FILM -> floatArrayOf(0.30f, 0.55f, 0f, 0.10f, 0.70f)
            }
        val width = w.toFloat()
        val height = h.toFloat()
        // bloom: versi kabur foto ditumpuk dengan mode SCREEN
        if (bloom > 0f) {
            frost?.let {
                paint.xfermode = screen
                paint.alpha = (bloom * 110).toInt()
                c.drawBitmap(it, 0f, 0f, paint)
                paint.alpha = 255
                paint.xfermode = null
            }
        }
        // bocor cahaya hangat dari pojok kanan atas
        if (leak > 0f) {
            fill.shader = RadialGradient(width * (0.95f - tx * 0.05f), height * 0.05f, width * 0.8f, intArrayOf(Color.argb((leak * 150).toInt(), 255, 140, 60), Color.argb(0, 255, 120, 40)), null, Shader.TileMode.CLAMP)
            fill.xfermode = screen
            c.drawRect(0f, 0f, width, height, fill)
            fill.xfermode = null
            fill.shader = null
        }
        // lens streak horizontal
        if (streak > 0f) {
            val y = anchorY + ty * height * 0.02f
            fill.shader = LinearGradient(0f, 0f, width, 0f, intArrayOf(Color.argb(0, 150, 190, 255), Color.argb((streak * 150).toInt(), 190, 220, 255), Color.argb(0, 150, 190, 255)), floatArrayOf(0f, 0.5f - tx * 0.1f, 1f), Shader.TileMode.CLAMP)
            fill.xfermode = screen
            for (k in -2..2) {
                val th = max(1f, height * 0.0016f) * (3 - kotlin.math.abs(k)).toFloat()
                rect.set(0f, y + k * th * 1.2f - th / 2f, width, y + k * th * 1.2f + th / 2f)
                c.drawRect(rect, fill)
            }
            fill.xfermode = null
            fill.shader = null
        }
        // kilau bintang
        if (sparkle > 0f) {
            val rnd = Random(7)
            val count = (6 + sparkle * 14).toInt()
            for (i in 0 until count) {
                val px = rnd.nextFloat() * width
                val py = rnd.nextFloat() * height * 0.62f
                val phase = rnd.nextFloat() * 6.28f
                val tw = (sin(t * 1.8f + phase) * 0.5f + 0.5f)
                val sz = width * (0.008f + 0.022f * rnd.nextFloat()) * (0.5f + tw)
                val x = px + tx * width * 0.03f
                star.reset()
                star.moveTo(x, py - sz)
                star.lineTo(x + sz * 0.16f, py - sz * 0.16f)
                star.lineTo(x + sz, py)
                star.lineTo(x + sz * 0.16f, py + sz * 0.16f)
                star.lineTo(x, py + sz)
                star.lineTo(x - sz * 0.16f, py + sz * 0.16f)
                star.lineTo(x - sz, py)
                star.lineTo(x - sz * 0.16f, py - sz * 0.16f)
                star.close()
                fill.color = Color.argb((60 + 170 * tw * sparkle).toInt().coerceIn(0, 255), 255, 255, 255)
                c.drawPath(star, fill)
            }
        }
        // grain film
        if (grain > 0f) {
            val n = noise ?: makeNoise().also { noise = it }
            val sh = BitmapShader(n, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            sm.setTranslate((t * 37f) % 128f, (t * 53f) % 128f)
            val scale = max(1f, width / 540f)
            sm.preScale(scale, scale)
            sh.setLocalMatrix(sm)
            paint.shader = sh
            paint.alpha = (grain * 70).toInt()
            c.drawRect(0f, 0f, width, height, paint)
            paint.shader = null
            paint.alpha = 255
        }
    }

    private fun makeNoise(): Bitmap {
        val n = 128
        val px = IntArray(n * n)
        val rnd = Random(11)
        for (i in px.indices) {
            val v = rnd.nextInt(256)
            px[i] = Color.argb(255, v, v, v)
        }
        return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun blend(a: Int, b: Int, t: Float): Int {
        val k = min(1f, max(0f, t))
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt(),
        )
    }

}
