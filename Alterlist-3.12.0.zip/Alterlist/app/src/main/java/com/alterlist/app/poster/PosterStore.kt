package com.alterlist.app.poster

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Poster terakhir disimpan di penyimpanan privat aplikasi supaya wallpaper hidup bisa memuatnya tanpa internet. */
object PosterStore {
    private fun dir(context: Context): File = File(context.filesDir, "poster").apply { mkdirs() }

    /** Penanda versi: berubah setiap poster disimpan (dipakai wallpaper untuk memuat ulang). */
    fun version(context: Context): Long = File(dir(context), "meta.json").lastModified()

    fun save(context: Context, data: PosterData) {
        val d = dir(context)
        d.listFiles()?.forEach { it.delete() }
        data.photo?.let { p -> FileOutputStream(File(d, "photo.jpg")).use { p.compress(Bitmap.CompressFormat.JPEG, 92, it) } }
        data.cutout?.let { c -> FileOutputStream(File(d, "cutout.png")).use { c.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        val songs = JSONArray()
        data.songs.forEachIndexed { i, s ->
            s.cover?.let { cv -> FileOutputStream(File(d, "cover_$i.jpg")).use { cv.compress(Bitmap.CompressFormat.JPEG, 90, it) } }
            songs.put(JSONObject().put("title", s.title).put("artist", s.artist).put("dur", s.durationSec).put("cover", s.cover != null))
        }
        val meta = JSONObject().put("name", data.name).put("accent", data.accent).put("songs", songs).put("style", data.style.toJson())
        // ditulis paling akhir: berkas ini penanda bahwa semuanya sudah lengkap
        File(d, "meta.json").writeText(meta.toString())
    }

    fun load(context: Context): PosterData? {
        val d = dir(context)
        val metaFile = File(d, "meta.json")
        if (!metaFile.exists()) return null
        return try {
            val m = JSONObject(metaFile.readText())
            val arr = m.optJSONArray("songs") ?: JSONArray()
            val songs =
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    val cover = if (o.optBoolean("cover")) BitmapFactory.decodeFile(File(d, "cover_$i.jpg").path) else null
                    PosterSong(o.optString("title"), o.optString("artist"), o.optInt("dur"), cover)
                }
            val photo = File(d, "photo.jpg").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            val cutout = File(d, "cutout.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            PosterData(m.optString("name"), photo, cutout, songs, m.optInt("accent", 0xFFE5333A.toInt()), PosterStyle.fromJson(m.optJSONObject("style")))
        } catch (e: Exception) {
            null
        }
    }
}
