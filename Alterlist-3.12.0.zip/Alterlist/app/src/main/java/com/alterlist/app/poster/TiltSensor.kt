package com.alterlist.app.poster

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Kemiringan ponsel -1..1 (x kanan/kiri, y atas/bawah) dari giroskop. Ponsel tanpa giroskop memakai akselerometer,
 * jadi efeknya tetap jalan. Nilai giroskop perlahan kembali ke tengah supaya tidak melayang (drift).
 */
class TiltSensor(context: Context) : SensorEventListener {
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro: Sensor? = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val acc: Sensor? = if (gyro == null) sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) else null

    @Volatile var x = 0f
        private set

    @Volatile var y = 0f
        private set

    val available: Boolean get() = gyro != null || acc != null

    private var lastNs = 0L
    private var baseX = 0f
    private var baseY = 0f
    private var baseSet = false

    fun start() {
        lastNs = 0L
        baseSet = false
        gyro?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        sm.unregisterListener(this)
        x = 0f
        y = 0f
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
            if (lastNs == 0L) {
                lastNs = e.timestamp
                return
            }
            val dt = ((e.timestamp - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
            lastNs = e.timestamp
            val leak = 1f - 1.1f * dt
            x = ((x + e.values[1] * dt * 1.7f) * leak).coerceIn(-1f, 1f)
            y = ((y - e.values[0] * dt * 1.7f) * leak).coerceIn(-1f, 1f)
        } else {
            val ax = e.values[0] / 9.81f
            val ay = e.values[1] / 9.81f
            if (!baseSet) {
                baseX = ax
                baseY = ay
                baseSet = true
            }
            // titik netral ikut bergeser pelan: cara memegang ponsel berubah-ubah
            baseX += (ax - baseX) * 0.01f
            baseY += (ay - baseY) * 0.01f
            x = ((ax - baseX) * 2.4f).coerceIn(-1f, 1f)
            y = ((ay - baseY) * -2.4f).coerceIn(-1f, 1f)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
