package com.alterlist.app.ui

import android.content.res.Configuration
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min

/**
 * Ukuran dan posisi kamera depan (satuan dp). [punch] = kamera "tompel" (lubang bulat, tidak menyatu dengan tepi atas),
 * false = menyatu dengan tepi (poni/notch) atau tidak ada kamera yang terdeteksi.
 */
data class BarCutout(
    val present: Boolean,
    val punch: Boolean,
    val widthDp: Float,
    val heightDp: Float,
    val topDp: Float,
    val bottomDp: Float,
    val offsetDp: Float,
) {
    companion object {
        val None = BarCutout(false, false, 0f, 0f, 8f, 38f, 0f)
    }
}

/** Warna cover dibuat lebih jelas (jenuh dan terang) supaya terlihat di atas latar gelap. */
private fun vivid(c: Color): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(c.toArgb(), hsv)
    hsv[1] = max(hsv[1], 0.62f)
    hsv[2] = max(hsv[2], 0.9f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/**
 * Dynamic bar (ala Dynamic Island) khusus musik. Tertutup: pil kecil melingkari kamera berisi cover dan visualizer.
 * Diketuk (atau lagu berganti): terbuka jadi kartu dengan judul, progres, dan tombol acak / sebelumnya / putar /
 * berikutnya / ulang (loop dan loop 1). Tersembunyi saat Alterlist sedang terbuka atau ponsel dalam mode landscape.
 */
@Composable
fun DynamicBarContent(cutout: BarCutout, onExpandedChange: (Boolean) -> Unit) {
    val app = AlterApp.instance
    val state by app.player.state.collectAsState()
    val foreground by app.appForeground.collectAsState()
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val song = state.current
    val show = song != null && !foreground && !landscape

    var expanded by remember { mutableStateOf(false) }
    var touch by remember { mutableIntStateOf(0) }
    var lastId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(song?.id) {
        val id = song?.id
        if (id != null && lastId != null && lastId != id) {
            expanded = true
            touch++
        }
        lastId = id
    }
    LaunchedEffect(expanded, touch) {
        if (expanded) {
            delay(4500)
            expanded = false
        }
    }
    LaunchedEffect(show) { if (!show) expanded = false }
    LaunchedEffect(expanded, show) { onExpandedChange(expanded && show) }

    if (!show || song == null) return

    val palette = rememberCoverPalette(song.thumbnail)
    val accent = vivid(palette.primary)
    val glass =
        Brush.verticalGradient(
            listOf(
                lerp(Color(0xFF050506), palette.primary, 0.34f).copy(alpha = 0.95f),
                lerp(Color(0xFF050506), palette.secondary, 0.2f).copy(alpha = 0.97f),
            ),
        )

    Crossfade(targetState = expanded, animationSpec = tween(200), label = "dynamicBar") { open ->
        if (!open) {
            val barH = if (cutout.present) max(cutout.heightDp + 10f, 30f).dp else 30.dp
            val gap = if (cutout.present) (cutout.widthDp + 8f).dp else 0.dp
            val side = if (cutout.present) 44.dp else 40.dp
            val flatTop = cutout.present && !cutout.punch
            val shape = if (flatTop) RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp, bottomStart = barH / 2, bottomEnd = barH / 2) else RoundedCornerShape(50)
            Row(
                Modifier
                    .height(barH)
                    .clip(shape)
                    .background(glass)
                    .border(1.dp, Color.White.copy(alpha = 0.16f), shape)
                    .clickable {
                        expanded = true
                        touch++
                    },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.width(side), contentAlignment = Alignment.Center) { Artwork(song.thumbnail, Modifier.size(22.dp), CircleShape, px = 96) }
                Spacer(Modifier.width(gap))
                Box(Modifier.width(side), contentAlignment = Alignment.Center) { MiniBars(accent, state.isPlaying, 14.dp) }
            }
        } else {
            val cardW = min(LocalConfiguration.current.screenWidthDp - 24, 360).dp
            val shape = RoundedCornerShape(30.dp)
            Column(
                Modifier
                    .width(cardW)
                    .clip(shape)
                    .background(glass)
                    .border(1.dp, Color.White.copy(alpha = 0.18f), shape)
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Artwork(song.thumbnail, Modifier.size(54.dp), RoundedCornerShape(12.dp), px = 160)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(song.title, style = T.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, style = T.small, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.width(10.dp))
                    MiniBars(accent, state.isPlaying, 22.dp)
                }
                Spacer(Modifier.height(12.dp))
                val frac = if (state.durationMs > 0) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
                Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f))) {
                    Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(CircleShape).background(accent))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    BarIcon(R.drawable.ic_shuffle, state.shuffle, accent) {
                        app.player.toggleShuffle()
                        touch++
                    }
                    BarIcon(R.drawable.ic_prev, false, accent) {
                        app.player.previous()
                        touch++
                    }
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(Color.White).clickable {
                            app.player.togglePlay()
                            touch++
                        },
                        contentAlignment = Alignment.Center,
                    ) {
                        Ic(if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, tint = Color.Black, size = 26.dp)
                    }
                    BarIcon(R.drawable.ic_next, false, accent) {
                        app.player.next()
                        touch++
                    }
                    BarIcon(
                        if (state.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                        state.repeatMode != Player.REPEAT_MODE_OFF,
                        accent,
                    ) {
                        app.player.cycleRepeat()
                        touch++
                    }
                }
            }
        }
    }
}

@Composable
private fun BarIcon(icon: Int, active: Boolean, accent: Color, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Ic(icon, tint = if (active) accent else Color.White.copy(alpha = 0.92f), size = 22.dp)
    }
}

/** Visualizer kecil: batang naik turun selama lagu diputar, diam saat jeda. Warnanya mengikuti cover. */
@Composable
private fun MiniBars(color: Color, playing: Boolean, height: androidx.compose.ui.unit.Dp) {
    val transition = rememberInfiniteTransition(label = "bars")
    val periods = intArrayOf(430, 560, 380, 510)
    Row(Modifier.height(height), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
        periods.forEachIndexed { i, ms ->
            val level by transition.animateFloat(
                initialValue = 0.28f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(ms, easing = LinearEasing), RepeatMode.Reverse),
                label = "bar$i",
            )
            val h = if (playing) level else 0.28f
            Box(Modifier.width(3.dp).height(height * h).clip(RoundedCornerShape(2.dp)).background(color))
        }
    }
}
