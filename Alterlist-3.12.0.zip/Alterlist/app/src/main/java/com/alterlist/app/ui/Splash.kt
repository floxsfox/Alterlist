package com.alterlist.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Animasi pembuka: logo Alterlist muncul membal, gelombang cahaya merah menyebar dari belakangnya,
 * lalu teks transparan "by Riyan Saputra" menyusul di bawah. Setelah selesai layar memudar dan [onDone] dipanggil.
 */
@Composable
fun LaunchSplash(onDone: () -> Unit) {
    val logoScale = remember { Animatable(0.5f) }
    val logoAlpha = remember { Animatable(0f) }
    val wave = remember { Animatable(0f) }
    val glow = remember { Animatable(0f) }
    val credit = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { logoAlpha.animateTo(1f, tween(420)) }
            launch { logoScale.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = 170f)) }
            launch { glow.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
            launch {
                delay(260)
                wave.animateTo(1f, tween(1200, easing = FastOutSlowInEasing))
            }
            launch {
                delay(950)
                credit.animateTo(0.5f, tween(750))
            }
        }
        delay(500)
        exit.animateTo(0f, tween(380))
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = exit.value }
            .background(AlterColors.Bg)
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(320.dp)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val base = size.minDimension / 2f
            // cahaya lembut di belakang logo
            drawCircle(
                brush = Brush.radialGradient(listOf(AlterColors.Red.copy(alpha = 0.34f * glow.value), Color.Transparent), center = c, radius = base * 0.9f),
                radius = base * 0.9f,
                center = c,
            )
            // gelombang menyebar
            val w = wave.value
            if (w > 0f && w < 1f) {
                val r = base * (0.25f + 0.75f * w)
                drawCircle(AlterColors.Red.copy(alpha = 0.55f * (1f - w)), radius = r, center = c, style = Stroke(width = 2.5.dp.toPx()))
                drawCircle(AlterColors.RedSoft.copy(alpha = 0.25f * (1f - w)), radius = r * 0.78f, center = c, style = Stroke(width = 1.5.dp.toPx()))
            }
        }
        Image(
            painterResource(R.drawable.logo_mark),
            contentDescription = null,
            modifier =
                Modifier.size(112.dp).graphicsLayer {
                    scaleX = logoScale.value
                    scaleY = logoScale.value
                    alpha = logoAlpha.value
                },
        )
        Text(
            "by Riyan Saputra",
            style = T.small.copy(letterSpacing = 1.4.sp),
            color = Color.White,
            modifier =
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 44.dp).graphicsLayer { alpha = credit.value },
        )
    }
}
