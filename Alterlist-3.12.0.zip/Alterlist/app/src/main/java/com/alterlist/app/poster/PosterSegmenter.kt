package com.alterlist.app.poster

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentationResult
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max

/**
 * Memisahkan subjek (manusia, kartun, hewan, benda) dari latar. Pendeteksi dari ML Kit (jalan di ponsel, model diunduh
 * Google Play Services sekali saja) hanya memberi peta keyakinan mentah; di sini dirapikan supaya hasilnya stabil:
 *  1. histeresis   - area yang yakin ("benih") menumbuhkan area yang agak yakin, jadi bagian lemah (tangan, rambut,
 *                    ujung baju) yang menyambung ke tubuh tidak lagi hilang;
 *  2. komponen     - serpihan kecil yang terpisah dibuang, bagian besar yang terpisah tetap dipakai;
 *  3. lubang       - lubang kecil di dalam subjek ditutup;
 *  4. tepi         - topeng dihaluskan lalu diberi ambang halus, hasilnya tepi rata tanpa gerigi.
 */
object PosterSegmenter {
    private const val MAX_SIDE = 1280
    private const val SEED = 0.62f
    private const val GROW = 0.18f

    /** [photo] = foto (sudah diperkecil), [cutout] = subjek ber-alpha dengan ukuran PERSIS sama (tidak dipotong). */
    class Result(val photo: Bitmap, val cutout: Bitmap)

    suspend fun cutout(source: Bitmap): Result {
        val scaled = scaleDown(source)
        val w = scaled.width
        val h = scaled.height
        val conf = confidence(scaled)
        return withContext(Dispatchers.Default) {
            val alpha = refine(conf, w, h)
            Result(scaled, compose(scaled, alpha, w, h))
        }
    }

    private fun scaleDown(src: Bitmap): Bitmap {
        val side = max(src.width, src.height)
        if (side <= MAX_SIDE) return src.copy(Bitmap.Config.ARGB_8888, false)
        val k = MAX_SIDE.toFloat() / side
        return Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
    }

    private suspend fun confidence(bmp: Bitmap): FloatArray {
        val options = SubjectSegmenterOptions.Builder().enableForegroundConfidenceMask().build()
        val segmenter = SubjectSegmentation.getClient(options)
        try {
            val result =
                suspendCancellableCoroutine<SubjectSegmentationResult> { cont ->
                    segmenter.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener { cont.resume(it) }
                        .addOnFailureListener { cont.resumeWithException(it) }
                }
            val buf = result.foregroundConfidenceMask ?: throw IllegalStateException("Subjek tidak terdeteksi")
            val n = bmp.width * bmp.height
            if (buf.remaining() < n) throw IllegalStateException("Ukuran hasil pendeteksi tidak cocok")
            val out = FloatArray(n)
            buf.rewind()
            buf.get(out, 0, n)
            return out
        } finally {
            segmenter.close()
        }
    }

    // ------------------------------------------------------------------ perapian topeng

    private fun refine(conf: FloatArray, w: Int, h: Int): FloatArray {
        val n = w * h
        val stack = IntArray(n)

        // 1. histeresis
        val grown = BooleanArray(n)
        var sp = 0
        for (i in 0 until n) {
            if (conf[i] >= SEED) {
                grown[i] = true
                stack[sp++] = i
            }
        }
        while (sp > 0) {
            val p = stack[--sp]
            val x = p % w
            val y = p / w
            if (x > 0) sp = grow(p - 1, conf, grown, stack, sp)
            if (x < w - 1) sp = grow(p + 1, conf, grown, stack, sp)
            if (y > 0) sp = grow(p - w, conf, grown, stack, sp)
            if (y < h - 1) sp = grow(p + w, conf, grown, stack, sp)
        }

        // 2. buang serpihan kecil
        val (label, areas) = components(grown, w, h, stack)
        var maxArea = 0
        for (k in 1 until areas.size) maxArea = max(maxArea, areas[k])
        val minArea = max((maxArea * 0.03f).toInt(), (n * 0.002f).toInt())
        val fg = BooleanArray(n)
        for (i in 0 until n) {
            val l = label[i]
            fg[i] = l != 0 && areas[l] >= minArea
        }

        // 3. tutup lubang kecil: latar yang tidak tersambung ke tepi gambar
        val outside = BooleanArray(n)
        sp = 0
        fun seed(i: Int) {
            if (!fg[i] && !outside[i]) {
                outside[i] = true
                stack[sp++] = i
            }
        }
        for (x in 0 until w) {
            seed(x)
            seed((h - 1) * w + x)
        }
        for (y in 0 until h) {
            seed(y * w)
            seed(y * w + w - 1)
        }
        while (sp > 0) {
            val p = stack[--sp]
            val x = p % w
            val y = p / w
            if (x > 0) seed(p - 1)
            if (x < w - 1) seed(p + 1)
            if (y > 0) seed(p - w)
            if (y < h - 1) seed(p + w)
        }
        val holes = BooleanArray(n) { !fg[it] && !outside[it] }
        val (holeLabel, holeAreas) = components(holes, w, h, stack)
        val maxHole = (n * 0.04f).toInt()
        for (i in 0 until n) {
            val l = holeLabel[i]
            if (l != 0 && holeAreas[l] <= maxHole) fg[i] = true
        }

        // 4. tepi rata: haluskan topeng biner lalu beri ambang halus
        var f = FloatArray(n) { if (fg[it]) 1f else 0f }
        f = boxBlur(f, w, h, 2)
        f = boxBlur(f, w, h, 2)
        for (i in 0 until n) f[i] = smooth(0.42f, 0.72f, f[i])
        return boxBlur(f, w, h, 1)
    }

    private fun grow(q: Int, conf: FloatArray, grown: BooleanArray, stack: IntArray, sp: Int): Int {
        if (grown[q] || conf[q] < GROW) return sp
        grown[q] = true
        stack[sp] = q
        return sp + 1
    }

    /** Label komponen terhubung (4 arah). label[i] = 0 untuk bukan anggota; areas[k] = jumlah piksel komponen k. */
    private fun components(mask: BooleanArray, w: Int, h: Int, stack: IntArray): Pair<IntArray, IntArray> {
        val n = w * h
        val label = IntArray(n)
        val areas = ArrayList<Int>()
        areas.add(0)
        var next = 1
        for (i in 0 until n) {
            if (!mask[i] || label[i] != 0) continue
            var count = 0
            var sp = 0
            stack[sp++] = i
            label[i] = next
            while (sp > 0) {
                val p = stack[--sp]
                count++
                val x = p % w
                val y = p / w
                if (x > 0 && mask[p - 1] && label[p - 1] == 0) { label[p - 1] = next; stack[sp++] = p - 1 }
                if (x < w - 1 && mask[p + 1] && label[p + 1] == 0) { label[p + 1] = next; stack[sp++] = p + 1 }
                if (y > 0 && mask[p - w] && label[p - w] == 0) { label[p - w] = next; stack[sp++] = p - w }
                if (y < h - 1 && mask[p + w] && label[p + w] == 0) { label[p + w] = next; stack[sp++] = p + w }
            }
            areas.add(count)
            next++
        }
        return label to areas.toIntArray()
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int): FloatArray {
        val tmp = FloatArray(src.size)
        val out = FloatArray(src.size)
        val d = (2 * r + 1).toFloat()
        for (y in 0 until h) {
            val row = y * w
            var acc = 0f
            for (k in -r..r) acc += src[row + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[row + x] = acc / d
                acc += src[row + (x + r + 1).coerceAtMost(w - 1)] - src[row + (x - r).coerceAtLeast(0)]
            }
        }
        for (x in 0 until w) {
            var acc = 0f
            for (k in -r..r) acc += tmp[k.coerceIn(0, h - 1) * w + x]
            for (y in 0 until h) {
                out[y * w + x] = acc / d
                acc += tmp[(y + r + 1).coerceAtMost(h - 1) * w + x] - tmp[(y - r).coerceAtLeast(0) * w + x]
            }
        }
        return out
    }

    private fun compose(src: Bitmap, alpha: FloatArray, w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w
        var minY = h
        var maxX = -1
        var maxY = -1
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val a = (alpha[i] * 255f + 0.5f).toInt().coerceIn(0, 255)
                px[i] = (a shl 24) or (px[i] and 0x00FFFFFF)
                if (a > 25) {
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) throw IllegalStateException("Subjek tidak ditemukan di foto ini")
        val full = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        full.setPixels(px, 0, w, 0, 0, w, h)
        return full
    }
}
