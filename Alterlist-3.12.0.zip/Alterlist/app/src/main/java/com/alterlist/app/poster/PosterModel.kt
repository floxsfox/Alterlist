package com.alterlist.app.poster

import android.graphics.Bitmap
import org.json.JSONObject

/** Susunan kartu lagu di poster (nama dan jumlah sama dengan editor poster Auralys). */
enum class PosterLayout(val label: String) { ORBIT("Orbit"), TUMPUK("Tumpuk"), DERET("Deret"), KOLOM("Kolom") }

/** Bahan kartu kaca. */
enum class CardMaterial(val label: String) { ASAP("Asap"), BENING("Bening"), SUSU("Susu"), GELAP("Gelap") }

/** Warna foto. */
enum class PosterGrade(val label: String) { ASLI("Asli"), HANGAT("Hangat"), DINGIN("Dingin"), NEON("Neon"), FILM("Film") }

/** Paket efek: bloom, bocor cahaya, lens streak, kilau, grain. */
enum class FxPreset(val label: String) { BERSIH("Bersih"), SINEMA("Sinema"), FILM("Film") }

class PosterSong(val title: String, val artist: String, val durationSec: Int, val cover: Bitmap?)

/** Semua pengaturan tampilan poster. Nilai 0..1 kecuali disebut lain. */
class PosterStyle(
    var layout: PosterLayout = PosterLayout.ORBIT,
    var material: CardMaterial = CardMaterial.ASAP,
    var grade: PosterGrade = PosterGrade.ASLI,
    var fx: FxPreset = FxPreset.SINEMA,
    var blur: Float = 0.15f,
    var dim: Float = 0.2f,
    var glow: Float = 0.5f,
    var frost: Float = 0.5f,
    var corner: Float = 0.5f,
    var perspective: Float = 0.55f,
    var cardSize: Float = 0.5f,
    /** Zoom foto 1..2. */
    var zoom: Float = 1f,
) {
    /** Kunci untuk cache latar: hanya yang mengubah latar. */
    fun baseKey(): String = "$grade|$blur|$dim|$glow|$zoom"

    fun toJson(): JSONObject =
        JSONObject()
            .put("layout", layout.name).put("material", material.name).put("grade", grade.name).put("fx", fx.name)
            .put("blur", blur.toDouble()).put("dim", dim.toDouble()).put("glow", glow.toDouble())
            .put("frost", frost.toDouble()).put("corner", corner.toDouble()).put("perspective", perspective.toDouble())
            .put("cardSize", cardSize.toDouble()).put("zoom", zoom.toDouble())

    companion object {
        fun fromJson(j: JSONObject?): PosterStyle {
            if (j == null) return PosterStyle()
            fun <T : Enum<T>> en(values: Array<T>, key: String, def: T): T = values.firstOrNull { it.name == j.optString(key) } ?: def
            return PosterStyle(
                layout = en(PosterLayout.entries.toTypedArray(), "layout", PosterLayout.ORBIT),
                material = en(CardMaterial.entries.toTypedArray(), "material", CardMaterial.ASAP),
                grade = en(PosterGrade.entries.toTypedArray(), "grade", PosterGrade.ASLI),
                fx = en(FxPreset.entries.toTypedArray(), "fx", FxPreset.SINEMA),
                blur = j.optDouble("blur", 0.15).toFloat(),
                dim = j.optDouble("dim", 0.2).toFloat(),
                glow = j.optDouble("glow", 0.5).toFloat(),
                frost = j.optDouble("frost", 0.5).toFloat(),
                corner = j.optDouble("corner", 0.5).toFloat(),
                perspective = j.optDouble("perspective", 0.55).toFloat(),
                cardSize = j.optDouble("cardSize", 0.5).toFloat(),
                zoom = j.optDouble("zoom", 1.0).toFloat().coerceIn(1f, 2f),
            )
        }
    }
}

/**
 * Isi poster. [photo] adalah foto latar, [cutout] subjek yang sudah dipisah dengan ukuran PERSIS sama dengan foto
 * (supaya subjek tepat menimpa foto dan kartu bisa terselip di antara keduanya).
 */
class PosterData(
    val name: String,
    val photo: Bitmap?,
    val cutout: Bitmap?,
    val songs: List<PosterSong>,
    val accent: Int,
    val style: PosterStyle,
)
