package com.alterlist.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Gaya tampilan aplikasi (menu Setelan > Visualy).
 *  - [ALTERLIST]: UI asli Alterlist (bawaan).
 *  - [LIQUID]: tema kaca cair, mengikuti model mini player liquid glass.
 *  - [METROLIST]: UI Material 3 bawaan Google (navigasi pil, kartu tonal, font sistem).
 *  - [ALDER]: UI buatan sendiri yang lebih premium dan profesional (tinta gelap + emas champagne, garis tipis).
 */
enum class UiStyle(val key: String, val label: String, val desc: String) {
    ALTERLIST("alterlist", "Alterlist UI", "Tampilan asli Alterlist. Merah, gelap, dan tegas. Ini bawaan."),
    LIQUID("liquid", "Liquid UI", "Tema kaca cair: panel tembus pandang, tepi mengilap, bar bawah melayang seperti mini player."),
    METROLIST("metrolist", "Metrolist UI", "Gaya Material 3 bawaan Google: font sistem, bar navigasi dengan indikator pil, kartu tonal."),
    ALDER("alder", "Alder UI", "Tampilan premium dan profesional buatan sendiri: hitam tinta, aksen emas champagne, garis tipis rapi."),
    ;

    companion object {
        fun from(key: String?): UiStyle = entries.firstOrNull { it.key == key } ?: ALTERLIST
    }
}

/**
 * Gaya yang sedang dipakai. Berupa state Compose supaya seluruh layar otomatis menggambar ulang begitu gaya diganti,
 * tanpa perlu membuka ulang aplikasi. Diisi saat [AppSettings] dibuat dan saat [AppSettings.setUiStyle] dipanggil.
 */
object UiStyleState {
    var current: UiStyle by mutableStateOf(UiStyle.ALTERLIST)
}
