package com.alterlist.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.data.UiStyle

/** Satu tab di bar bawah. */
class NavSpec(val label: String, @DrawableRes val icon: Int, @DrawableRes val iconActive: Int)

/** Panel kaca "frosted": gradasi putih tipis + garis tepi mengilap. Dipakai gaya Liquid UI untuk bar bawah dan kartu. */
fun Modifier.glassPanel(shape: Shape, strength: Float = 1f): Modifier =
    this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.13f * strength), Color.White.copy(alpha = 0.05f * strength)),
            ),
        )
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = 0.55f),
                    Color.White.copy(alpha = 0.06f),
                    Color.White.copy(alpha = 0.18f),
                    Color.White.copy(alpha = 0.40f),
                ),
            ),
            shape,
        )

/** Latar kartu untuk kategori Setelan dan sejenisnya, mengikuti gaya aktif. Alterlist UI = tanpa latar (daftar polos). */
fun Modifier.skinCard(): Modifier {
    val shape = RoundedCornerShape(Skin.cardCorner)
    return when (Skin.style) {
        UiStyle.ALTERLIST -> this
        UiStyle.LIQUID -> this.glassPanel(shape, strength = 0.9f)
        UiStyle.METROLIST -> this.clip(shape).background(Color(0xFF211F26))
        UiStyle.ALDER ->
            this
                .clip(shape)
                .background(AlterColors.Surface)
                .border(1.dp, AlterColors.Divider, shape)
    }
}

/** Bar navigasi bawah. [selected] = indeks tab aktif, atau -1 bila sedang membuka halaman di atas tab. */
@Composable
fun SkinNavBar(items: List<NavSpec>, selected: Int, onSelect: (Int) -> Unit) {
    when (Skin.style) {
        UiStyle.ALTERLIST -> ClassicNav(items, selected, onSelect)
        UiStyle.LIQUID -> LiquidNav(items, selected, onSelect)
        UiStyle.METROLIST -> MaterialNav(items, selected, onSelect)
        UiStyle.ALDER -> AlderNav(items, selected, onSelect)
    }
}

@Composable
private fun ClassicNav(items: List<NavSpec>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().navigationBarsPadding().height(58.dp)) {
        items.forEachIndexed { i, t ->
            val on = selected == i
            Column(
                Modifier.weight(1f).fillMaxSize().noRippleClickable { onSelect(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                // diredupkan sedikit supaya menyatu dengan fade di belakangnya
                val tint = if (on) Color.White.copy(alpha = 0.88f) else AlterColors.Sub.copy(alpha = 0.58f)
                Ic(if (on) t.iconActive else t.icon, tint = tint, size = 25.dp)
                Spacer(Modifier.height(3.dp))
                Text(t.label, style = T.tiny, color = tint)
            }
        }
    }
}

/** Liquid UI: kapsul kaca melayang, tab aktif mendapat kapsul kaca kedua yang lebih terang. */
@Composable
private fun LiquidNav(items: List<NavSpec>, selected: Int, onSelect: (Int) -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 22.dp, vertical = 6.dp)) {
        Row(
            Modifier.fillMaxWidth().height(60.dp).glassPanel(RoundedCornerShape(30.dp)).padding(5.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEachIndexed { i, t ->
                val on = selected == i
                val tint by animateColorAsState(if (on) AlterColors.Red else AlterColors.Sub.copy(alpha = 0.78f), tween(200), label = "liquidNavTint")
                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .then(if (on) Modifier.glassPanel(RoundedCornerShape(25.dp), strength = 1.6f) else Modifier)
                        .noRippleClickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Ic(if (on) t.iconActive else t.icon, tint = tint, size = 23.dp)
                    Spacer(Modifier.height(2.dp))
                    Text(t.label, style = T.tiny.copy(fontWeight = if (on) FontWeight.Bold else FontWeight.Medium), color = tint)
                }
            }
        }
    }
}

/** Metrolist UI: NavigationBar Material 3 (indikator pil di belakang ikon aktif, label di bawahnya). */
@Composable
private fun MaterialNav(items: List<NavSpec>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF211F26)).navigationBarsPadding().height(72.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items.forEachIndexed { i, t ->
            val on = selected == i
            val pill by animateColorAsState(if (on) Color(0xFF4A4458) else Color.Transparent, tween(220), label = "m3Pill")
            val tint by animateColorAsState(if (on) Color(0xFFE8DEF8) else AlterColors.Sub, tween(220), label = "m3Tint")
            Column(
                Modifier.weight(1f).fillMaxSize().noRippleClickable { onSelect(i) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(Modifier.size(width = 64.dp, height = 32.dp).clip(RoundedCornerShape(16.dp)).background(pill), contentAlignment = Alignment.Center) {
                    Ic(if (on) t.iconActive else t.icon, tint = tint, size = 24.dp)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    t.label,
                    style = T.tiny.copy(fontSize = 12.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium),
                    color = if (on) Color(0xFFE6E0E9) else AlterColors.Sub,
                )
            }
        }
    }
}

/** Alder UI: bar tipis dengan garis atas halus, garis emas pendek di atas tab aktif. */
@Composable
private fun AlderNav(items: List<NavSpec>, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().background(AlterColors.Bg)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, AlterColors.Red.copy(alpha = 0.45f), Color.Transparent))))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().height(60.dp)) {
            items.forEachIndexed { i, t ->
                val on = selected == i
                val tint by animateColorAsState(if (on) AlterColors.Red else AlterColors.Muted, tween(220), label = "alderTint")
                Column(
                    Modifier.weight(1f).fillMaxSize().noRippleClickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .width(22.dp)
                            .height(2.dp)
                            .clip(RoundedCornerShape(1.dp))
                            .background(if (on) AlterColors.Red else Color.Transparent),
                    )
                    Spacer(Modifier.weight(1f))
                    Ic(if (on) t.iconActive else t.icon, tint = tint, size = 23.dp)
                    Spacer(Modifier.height(3.dp))
                    Text(t.label, style = T.tiny.copy(fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp), color = tint)
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/**
 * Wadah mini player sesuai gaya: kaca cair (Alterlist & Liquid), kartu tonal Material 3 (Metrolist),
 * atau kartu gelap berbingkai emas tipis (Alder).
 */
@Composable
fun MiniPlayerSurface(
    backdrop: BackdropState,
    palette: CoverPalette,
    modifier: Modifier,
    light: () -> Float,
    content: @Composable BoxScope.() -> Unit,
) {
    val corner = Skin.miniPlayerCorner
    val shape = RoundedCornerShape(corner)
    when (Skin.style) {
        UiStyle.ALTERLIST, UiStyle.LIQUID -> LiquidGlass(state = backdrop, modifier = modifier, palette = palette, shape = shape, corner = corner, light = light, content = content)
        UiStyle.METROLIST -> Box(modifier.clip(shape).background(Color(0xFF2B2930)), content = content)
        UiStyle.ALDER ->
            Box(
                modifier
                    .clip(shape)
                    .background(Brush.verticalGradient(listOf(AlterColors.Surface2, AlterColors.Surface)))
                    .border(1.dp, Brush.verticalGradient(listOf(AlterColors.Red.copy(alpha = 0.55f), AlterColors.Red.copy(alpha = 0.10f))), shape),
                content = content,
            )
    }
}
