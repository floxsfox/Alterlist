package com.alterlist.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.playback.PlayerUiState
import kotlinx.coroutines.launch

/**
 * Mini player kaca ("liquid glass"): warna mengikuti metadata cover lagu, cover di-blur sebagai dasar,
 * cahaya bergerak saat musik diputar. Geser kiri/kanan untuk ganti lagu, ketuk untuk membuka pemutar penuh.
 */
@Composable
fun MiniPlayer(state: PlayerUiState, backdrop: BackdropState, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val app = AlterApp.instance
    val song = state.current ?: return
    val lib by app.library.data.collectAsState()
    val liked = lib.liked.any { it.id == song.id }
    val palette = rememberCoverPalette(song.thumbnail)
    val progress = if (state.durationMs > 0L) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f

    var dragX by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }
    val offsetX by animateFloatAsState(
        targetValue = dragX,
        animationSpec = if (dragging) snap() else spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
        label = "miniDrag",
    )
    val artScale by animateFloatAsState(
        targetValue = if (state.isPlaying) 1f else 0.9f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "miniArt",
    )

    MiniPlayerSurface(
        backdrop = backdrop,
        modifier =
            modifier
                .fillMaxWidth()
                .graphicsLayer { translationX = offsetX * 0.45f }
                .pointerInput(Unit) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = {
                            total = 0f
                            dragging = true
                        },
                        onDragEnd = {
                            if (total < -110f) app.player.next() else if (total > 110f) app.player.previous()
                            total = 0f
                            dragging = false
                            dragX = 0f
                        },
                        onDragCancel = {
                            total = 0f
                            dragging = false
                            dragX = 0f
                        },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            total += dx
                            dragX = total
                        },
                    )
                }
                .clickable(onClick = onOpen),
        palette = palette,
        light = { (offsetX / 260f).coerceIn(-1f, 1f) },
    ) {
        Column {
            Row(
                Modifier.padding(start = 10.dp, end = 6.dp, top = 9.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(
                    song.thumbnail,
                    Modifier.size(46.dp).graphicsLayer {
                        scaleX = artScale
                        scaleY = artScale
                    },
                    RoundedCornerShape(if (Skin.isMaterial) 8.dp else if (Skin.isAlder) 10.dp else 12.dp),
                )
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        style = T.body.copy(fontWeight = FontWeight.SemiBold),
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SongTags(song, gap = 4.dp)
                        Text(song.artist, style = T.small, color = Color.White.copy(alpha = 0.78f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                LikeButton(
                    liked = liked,
                    onClick = {
                        val nowLiked = app.library.toggleLike(song)
                        if (song.isYoutube) app.scope.launch { app.yt.likeOnAccount(song.id, nowLiked) }
                    },
                    size = 24.dp,
                    box = 42.dp,
                )
                // Metrolist & Alder: tombol putar terisi warna aksen. Alterlist & Liquid: lingkaran kaca.
                val filledPlay = Skin.isMaterial || Skin.isAlder
                val playInk = if (filledPlay) AlterColors.OnAccent else Color.White
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .then(
                            if (filledPlay) {
                                Modifier.background(AlterColors.Red)
                            } else {
                                Modifier
                                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.12f))))
                                    .border(1.dp, Color.White.copy(alpha = 0.40f), CircleShape)
                            },
                        )
                        .clickable { app.player.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    if (state.isBuffering && !state.isPlaying) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = playInk, strokeWidth = 2.dp)
                    } else {
                        Crossfade(targetState = state.isPlaying, label = "miniPlayPause") { playing ->
                            Ic(if (playing) R.drawable.ic_pause else R.drawable.ic_play, tint = playInk, size = 24.dp)
                        }
                    }
                }
                Spacer(Modifier.width(4.dp))
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (Skin.isMaterial) AlterColors.Surface3 else if (Skin.isAlder) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.22f)),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress)
                        .height(3.dp)
                        .background(
                            when {
                                Skin.isMaterial -> Brush.horizontalGradient(listOf(AlterColors.Red, AlterColors.Red))
                                Skin.isAlder -> Brush.horizontalGradient(listOf(AlterColors.Red, AlterColors.RedSoft))
                                else -> Brush.horizontalGradient(listOf(Color.White, lerp(palette.secondary, Color.White, 0.6f)))
                            },
                        ),
                )
            }
        }
    }
}
