package com.alterlist.app.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.alterlist.app.data.UiStyle
import com.alterlist.app.data.UiStyleState
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.alterlist.app.R

/** Satu set warna + font untuk satu gaya tampilan (Visualy). */
@Immutable
class Palette(
    val accent: Color,
    val accentSoft: Color,
    /** Warna isi (teks / ikon) di atas [accent]. */
    val onAccent: Color,
    val bg: Color,
    val surface: Color,
    val surface2: Color,
    val surface3: Color,
    val sub: Color,
    val muted: Color,
    val divider: Color,
    val useSystemFont: Boolean = false,
)

object Palettes {
    val Alterlist =
        Palette(
            accent = Color(0xFFFA0107), accentSoft = Color(0xFFFF4A50), onAccent = Color.White,
            bg = Color(0xFF0C0C0D), surface = Color(0xFF171718), surface2 = Color(0xFF242426), surface3 = Color(0xFF303033),
            sub = Color(0xFFB3B3B3), muted = Color(0xFF7C7C80), divider = Color(0xFF2A2A2D),
        )

    /** Kaca cair: biru-hitam dalam dengan aksen biru es. */
    val Liquid =
        Palette(
            accent = Color(0xFF58A9FF), accentSoft = Color(0xFF9CCBFF), onAccent = Color(0xFF04172E),
            bg = Color(0xFF05060A), surface = Color(0xFF0E1119), surface2 = Color(0xFF171B27), surface3 = Color(0xFF232838),
            sub = Color(0xFFB9C0D0), muted = Color(0xFF7A8296), divider = Color(0xFF1C2130),
        )

    /** Material 3 baseline (gelap) + font sistem. */
    val Metrolist =
        Palette(
            accent = Color(0xFFD0BCFF), accentSoft = Color(0xFFEADDFF), onAccent = Color(0xFF381E72),
            bg = Color(0xFF141218), surface = Color(0xFF1D1B20), surface2 = Color(0xFF2B2930), surface3 = Color(0xFF36343B),
            sub = Color(0xFFCAC4D0), muted = Color(0xFF938F99), divider = Color(0xFF49454F),
            useSystemFont = true,
        )

    /** Premium: hitam tinta dengan emas champagne. */
    val Alder =
        Palette(
            accent = Color(0xFFD8B26A), accentSoft = Color(0xFFEBCF98), onAccent = Color(0xFF1B1405),
            bg = Color(0xFF0A0B0E), surface = Color(0xFF121419), surface2 = Color(0xFF1A1D24), surface3 = Color(0xFF262A33),
            sub = Color(0xFFAAB0BC), muted = Color(0xFF6E7482), divider = Color(0xFF22262E),
        )

    fun of(style: UiStyle): Palette =
        when (style) {
            UiStyle.ALTERLIST -> Alterlist
            UiStyle.LIQUID -> Liquid
            UiStyle.METROLIST -> Metrolist
            UiStyle.ALDER -> Alder
        }
}

/**
 * Warna aplikasi. Semua nilai dibaca dari palet gaya yang sedang aktif ([UiStyleState]); karena itu state Compose,
 * mengganti gaya di Setelan > Visualy langsung menggambar ulang seluruh layar. Nama "Red" dipertahankan: itu warna aksen
 * (merah di Alterlist UI, biru es di Liquid, ungu Material di Metrolist, emas di Alder).
 */
object AlterColors {
    private val p: Palette get() = Palettes.of(UiStyleState.current)
    val Red: Color get() = p.accent
    val RedSoft: Color get() = p.accentSoft
    val OnAccent: Color get() = p.onAccent
    val Bg: Color get() = p.bg
    val Surface: Color get() = p.surface
    val Surface2: Color get() = p.surface2
    val Surface3: Color get() = p.surface3
    val Sub: Color get() = p.sub
    val Muted: Color get() = p.muted
    val Divider: Color get() = p.divider
}

/** Bentuk khas tiap gaya, dipakai komponen yang menyesuaikan diri (bar bawah, mini player, kartu setelan). */
object Skin {
    val style: UiStyle get() = UiStyleState.current
    val isLiquid: Boolean get() = style == UiStyle.LIQUID
    val isMaterial: Boolean get() = style == UiStyle.METROLIST
    val isAlder: Boolean get() = style == UiStyle.ALDER
    val isClassic: Boolean get() = style == UiStyle.ALTERLIST

    val miniPlayerCorner: Dp
        get() =
            when (style) {
                UiStyle.METROLIST -> 16.dp
                UiStyle.ALDER -> 18.dp
                else -> 26.dp
            }
    val cardCorner: Dp
        get() =
            when (style) {
                UiStyle.METROLIST -> 16.dp
                UiStyle.ALDER -> 14.dp
                UiStyle.LIQUID -> 22.dp
                else -> 12.dp
            }
}

val Figtree =
    FontFamily(
        Font(R.font.figtree_regular, FontWeight.Normal),
        Font(R.font.figtree_medium, FontWeight.Medium),
        Font(R.font.figtree_semibold, FontWeight.SemiBold),
        Font(R.font.figtree_bold, FontWeight.Bold),
    )

private class TextSet(font: FontFamily) {
    val screen = TextStyle(fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 28.sp, letterSpacing = (-0.4).sp)
    val section = TextStyle(fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 21.sp, letterSpacing = (-0.2).sp)
    val title = TextStyle(fontFamily = font, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    val body = TextStyle(fontFamily = font, fontWeight = FontWeight.Medium, fontSize = 14.sp)
    val small = TextStyle(fontFamily = font, fontWeight = FontWeight.Medium, fontSize = 13.sp)
    val tiny = TextStyle(fontFamily = font, fontWeight = FontWeight.Medium, fontSize = 11.sp)
    val button = TextStyle(fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    val hero = TextStyle(fontFamily = font, fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = (-0.3).sp)
}

private val FigtreeSet by lazy { TextSet(Figtree) }
private val SystemSet by lazy { TextSet(FontFamily.Default) }

/** Gaya teks Alterlist: Figtree, kecuali Metrolist UI yang memakai font sistem (Roboto / Google Sans). */
object T {
    private val set: TextSet get() = if (Palettes.of(UiStyleState.current).useSystemFont) SystemSet else FigtreeSet
    val screen: TextStyle get() = set.screen
    val section: TextStyle get() = set.section
    val title: TextStyle get() = set.title
    val body: TextStyle get() = set.body
    val small: TextStyle get() = set.small
    val tiny: TextStyle get() = set.tiny
    val button: TextStyle get() = set.button
    val hero: TextStyle get() = set.hero
}

@Composable
fun AlterTheme(content: @Composable () -> Unit) {
    val style = UiStyleState.current
    val colors =
        when (style) {
            UiStyle.METROLIST ->
                darkColorScheme(
                    primary = AlterColors.Red,
                    onPrimary = AlterColors.OnAccent,
                    primaryContainer = Color(0xFF4F378B),
                    onPrimaryContainer = Color(0xFFEADDFF),
                    secondaryContainer = Color(0xFF4A4458),
                    onSecondaryContainer = Color(0xFFE8DEF8),
                    background = AlterColors.Bg,
                    onBackground = Color(0xFFE6E0E9),
                    surface = AlterColors.Surface,
                    onSurface = Color(0xFFE6E0E9),
                    surfaceVariant = AlterColors.Surface2,
                    onSurfaceVariant = AlterColors.Sub,
                    outline = AlterColors.Muted,
                    outlineVariant = AlterColors.Divider,
                    error = Color(0xFFF2B8B5),
                )
            UiStyle.ALTERLIST ->
                darkColorScheme(
                    primary = AlterColors.Red,
                    onPrimary = Color.White,
                    background = AlterColors.Bg,
                    onBackground = Color.White,
                    surface = AlterColors.Surface,
                    onSurface = Color.White,
                    surfaceVariant = AlterColors.Surface2,
                    onSurfaceVariant = AlterColors.Sub,
                    error = AlterColors.RedSoft,
                )
            else ->
                darkColorScheme(
                    primary = AlterColors.Red,
                    onPrimary = AlterColors.OnAccent,
                    background = AlterColors.Bg,
                    onBackground = Color.White,
                    surface = AlterColors.Surface,
                    onSurface = Color.White,
                    surfaceVariant = AlterColors.Surface2,
                    onSurfaceVariant = AlterColors.Sub,
                    outline = AlterColors.Muted,
                    outlineVariant = AlterColors.Divider,
                    error = Color(0xFFFF6B6B),
                )
        }
    val shapes =
        if (style == UiStyle.METROLIST) {
            Shapes(
                extraSmall = RoundedCornerShape(4.dp),
                small = RoundedCornerShape(8.dp),
                medium = RoundedCornerShape(12.dp),
                large = RoundedCornerShape(16.dp),
                extraLarge = RoundedCornerShape(28.dp),
            )
        } else {
            Shapes()
        }
    MaterialTheme(colorScheme = colors, shapes = shapes) {
        CompositionLocalProvider(
            LocalContentColor provides if (style == UiStyle.METROLIST) Color(0xFFE6E0E9) else Color.White,
            LocalTextStyle provides T.body,
            content = content,
        )
    }
}
