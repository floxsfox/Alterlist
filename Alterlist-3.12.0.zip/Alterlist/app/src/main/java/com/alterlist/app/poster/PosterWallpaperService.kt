package com.alterlist.app.poster

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder

/** Wallpaper hidup "Poster 3D playlist": adegan yang sama dengan pratinjau, bergerak mengikuti giroskop. */
class PosterWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = PosterEngine()

    private inner class PosterEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val tilt = TiltSensor(this@PosterWallpaperService)
        private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(170, 255, 255, 255) }
        private var renderer: PosterRenderer? = null
        private var loadedVersion = -1L
        private var visible = false
        private var w = 0
        private var h = 0
        private var sx = 0f
        private var sy = 0f
        private var startMs = 0L

        private val frame =
            object : Runnable {
                override fun run() {
                    draw()
                    if (visible) handler.postDelayed(this, 33L)
                }
            }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            startMs = System.currentTimeMillis()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width
            h = height
            draw()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            handler.removeCallbacks(frame)
            if (visible) {
                reloadIfChanged()
                tilt.start()
                handler.post(frame)
            } else {
                tilt.stop()
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(frame)
            tilt.stop()
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(frame)
            tilt.stop()
            super.onDestroy()
        }

        private fun reloadIfChanged() {
            val v = PosterStore.version(this@PosterWallpaperService)
            if (v == loadedVersion && (renderer != null || v == 0L)) return
            loadedVersion = v
            renderer = PosterStore.load(this@PosterWallpaperService)?.let { PosterRenderer(it) }
        }

        private fun lock(holder: SurfaceHolder): Canvas? =
            try {
                holder.lockHardwareCanvas()
            } catch (e: Exception) {
                try {
                    holder.lockCanvas()
                } catch (e2: Exception) {
                    null
                }
            }

        private fun draw() {
            if (w <= 0 || h <= 0) return
            val holder = surfaceHolder
            val canvas = lock(holder) ?: return
            try {
                val r = renderer
                if (r == null) {
                    canvas.drawColor(0xFF0C0C0D.toInt())
                    hint.textSize = w * 0.04f
                    val msg = "Buat poster 3D di Alterlist lebih dulu"
                    canvas.drawText(msg, w / 2f - hint.measureText(msg) / 2f, h / 2f, hint)
                } else {
                    sx += (tilt.x - sx) * 0.18f
                    sy += (tilt.y - sy) * 0.18f
                    val t = (System.currentTimeMillis() - startMs) / 1000f
                    r.draw(canvas, w, h, sx, sy, t)
                }
            } finally {
                try {
                    holder.unlockCanvasAndPost(canvas)
                } catch (e: Exception) {
                    // permukaan sudah hilang
                }
            }
        }
    }
}
