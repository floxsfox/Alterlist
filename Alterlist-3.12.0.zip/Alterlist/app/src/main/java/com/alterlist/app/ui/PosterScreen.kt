package com.alterlist.app.ui

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.Canvas as ComposeCanvas
import coil3.compose.AsyncImage
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.LibraryData
import com.alterlist.app.data.LocalArt
import com.alterlist.app.data.Net
import com.alterlist.app.data.withSize
import com.alterlist.app.poster.CardMaterial
import com.alterlist.app.poster.FxPreset
import com.alterlist.app.poster.PosterData
import com.alterlist.app.poster.PosterGrade
import com.alterlist.app.poster.PosterLayout
import com.alterlist.app.poster.PosterSong
import com.alterlist.app.poster.PosterStyle
import com.alterlist.app.poster.PosterRenderer
import com.alterlist.app.poster.PosterSegmenter
import com.alterlist.app.poster.PosterStore
import com.alterlist.app.poster.PosterWallpaperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.math.max
import kotlin.math.min

/** Poster / wallpaper hidup "playlist 3D": sampul playlist berputar 3D, subjek dari fotomu di tengah. */
@Composable
fun PosterScreen(onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        PosterContent(onClose)
    }
}

@Composable
private fun PosterContent(onClose: () -> Unit) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lib by app.library.data.collectAsState()
    var sourceId by remember { mutableStateOf<String?>(null) } // null = Lagu disukai
    var count by remember { mutableIntStateOf(4) }
    var photo by remember { mutableStateOf<Uri?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var poster by remember { mutableStateOf<PosterData?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) photo = uri }

    Column(
        Modifier.fillMaxSize().background(AlterColors.Bg).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_close, onClose)
            Text("Poster lagu 3D", style = T.hero, modifier = Modifier.padding(start = 4.dp))
        }
        Text(
            "Fotomu jadi latar, kartu lagu kaca melayang di antara latar dan dirimu, lalu subjek dipisah dari latar supaya menimpa kartu. Simpan sebagai poster, atau pasang jadi wallpaper hidup yang bergerak mengikuti giroskop.",
            style = T.small,
            color = AlterColors.Sub,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )

        Text("Playlist", style = T.title, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { AlterChip("Lagu disukai (${lib.liked.size})", sourceId == null, { sourceId = null }) }
            items(lib.playlists, key = { it.id }) { pl -> AlterChip("${pl.name} (${pl.songs.size})", sourceId == pl.id, { sourceId = pl.id }) }
        }

        ChipRow("Jumlah kartu", listOf(3, 4, 5), count, { "$it lagu" }) { count = it }

        Text("Foto", style = T.title, modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(64.dp).clip(RoundedCornerShape(10.dp)).background(AlterColors.Surface2), contentAlignment = Alignment.Center) {
                val p = photo
                if (p == null) {
                    Ic(R.drawable.ic_user, tint = AlterColors.Muted, size = 26.dp)
                } else {
                    AsyncImage(model = p, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                PillButton(
                    if (photo == null) "Pilih foto" else "Ganti foto",
                    { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    container = AlterColors.Surface3,
                )
                if (photo != null) {
                    Text(
                        "Hapus foto",
                        style = T.small,
                        color = AlterColors.RedSoft,
                        modifier = Modifier.clickable { photo = null }.padding(top = 8.dp, start = 4.dp),
                    )
                }
            }
        }
        Text(
            "Pemisah subjek memakai Google Play Services (model diunduh sekali, lalu jalan di ponsel). Foto setengah badan dengan latar yang jelas hasilnya paling rapi.",
            style = T.tiny,
            color = AlterColors.Muted,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )

        PillButton(
            if (poster == null) "Buat poster" else "Buat ulang",
            {
                if (busy == null) {
                    scope.launch {
                        try {
                            poster = null
                            poster = buildPoster(context, lib, sourceId, photo, count, { busy = it }, { context.toast(it) })
                        } catch (e: Exception) {
                            context.toast(e.message ?: "Gagal membuat poster")
                        }
                        busy = null
                    }
                }
            },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        )

        busy?.let { msg ->
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator(color = AlterColors.Red, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Text(msg, style = T.body, color = AlterColors.Sub)
            }
        }

        poster?.let { data ->
            val dm = context.resources.displayMetrics
            val st = remember(tick) { data.style }
            fun tweak(block: PosterStyle.() -> Unit) {
                data.style.block()
                tick++
            }
            Text("Pratinjau", style = T.title, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp))
            Text("Miringkan ponsel atau geser jarimu untuk menggerakkan kartu.", style = T.small, color = AlterColors.Sub, modifier = Modifier.padding(horizontal = 16.dp))
            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                PosterPreview(
                    data,
                    Modifier.fillMaxWidth(0.78f).aspectRatio(dm.widthPixels.toFloat() / dm.heightPixels).clip(RoundedCornerShape(18.dp)),
                )
            }

            ChipRow("Susunan kartu", PosterLayout.entries.toList(), st.layout, { it.label }) { tweak { layout = it } }
            ChipRow("Bahan kartu", CardMaterial.entries.toList(), st.material, { it.label }) { tweak { material = it } }
            ChipRow("Warna foto", PosterGrade.entries.toList(), st.grade, { it.label }) { tweak { grade = it } }
            ChipRow("Efek", FxPreset.entries.toList(), st.fx, { it.label }) { tweak { fx = it } }

            Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                PosterSlider("Blur latar", st.blur) { tweak { blur = it } }
                PosterSlider("Redup", st.dim) { tweak { dim = it } }
                PosterSlider("Cahaya warna", st.glow) { tweak { glow = it } }
                PosterSlider("Zoom foto", st.zoom - 1f) { tweak { zoom = 1f + it } }
                PosterSlider("Ukuran kartu", st.cardSize) { tweak { cardSize = it } }
                PosterSlider("Sudut kartu", st.corner) { tweak { corner = it } }
                PosterSlider("Kaca (frost)", st.frost) { tweak { frost = it } }
                PosterSlider("Perspektif 3D", st.perspective) { tweak { perspective = it } }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(
                    "Simpan poster",
                    {
                        scope.launch {
                            val ok = savePng(context, data)
                            context.toast(if (ok) "Poster disimpan di Gambar/Alterlist" else "Gagal menyimpan poster")
                        }
                    },
                    Modifier.weight(1f),
                    container = AlterColors.Surface3,
                )
                PillButton(
                    "Wallpaper hidup",
                    {
                        scope.launch {
                            withContext(Dispatchers.IO) { PosterStore.save(context, data) }
                            openLiveWallpaper(context)
                        }
                    },
                    Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun <E> ChipRow(title: String, options: List<E>, selected: E, label: (E) -> String, onPick: (E) -> Unit) {
    Text(title, style = T.title, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp))
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { opt -> AlterChip(label(opt), opt == selected, { onPick(opt) }) }
    }
}

@Composable
private fun PosterSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    EffectSlider(label, "${(value.coerceIn(0f, 1f) * 100).toInt()}%", value, onChange)
}

/** Pratinjau hidup: kemiringan dari giroskop; tanpa sensor (atau sambil menyentuh) memakai geseran jari. */
@Composable
private fun PosterPreview(data: PosterData, modifier: Modifier) {
    val context = LocalContext.current
    val renderer = remember(data) { PosterRenderer(data) }
    val tilt = remember { com.alterlist.app.poster.TiltSensor(context) }
    DisposableEffect(Unit) {
        tilt.start()
        onDispose { tilt.stop() }
    }
    var t by remember { mutableFloatStateOf(0f) }
    var sx by remember { mutableFloatStateOf(0f) }
    var sy by remember { mutableFloatStateOf(0f) }
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    var dragging by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val start = androidx.compose.runtime.withFrameNanos { it }
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                t = (now - start) / 1_000_000_000f
                if (!dragging) {
                    dragX *= 0.93f
                    dragY *= 0.93f
                }
                val targetX = (tilt.x + dragX).coerceIn(-1f, 1f)
                val targetY = (tilt.y + dragY).coerceIn(-1f, 1f)
                sx += (targetX - sx) * 0.18f
                sy += (targetY - sy) * 0.18f
            }
        }
    }
    ComposeCanvas(
        modifier.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { dragging = true },
                onDragEnd = { dragging = false },
                onDragCancel = { dragging = false },
                onDrag = { change, delta ->
                    change.consume()
                    dragX = (dragX + delta.x / 260f).coerceIn(-1f, 1f)
                    dragY = (dragY + delta.y / 360f).coerceIn(-1f, 1f)
                },
            )
        },
    ) {
        drawIntoCanvas { c -> renderer.draw(c.nativeCanvas, size.width.toInt(), size.height.toInt(), sx, sy, t) }
    }
}

// ---------------------------------------------------------------------- bahan poster

private suspend fun buildPoster(
    context: Context,
    lib: LibraryData,
    sourceId: String?,
    photoUri: Uri?,
    count: Int,
    onStep: (String) -> Unit,
    onWarn: (String) -> Unit,
): PosterData {
    val name: String
    val songs: List<com.alterlist.app.data.Song>
    if (sourceId == null) {
        name = "Lagu disukai"
        songs = lib.liked
    } else {
        val pl = lib.playlists.firstOrNull { it.id == sourceId }
        name = pl?.name ?: "Playlist"
        songs = pl?.songs ?: emptyList()
    }
    val picked = songs.filter { !it.thumbnail.isNullOrBlank() }.distinctBy { it.thumbnail }.take(count)
    if (picked.isEmpty()) throw IllegalStateException("Playlist ini belum punya sampul lagu")

    onStep("Mengambil sampul...")
    val posterSongs =
        withContext(Dispatchers.IO) {
            picked.map { PosterSong(it.title, it.artist, it.durationSeconds ?: 0, loadCover(context, it)) }
        }
    if (posterSongs.none { it.cover != null }) throw IllegalStateException("Sampul tidak bisa diambil, periksa koneksi")

    var photo: Bitmap? = null
    var cutout: Bitmap? = null
    if (photoUri != null) {
        onStep("Memisahkan subjek dari latar...")
        try {
            val bmp = withContext(Dispatchers.IO) { decodePhoto(context, photoUri) }
            try {
                val r = PosterSegmenter.cutout(bmp)
                photo = r.photo
                cutout = r.cutout
            } catch (e: Exception) {
                photo = bmp
                onWarn("Subjek gagal dipisah (${e.message ?: "kesalahan"}). Foto dipakai sebagai latar saja.")
            }
        } catch (e: Exception) {
            onWarn("Foto tidak bisa dibuka: ${e.message ?: "kesalahan"}")
        }
    }
    onStep("Menyusun poster...")
    val accent = posterAccentOf(posterSongs.firstNotNullOf { it.cover })
    return PosterData(name, photo, cutout, posterSongs, accent, PosterStyle())
}

private suspend fun loadCover(context: Context, song: com.alterlist.app.data.Song): Bitmap? {
    val url = song.thumbnail ?: return null
    val raw =
        if (LocalArt.isLocalArt(url)) {
            LocalArt.load(context, url, 360)
        } else {
            Net.getBytes(url.withSize(360))?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
        } ?: return null
    // sampul dipotong persegi supaya kartu 3D tidak gepeng
    val side = min(raw.width, raw.height)
    return Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side)
}

private fun decodePhoto(context: Context, uri: Uri): Bitmap {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val side = max(info.size.width, info.size.height)
        if (side > 1400) {
            val k = 1400f / side
            decoder.setTargetSize((info.size.width * k).toInt().coerceAtLeast(1), (info.size.height * k).toInt().coerceAtLeast(1))
        }
    }
}

/** Warna aksen: rata-rata sampul pertama, dibuat lebih hidup (jenuh dan terang). */
private fun posterAccentOf(cover: Bitmap): Int {
    val avg = Bitmap.createScaledBitmap(cover, 1, 1, true).getPixel(0, 0)
    val hsv = FloatArray(3)
    Color.colorToHSV(avg, hsv)
    hsv[1] = max(hsv[1], 0.6f)
    hsv[2] = max(hsv[2], 0.85f)
    return Color.HSVToColor(hsv)
}

private suspend fun savePng(context: Context, data: PosterData): Boolean =
    withContext(Dispatchers.IO) {
        val dm = context.resources.displayMetrics
        val w = 1080
        val h = (w * dm.heightPixels.toFloat() / dm.widthPixels).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        PosterRenderer(data).draw(Canvas(bmp), w, h, 0f, 0f, 3f)
        val values =
            ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "Alterlist-poster-${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Alterlist")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
        try {
            resolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: throw IOException("tidak bisa menulis")
            val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            true
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            false
        }
    }

private fun openLiveWallpaper(context: Context) {
    val direct =
        Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(context, PosterWallpaperService::class.java))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(direct)
    } catch (e: Exception) {
        try {
            context.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            context.toast("Pilih \"Poster 3D Alterlist\" dari daftar wallpaper hidup")
        } catch (e2: Exception) {
            context.toast("Ponsel ini tidak mendukung wallpaper hidup")
        }
    }
}
