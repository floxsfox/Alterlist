# Alterlist

Pemutar musik Android (Kotlin + Jetpack Compose + Media3) untuk YouTube Music.

Dibuat oleh **eliojioDev**. API: **InnerTubeX** (YouTube Music) dan **NewPipeExtractor** (SoundCloud, tidak resmi).

## Fitur

- Beranda "Untuk Kamu": rekomendasi sesuai selera (genre favorit dominan = beranda dominan genre itu), Daily Mix, rak per genre
- Pencarian tanpa batas, pencarian lewat lirik, putar dari tautan YouTube
- Musik di perangkat (semua format audio yang didukung Android)
- Efek suara: 3D, 8D, reverb, slowed, sped up, equalizer 5 pita, bass booster
- Profil audio otomatis per perangkat (Bluetooth, berkabel, speaker)
- Lirik sinkron + terjemahan + geser waktu lirik, loop A-B
- Unduhan (tersimpan di penyimpanan privat aplikasi, ikut terhapus saat aplikasi dihapus), unduh otomatis lagu disukai (Wi-Fi)
- Mode offline, rekap musikmu, cadangan dan pemulihan pustaka
- Streak harian dengan api kartun beranimasi (oranye, biru, ungu, merah, hijau, putih, pelangi) dan api padam saat terlewat
- Nada (pitch) terpisah dari kecepatan di tab Reverb & Tempo
- SoundCloud tidak resmi lewat NewPipeExtractor (JitPack), hanya `ServiceList.SoundCloud`: lagu diputar penuh (bukan cuplikan), HLS didukung, bisa diunduh. Artis dan playlist SoundCloud juga bisa dicari (filter Artis / Playlist)
- Pengaturan > Tentang > Developer: profil dan latar eliojioDev
- Label ala Spotify: **E** (eksplisit) dan **SC** (SoundCloud) di daftar lagu, pemutar, dan menu lagu
- Mode game: panel musik melayang + notifikasi lagu berikutnya (bola cover jatuh dari atas, memanjang jadi pil judul lagu, kembali jadi bola dan terlempar ke atas; bisa dimatikan di Pengaturan > Mode game)
- Impor playlist dari Spotify, Apple Music, SoundCloud, dan YouTube Music (atau daftar judul / CSV); API SoundCloud bisa diganti di Pengaturan

## Build

Workflow `.github/workflows/build.yml` membangun **satu APK rilis** dan menerbitkannya ke halaman **Releases**
(tag `v<versionName>`). Versi saat ini: 3.10.1.

Build lokal: `./gradlew assembleRelease` (JDK 21, Android SDK 37).

Dukungan: Android 10 sampai 17 (API 29-37), ARM 64-bit (`arm64-v8a`) dan ARM 32-bit (`armeabi-v7a`) dalam satu APK.

## Struktur

```
app/src/main/java/com/alterlist/app/
  data/      YtMusic, ScNewPipe (SoundCloud), Library, Account, Lyrics, Translator, Recommender, LocalMusic, ...
  system/    NetworkMonitor, AudioOutputMonitor, PermissionHelper, GameOverlayService (mode game)
  importer/  PlaylistImporter (impor playlist dari Spotify, Apple Music, SoundCloud, YouTube Music, teks/CSV)
  fx/        ReverbEngine, SpatialAudioProcessor (3D/8D), EqualizerFx, AudioFx
  playback/  PlaybackService, PlayerConnection, QueueStore, FadeController
  download/  Downloader, DownloadService, Mp4Tagger (M4A), Id3Tagger (MP3)
  ui/        layar Compose
```

Lisensi: GPL-3.0. Font: Figtree (SIL OFL 1.1).
