# Alterlist

Pemutar musik Android (Kotlin + Jetpack Compose) untuk YouTube Music dengan tampilan bergaya Spotify, warna merah.
Memakai API privat **InnerTube** (client `WEB_REMIX`) lewat library [InnerTubeX](https://github.com/MetrolistGroup/innertubex),
sama seperti Metrolist. Tanpa server: semua data (login, pustaka, unduhan) hanya ada di HP.

## Yang baru di 3.0.0

- **Beranda "Untuk Kamu" (mirip FYP / Spotify)**: profil selera dibangun di HP dari lagu yang sering diputar, disukai, riwayat,
  artis diikuti, dan genre tebakan dari judul/artis. Kartu besar yang bisa digeser, Daily Mix, rak "Karena kamu suka ...",
  Mix per genre, dan artis baru. Pengguna baru memilih genre favorit dulu. Kalau login, cookie akun ikut mempengaruhi rekomendasi.
- **Offline**: saat tidak ada internet, Beranda dan pencarian berhenti memuat dan hanya menampilkan unduhan + musik di perangkat.
  Otomatis lanjut saat sinyal kembali.
- **Musik di perangkat**: tab baru *Perangkat* (Lagu / Album / Artis / Folder) untuk semua format audio yang didukung Android,
  ditambah pemilih berkas manual untuk file yang tidak terdeteksi.
- **Pencarian tanpa batas**: hasil terus dimuat otomatis saat scroll sampai YouTube Music tidak punya hasil lagi.
- **Efek suara baru ("Kustom")**: preset bergaya kartu, **3D** (pelebar + pantulan ruang) dan **8D** (suara berputar di kepala,
  dengan pratinjau animasi), reverb/tempo, dan **equalizer 5 pita** + bass booster + virtualizer + penguat volume.
- **Bluetooth / perangkat audio**: nama speaker atau earphone yang tersambung tampil di pemutar, ada notifikasi saat berganti.
- **Liquid glass**: mini player dan bar navigasi kaca dengan warna dari metadata cover lagu; animasi transisi, bounce, shimmer.
- Fitur ala Spotify: Rekap musikmu, lanjut dari lagu terakhir, fade antar lagu, lewati keheningan, simpan antrean sebagai playlist,
  info lagu, radio dari lagu, cadangan dan pemulihan pustaka.

## Fitur

- **Layar awal**: Masuk dengan Google (tombol merah) atau Lanjut sebagai tamu (tombol putih).
  Login memakai halaman login YouTube Music di WebView; cookie sesi disimpan lokal.
- **Beranda yang mengikuti kebiasaanmu**: grid cepat, Putar ulang, Mix untukmu (dari artis yang paling sering diputar),
  Artis favoritmu, Paling sering kamu putar, lalu rak rekomendasi YouTube Music (personal kalau sudah login).
- **Cari**: saran pencarian, riwayat pencarian, filter Lagu / Artis / Album / Playlist / Video, dan "Jelajahi semua" (mood & genre).
- **Koleksi**: Lagu disukai, Riwayat, playlist buatan sendiri, artis yang diikuti, Unduhan, dan playlist akun YouTube Music.
- **Pemutar**: gradasi warna dari cover, antrean, Autoplay (lagu mirip saat antrean habis), shuffle/repeat, sleep timer,
  lirik tersinkron (LRCLIB), bagikan, mini player yang bisa digeser.
- **Efek suara**: *Slowed* gaya tape (kecepatan + nada turun bersamaan, halus, tidak patah-patah) dan *Reverb* yang
  distabilkan (Freeverb dengan pre-delay, filter, soft limiter). Preset: Normal, Slowed, Slowed + Reverb, Reverb, Sped up.
- **Unduh**: audio M4A lengkap dengan cover, judul, artis, album, penerbit, dan tautan sumber. Tanpa FFmpeg:
  kemasan DASH dari YouTube dikonversi ke M4A biasa dan tag ditulis langsung oleh aplikasi. Lagu unduhan diputar offline
  dan (Android 10+) juga disalin ke folder `Music/Alterlist`.
- **Sesi pribadi**: riwayat dan statistik tidak disimpan selama aktif.

## Build lewat GitHub Actions

Jalur termudah dari HP: upload `Alterlist.zip` (jangan diekstrak) ke repo GitHub, lalu buat file
`.github/workflows/build.yml` berisi isi `build-dari-zip.yml`. Atau upload seluruh isi folder ini lalu pakai `build.yml`.
APK muncul di artifact `Alterlist-APK` (`Alterlist-release.apk` dan `Alterlist-debug.apk`) setelah workflow selesai.

Keystore sendiri (opsional): secret `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Tanpa itu APK rilis ditandatangani dengan debug key (tetap bisa di-install).

Build lokal: JDK 21 + Android SDK, lalu `./gradlew assembleDebug`.

## Struktur

```
app/src/main/java/com/alterlist/app/
  AlterApp.kt, MainActivity.kt
  data/      YtMusic (InnerTube), Parsers, Library (pustaka lokal), Account, Lyrics, Models, Net,
             LocalMusic + LocalArt (musik HP), Taste + Recommender + GenreTags (rekomendasi), Recap, Backup, Settings
  system/    NetworkMonitor (offline), AudioOutputMonitor (Bluetooth), PermissionHelper
  fx/        ReverbEngine, ReverbAudioProcessor, SpatialAudioProcessor (3D/8D), EqualizerFx, EqPresets, Dsp, AudioFx
  download/  Downloader, DownloadService, Mp4Defrag (DASH -> M4A), Mp4Tagger (tag + cover)
  playback/  PlaybackService (ExoPlayer, cache, resolve URL), PlayerConnection, QueueStore, FadeController
  ui/        Theme (Figtree, merah), ikon vector buatan sendiri, layar-layar, sheet, Now Playing
```

## Catatan

- API tidak resmi: bisa berubah kapan saja; kalau pemutaran gagal, naikkan versi `innertubex` di `gradle/libs.versions.toml`.
  Pemakaiannya juga bisa melanggar ketentuan layanan YouTube; pakai untuk keperluan pribadi.
- Login Google lewat WebView menyimpan cookie sesi di HP. Keluar dari akun menghapusnya.
- **Lisensi GPL-3.0** (InnerTubeX berlisensi GPL-3.0). Font Figtree berlisensi SIL OFL (lihat `FONT-LICENSE-Figtree-OFL.txt`).
- Belum ada: crossfade tumpang-tindih (yang ada fade keluar/masuk), podcast, Spotify Connect, PO-token (BotGuard).
