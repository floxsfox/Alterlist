# Alterlist

Pemutar musik Android (Kotlin + Jetpack Compose + Media3) untuk YouTube Music.

Dibuat oleh **eliojioDev**. API: **InnerTubeX**.

## Fitur

- Beranda "Untuk Kamu": rekomendasi sesuai selera (genre favorit dominan = beranda dominan genre itu), Daily Mix, rak per genre
- Pencarian tanpa batas, pencarian lewat lirik, putar dari tautan YouTube
- Musik di perangkat (semua format audio yang didukung Android)
- Efek suara: 3D, 8D, reverb, slowed, sped up, equalizer 5 pita, bass booster
- Profil audio otomatis per perangkat (Bluetooth, berkabel, speaker)
- Lirik sinkron + terjemahan + geser waktu lirik, loop A-B
- Unduhan (tersimpan di penyimpanan privat aplikasi, ikut terhapus saat aplikasi dihapus), unduh otomatis lagu disukai (Wi-Fi)
- Mode offline, rekap musikmu, cadangan dan pemulihan pustaka

## Build

Workflow `.github/workflows/build.yml` membangun **satu APK rilis** dan menerbitkannya ke halaman **Releases**
(tag `v<versionName>`). Versi saat ini: 3.6.8.

Build lokal: `./gradlew assembleRelease` (JDK 21, Android SDK 37).

Dukungan: Android 10 sampai 17 (API 29-37), ARM 64-bit (`arm64-v8a`) dan ARM 32-bit (`armeabi-v7a`) dalam satu APK.

## Struktur

```
app/src/main/java/com/alterlist/app/
  data/      YtMusic, Library, Account, Lyrics, Translator, Recommender, LocalMusic, ...
  system/    NetworkMonitor, AudioOutputMonitor, PermissionHelper
  fx/        ReverbEngine, SpatialAudioProcessor (3D/8D), EqualizerFx, AudioFx
  playback/  PlaybackService, PlayerConnection, QueueStore, FadeController
  download/  Downloader, DownloadService
  ui/        layar Compose
```

Lisensi: GPL-3.0. Font: Figtree (SIL OFL 1.1).
