package com.alterlist.app.system

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class OutputKind(val label: String) {
    PHONE("Speaker ponsel"),
    BLUETOOTH("Bluetooth"),
    WIRED("Headset berkabel"),
    USB("USB audio"),
    HDMI("HDMI"),
    OTHER("Perangkat audio"),
}

data class AudioOutput(val kind: OutputKind, val name: String, val id: Int) {
    val isBluetooth: Boolean get() = kind == OutputKind.BLUETOOTH
    val isHeadphoneLike: Boolean get() = kind == OutputKind.BLUETOOTH || kind == OutputKind.WIRED || kind == OutputKind.USB

    companion object {
        val Phone = AudioOutput(OutputKind.PHONE, "Speaker ponsel", -1)
    }
}

/**
 * Mendeteksi perangkat keluaran audio: speaker ponsel, earphone berkabel, dan speaker / earphone Bluetooth
 * (lengkap dengan nama perangkatnya). Berubah otomatis saat perangkat tersambung atau terputus.
 */
class AudioOutputMonitor(context: Context) {
    private val audioManager: AudioManager? = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _devices = MutableStateFlow<List<AudioOutput>>(listOf(AudioOutput.Phone))

    /** Semua keluaran yang sedang tersedia. */
    val devices: StateFlow<List<AudioOutput>> = _devices.asStateFlow()

    private val _active = MutableStateFlow(AudioOutput.Phone)

    /** Keluaran yang sedang dipakai memutar musik. */
    val active: StateFlow<AudioOutput> = _active.asStateFlow()

    init {
        refresh()
        try {
            audioManager?.registerAudioDeviceCallback(
                object : AudioDeviceCallback() {
                    override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
                        refresh()
                    }

                    override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
                        refresh()
                    }
                },
                Handler(Looper.getMainLooper()),
            )
        } catch (e: Exception) {
            // abaikan: tetap pakai nilai awal
        }
    }

    fun refresh() {
        val am = audioManager ?: return
        try {
            val infos = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
            val mapped = infos.mapNotNull { toOutput(it) }.distinctBy { it.id }
            val list = mapped.ifEmpty { listOf(AudioOutput.Phone) }
            _devices.value = list.sortedBy { priority(it.kind) }
            _active.value = pickActive(am, list)
        } catch (e: Exception) {
            // biarkan nilai terakhir
        }
    }

    private fun pickActive(am: AudioManager, list: List<AudioOutput>): AudioOutput {
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                val attrs =
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                val routed = am.getAudioDevicesForAttributes(attrs).firstOrNull()
                if (routed != null) {
                    val match = list.firstOrNull { it.id == routed.id }
                    if (match != null) return match
                }
            } catch (e: Exception) {
                // pakai heuristik di bawah
            }
        }
        return list.minByOrNull { priority(it.kind) } ?: AudioOutput.Phone
    }

    private fun priority(kind: OutputKind): Int =
        when (kind) {
            OutputKind.BLUETOOTH -> 0
            OutputKind.WIRED -> 1
            OutputKind.USB -> 2
            OutputKind.HDMI -> 3
            OutputKind.OTHER -> 4
            OutputKind.PHONE -> 5
        }

    private fun toOutput(d: AudioDeviceInfo): AudioOutput? {
        val kind =
            when (d.type) {
                AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> OutputKind.PHONE
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_HEARING_AID,
                AudioDeviceInfo.TYPE_BLE_HEADSET,
                AudioDeviceInfo.TYPE_BLE_SPEAKER,
                -> OutputKind.BLUETOOTH
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_LINE_ANALOG,
                AudioDeviceInfo.TYPE_AUX_LINE,
                -> OutputKind.WIRED
                AudioDeviceInfo.TYPE_USB_DEVICE,
                AudioDeviceInfo.TYPE_USB_HEADSET,
                AudioDeviceInfo.TYPE_USB_ACCESSORY,
                -> OutputKind.USB
                AudioDeviceInfo.TYPE_HDMI,
                AudioDeviceInfo.TYPE_HDMI_ARC,
                -> OutputKind.HDMI
                // earpiece (speaker telepon), telepon, dll bukan keluaran musik
                AudioDeviceInfo.TYPE_BUILTIN_EARPIECE,
                AudioDeviceInfo.TYPE_TELEPHONY,
                -> return null
                else -> OutputKind.OTHER
            }
        val raw = d.productName?.toString()?.trim().orEmpty()
        val name =
            when {
                kind == OutputKind.PHONE -> "Speaker ponsel"
                raw.isNotBlank() && !raw.equals("Android", true) -> raw
                else -> kind.label
            }
        return AudioOutput(kind, name, d.id)
    }
}
