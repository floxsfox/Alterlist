package com.alterlist.app.ui

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.alterlist.app.R

object AlterColors {
    val Red = Color(0xFFFA0107)
    val RedSoft = Color(0xFFFF4A50)
    val Bg = Color(0xFF0C0C0D)
    val Surface = Color(0xFF171718)
    val Surface2 = Color(0xFF242426)
    val Surface3 = Color(0xFF303033)
    val Sub = Color(0xFFB3B3B3)
    val Muted = Color(0xFF7C7C80)
    val Divider = Color(0xFF2A2A2D)
}

val Figtree =
    FontFamily(
        Font(R.font.figtree_regular, FontWeight.Normal),
        Font(R.font.figtree_medium, FontWeight.Medium),
        Font(R.font.figtree_semibold, FontWeight.SemiBold),
        Font(R.font.figtree_bold, FontWeight.Bold),
    )

/** Gaya teks Alterlist (Figtree). */
object T {
    val screen = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Bold, fontSize = 28.sp, letterSpacing = (-0.4).sp)
    val section = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Bold, fontSize = 21.sp, letterSpacing = (-0.2).sp)
    val title = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    val body = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Medium, fontSize = 14.sp)
    val small = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Medium, fontSize = 13.sp)
    val tiny = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Medium, fontSize = 11.sp)
    val button = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    val hero = TextStyle(fontFamily = Figtree, fontWeight = FontWeight.Bold, fontSize = 24.sp, letterSpacing = (-0.3).sp)
}

@Composable
fun AlterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme =
            darkColorScheme(
                primary = AlterColors.Red,
                onPrimary = Color.White,
                background = AlterColors.Bg,
                onBackground = Color.White,
                surface = AlterColors.Surface,
                onSurface = Color.White,
                surfaceVariant = AlterColors.Surface2,
                onSurfaceVariant = AlterColors.Sub,
                error = AlterColors.RedSoft,
            ),
    ) {
        CompositionLocalProvider(
            LocalContentColor provides Color.White,
            LocalTextStyle provides T.body,
            content = content,
        )
    }
}
