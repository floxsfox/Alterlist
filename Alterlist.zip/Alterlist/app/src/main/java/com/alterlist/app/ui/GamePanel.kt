package com.alterlist.app.ui

import android.content.Context
import android.media.AudioManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.SearchFilter
import com.alterlist.app.data.Song
import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.EqPreset
import com.alterlist.app.fx.EqualizerFx
import com.alterlist.app.fx.FxPreset
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val GameAccent = Color(0xFFFF3B30)
private val GameAccent2 = Color(0xFFFF8A3D)
private val GameBgTop = Color(0xFF14161C)
private val GameBgBottom = Color(0xFF07080B)
private val GameLine = Color.White.copy(alpha = 0.08f)

private enum class GameTab(val label: String, val icon: Int) {
    NOW("Lagu", R.drawable.ic_music_note),
    LISTS("Playlist", R.drawable.ic_queue),
    FX("Efek", R.drawable.ic_sliders),
    SEARCH("Cari", R.drawable.ic_search),
}

/**
 * Panel musik mode game: kecil, gelap, bergaya gaming. Ditampilkan oleh GameOverlayService di atas game.
 * Geser ke kiri di bagian atas panel, ketuk di luar panel, atau tombol silang untuk menutup.
 */
@Composable
fun GamePanel(visible: Boolean, onClose: () -> Unit, onFocusable: (Boolean) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val panelW = (maxWidth * 0.40f).coerceIn(300.dp, 420.dp).coerceAtMost(maxWidth - 24.dp)
        val scrim by animateFloatAsState(if (visible) 0.30f else 0f, tween(220), label = "gameScrim")
        // ketuk di luar panel = tutup
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = scrim))
                .pointerInput(Unit) { detectTapGestures { onClose() } },
        )
        AnimatedVisibility(
            visible = visible,
            modifier =
                Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 14.dp, top = 14.dp, bottom = 14.dp)
                    .width(panelW)
                    .fillMaxHeight(),
            enter = slideInHorizontally(tween(260)) { -it - 60 } + fadeIn(tween(200)),
            exit = slideOutHorizontally(tween(220)) { -it - 60 } + fadeOut(tween(160)),
        ) {
            PanelBody(onClose, onFocusable)
        }
    }
}

@Composable
private fun PanelBody(onClose: () -> Unit, onFocusable: (Boolean) -> Unit) {
    var tab by remember { mutableStateOf(GameTab.NOW) }
    val shape = CutCornerShape(topStart = 18.dp, topEnd = 6.dp, bottomEnd = 18.dp, bottomStart = 6.dp)
    Column(
        Modifier
            .fillMaxSize()
            // menelan ketukan di dalam panel supaya tidak tembus ke latar yang menutup panel
            .pointerInput(Unit) { detectTapGestures { } }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(GameBgTop.copy(alpha = 0.97f), GameBgBottom.copy(alpha = 0.98f))))
            .border(1.dp, Brush.linearGradient(listOf(GameAccent.copy(alpha = 0.75f), Color.White.copy(alpha = 0.06f), GameAccent2.copy(alpha = 0.45f))), shape),
    ) {
        Header(onClose)
        Row(Modifier.weight(1f).fillMaxWidth()) {
            Sidebar(tab) { tab = it }
            Box(Modifier.weight(1f).fillMaxHeight().padding(end = 10.dp, bottom = 10.dp)) {
                when (tab) {
                    GameTab.NOW -> NowTab()
                    GameTab.LISTS -> ListsTab()
                    GameTab.FX -> FxTab()
                    GameTab.SEARCH -> SearchTab(onFocusable)
                }
            }
        }
    }
}

@Composable
private fun Header(onClose: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            // geser ke kiri di header untuk menutup panel
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -70f) onClose() },
                    onDragCancel = { total = 0f },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                    },
                )
            }
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "ALTERLIST",
            style = T.title.copy(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic, fontSize = 15.sp, letterSpacing = 2.sp),
            color = Color.White,
        )
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .clip(CutCornerShape(topStart = 5.dp, bottomEnd = 5.dp))
                .background(Brush.horizontalGradient(listOf(GameAccent, GameAccent2)))
                .padding(horizontal = 6.dp, vertical = 2.dp),
        ) { Text("GAME MODE", style = T.tiny.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp), color = Color.White) }
        Spacer(Modifier.weight(1f))
        IconBtn(R.drawable.ic_close, onClose, tint = Color.White.copy(alpha = 0.7f), size = 18.dp, box = 36.dp)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(GameAccent.copy(alpha = 0.8f), Color.Transparent))))
}

@Composable
private fun Sidebar(selected: GameTab, onSelect: (GameTab) -> Unit) {
    Column(Modifier.width(66.dp).fillMaxHeight().padding(vertical = 6.dp), verticalArrangement = Arrangement.SpaceEvenly) {
        GameTab.entries.forEach { t ->
            val on = t == selected
            Box(
                Modifier.fillMaxWidth().height(56.dp).clickable { onSelect(t) },
                contentAlignment = Alignment.Center,
            ) {
                if (on) {
                    Box(
                        Modifier
                            .align(Alignment.CenterStart)
                            .width(3.dp)
                            .height(30.dp)
                            .clip(RoundedCornerShape(topEnd = 3.dp, bottomEnd = 3.dp))
                            .background(Brush.verticalGradient(listOf(GameAccent, GameAccent2))),
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Ic(t.icon, tint = if (on) GameAccent2 else Color.White.copy(alpha = 0.62f), size = 22.dp)
                    Spacer(Modifier.height(3.dp))
                    Text(t.label, style = T.tiny.copy(fontSize = 10.sp), color = if (on) Color.White else Color.White.copy(alpha = 0.6f))
                }
            }
        }
    }
}

// ------------------------------------------------------------------ tab Lagu

@Composable
private fun NowTab() {
    val app = AlterApp.instance
    val st by app.player.state.collectAsState()
    val song = st.current
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol) }
    var drag by remember { mutableStateOf<Float?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (song == null) {
            Text(
                "Belum ada lagu yang diputar. Pilih dari tab Playlist atau Cari.",
                style = T.small,
                color = Color.White.copy(alpha = 0.6f),
                modifier = Modifier.padding(top = 14.dp, start = 6.dp),
            )
        } else {
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(song.thumbnail, Modifier.size(58.dp), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp), px = 160)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(song.title, style = T.body.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (song.isSoundCloud) {
                            SoundCloudBadge()
                            Spacer(Modifier.width(5.dp))
                        }
                        Text(song.artist, style = T.small.copy(fontSize = 12.sp), color = Color.White.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            val progress = if (st.durationMs > 0L) (st.positionMs.toFloat() / st.durationMs).coerceIn(0f, 1f) else 0f
            SeekBar(
                value = drag ?: progress,
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { app.player.seekTo((it * st.durationMs).toLong()) }
                    drag = null
                },
                activeColor = GameAccent2,
                trackColor = Color.White.copy(alpha = 0.16f),
                trackHeight = 3.dp,
                thumbRadius = 5.dp,
                enabled = st.durationMs > 0L,
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
                Text(formatTime(st.positionMs), style = T.tiny, color = Color.White.copy(alpha = 0.55f))
                Spacer(Modifier.weight(1f))
                Text(formatTime(st.durationMs), style = T.tiny, color = Color.White.copy(alpha = 0.55f))
            }
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
            IconBtn(R.drawable.ic_shuffle, { app.player.toggleShuffle() }, tint = if (st.shuffle) GameAccent2 else Color.White.copy(alpha = 0.7f), size = 20.dp, box = 38.dp)
            IconBtn(R.drawable.ic_prev, { app.player.previous() }, tint = Color.White, size = 24.dp, box = 40.dp)
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(GameAccent, GameAccent2)))
                    .clickable { app.player.togglePlay() },
                contentAlignment = Alignment.Center,
            ) { Ic(if (st.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, tint = Color.White, size = 24.dp) }
            IconBtn(R.drawable.ic_next, { app.player.next() }, tint = Color.White, size = 24.dp, box = 40.dp)
            IconBtn(
                if (st.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                { app.player.cycleRepeat() },
                tint = if (st.repeatMode != Player.REPEAT_MODE_OFF) GameAccent2 else Color.White.copy(alpha = 0.7f),
                size = 20.dp,
                box = 38.dp,
            )
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Ic(R.drawable.ic_speaker, tint = Color.White.copy(alpha = 0.65f), size = 18.dp)
            Spacer(Modifier.width(6.dp))
            Box(Modifier.weight(1f)) {
                SeekBar(
                    value = vol,
                    onValueChange = {
                        vol = it
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * maxVol).roundToInt(), 0)
                    },
                    onValueChangeFinished = {},
                    activeColor = Color.White,
                    trackColor = Color.White.copy(alpha = 0.16f),
                    trackHeight = 3.dp,
                    thumbRadius = 5.dp,
                )
            }
        }
    }
}

// ------------------------------------------------------------------ tab Playlist

private data class SongList(val id: String, val name: String, val songs: List<Song>)

@Composable
private fun ListsTab() {
    val app = AlterApp.instance
    val lib by app.library.data.collectAsState()
    val player by app.player.state.collectAsState()
    var openId by remember { mutableStateOf<String?>(null) }
    val lists =
        remember(lib) {
            val out = ArrayList<SongList>()
            out.add(SongList("liked", "Lagu disukai", lib.liked))
            if (lib.recent.isNotEmpty()) out.add(SongList("recent", "Terakhir diputar", lib.recent))
            if (lib.downloads.isNotEmpty()) out.add(SongList("downloads", "Diunduh", lib.downloads.map { it.song }))
            lib.playlists.forEach { out.add(SongList(it.id, it.name, it.songs)) }
            out
        }
    val open = lists.firstOrNull { it.id == openId }

    if (open == null) {
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(lists, key = { it.id }) { l ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                        .background(Color.White.copy(alpha = 0.05f))
                        .clickable { openId = l.id }
                        .padding(horizontal = 12.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(l.name, style = T.body.copy(fontWeight = FontWeight.SemiBold, fontSize = 13.sp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Text("${l.songs.size}", style = T.tiny, color = Color.White.copy(alpha = 0.55f))
                }
            }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.ic_chevron_left, { openId = null }, tint = Color.White, size = 20.dp, box = 36.dp)
                Text(open.name, style = T.body.copy(fontWeight = FontWeight.Bold, fontSize = 13.sp), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (open.songs.isNotEmpty()) {
                    GameChip("Acak", false) { app.player.playSongs(open.songs, 0, shuffle = true) }
                }
            }
            if (open.songs.isEmpty()) {
                Text("Daftar ini masih kosong.", style = T.small, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp))
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(open.songs) { index, song ->
                        MiniSongRow(song, current = player.current?.id == song.id, trailingAdd = false) { app.player.playSongs(open.songs, index) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniSongRow(song: Song, current: Boolean, trailingAdd: Boolean, onClick: () -> Unit) {
    val app = AlterApp.instance
    val context = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(song.thumbnail, Modifier.size(38.dp), RoundedCornerShape(4.dp), px = 96)
        Spacer(Modifier.width(9.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, style = T.body.copy(fontWeight = FontWeight.SemiBold, fontSize = 12.sp), color = if (current) GameAccent2 else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (song.isSoundCloud) {
                    SoundCloudBadge()
                    Spacer(Modifier.width(4.dp))
                }
                Text(song.artist, style = T.tiny, color = Color.White.copy(alpha = 0.55f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailingAdd) {
            IconBtn(
                R.drawable.ic_plus,
                {
                    app.player.addToQueue(song)
                    context.toast("Ditambahkan ke antrean")
                },
                tint = Color.White.copy(alpha = 0.7f),
                size = 18.dp,
                box = 34.dp,
            )
        }
    }
}

// ------------------------------------------------------------------ tab Efek

@Composable
private fun FxTab() {
    val fx by AudioFx.state.collectAsState()
    val eq by EqualizerFx.state.collectAsState()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        GameLabel("Efek suara")
        FxPreset.entries.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { p -> GameChip(p.label, fx.preset == p, Modifier.weight(1f)) { AudioFx.applyPreset(p) } }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        GameLabel("Equalizer")
        listOf(EqPreset.FLAT, EqPreset.BASS, EqPreset.VOCAL, EqPreset.TREBLE, EqPreset.POP, EqPreset.ROCK, EqPreset.HIPHOP, EqPreset.ELECTRONIC)
            .chunked(2)
            .forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { p -> GameChip(p.label, eq.enabled && eq.preset == p, Modifier.weight(1f)) { EqualizerFx.applyPreset(p) } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        Spacer(Modifier.height(2.dp))
        GameChip("Reset semua efek", false, Modifier.fillMaxWidth()) {
            AudioFx.reset()
            EqualizerFx.resetAll()
        }
    }
}

// ------------------------------------------------------------------ tab Cari

@Composable
private fun SearchTab(onFocusable: (Boolean) -> Unit) {
    val app = AlterApp.instance
    val scope = rememberCoroutineScope()
    val sources by app.settings.state.collectAsState()
    val player by app.player.state.collectAsState()
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Song>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun runSearch() {
        val q = query.trim()
        if (q.isEmpty()) return
        scope.launch {
            busy = true
            message = null
            val (yt, sc) =
                coroutineScope {
                    val a =
                        async {
                            if (sources.useYoutube) runCatching { app.yt.search(q, SearchFilter.SONG) }.getOrDefault(emptyList()) else emptyList()
                        }
                    val b =
                        async {
                            if (sources.useSoundcloud) runCatching { app.soundcloud.search(q) }.getOrDefault(emptyList()) else emptyList()
                        }
                    a.await() to b.await()
                }
            val ytSongs = yt.mapNotNull { it.toSong() }
            val scSongs = sc.mapNotNull { it.toSong() }
            val merged = ArrayList<Song>()
            var i = 0
            var j = 0
            while (i < ytSongs.size || j < scSongs.size) {
                repeat(2) { if (i < ytSongs.size) merged.add(ytSongs[i++]) }
                if (j < scSongs.size) merged.add(scSongs[j++])
            }
            results = merged
            if (merged.isEmpty()) message = "Tidak ada hasil"
            busy = false
        }
    }
    val latestSearch = rememberUpdatedState { runSearch() }

    // saat tab ditutup, jendela panel dikembalikan ke mode tidak fokus supaya game tetap berjalan
    DisposableEffect(Unit) { onDispose { onFocusable(false) } }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                .background(Color.White.copy(alpha = 0.07f))
                .border(1.dp, GameLine, CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                .padding(start = 10.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // EditText bawaan Android: bisa memakai IME_FLAG_NO_EXTRACT_UI sehingga keyboard landscape tidak menutupi seluruh layar
            AndroidView(
                modifier = Modifier.weight(1f).height(40.dp),
                factory = { ctx ->
                    EditText(ctx).apply {
                        hint = "Cari lagu..."
                        setHintTextColor(0x88FFFFFF.toInt())
                        setTextColor(android.graphics.Color.WHITE)
                        textSize = 14f
                        background = null
                        setSingleLine(true)
                        inputType = InputType.TYPE_CLASS_TEXT
                        imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
                        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        addTextChangedListener(
                            object : TextWatcher {
                                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

                                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit

                                override fun afterTextChanged(s: Editable?) {
                                    query = s?.toString().orEmpty()
                                }
                            },
                        )
                        setOnTouchListener { v, ev ->
                            if (ev.action == MotionEvent.ACTION_DOWN) {
                                // jendela perlu fokus agar keyboard bisa muncul; beri waktu layanan memperbarui flag jendela
                                onFocusable(true)
                                v.postDelayed(
                                    {
                                        v.requestFocus()
                                        imm.showSoftInput(v, 0)
                                    },
                                    140,
                                )
                            }
                            false
                        }
                        setOnEditorActionListener { v, actionId, _ ->
                            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                                imm.hideSoftInputFromWindow(v.windowToken, 0)
                                v.clearFocus()
                                onFocusable(false)
                                latestSearch.value()
                                true
                            } else {
                                false
                            }
                        }
                    }
                },
            )
            IconBtn(R.drawable.ic_search, { latestSearch.value() }, tint = GameAccent2, size = 20.dp, box = 38.dp)
        }
        Spacer(Modifier.height(6.dp))
        when {
            busy -> Text("Mencari...", style = T.small, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp))
            message != null -> Text(message.orEmpty(), style = T.small, color = Color.White.copy(alpha = 0.6f), modifier = Modifier.padding(8.dp))
            results.isEmpty() ->
                Text(
                    "Ketik judul lagu atau artis lalu tekan cari. Hasil dari YouTube Music dan SoundCloud sesuai sumber yang aktif.",
                    style = T.tiny,
                    color = Color.White.copy(alpha = 0.5f),
                    modifier = Modifier.padding(8.dp),
                )
            else ->
                LazyColumn(Modifier.fillMaxSize()) {
                    items(results, key = { it.id }) { song ->
                        MiniSongRow(song, current = player.current?.id == song.id, trailingAdd = true) { app.player.playRadio(song) }
                    }
                }
        }
    }
}

// ------------------------------------------------------------------ komponen kecil

@Composable
private fun GameLabel(text: String) {
    Text(
        text.uppercase(),
        style = T.tiny.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp),
        color = GameAccent2,
        modifier = Modifier.padding(top = 6.dp, start = 2.dp),
    )
}

@Composable
private fun GameChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = CutCornerShape(topStart = 7.dp, bottomEnd = 7.dp)
    Box(
        modifier
            .clip(shape)
            .background(
                if (selected) {
                    Brush.horizontalGradient(listOf(GameAccent.copy(alpha = 0.85f), GameAccent2.copy(alpha = 0.85f)))
                } else {
                    Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.06f)))
                },
            )
            .border(1.dp, if (selected) Color.Transparent else GameLine, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = T.tiny.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
