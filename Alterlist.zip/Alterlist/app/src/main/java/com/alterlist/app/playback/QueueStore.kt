package com.alterlist.app.playback

import android.content.Context
import com.alterlist.app.data.Song
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

/** Antrean terakhir, supaya Alterlist melanjutkan dari lagu terakhir seperti Spotify. */
@Serializable
data class SavedQueue(
    val songs: List<Song>,
    val index: Int = 0,
    val positionMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = 0,
)

class QueueStore(context: Context) {
    private val file = File(context.filesDir, "queue.json")
    private val json =
        Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }

    fun save(q: SavedQueue) {
        try {
            if (q.songs.isEmpty()) {
                file.delete()
                return
            }
            // batasi ukuran: ambil jendela di sekitar lagu yang sedang diputar
            val trimmed =
                if (q.songs.size > MAX_SAVED) {
                    val from = (q.index - 5).coerceAtLeast(0)
                    val list = q.songs.drop(from).take(MAX_SAVED)
                    q.copy(songs = list, index = (q.index - from).coerceIn(0, list.lastIndex))
                } else {
                    q
                }
            val tmp = File(file.path + ".tmp")
            tmp.writeText(json.encodeToString(SavedQueue.serializer(), trimmed))
            tmp.renameTo(file)
        } catch (e: Exception) {
            // gagal menyimpan antrean tidak boleh mengganggu pemutaran
        }
    }

    fun load(): SavedQueue? =
        try {
            if (file.exists()) json.decodeFromString(SavedQueue.serializer(), file.readText()).takeIf { it.songs.isNotEmpty() } else null
        } catch (e: Exception) {
            null
        }

    private companion object {
        const val MAX_SAVED = 150
    }
}
