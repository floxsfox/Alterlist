package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.data.GenreTags
import com.alterlist.app.data.LocalFileInfo
import com.alterlist.app.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/** Info lagu: metadata, sumber, genre tebakan, dan (untuk berkas lokal) format, ukuran, bitrate, lokasi. */
@Composable
fun SongInfoSheet(song: Song, onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val lib by app.library.data.collectAsState()
    val fileInfo by produceState<LocalFileInfo?>(initialValue = null, key1 = song.id) {
        if (song.isLocal) value = withContext(Dispatchers.IO) { app.localMusic.describe(song) }
    }
    val downloaded = lib.downloads.firstOrNull { it.song.id == song.id }
    val tags = GenreTags.infer(song)

    BottomSheetDialog(onDismiss) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(song.thumbnail, Modifier.size(64.dp), RoundedCornerShape(8.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, style = T.title.copy(fontWeight = FontWeight.Bold), maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(song.artist, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            InfoLine("Sumber", if (song.isLocal) "Penyimpanan perangkat" else "YouTube Music")
            song.album?.let { InfoLine("Album", it) }
            song.durationText?.let { InfoLine("Durasi", it) }
            if (song.isLocal) {
                fileInfo?.let { f ->
                    f.displayName?.let { InfoLine("Nama berkas", it) }
                    val ext = f.displayName?.substringAfterLast('.', "")?.uppercase(Locale.ROOT).orEmpty()
                    if (ext.isNotEmpty()) InfoLine("Format", ext)
                    f.mime?.let { InfoLine("Tipe", it) }
                    f.bitrateKbps?.let { InfoLine("Bitrate", "$it kbps") }
                    f.bytes?.let { InfoLine("Ukuran", "%.1f MB".format(Locale.US, it / 1048576.0)) }
                    f.path?.let { InfoLine("Lokasi", it) }
                }
            } else {
                InfoLine("ID video", song.id)
                if (downloaded != null) InfoLine("Status", "Sudah diunduh (bisa offline)")
            }
            if (tags.isNotEmpty()) {
                Text("Genre dan suasana (tebakan)", style = T.small, color = AlterColors.Sub, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    tags.forEach { t ->
                        Text(
                            t,
                            style = T.small.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(GenreTags.colorFor(t)).copy(alpha = 0.8f)).padding(horizontal = 12.dp, vertical = 6.dp),
                        )
                    }
                }
            }
            Spacer(Modifier.size(12.dp))
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Text(label, style = T.small, color = AlterColors.Sub, modifier = Modifier.width(110.dp))
        Text(value, style = T.body, modifier = Modifier.weight(1f))
    }
}
