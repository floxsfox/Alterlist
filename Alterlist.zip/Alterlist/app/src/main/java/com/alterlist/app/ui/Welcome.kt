package com.alterlist.app.ui

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.alterlist.app.R
import com.alterlist.app.data.AccountSession
import java.util.concurrent.atomic.AtomicBoolean

/** Layar pertama: masuk dengan Google (tombol merah) atau lanjut sebagai tamu (tombol putih). */
@Composable
fun WelcomeScreen(onGoogle: () -> Unit, onGuest: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(AlterColors.Red.copy(alpha = 0.38f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height * 0.27f),
                        radius = size.width * 0.95f,
                    ),
                )
            },
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.weight(1f))
            Image(
                painter = painterResource(R.drawable.logo_mark),
                contentDescription = "Alterlist",
                modifier = Modifier.size(150.dp),
            )
            Spacer(Modifier.height(22.dp))
            Text("Alterlist", style = T.screen.copy(fontSize = 44.sp, letterSpacing = (-1).sp), color = Color.White)
            Spacer(Modifier.height(10.dp))
            Text(
                "Musik tanpa batas",
                style = T.body.copy(fontSize = 16.sp),
                color = AlterColors.Sub,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.weight(1.2f))

            // Tombol Google = merah
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(AlterColors.Red)
                    .clickable(onClick = onGoogle)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                    Text("G", style = T.button.copy(fontSize = 18.sp), color = AlterColors.Red)
                }
                Text(
                    "Masuk dengan Google",
                    style = T.button.copy(fontSize = 16.sp),
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(34.dp))
            }
            Spacer(Modifier.height(12.dp))
            // Tombol tamu = putih
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(50))
                    .background(Color.White)
                    .clickable(onClick = onGuest)
                    .padding(vertical = 15.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Lanjut sebagai tamu", style = T.button.copy(fontSize = 16.sp), color = Color.Black)
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

private class LoginBridge {
    @Volatile var visitorData: String? = null

    @Volatile var dataSyncId: String? = null

    @JavascriptInterface
    fun onRetrieveVisitorData(value: String?) {
        visitorData = value
    }

    @JavascriptInterface
    fun onRetrieveDataSyncId(value: String?) {
        dataSyncId = value
    }
}

private const val JS_VISITOR = "javascript:Android.onRetrieveVisitorData(window.yt.config_.VISITOR_DATA)"
private const val JS_DATASYNC = "javascript:Android.onRetrieveDataSyncId(window.yt.config_.DATASYNC_ID)"

/**
 * Login Google lewat WebView ke YouTube Music (tanpa server). Setelah masuk, cookie sesi diambil dari WebView
 * dan dipakai untuk permintaan ke API YouTube Music, sama seperti aplikasi pihak ketiga lain.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(onSuccess: (AccountSession) -> Unit, onBack: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    val finished = remember { AtomicBoolean(false) }
    val bridge = remember { LoginBridge() }

    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else onBack()
    }
    DisposableEffect(Unit) {
        onDispose {
            web?.apply {
                stopLoading()
                destroy()
            }
        }
    }

    fun tryFinish(view: WebView, attempt: Int) {
        if (finished.get()) return
        val cookie = CookieManager.getInstance().getCookie("https://music.youtube.com").orEmpty()
        val visitor = bridge.visitorData
        if (cookie.contains("SAPISID=") && !visitor.isNullOrBlank()) {
            if (finished.compareAndSet(false, true)) {
                onSuccess(
                    AccountSession(
                        cookie = cookie,
                        visitorData = visitor,
                        dataSyncId = bridge.dataSyncId.orEmpty().substringBefore("||").ifBlank { null },
                        authUser = "0",
                    ),
                )
            }
            return
        }
        if (attempt < 30) {
            view.postDelayed(
                {
                    view.evaluateJavascript(JS_VISITOR, null)
                    view.evaluateJavascript(JS_DATASYNC, null)
                    tryFinish(view, attempt + 1)
                },
                500,
            )
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(R.drawable.ic_chevron_left, onBack)
            Text("Masuk dengan Google", style = T.title, modifier = Modifier.weight(1f))
        }
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth().navigationBarsPadding(),
            factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                    addJavascriptInterface(bridge, "Android")
                    webViewClient =
                        object : WebViewClient() {
                            override fun onPageFinished(view: WebView, url: String?) {
                                if (url != null && url.startsWith("https://music.youtube.com")) {
                                    view.evaluateJavascript(JS_VISITOR, null)
                                    view.evaluateJavascript(JS_DATASYNC, null)
                                    tryFinish(view, 0)
                                }
                            }
                        }
                    loadUrl("https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmusic.youtube.com")
                    web = this
                }
            },
        )
    }
}
