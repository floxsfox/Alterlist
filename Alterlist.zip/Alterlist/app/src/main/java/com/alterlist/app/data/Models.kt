package com.alterlist.app.data

import kotlinx.serialization.Serializable

/** Lagu yang bisa diputar. Disimpan juga di Disukai, Playlist, Riwayat, dan Unduhan. */
@Serializable
data class Song(
    val id: String,
    val title: String,
    val artist: String = "",
    val artistId: String? = null,
    val album: String? = null,
    val albumId: String? = null,
    val thumbnail: String? = null,
    val durationText: String? = null,
    /** Hanya untuk musik di perangkat: alamat content:// berkas audio. */
    val uri: String? = null,
    /** Lagu bertanda eksplisit (label E ala Spotify). Dibaca dari YouTube Music dan metadata SoundCloud. */
    val explicit: Boolean = false,
) {
    val durationSeconds: Int?
        get() = durationToSeconds(durationText)

    /** True untuk lagu dari penyimpanan HP (bukan YouTube Music). */
    val isLocal: Boolean
        get() = id.startsWith(LOCAL_PREFIX)

    /** True untuk lagu dari SoundCloud (id berawalan "sc:"). Kolom [uri] berisi tautan halaman lagunya. */
    val isSoundCloud: Boolean
        get() = id.startsWith(SC_PREFIX)

    /** True untuk lagu YouTube Music (bukan perangkat, bukan SoundCloud). */
    val isYoutube: Boolean
        get() = !isLocal && !isSoundCloud
}

enum class EntryKind { SONG, ALBUM, ARTIST, PLAYLIST, MIX, OTHER }

/** Item hasil pencarian / beranda: lagu, album, playlist, mix, atau artis. */
data class Entry(
    val title: String,
    val subtitle: String = "",
    val thumbnail: String? = null,
    val videoId: String? = null,
    val browseId: String? = null,
    val playlistId: String? = null,
    val params: String? = null,
    val durationText: String? = null,
    val artistId: String? = null,
    val album: String? = null,
    val albumId: String? = null,
    /** Hanya SoundCloud: tautan halaman lagu (dipakai untuk Bagikan). */
    val uri: String? = null,
    /** Lagu bertanda eksplisit. */
    val explicit: Boolean = false,
) {
    val kind: EntryKind
        get() =
            when {
                videoId != null -> EntryKind.SONG
                browseId != null && browseId.startsWith(SC_USER_PREFIX) -> EntryKind.ARTIST
                browseId != null && browseId.startsWith(SC_PLAYLIST_PREFIX) -> EntryKind.PLAYLIST
                browseId != null && browseId.startsWith("MPRE") -> EntryKind.ALBUM
                browseId != null && browseId.startsWith("UC") -> EntryKind.ARTIST
                browseId != null && (browseId.startsWith("VL") || browseId.startsWith("PL") || browseId.startsWith("OLAK")) ->
                    EntryKind.PLAYLIST
                playlistId != null && browseId == null -> EntryKind.MIX
                else -> EntryKind.OTHER
            }

    fun toSong(): Song? =
        videoId?.let {
            Song(
                id = it,
                title = title,
                artist = subtitle,
                artistId = artistId,
                album = album,
                albumId = albumId,
                thumbnail = thumbnail,
                durationText = durationText,
                uri = uri,
                explicit = explicit,
            )
        }
}

data class Shelf(val title: String, val entries: List<Entry>)

/** Satu halaman hasil pencarian + token untuk halaman berikutnya (null bila sudah habis). */
data class SearchPage(val entries: List<Entry>, val next: String?)

/** Halaman album / playlist / artis / kategori. */
data class BrowsePage(
    val title: String,
    val subtitle: String,
    val thumbnail: String?,
    val songs: List<Song>,
    val shelves: List<Shelf>,
)

/** Kartu "Jelajahi semua" (mood & genre YouTube Music). */
data class Category(val title: String, val color: Int, val browseId: String, val params: String?)

@Serializable
data class Playlist(
    val id: String,
    val name: String,
    val songs: List<Song> = emptyList(),
    val createdAt: Long = 0L,
)

@Serializable
data class PlayStat(val song: Song, val count: Int = 0, val last: Long = 0L)

@Serializable
data class ArtistRef(val id: String, val name: String, val thumbnail: String? = null)

@Serializable
data class DownloadedSong(
    val song: Song,
    val fileName: String,
    val bytes: Long = 0L,
    val addedAt: Long = 0L,
    val publisher: String? = null,
    val exportUri: String? = null,
)

@Serializable
data class LibraryData(
    val liked: List<Song> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val recent: List<Song> = emptyList(),
    val stats: Map<String, PlayStat> = emptyMap(),
    val searches: List<String> = emptyList(),
    val artists: List<ArtistRef> = emptyList(),
    val downloads: List<DownloadedSong> = emptyList(),
    val privateSession: Boolean = false,
    val autoplay: Boolean = true,
    /** Genre yang dipilih sendiri di layar "Pilih genre favoritmu" (untuk pengguna baru). */
    val tastePicks: List<String> = emptyList(),
    /** Streak: jumlah hari berturut-turut aplikasi dibuka. */
    val streak: Int = 0,
    /** Streak terpanjang yang pernah dicapai. */
    val streakBest: Int = 0,
    /** Hari terakhir aplikasi dibuka (LocalDate.toEpochDay, waktu lokal). -1 = belum pernah. */
    val streakDay: Long = -1L,
    /** Streak yang baru padam dan belum diperlihatkan sebagai "api hitam" di Beranda (0 = tidak ada). */
    val streakLost: Int = 0,
)

data class AccountInfo(val name: String, val email: String, val photo: String?)

data class LyricLine(val timeMs: Long, val text: String)

data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

enum class SearchFilter(val label: String, val params: String) {
    SONG("Lagu", "EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D"),
    ARTIST("Artis", "EgWKAQIgAWoKEAkQChAFEAMQBA%3D%3D"),
    ALBUM("Album", "EgWKAQIYAWoKEAkQChAFEAMQBA%3D%3D"),
    PLAYLIST("Playlist", "EgeKAQQoAEABagoQAxAEEAoQCRAF"),
    VIDEO("Video", "EgWKAQIQAWoKEAkQChAFEAMQBA%3D%3D"),
}

sealed interface UiLoad<out T> {
    data object Idle : UiLoad<Nothing>

    data object Loading : UiLoad<Nothing>

    data class Data<T>(val value: T) : UiLoad<T>

    data class Error(val message: String) : UiLoad<Nothing>
}

private val SIZE_REGEX = Regex("=w\\d+-h\\d+")

/** Thumbnail googleusercontent bisa diminta ukuran lain lewat parameter =wXXX-hXXX. */
fun String.withSize(px: Int): String =
    if (SIZE_REGEX.containsMatchIn(this)) replace(SIZE_REGEX, "=w$px-h$px") else this

fun durationToSeconds(text: String?): Int? {
    if (text.isNullOrBlank()) return null
    val parts = text.trim().split(":").map { it.toIntOrNull() ?: return null }
    return when (parts.size) {
        2 -> parts[0] * 60 + parts[1]
        3 -> parts[0] * 3600 + parts[1] * 60 + parts[2]
        else -> null
    }
}

fun Song.watchUrl(): String =
    if (isSoundCloud) (uri ?: "https://soundcloud.com/") else "https://music.youtube.com/watch?v=$id"

/** Format durasi detik -> "m:ss" atau "h:mm:ss". */
fun formatDurationText(totalSeconds: Long): String {
    val t = totalSeconds.coerceAtLeast(0L)
    val h = t / 3600L
    val m = (t % 3600L) / 60L
    val sec = t % 60L
    return if (h > 0L) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}
