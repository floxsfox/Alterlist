package com.alterlist.app.system

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.Surface
import android.view.WindowManager
import kotlin.math.abs

/**
 * Sensor gerak bersama untuk add-on game (gyro bidik dan motion blur).
 *
 * Memakai vektor rotasi: ponsel BERGYRO memakai GAME_ROTATION_VECTOR (gyro + akselerometer, tanpa melayang oleh kompas),
 * ponsel TANPA gyro memakai ROTATION_VECTOR yang dihitung Android dari akselerometer + magnetometer ("gyro virtual").
 * Dari selisih dua rotasi berurutan dihitung seberapa jauh ponsel berputar (derajat) ke arah mendatar (yaw, putar badan)
 * dan tegak (pitch, angkat/turunkan layar), sudah disesuaikan dengan rotasi layar.
 */
object MotionSensor {
    enum class Kind { NONE, GYRO, VIRTUAL }

    fun interface Listener {
        /** [yawDeg] putar kiri-kanan (positif = ke kiri), [pitchDeg] angkat-turun, [dtSec] selang waktu sejak event sebelumnya. */
        fun onMotion(yawDeg: Float, pitchDeg: Float, dtSec: Float)
    }

    private val listeners = LinkedHashSet<Listener>()
    private var sm: SensorManager? = null
    private var wm: WindowManager? = null
    private var registered = false
    var kind: Kind = Kind.NONE
        private set

    private val prevR = FloatArray(9)
    private val curR = FloatArray(9)
    private var hasPrev = false
    private var lastNs = 0L

    private val sensorListener =
        object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) = handle(e)

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

    /** Jenis sensor yang akan dipakai di ponsel ini (untuk ditampilkan di UI), tanpa mulai mendengarkan. */
    fun detect(context: Context): Kind {
        val m = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val hasGyro = m.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        return when {
            hasGyro && m.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) != null -> Kind.GYRO
            m.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null -> if (hasGyro) Kind.GYRO else Kind.VIRTUAL
            else -> Kind.NONE
        }
    }

    fun register(context: Context, l: Listener) {
        listeners.add(l)
        if (!registered) start(context.applicationContext)
    }

    fun unregister(l: Listener) {
        listeners.remove(l)
        if (listeners.isEmpty() && registered) stop()
    }

    private fun start(context: Context) {
        val m = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        sm = m
        val hasGyro = m.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null
        val sensor =
            (if (hasGyro) m.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) else null)
                ?: m.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (sensor == null) {
            kind = Kind.NONE
            return
        }
        kind = if (hasGyro) Kind.GYRO else Kind.VIRTUAL
        hasPrev = false
        lastNs = 0L
        registered = m.registerListener(sensorListener, sensor, SensorManager.SENSOR_DELAY_GAME, Handler(Looper.getMainLooper()))
    }

    private fun stop() {
        sm?.unregisterListener(sensorListener)
        registered = false
        hasPrev = false
    }

    @Suppress("DEPRECATION")
    private fun displayRotation(): Int = wm?.defaultDisplay?.rotation ?: Surface.ROTATION_0

    private fun handle(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(curR, e.values)
        val nowNs = e.timestamp
        if (!hasPrev || lastNs == 0L) {
            System.arraycopy(curR, 0, prevR, 0, 9)
            hasPrev = true
            lastNs = nowNs
            return
        }
        val dt = ((nowNs - lastNs) / 1.0e9f).coerceIn(0.002f, 0.1f)
        lastNs = nowNs

        // rotasi relatif dalam kerangka perangkat: D = prev^T * cur  (R baris-utama, device -> dunia)
        fun d(i: Int, j: Int): Float {
            var s = 0f
            for (k in 0..2) s += prevR[k * 3 + i] * curR[k * 3 + j]
            return s
        }
        // vektor sudut kecil (radian) dari bagian antisimetris D
        val ax = 0.5f * (d(2, 1) - d(1, 2))
        val ay = 0.5f * (d(0, 2) - d(2, 0))
        val az = 0.5f * (d(1, 0) - d(0, 1))
        System.arraycopy(curR, 0, prevR, 0, 9)

        // arah "atas dunia" dalam kerangka perangkat = baris ke-3 matriks rotasi; yaw = putaran terhadap sumbu itu
        val yaw = ax * curR[6] + ay * curR[7] + az * curR[8]
        // pitch = putaran terhadap sumbu kanan-kiri layar (tergantung rotasi layar)
        val pitch =
            when (displayRotation()) {
                Surface.ROTATION_90 -> -ay
                Surface.ROTATION_270 -> ay
                Surface.ROTATION_180 -> -ax
                else -> ax
            }
        val toDeg = (180.0 / Math.PI).toFloat()
        val yawDeg = yaw * toDeg
        val pitchDeg = pitch * toDeg
        if (abs(yawDeg) > 90f || abs(pitchDeg) > 90f) return // loncatan sensor, abaikan
        for (l in listeners.toList()) l.onMotion(yawDeg, pitchDeg, dt)
    }
}
