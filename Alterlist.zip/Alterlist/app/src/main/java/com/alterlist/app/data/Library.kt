package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/** Statistik per artis, dipakai untuk beranda yang mengikuti kebiasaan memutar. */
data class ArtistStat(
    val name: String,
    val id: String?,
    val thumbnail: String?,
    val plays: Int,
    val topSong: Song,
)

fun primaryArtist(artist: String): String =
    artist.split(", ", " & ", " x ", " X ", " feat. ", " ft. ").firstOrNull()?.trim().orEmpty()

fun LibraryData.topSongs(n: Int, includeLocal: Boolean = false): List<Song> =
    stats.values
        .filter { includeLocal || !it.song.isLocal }
        .sortedWith(compareByDescending<PlayStat> { it.count }.thenByDescending { it.last })
        .take(n)
        .map { it.song }

fun LibraryData.topArtists(n: Int, includeLocal: Boolean = false): List<ArtistStat> =
    stats.values
        .filter { (includeLocal || !it.song.isLocal) && primaryArtist(it.song.artist).isNotBlank() }
        .groupBy { primaryArtist(it.song.artist).lowercase() }
        .map { (_, list) ->
            val best = list.maxWith(compareBy<PlayStat> { it.count }.thenBy { it.last })
            ArtistStat(
                name = primaryArtist(best.song.artist),
                id = best.song.artistId,
                thumbnail = best.song.thumbnail,
                plays = list.sumOf { it.count },
                topSong = best.song,
            )
        }
        .sortedByDescending { it.plays }
        .take(n)

/** Pustaka lokal: disukai, playlist, riwayat, statistik, artis diikuti, unduhan. Satu berkas JSON di HP. */
class Library(context: Context) {
    private val file = File(context.filesDir, "library.json")
    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null

    private val _data = MutableStateFlow(load())
    val data: StateFlow<LibraryData> = _data.asStateFlow()

    private fun load(): LibraryData =
        try {
            if (file.exists()) json.decodeFromString(LibraryData.serializer(), file.readText()) else LibraryData()
        } catch (e: Exception) {
            LibraryData()
        }

    private fun mutate(block: (LibraryData) -> LibraryData) {
        _data.update(block)
        saveJob?.cancel()
        saveJob =
            scope.launch {
                delay(500)
                write()
            }
    }

    @Synchronized
    private fun write() {
        try {
            val text = json.encodeToString(LibraryData.serializer(), _data.value)
            val tmp = File(file.path + ".tmp")
            tmp.writeText(text)
            tmp.renameTo(file)
        } catch (e: Exception) {
            // gagal menyimpan tidak boleh membuat aplikasi berhenti
        }
    }

    fun flush() {
        saveJob?.cancel()
        write()
    }

    // ---------------------------------------------------------------- disukai

    fun isLiked(id: String): Boolean = _data.value.liked.any { it.id == id }

    /** @return status disukai yang baru */
    fun toggleLike(song: Song): Boolean {
        val nowLiked = !isLiked(song.id)
        setLiked(song, nowLiked)
        return nowLiked
    }

    fun setLiked(song: Song, liked: Boolean) =
        mutate { d ->
            val rest = d.liked.filterNot { it.id == song.id }
            d.copy(liked = if (liked) listOf(song) + rest else rest)
        }

    /** Gabungkan lagu yang disukai dari akun YouTube Music tanpa menimpa yang sudah ada. */
    fun mergeLiked(songs: List<Song>) =
        mutate { d ->
            val have = d.liked.map { it.id }.toHashSet()
            d.copy(liked = d.liked + songs.filter { have.add(it.id) })
        }

    // ---------------------------------------------------------------- riwayat & statistik

    fun addRecent(song: Song) {
        if (_data.value.privateSession) return
        mutate { d -> d.copy(recent = (listOf(song) + d.recent.filterNot { it.id == song.id }).take(200)) }
    }

    fun recordPlay(song: Song) {
        if (_data.value.privateSession) return
        mutate { d ->
            val old = d.stats[song.id]
            val stat = PlayStat(song = song, count = (old?.count ?: 0) + 1, last = System.currentTimeMillis())
            var stats = d.stats + (song.id to stat)
            if (stats.size > 600) {
                val keep =
                    stats.values
                        .sortedWith(compareByDescending<PlayStat> { it.count }.thenByDescending { it.last })
                        .take(500)
                        .map { it.song.id }
                        .toHashSet()
                stats = stats.filterKeys { it in keep }
            }
            d.copy(stats = stats)
        }
    }

    fun clearRecent() = mutate { it.copy(recent = emptyList()) }

    fun clearStats() = mutate { it.copy(stats = emptyMap()) }

    // ---------------------------------------------------------------- pencarian

    fun addSearch(query: String) {
        val q = query.trim()
        if (q.isEmpty() || _data.value.privateSession) return
        mutate { d -> d.copy(searches = (listOf(q) + d.searches.filterNot { it.equals(q, true) }).take(12)) }
    }

    fun removeSearch(query: String) = mutate { d -> d.copy(searches = d.searches.filterNot { it == query }) }

    fun clearSearches() = mutate { it.copy(searches = emptyList()) }

    // ---------------------------------------------------------------- playlist

    /** Buat playlist langsung dengan banyak lagu (mis. simpan antrean jadi playlist). */
    fun createPlaylistWith(name: String, songs: List<Song>): Playlist {
        val p =
            Playlist(
                id = UUID.randomUUID().toString().take(8),
                name = name.trim().ifBlank { "Playlist baru" },
                songs = songs.distinctBy { it.id },
                createdAt = System.currentTimeMillis(),
            )
        mutate { d -> d.copy(playlists = listOf(p) + d.playlists) }
        return p
    }

    fun createPlaylist(name: String, first: Song? = null): Playlist {
        val p =
            Playlist(
                id = UUID.randomUUID().toString().take(8),
                name = name.trim().ifBlank { "Playlist baru" },
                songs = listOfNotNull(first),
                createdAt = System.currentTimeMillis(),
            )
        mutate { d -> d.copy(playlists = listOf(p) + d.playlists) }
        return p
    }

    fun renamePlaylist(id: String, name: String) =
        mutate { d -> d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it }) }

    fun deletePlaylist(id: String) = mutate { d -> d.copy(playlists = d.playlists.filterNot { it.id == id }) }

    /** @return false bila lagu sudah ada di playlist */
    fun addToPlaylist(id: String, song: Song): Boolean {
        val target = _data.value.playlists.firstOrNull { it.id == id } ?: return false
        if (target.songs.any { it.id == song.id }) return false
        mutate { d -> d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(songs = it.songs + song) else it }) }
        return true
    }

    fun removeFromPlaylist(id: String, songId: String) =
        mutate { d ->
            d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(songs = it.songs.filterNot { s -> s.id == songId }) else it })
        }

    // ---------------------------------------------------------------- artis

    fun isFollowing(id: String): Boolean = _data.value.artists.any { it.id == id }

    fun toggleArtist(ref: ArtistRef) =
        mutate { d ->
            val has = d.artists.any { it.id == ref.id }
            d.copy(artists = if (has) d.artists.filterNot { it.id == ref.id } else listOf(ref) + d.artists)
        }

    // ---------------------------------------------------------------- unduhan

    fun addDownload(item: DownloadedSong) =
        mutate { d -> d.copy(downloads = listOf(item) + d.downloads.filterNot { it.song.id == item.song.id }) }

    fun removeDownload(id: String) = mutate { d -> d.copy(downloads = d.downloads.filterNot { it.song.id == id }) }

    // ---------------------------------------------------------------- streak

    /**
     * Dipanggil setiap aplikasi dibuka. [today] = hari lokal (LocalDate.toEpochDay).
     * Hari berikutnya setelah hari terakhir: streak naik. Terlewat sehari atau lebih: api padam
     * ([LibraryData.streakLost] menyimpan angka lama untuk animasi "api hitam") dan mulai lagi dari 1.
     */
    fun touchStreak(today: Long) {
        val d = _data.value
        // sudah dihitung hari ini, atau jam HP mundur: jangan ubah apa pun
        if (d.streakDay == today || d.streakDay > today) return
        mutate { cur ->
            when {
                cur.streakDay < 0L || cur.streak <= 0 ->
                    cur.copy(streak = 1, streakBest = maxOf(cur.streakBest, 1), streakDay = today, streakLost = 0)
                cur.streakDay == today - 1L -> {
                    val next = cur.streak + 1
                    cur.copy(streak = next, streakBest = maxOf(cur.streakBest, next), streakDay = today, streakLost = 0)
                }
                else ->
                    cur.copy(streak = 1, streakBest = maxOf(cur.streakBest, cur.streak, 1), streakDay = today, streakLost = cur.streak)
            }
        }
    }

    /** Animasi api padam sudah diperlihatkan. */
    fun clearStreakLost() {
        if (_data.value.streakLost != 0) mutate { it.copy(streakLost = 0) }
    }

    // ---------------------------------------------------------------- pengaturan

    fun setTastePicks(picks: List<String>) = mutate { it.copy(tastePicks = picks.distinct()) }

    /** Ganti seluruh isi pustaka (dipakai saat memulihkan cadangan). */
    fun replaceAll(newData: LibraryData) = mutate { newData }

    fun snapshot(): LibraryData = _data.value

    fun setPrivateSession(on: Boolean) = mutate { it.copy(privateSession = on) }

    fun setAutoplay(on: Boolean) = mutate { it.copy(autoplay = on) }
}
