package com.alterlist.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.GenreTags
import com.alterlist.app.data.recap

/** Rekap musikmu (mirip Wrapped): dihitung sepenuhnya di HP dari statistik putar. */
@Composable
fun StatsScreen(padding: PaddingValues, onBack: () -> Unit) {
    val app = AlterApp.instance
    val lib by app.library.data.collectAsState()
    val recap = remember(lib.stats, lib.liked, lib.downloads) { lib.recap() }
    BackHandler(onBack = onBack)

    LazyColumn(Modifier.fillMaxSize().background(AlterColors.Bg), contentPadding = padding) {
        item {
            Box(
                Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF5A0A2E), Color(0xFF2A1250), AlterColors.Bg))).padding(bottom = 18.dp),
            ) {
                Column {
                    Row(Modifier.padding(start = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconBtn(R.drawable.ic_chevron_left, onBack)
                    }
                    Text("Rekap musikmu", style = T.screen, modifier = Modifier.padding(horizontal = 20.dp))
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
                        BigStat("Pemutaran", animatedCount(recap.totalPlays).toString(), Modifier.weight(1f))
                        BigStat("Menit", animatedCount(recap.minutes.toInt()).toString(), Modifier.weight(1f))
                        BigStat("Artis", animatedCount(recap.uniqueArtists).toString(), Modifier.weight(1f))
                    }
                }
            }
        }
        if (recap.totalPlays == 0) {
            item { EmptyText("Belum ada data") }
            return@LazyColumn
        }

        recap.topArtists.firstOrNull()?.let { top ->
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).clip(RoundedCornerShape(20.dp)).background(AlterColors.Surface).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Artwork(top.topSong.thumbnail, Modifier.size(84.dp), CircleShape, px = 300)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("ARTIS TERATAS", style = T.tiny, color = AlterColors.RedSoft)
                        Text(top.name, style = T.hero, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("${top.plays}x diputar", style = T.small, color = AlterColors.Sub)
                    }
                }
            }
        }

        item { SectionTitle("Lagu teratas") }
        recap.topSongs.forEachIndexed { i, st ->
            item(key = "top-" + st.song.id) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).appear(i), verticalAlignment = Alignment.CenterVertically) {
                    Text("${i + 1}", style = T.hero.copy(fontWeight = FontWeight.Bold), color = if (i < 3) AlterColors.Red else AlterColors.Muted, modifier = Modifier.width(34.dp))
                    Artwork(st.song.thumbnail, Modifier.size(48.dp), RoundedCornerShape(6.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(st.song.title, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(st.song.artist, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("${st.count}x", style = T.small, color = AlterColors.Sub)
                }
            }
        }

        if (recap.topTags.isNotEmpty()) {
            item { SectionTitle("Genre favoritmu") }
            val maxTag = recap.topTags.first().second.toFloat().coerceAtLeast(1f)
            recap.topTags.forEach { (tag, n) ->
                item(key = "tag-$tag") { TagBar(tag, n, n / maxTag) }
            }
        }

        item { SectionTitle("Sumber pemutaran") }
        item {
            val total = (recap.localPlays + recap.streamPlays).coerceAtLeast(1).toFloat()
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(AlterColors.Surface3)) {
                    if (recap.streamPlays > 0) Box(Modifier.weight(recap.streamPlays / total).fillMaxSize().background(AlterColors.Red))
                    if (recap.localPlays > 0) Box(Modifier.weight(recap.localPlays / total).fillMaxSize().background(Color(0xFF3DA5FF)))
                }
                Spacer(Modifier.height(8.dp))
                Text("YouTube Music ${recap.streamPlays}x • Perangkat ${recap.localPlays}x", style = T.small, color = AlterColors.Sub)
                Text("${recap.likedCount} lagu disukai • ${recap.downloadCount} diunduh • ${recap.uniqueSongs} lagu berbeda", style = T.small, color = AlterColors.Sub, modifier = Modifier.padding(top = 4.dp))
            }
        }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
private fun BigStat(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.10f)).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = T.hero)
        Text(label, style = T.small, color = Color.White.copy(alpha = 0.7f))
    }
}

@Composable
private fun TagBar(tag: String, count: Int, fraction: Float) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(fraction) { progress.animateTo(fraction, tween(800, easing = FastOutSlowInEasing)) }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row {
            Text(tag, style = T.body, modifier = Modifier.weight(1f))
            Text("${count}x", style = T.small, color = AlterColors.Sub)
        }
        Spacer(Modifier.height(4.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(AlterColors.Surface3)) {
            Box(Modifier.fillMaxWidth(progress.value.coerceIn(0.02f, 1f)).fillMaxSize().clip(RoundedCornerShape(4.dp)).background(Color(GenreTags.colorFor(tag))))
        }
    }
}
