package com.alterlist.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** HTTP sederhana (HttpURLConnection) untuk lirik, gambar cover, dan unduhan. */
object Net {
    const val USER_AGENT = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    fun open(url: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 20_000): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs
        c.readTimeout = timeoutMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", USER_AGENT)
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        return c
    }

    suspend fun getText(url: String, headers: Map<String, String> = emptyMap()): String? =
        withContext(Dispatchers.IO) {
            val c = open(url, headers)
            try {
                if (c.responseCode !in 200..299) null else c.inputStream.bufferedReader().use { it.readText() }
            } catch (e: IOException) {
                null
            } finally {
                c.disconnect()
            }
        }

    suspend fun getBytes(url: String, headers: Map<String, String> = emptyMap(), maxBytes: Int = 8 * 1024 * 1024): ByteArray? =
        withContext(Dispatchers.IO) {
            val c = open(url, headers)
            try {
                if (c.responseCode !in 200..299) {
                    null
                } else {
                    val out = java.io.ByteArrayOutputStream()
                    val buf = ByteArray(16 * 1024)
                    c.inputStream.use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                            if (out.size() > maxBytes) throw IOException("terlalu besar")
                        }
                    }
                    out.toByteArray()
                }
            } catch (e: IOException) {
                null
            } finally {
                c.disconnect()
            }
        }
}
