package com.alterlist.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * ===========================================================================
 *  WAVE CANDY — visualizer gelombang ala FL Studio, diambil dari Audionce
 * ===========================================================================
 *
 *  Satu file, tanpa dependency tambahan (hanya Android SDK). Tempel ke proyekmu,
 *  ganti baris package di atas, selesai.
 *
 *  CARA KERJA (sama dengan Audionce):
 *   1. Menyimpan sampel audio mono terbaru di ring buffer, lalu mengambil 8192 sampel terakhir.
 *   2. TRIGGER: mencari titik di 20% awal jendela tempat gelombang naik melewati nol
 *      (dengan hysteresis supaya kebal noise), lalu memilih titik yang bentuknya paling mirip
 *      dengan gelombang frame sebelumnya (korelasi), dengan posisi pecahan. Inilah yang
 *      membuat gelombang tidak bergetar / loncat dari frame ke frame.
 *   3. Lebar jendela dibuat TETAP (80 persen dari buffer), jadi gelombang tidak melar-mengkerut.
 *   4. Menggambar sekitar 1200 titik sebagai garis lurus dengan fade di kedua tepi.
 *   5. Saat tidak memutar, gelombang berubah halus menjadi garis idle.
 *
 *  PEMAKAIAN DASAR
 *    XML   : <com.audionce.wavecandy.WaveCandyView android:id="@+id/wave"
 *                android:layout_width="match_parent" android:layout_height="220dp"
 *                android:background="#0D0D0E" />
 *    Kotlin: val wave = findViewById<WaveCandyView>(R.id.wave)
 *            wave.playing = true                    // true saat musik main, false saat pause
 *            wave.feedPcm16(shortArray, count, 2)   // suapi sampel dari audio thread mana pun
 *    Compose: AndroidView(factory = { WaveCandyView(it) }, modifier = Modifier.fillMaxWidth().height(220.dp))
 *
 *  SUMBER DATA AUDIO (pilih salah satu)
 *   A) Media3 / ExoPlayer (kualitas penuh, direkomendasikan): TeeAudioProcessor
 *        val sink = object : TeeAudioProcessor.AudioBufferSink {
 *            var ch = 2
 *            var enc = 2
 *            override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
 *                ch = channelCount; enc = encoding; wave.sampleRate = sampleRateHz
 *            }
 *            override fun handleBuffer(buffer: ByteBuffer) { wave.feedPcm(buffer, ch, enc) }
 *        }
 *        val factory = object : DefaultRenderersFactory(context) {
 *            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean,
 *                                        enableAudioTrackPlaybackParams: Boolean): AudioSink =
 *                DefaultAudioSink.Builder(context)
 *                    .setAudioProcessors(arrayOf(TeeAudioProcessor(sink))).build()
 *        }
 *        val player = ExoPlayer.Builder(context, factory).build()
 *      (API ini butuh opt-in @UnstableApi. Data tiba sedikit lebih awal dari suara yang terdengar,
 *       jadi atur wave.syncOffsetMs sekitar 100 sampai 250 sampai gelombang pas dengan suara.)
 *
 *   B) Mesin audio sendiri (AudioTrack / decoder sendiri):
 *        wave.feedPcm16(shortArray, jumlahSampel, jumlahKanal)   atau
 *        wave.feedPcmFloat(floatArray, jumlahSampel, jumlahKanal)
 *
 *   C) MediaPlayer atau pemutar apa pun lewat android.media.audiofx.Visualizer
 *      (butuh izin RECORD_AUDIO; data hanya 1024 sampel sekali ambil, jadi gelombang tampak lebih
 *       "zoom" dibanding mode A/B):
 *        val viz = Visualizer(audioSessionId)
 *        viz.captureSize = Visualizer.getCaptureSizeRange()[1]
 *        viz.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
 *            override fun onWaveFormDataCapture(v: Visualizer?, w: ByteArray, rate: Int) {
 *                wave.feedVisualizerWaveform(w)
 *            }
 *            override fun onFftDataCapture(v: Visualizer?, f: ByteArray, rate: Int) {}
 *        }, Visualizer.getMaxCaptureRate(), true, false)
 *        viz.enabled = true
 *
 *  TAMPILAN (semua opsional): waveColor, centerLineColor, showCenterLine, lineWidthPx, maxPoints.
 *  Latar belakang diatur seperti View biasa (android:background / setBackgroundColor).
 *  reset() dipanggil saat ganti lagu atau seek untuk mengosongkan buffer.
 */

/**
 * Wave Candy: trigger stabil (korelasi dengan frame sebelumnya + posisi pecahan) dan lebar jendela tetap.
 * Ini terjemahan langsung dari createWaveEngine() di versi HTML.
 */
class WaveCandyEngine(private val searchFrac: Float) {
    private val refN = 128
    private val maxCand = 48
    private val ref = FloatArray(refN)
    private val seg = FloatArray(refN)
    private val cand = FloatArray(maxCand)
    private var hasRef = false
    private var outStart = 0f
    private var xs = FloatArray(0)
    private var ys = FloatArray(0)

    private fun sampleAt(data: FloatArray, p: Float): Float {
        val k = Math.floor(p.toDouble()).toInt()
        val a = if (k >= 0 && k < data.size) data[k] else 0f
        val b = if (k + 1 >= 0 && k + 1 < data.size) data[k + 1] else 0f
        return a + (b - a) * (p - k.toFloat())
    }

    private fun findStart(data: FloatArray) {
        val n = data.size
        val searchEnd = Math.floor((n * searchFrac).toDouble()).toInt()

        var peak = 0f
        var q = 0
        while (q < n) {
            val v = Math.abs(data[q])
            if (v > peak) peak = v
            q += 4
        }
        if (peak < 1e-5f) {
            outStart = 0f
            return
        }

        val h = peak * 0.04f
        var cnt = 0
        var armed = false
        for (j in 1 until searchEnd) {
            val a = data[j - 1]
            val b = data[j]
            if (a < -h) armed = true
            if (armed && a < 0f && b >= 0f) {
                cand[cnt % maxCand] = (j - 1).toFloat() + (-a) / (b - a)
                cnt++
                armed = false
            }
        }
        if (cnt == 0) {
            outStart = 0f
            return
        }

        val count = Math.min(cnt, maxCand)
        val span = Math.min(1024, n - searchEnd - 2)
        val stepR = (span - 1).toFloat() / (refN - 1).toFloat()
        var best = cand[(cnt - 1) % maxCand]

        if (hasRef) {
            var bestScore = Float.NEGATIVE_INFINITY
            for (c in 0 until count) {
                val pos = cand[c]
                var dot = 0f
                var en = 0f
                for (k in 0 until refN) {
                    val v = sampleAt(data, pos + k * stepR)
                    dot += v * ref[k]
                    en += v * v
                }
                val score = dot / Math.sqrt((en + 1e-12f).toDouble()).toFloat()
                if (score > bestScore) {
                    bestScore = score
                    best = pos
                }
            }
        }

        var en2 = 0f
        for (k in 0 until refN) {
            val v = sampleAt(data, best + k * stepR)
            seg[k] = v
            en2 += v * v
        }
        val inv = 1f / Math.sqrt((en2 / refN + 1e-12f).toDouble()).toFloat()
        for (k in 0 until refN) {
            val v = seg[k] * inv
            ref[k] = if (hasRef) ref[k] * 0.5f + v * 0.5f else v
        }
        hasRef = true
        outStart = best
    }

    /** Mengisi out dengan segmen garis (x0,y0,x1,y1 ...). Mengembalikan jumlah float yang terisi. */
    fun buildLines(data: FloatArray, x0: Float, midY: Float, w: Float, halfH: Float, maxPts: Int, out: FloatArray): Int {
        findStart(data)
        val n = data.size
        val win = (n - Math.floor((n * searchFrac).toDouble()).toInt() - 1).toFloat()
        val points = Math.min(Math.max(8, maxPts), out.size / 4)
        if (xs.size < points) {
            xs = FloatArray(points)
            ys = FloatArray(points)
        }
        val step = win / points.toFloat()
        val edge = Math.floor(points * 0.05).toInt()
        for (i in 0 until points) {
            var s = sampleAt(data, outStart + i * step)
            if (i < edge) s *= i.toFloat() / edge.toFloat()
            else if (i > points - edge) s *= (points - i).toFloat() / edge.toFloat()
            xs[i] = x0 + (i.toFloat() / points.toFloat()) * w
            ys[i] = midY + s * halfH * 0.88f
        }
        var o = 0
        for (i in 0 until points - 1) {
            out[o++] = xs[i]
            out[o++] = ys[i]
            out[o++] = xs[i + 1]
            out[o++] = ys[i + 1]
        }
        return o
    }
}

/** View Wave Candy siap pakai. Thread-safe untuk metode feed*(): boleh dipanggil dari audio thread. */
class WaveCandyView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        /** Jumlah sampel yang dianalisis per frame (sama dengan Audionce). */
        const val WINDOW = 8192
        private const val RING = 1 shl 16
        private const val RING_MASK = (RING - 1).toLong()
    }

    // ------------------------------------------------------------------ pengaturan tampilan
    var waveColor: Int = 0xFFFF3344.toInt()
    var centerLineColor: Int = 0x1FFF3344
    var showCenterLine: Boolean = true
    var lineWidthPx: Float = 2f
    var maxPoints: Int = 1200

    // ------------------------------------------------------------------ pengaturan audio
    /** Sample rate audio yang disuapkan (dipakai untuk menghitung syncOffsetMs). */
    var sampleRate: Int = 44100

    /** Mundurkan tampilan sekian milidetik supaya sinkron dengan suara yang benar-benar terdengar. */
    var syncOffsetMs: Int = 0

    /** true saat musik diputar. Saat false, gelombang berubah halus menjadi garis idle. */
    @Volatile
    var playing: Boolean = false
        set(value) {
            field = value
            if (value) postInvalidateOnAnimation()
        }

    // ------------------------------------------------------------------ internal
    private val ring = FloatArray(RING)
    @Volatile private var ringWrite: Long = 0L

    private var engine = WaveCandyEngine(0.2f)
    private var data = FloatArray(WINDOW)
    private var sinTab = FloatArray(WINDOW)
    private var cosTab = FloatArray(WINDOW)
    private var lines = FloatArray(4 * 1300)
    private var idleMix = 1f
    private var lastNs = 0L

    private val snapLock = Any()
    private var snapshot = FloatArray(0)
    private var snapshotCount = 0
    @Volatile private var snapshotMode = false
    private var visTmp = FloatArray(0)

    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.SQUARE
    }
    private val centerPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
    }

    init {
        buildTables(WINDOW)
    }

    private fun buildTables(n: Int) {
        sinTab = FloatArray(n)
        cosTab = FloatArray(n)
        val k = (PI * 12.0 / n.toDouble()).toFloat()
        for (i in 0 until n) {
            sinTab[i] = sin(i * k)
            cosTab[i] = cos(i * k)
        }
    }

    private fun resizeData(n: Int) {
        if (data.size != n) {
            data = FloatArray(n)
            buildTables(n)
        }
    }

    // ------------------------------------------------------------------ menyuapi data
    /** Sampel mono float -1..1. */
    fun feed(samples: FloatArray, count: Int = samples.size) {
        snapshotMode = false
        var w = ringWrite
        val n = Math.min(count, samples.size)
        for (i in 0 until n) {
            ring[(w and RING_MASK).toInt()] = samples[i]
            w++
        }
        ringWrite = w
    }

    /** PCM 16-bit ter-interleave (L,R,L,R...) dalam ShortArray. count = jumlah Short yang valid. */
    fun feedPcm16(samples: ShortArray, count: Int, channels: Int) {
        snapshotMode = false
        val ch = if (channels < 1) 1 else channels
        val total = Math.min(count, samples.size)
        val frames = total / ch
        var w = ringWrite
        var idx = 0
        for (f in 0 until frames) {
            var sum = 0
            for (c in 0 until ch) {
                sum += samples[idx].toInt()
                idx++
            }
            ring[(w and RING_MASK).toInt()] = sum.toFloat() / (32768f * ch)
            w++
        }
        ringWrite = w
    }

    /** PCM float ter-interleave dalam FloatArray. count = jumlah float yang valid. */
    fun feedPcmFloat(samples: FloatArray, count: Int, channels: Int) {
        snapshotMode = false
        val ch = if (channels < 1) 1 else channels
        val total = Math.min(count, samples.size)
        val frames = total / ch
        var w = ringWrite
        var idx = 0
        for (f in 0 until frames) {
            var sum = 0f
            for (c in 0 until ch) {
                sum += samples[idx]
                idx++
            }
            ring[(w and RING_MASK).toInt()] = sum / ch
            w++
        }
        ringWrite = w
    }

    /** Buffer PCM little-endian. encoding: 2 = PCM 16-bit, 4 = PCM float (nilai sama dengan C.ENCODING_PCM_*). */
    fun feedPcm(buffer: ByteBuffer, channels: Int, encoding: Int) {
        val b = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val ch = if (channels < 1) 1 else channels
        var w = ringWrite
        if (encoding == 4) {
            val frames = b.remaining() / (4 * ch)
            for (f in 0 until frames) {
                var sum = 0f
                for (c in 0 until ch) sum += b.getFloat()
                ring[(w and RING_MASK).toInt()] = sum / ch
                w++
            }
        } else if (encoding == 2) {
            val frames = b.remaining() / (2 * ch)
            for (f in 0 until frames) {
                var sum = 0
                for (c in 0 until ch) sum += b.getShort().toInt()
                ring[(w and RING_MASK).toInt()] = sum.toFloat() / (32768f * ch)
                w++
            }
        } else {
            return
        }
        snapshotMode = false
        ringWrite = w
    }

    fun feedPcm16(buffer: ByteBuffer, channels: Int) {
        feedPcm(buffer, channels, 2)
    }

    /** Mode snapshot: satu potongan gelombang utuh (mis. dari Visualizer) langsung dijadikan jendela. */
    fun submitSnapshot(samples: FloatArray, count: Int = samples.size) {
        val n = Math.min(count, samples.size)
        if (n < 64) return
        synchronized(snapLock) {
            if (snapshot.size < n) snapshot = FloatArray(n)
            System.arraycopy(samples, 0, snapshot, 0, n)
            snapshotCount = n
            snapshotMode = true
        }
        postInvalidateOnAnimation()
    }

    /** Waveform dari android.media.audiofx.Visualizer (8-bit unsigned). */
    fun feedVisualizerWaveform(bytes: ByteArray) {
        if (visTmp.size != bytes.size) visTmp = FloatArray(bytes.size)
        for (i in bytes.indices) {
            visTmp[i] = ((bytes[i].toInt() and 0xFF) - 128) / 128f
        }
        submitSnapshot(visTmp, visTmp.size)
    }

    /** Kosongkan buffer (panggil saat ganti lagu atau seek). */
    fun reset() {
        ringWrite = 0L
        java.util.Arrays.fill(ring, 0f)
        engine = WaveCandyEngine(0.2f)
        snapshotMode = false
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ menggambar
    private fun readRing(dest: FloatArray): Boolean {
        val written = ringWrite
        if (written <= 0L) return false
        var delay = (syncOffsetMs.toLong() * sampleRate.toLong()) / 1000L
        val maxDelay = (RING - dest.size - 1024).toLong()
        if (delay < 0L) delay = 0L
        if (delay > maxDelay) delay = maxDelay
        val end = written - delay
        val start = end - dest.size.toLong()
        for (i in dest.indices) {
            val idx = start + i.toLong()
            dest[i] = if (idx < 0L) 0f else ring[(idx and RING_MASK).toInt()]
        }
        return true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (playing) postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = paddingLeft.toFloat()
        val top = paddingTop.toFloat()
        val w = (width - paddingLeft - paddingRight).toFloat()
        val h = (height - paddingTop - paddingBottom).toFloat()
        if (w <= 8f || h <= 8f) return

        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1.0e9f).coerceIn(0f, 0.1f)
        lastNs = now

        // 1) ambil data
        var got = false
        if (playing) {
            if (snapshotMode) {
                synchronized(snapLock) {
                    val c = snapshotCount
                    if (c >= 64) {
                        resizeData(c)
                        System.arraycopy(snapshot, 0, data, 0, c)
                        got = true
                    }
                }
            } else {
                resizeData(WINDOW)
                got = readRing(data)
            }
        }
        if (!got) java.util.Arrays.fill(data, 0f)

        // 2) transisi halus antara musik dan animasi idle
        val target = if (got) 0f else 1f
        idleMix += (target - idleMix) * (1f - Math.exp((-dt / 0.15f).toDouble()).toFloat())
        if (idleMix < 0.002f) idleMix = 0f else if (idleMix > 0.998f) idleMix = 1f
        if (idleMix > 0f) {
            val tt = SystemClock.uptimeMillis() / 2000.0
            val cs = cos(tt).toFloat()
            val sn = sin(tt).toFloat()
            val keep = 1f - idleMix
            val amp = 0.015f * idleMix
            for (i in 0 until data.size) {
                data[i] = data[i] * keep + amp * (sinTab[i] * cs + cosTab[i] * sn)
            }
        }

        // 3) gambar
        val pts = Math.min(maxPoints, w.toInt())
        if (lines.size < (pts + 1) * 4) lines = FloatArray((pts + 1) * 4)
        wavePaint.color = waveColor
        wavePaint.strokeWidth = lineWidthPx
        val n = engine.buildLines(data, left, top + h / 2f, w, h / 2f, pts, lines)
        canvas.drawLines(lines, 0, n, wavePaint)
        if (showCenterLine) {
            centerPaint.color = centerLineColor
            canvas.drawLine(left, top + h / 2f, left + w, top + h / 2f, centerPaint)
        }

        // lanjut animasi hanya jika perlu (hemat baterai saat idle)
        if (playing || idleMix < 1f) postInvalidateOnAnimation()
    }
}
