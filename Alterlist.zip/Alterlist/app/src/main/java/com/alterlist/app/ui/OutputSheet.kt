package com.alterlist.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.system.OutputKind

fun outputIcon(kind: OutputKind): Int =
    when (kind) {
        OutputKind.BLUETOOTH -> R.drawable.ic_bluetooth
        OutputKind.WIRED, OutputKind.USB -> R.drawable.ic_headphones
        OutputKind.PHONE -> R.drawable.ic_phone
        OutputKind.HDMI, OutputKind.OTHER -> R.drawable.ic_speaker
    }

/** Pil kecil di pemutar penuh: menunjukkan keluaran audio aktif (mis. "JBL Flip 6"). Ketuk untuk membuka daftar perangkat. */
@Composable
fun OutputPill(modifier: Modifier = Modifier) {
    val ui = LocalUi.current
    val active by AlterApp.instance.audioOutput.active.collectAsState()
    GlassChip(onClick = { ui.outputOpen = true }, modifier = modifier) {
        Ic(outputIcon(active.kind), tint = if (active.isBluetooth) Color(0xFF6FB6FF) else Color.White, size = 16.dp)
        Text(active.name, style = T.small, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 180.dp))
    }
}

/** Daftar perangkat audio yang tersambung (speaker ponsel, earphone, Bluetooth) dan pintasan pengaturannya. */
@Composable
fun OutputSheet(onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val devices by app.audioOutput.devices.collectAsState()
    val active by app.audioOutput.active.collectAsState()

    fun open(action: String) {
        try {
            context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            context.toast("Tidak bisa membuka pengaturan")
        }
        onDismiss()
    }

    BottomSheetDialog(onDismiss) {
        Text("Putar di perangkat", style = T.section, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        devices.forEach { d ->
            val on = d.id == active.id
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(CircleShape).background(if (on) AlterColors.Red else AlterColors.Surface3),
                    contentAlignment = Alignment.Center,
                ) { Ic(outputIcon(d.kind), tint = Color.White, size = 22.dp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(d.name, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (on) "Sedang dipakai • ${d.kind.label}" else d.kind.label, style = T.small, color = if (on) AlterColors.RedSoft else AlterColors.Sub)
                }
                if (on) PlayingBars(color = AlterColors.Red)
            }
        }
        Text(
            "Alterlist mendeteksi speaker atau earphone Bluetooth secara otomatis. Sambungkan perangkat dari pengaturan Bluetooth, lalu musik pindah sendiri.",
            style = T.small,
            color = AlterColors.Sub,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
        MenuItem(R.drawable.ic_bluetooth, "Pengaturan Bluetooth") { open(Settings.ACTION_BLUETOOTH_SETTINGS) }
        MenuItem(R.drawable.ic_speaker, "Pengaturan suara") { open(Settings.ACTION_SOUND_SETTINGS) }
    }
}
