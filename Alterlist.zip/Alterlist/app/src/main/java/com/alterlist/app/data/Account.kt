package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AccountMode { UNSET, GUEST, GOOGLE }

/** Data login YouTube Music (cookie dari WebView). Tersimpan hanya di HP, tanpa server. */
data class AccountSession(
    val cookie: String,
    val visitorData: String?,
    val dataSyncId: String?,
    val authUser: String,
)

data class AccountState(
    val mode: AccountMode = AccountMode.UNSET,
    val name: String = "",
    val email: String = "",
    val photo: String? = null,
)

class AccountStore(context: Context) {
    private val prefs = context.getSharedPreferences("alterlist_account", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<AccountState> = _state.asStateFlow()

    private fun readState(): AccountState {
        val mode =
            when (prefs.getString("mode", null)) {
                "google" -> if (prefs.getString("cookie", null).isNullOrBlank()) AccountMode.GUEST else AccountMode.GOOGLE
                "guest" -> AccountMode.GUEST
                else -> AccountMode.UNSET
            }
        return AccountState(
            mode = mode,
            name = prefs.getString("name", "").orEmpty(),
            email = prefs.getString("email", "").orEmpty(),
            photo = prefs.getString("photo", null),
        )
    }

    fun session(): AccountSession? {
        if (_state.value.mode != AccountMode.GOOGLE) return null
        val cookie = prefs.getString("cookie", null)?.takeIf { it.isNotBlank() } ?: return null
        return AccountSession(
            cookie = cookie,
            visitorData = prefs.getString("visitorData", null),
            dataSyncId = prefs.getString("dataSyncId", null),
            authUser = prefs.getString("authUser", null) ?: "0",
        )
    }

    fun chooseGuest() {
        prefs.edit().putString("mode", "guest").apply()
        _state.value = readState()
    }

    fun saveGoogle(session: AccountSession, info: AccountInfo?) {
        prefs.edit()
            .putString("mode", "google")
            .putString("cookie", session.cookie)
            .putString("visitorData", session.visitorData)
            .putString("dataSyncId", session.dataSyncId)
            .putString("authUser", session.authUser)
            .putString("name", info?.name.orEmpty())
            .putString("email", info?.email.orEmpty())
            .putString("photo", info?.photo)
            .apply()
        _state.value = readState()
    }

    fun signOut() {
        prefs.edit()
            .putString("mode", "guest")
            .remove("cookie")
            .remove("visitorData")
            .remove("dataSyncId")
            .remove("authUser")
            .remove("name")
            .remove("email")
            .remove("photo")
            .apply()
        _state.value = readState()
    }
}
