package com.alterlist.app.system

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.File
import java.io.FileOutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/**
 * Log galat dan jejak peristiwa aplikasi, disimpan di penyimpanan privat aplikasi (tidak dikirim ke mana pun).
 *
 *  - Crash (pengecualian yang tidak tertangkap) ditulis lengkap dengan stack trace sebelum proses mati.
 *  - Galat yang tertangkap (pemutar, SoundCloud, notifikasi game) dan jejak ringkas (pergantian lagu, memori) dicatat.
 *  - Saat aplikasi dibuka lagi, alasan berakhirnya proses sebelumnya dibaca dari sistem (Android 11+): crash,
 *    crash native, dimatikan karena memori habis, dll. Ini membedakan crash kode dari proses yang dibunuh sistem.
 *
 * Dibuka dari Pengaturan > Log dan galat (lihat, salin, atau unduh sebagai .txt).
 */
object AppLog {
    private const val MAX_BYTES = 600_000L
    private val STAMP: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")

    private lateinit var appContext: Context
    private lateinit var file: File
    private lateinit var old: File
    private val lock = Any()

    private val ready get() = ::file.isInitialized

    fun init(context: Context) {
        if (ready) return
        appContext = context.applicationContext
        val dir = File(appContext.filesDir, "log").apply { mkdirs() }
        file = File(dir, "alterlist.log")
        old = File(dir, "alterlist.old.log")

        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { crash(thread, error) }
            previous?.uncaughtException(thread, error)
        }

        i("Aplikasi", header())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) runCatching { logPreviousExit() }
    }

    // ---------------------------------------------------------------- menulis

    fun i(tag: String, msg: String) = write('I', tag, msg, null)

    fun w(tag: String, msg: String) = write('W', tag, msg, null)

    fun e(tag: String, msg: String, t: Throwable? = null) = write('E', tag, msg, t)

    /** Catat baris memori (heap aplikasi dan RAM kosong perangkat). */
    fun mem(tag: String) = i(tag, memLine())

    fun memLine(): String {
        if (!ready) return ""
        return try {
            val rt = Runtime.getRuntime()
            val used = (rt.totalMemory() - rt.freeMemory()) / 1_048_576
            val max = rt.maxMemory() / 1_048_576
            val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            "memori: heap $used/$max MB, RAM kosong ${mi.availMem / 1_048_576} MB (ambang ${mi.threshold / 1_048_576} MB, menipis=${mi.lowMemory})"
        } catch (e: Throwable) {
            "memori: tidak terbaca"
        }
    }

    /** Dipanggil dari penangkap crash. Ditulis sinkron karena proses akan segera mati. */
    private fun crash(thread: Thread, error: Throwable) {
        val sb = StringBuilder()
        sb.append("\n==================== CRASH ====================\n")
        sb.append(stamp()).append("  thread=").append(thread.name).append('\n')
        sb.append(memLine()).append('\n')
        sb.append(stackOf(error))
        sb.append("===============================================\n\n")
        append(sb.toString())
    }

    private fun write(level: Char, tag: String, msg: String, t: Throwable?) {
        if (!ready) return
        val sb = StringBuilder()
        sb.append(stamp()).append(' ').append(level).append('/').append(tag).append(": ").append(msg).append('\n')
        if (t != null) sb.append(stackOf(t))
        append(sb.toString())
    }

    private fun append(text: String) {
        synchronized(lock) {
            try {
                if (file.length() > MAX_BYTES) {
                    old.delete()
                    file.renameTo(old)
                }
                FileOutputStream(file, true).use { it.write(text.toByteArray(Charsets.UTF_8)) }
            } catch (e: Throwable) {
                // log tidak boleh pernah menjadi sumber masalah baru
            }
        }
    }

    private fun stamp(): String = LocalDateTime.now().format(STAMP)

    private fun stackOf(t: Throwable): String {
        val sw = StringWriter()
        t.printStackTrace(PrintWriter(sw))
        return sw.toString()
    }

    private fun header(): String {
        val v =
            try {
                val p = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
                "${p.versionName} (${p.longVersionCode})"
            } catch (e: Throwable) {
                "?"
            }
        return "Alterlist $v, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}, ${memLine()}"
    }

    // ---------------------------------------------------------------- alasan proses sebelumnya berakhir

    @RequiresApi(Build.VERSION_CODES.R)
    private fun logPreviousExit() {
        val am = appContext.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val prefs = appContext.getSharedPreferences("applog", Context.MODE_PRIVATE)
        val last = prefs.getLong("lastExitTs", 0L)
        var newest = last
        for (x in am.getHistoricalProcessExitReasons(appContext.packageName, 0, 6).sortedBy { it.timestamp }) {
            if (x.timestamp <= last) continue
            newest = maxOf(newest, x.timestamp)
            val reason =
                when (x.reason) {
                    1 -> "keluar sendiri (EXIT_SELF)"
                    2 -> "dibunuh sinyal / sistem (SIGNALED)"
                    3 -> "dimatikan karena memori habis (LOW_MEMORY)"
                    4 -> "CRASH (pengecualian Java)"
                    5 -> "CRASH NATIVE"
                    6 -> "tidak merespons (ANR)"
                    7 -> "gagal inisialisasi"
                    8 -> "izin diubah"
                    9 -> "pemakaian sumber daya berlebihan"
                    10 -> "ditutup pengguna"
                    11 -> "dihentikan paksa pengguna"
                    12 -> "ketergantungan mati"
                    13 -> "lainnya (OTHER)"
                    14 -> "dibekukan sistem (FREEZER)"
                    15 -> "status paket berubah"
                    16 -> "paket diperbarui"
                    else -> "tidak diketahui (${x.reason})"
                }
            val whenText = LocalDateTime.ofInstant(Instant.ofEpochMilli(x.timestamp), ZoneId.systemDefault()).format(STAMP)
            val importance =
                when (x.importance) {
                    100 -> "latar depan"
                    125 -> "layanan latar depan"
                    200 -> "terlihat"
                    230 -> "terasa"
                    300 -> "layanan"
                    400 -> "tersimpan (cache)"
                    else -> x.importance.toString()
                }
            val line = "Proses sebelumnya berakhir pada $whenText: $reason, proses=${x.processName}, prioritas=$importance, rss=${x.rss / 1024} MB, ${x.description.orEmpty()}"
            if (x.reason in 2..6 || x.reason == 9) e("Proses", line) else i("Proses", line)
        }
        prefs.edit().putLong("lastExitTs", newest).apply()
    }

    // ---------------------------------------------------------------- membaca / mengelola

    fun sizeBytes(): Long = synchronized(lock) { (if (ready && file.exists()) file.length() else 0L) + (if (ready && old.exists()) old.length() else 0L) }

    /** Seluruh log (lama lalu baru). */
    fun readAll(): String =
        synchronized(lock) {
            if (!ready) return ""
            buildString {
                if (old.exists()) append(old.readText(Charsets.UTF_8))
                if (file.exists()) append(file.readText(Charsets.UTF_8))
            }
        }

    /** [maxChars] karakter terakhir dari log, dipotong di awal baris. */
    fun readTail(maxChars: Int): String {
        val all = readAll()
        if (all.length <= maxChars) return all
        val cut = all.substring(all.length - maxChars)
        return cut.substringAfter('\n', cut)
    }

    private val crashMarker = Regex("={20} CRASH ={20}")
    private val errorLine = Regex("""^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d{3} E/""")

    fun crashCount(): Int = crashMarker.findAll(readAll()).count()

    fun errorCount(): Int = readAll().lineSequence().count { errorLine.containsMatchIn(it) }

    fun clear() {
        synchronized(lock) {
            if (!ready) return
            runCatching { file.delete() }
            runCatching { old.delete() }
        }
        i("Aplikasi", "Log dihapus")
    }

    /** Tulis seluruh log ke [uri] (dipilih pengguna lewat penyimpan berkas). */
    fun exportTo(context: Context, uri: Uri): Boolean =
        try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                out.write(("Log Alterlist, diekspor ${stamp()}\n${header()}\n\n").toByteArray(Charsets.UTF_8))
                out.write(readAll().toByteArray(Charsets.UTF_8))
            } != null
        } catch (e: Throwable) {
            false
        }
}
