package com.alterlist.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import com.alterlist.app.data.Category
import com.alterlist.app.data.Entry
import com.alterlist.app.data.Song

/** Halaman yang ditumpuk di atas tab (Beranda / Cari / Koleksi). */
sealed interface Route {
    data class Browse(val entry: Entry) : Route

    data class CategoryPage(val category: Category) : Route

    data class LocalPlaylist(val id: String) : Route

    data object Liked : Route

    data object Downloads : Route

    data object Recent : Route

    data object Settings : Route

    data object Login : Route

    data object Local : Route

    data object Stats : Route

    data object About : Route
}

/** Status UI global (menu lagu, dialog, navigasi) yang bisa dipakai dari layar mana pun. */
class UiController {
    var menuSong by mutableStateOf<Song?>(null)
    var menuPlaylistId by mutableStateOf<String?>(null)
    var addToPlaylistSong by mutableStateOf<Song?>(null)
    var createPlaylistOpen by mutableStateOf(false)
    var createPlaylistSong by mutableStateOf<Song?>(null)
    var sleepOpen by mutableStateOf(false)
    var fxOpen by mutableStateOf(false)
    var outputOpen by mutableStateOf(false)
    var infoSong by mutableStateOf<Song?>(null)
    var queueSaveOpen by mutableStateOf(false)

    var navigate: (Route) -> Unit = {}
    var openPlayer: () -> Unit = {}
    var closePlayer: () -> Unit = {}

    /** Pindah ke tab "Perangkat" (musik lokal). */
    var goLocal: () -> Unit = {}

    fun openMenu(song: Song, playlistId: String? = null) {
        menuSong = song
        menuPlaylistId = playlistId
    }
}

val LocalUi = staticCompositionLocalOf { UiController() }
