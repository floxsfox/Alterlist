package com.alterlist.app.system

import java.io.File

/**
 * Pembaca beban CPU dan GPU "sebisanya". Android tidak punya API publik untuk ini, jadi dibaca dari berkas sistem
 * (/proc dan /sys). Banyak ponsel memblokir sebagian berkas itu untuk aplikasi biasa, jadi tiap sumber dicoba
 * berurutan dan yang pertama berhasil dipakai terus. Kalau tidak ada yang terbaca, hasilnya null (UI menampilkan "tidak tersedia").
 */
object SystemMonitor {
    /** Satu pembacaan. Nilai 0..100, null = tidak bisa dibaca di ponsel ini. [estimated] true = dihitung dari frekuensi, bukan beban asli. */
    data class Load(val percent: Float?, val estimated: Boolean)

    data class Reading(val cpu: Load, val gpu: Load)

    private var lastTotal = -1L
    private var lastBusy = -1L
    private var procStatBroken = false
    private var gpuSourceIndex = -1
    private var gpuBroken = false
    private var lastGpuBusy = -1L
    private var lastGpuTotal = -1L

    private fun read(path: String): String? =
        try {
            File(path).readText().trim().takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            null
        }

    private fun num(path: String): Long? = read(path)?.substringBefore(' ')?.trim()?.toLongOrNull()

    fun sample(): Reading = Reading(cpu(), gpu())

    // ---------------------------------------------------------------- CPU

    private fun cpu(): Load {
        if (!procStatBroken) {
            val line = read("/proc/stat")?.lineSequence()?.firstOrNull { it.startsWith("cpu ") }
            if (line == null) {
                procStatBroken = true
            } else {
                val v = line.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                if (v.size >= 4) {
                    val idle = v[3] + (v.getOrNull(4) ?: 0L)
                    val total = v.sum()
                    val busy = total - idle
                    val out =
                        if (lastTotal >= 0 && total > lastTotal) {
                            ((busy - lastBusy).toFloat() / (total - lastTotal).toFloat() * 100f).coerceIn(0f, 100f)
                        } else {
                            null
                        }
                    lastTotal = total
                    lastBusy = busy
                    if (out != null) return Load(out, estimated = false)
                    return Load(null, estimated = false)
                }
            }
        }
        // cadangan: rata-rata frekuensi inti CPU terhadap frekuensi maksimumnya
        var cur = 0L
        var max = 0L
        for (i in 0 until Runtime.getRuntime().availableProcessors().coerceAtMost(16)) {
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val m = num(base + "cpuinfo_max_freq") ?: continue
            val c = num(base + "scaling_cur_freq") ?: continue
            cur += c
            max += m
        }
        return if (max > 0) Load((cur.toFloat() / max.toFloat() * 100f).coerceIn(0f, 100f), estimated = true) else Load(null, estimated = true)
    }

    // ---------------------------------------------------------------- GPU

    /** Daftar sumber GPU; tiap sumber mengembalikan persen atau null bila tidak terbaca. Urutan: beban asli dulu, lalu frekuensi. */
    private val gpuSources: List<() -> Load?> =
        listOf(
            // Qualcomm Adreno
            { num("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")?.let { Load(it.toFloat().coerceIn(0f, 100f), false) } },
            { num("/sys/kernel/gpu/gpu_busy")?.let { Load(it.toFloat().coerceIn(0f, 100f), false) } },
            {
                val parts = read("/sys/class/kgsl/kgsl-3d0/gpubusy")?.split(Regex("\\s+"))?.mapNotNull { it.toLongOrNull() }
                if (parts != null && parts.size >= 2) {
                    val busy = parts[0]
                    val total = parts[1]
                    val out =
                        if (lastGpuTotal >= 0 && total != lastGpuTotal) {
                            ((busy - lastGpuBusy).toFloat() / (total - lastGpuTotal).toFloat() * 100f).coerceIn(0f, 100f)
                        } else if (total > 0) {
                            (busy.toFloat() / total.toFloat() * 100f).coerceIn(0f, 100f)
                        } else {
                            null
                        }
                    lastGpuBusy = busy
                    lastGpuTotal = total
                    out?.let { Load(it, false) }
                } else {
                    null
                }
            },
            // MediaTek
            {
                read("/sys/kernel/ged/hal/gpu_utilization")?.let { t ->
                    Regex("(\\d{1,3})").find(t)?.groupValues?.get(1)?.toFloatOrNull()?.let { Load(it.coerceIn(0f, 100f), false) }
                }
            },
            // Mali (Samsung / lainnya)
            { num("/sys/class/misc/mali0/device/utilization")?.let { Load(it.toFloat().coerceIn(0f, 100f), false) } },
            { num("/sys/devices/platform/mali.0/utilization")?.let { Load(it.toFloat().coerceIn(0f, 100f), false) } },
            // cadangan: frekuensi GPU terhadap maksimum lewat devfreq
            {
                val dirs = File("/sys/class/devfreq").listFiles()?.filter {
                    val n = it.name.lowercase()
                    "gpu" in n || "mali" in n || "kgsl" in n
                }
                var out: Load? = null
                if (dirs != null) {
                    for (d in dirs) {
                        val c = num(d.path + "/cur_freq")
                        val m = num(d.path + "/max_freq")
                        if (c != null && m != null && m > 0) {
                            out = Load((c.toFloat() / m.toFloat() * 100f).coerceIn(0f, 100f), true)
                            break
                        }
                    }
                }
                out
            },
            {
                val c = num("/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq") ?: num("/sys/class/kgsl/kgsl-3d0/gpuclk")
                val m = num("/sys/class/kgsl/kgsl-3d0/devfreq/max_freq") ?: num("/sys/class/kgsl/kgsl-3d0/max_gpuclk")
                if (c != null && m != null && m > 0) Load((c.toFloat() / m.toFloat() * 100f).coerceIn(0f, 100f), true) else null
            },
        )

    private fun gpu(): Load {
        if (gpuBroken) return Load(null, false)
        if (gpuSourceIndex >= 0) {
            val r = runCatching { gpuSources[gpuSourceIndex]() }.getOrNull()
            if (r?.percent != null) return r
        }
        for (i in gpuSources.indices) {
            val r = runCatching { gpuSources[i]() }.getOrNull()
            if (r?.percent != null) {
                gpuSourceIndex = i
                return r
            }
        }
        // tidak ada sumber yang bisa dibaca: berhenti mencoba supaya tidak membuang waktu setiap detik
        if (gpuSourceIndex < 0) gpuBroken = true
        return Load(null, false)
    }
}
