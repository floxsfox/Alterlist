package com.alterlist.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * "Gravity" untuk mini player: saat daftar digulir cepat, mini player ikut terdorong seperti benda yang punya massa.
 *
 * - Gulir ke bawah (isi bergerak naik) cepat  -> mini player terangkat ke atas.
 * - Gulir ke atas (isi bergerak turun) cepat  -> mini player tertarik turun.
 * - Gulir berhenti -> mini player jatuh kembali ke posisi semula dengan pantulan pegas.
 *
 * Besar dorongan sebanding dengan kecepatan gulir. Connection ini pasif (tidak mengonsumsi scroll apa pun),
 * jadi aman dipasang di atas semua layar.
 */
@Stable
class ScrollGravity(
    private val scope: CoroutineScope,
    private val maxLiftPx: Float,
    private val maxDropPx: Float,
) {
    /** Offset vertikal saat ini dalam piksel (negatif = naik). Dibaca di fase layout supaya kaca ikut sinkron. */
    val offset = Animatable(0f)

    /** Target dorongan; dikumpulkan oleh [rememberScrollGravity] lalu dianimasikan dengan pegas. */
    var target by mutableFloatStateOf(0f)
        private set

    private var velocity = 0f
    private var lastNs = 0L
    private var settleJob: Job? = null

    val connection: NestedScrollConnection =
        object : NestedScrollConnection {
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                onScrolled(consumed.y)
                return Offset.Zero
            }
        }

    private fun onScrolled(dy: Float) {
        if (dy == 0f) return
        val now = System.nanoTime()
        // selang antar-event dibatasi supaya satu event yang telat tidak dianggap kecepatan raksasa
        val dt = ((now - lastNs) / 1_000_000_000f).coerceIn(MIN_DT, MAX_DT)
        lastNs = now
        // dy < 0: isi naik (pengguna menggulir ke bawah); dy > 0: isi turun (menggulir ke atas)
        val instant = dy / dt
        velocity = velocity * 0.55f + instant * 0.45f
        target =
            if (abs(velocity) < DEAD_ZONE) {
                0f
            } else {
                (velocity * GAIN).coerceIn(-maxLiftPx, maxDropPx)
            }
        settleJob?.cancel()
        settleJob =
            scope.launch {
                delay(SETTLE_DELAY_MS)
                velocity = 0f
                target = 0f
            }
    }

    private companion object {
        const val GAIN = 0.022f
        const val DEAD_ZONE = 450f
        const val MIN_DT = 0.008f
        const val MAX_DT = 0.050f
        const val SETTLE_DELAY_MS = 90L
    }
}

@Composable
fun rememberScrollGravity(): ScrollGravity {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val gravity =
        remember(density) {
            ScrollGravity(
                scope = scope,
                maxLiftPx = with(density) { 26.dp.toPx() },
                maxDropPx = with(density) { 14.dp.toPx() },
            )
        }
    LaunchedEffect(gravity) {
        snapshotFlow { gravity.target }.collectLatest { t ->
            if (t == 0f) {
                // jatuh kembali: pegas lembut dengan pantulan kecil, terasa seperti gravitasi
                gravity.offset.animateTo(0f, spring(dampingRatio = 0.42f, stiffness = 190f))
            } else {
                // terdorong: respons cepat mengikuti kecepatan jari
                gravity.offset.animateTo(t, spring(dampingRatio = 0.62f, stiffness = 420f))
            }
        }
    }
    return gravity
}
