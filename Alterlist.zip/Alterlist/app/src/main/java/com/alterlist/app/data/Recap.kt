package com.alterlist.app.data

/** Ringkasan kebiasaan mendengarkan (layar Rekap, mirip "Wrapped"). Dihitung dari statistik di HP. */
data class Recap(
    val totalPlays: Int,
    val uniqueSongs: Int,
    val uniqueArtists: Int,
    val minutes: Long,
    val localPlays: Int,
    val streamPlays: Int,
    val topSongs: List<PlayStat>,
    val topArtists: List<ArtistStat>,
    val topTags: List<Pair<String, Int>>,
    val likedCount: Int,
    val downloadCount: Int,
)

fun LibraryData.recap(): Recap {
    val all = stats.values.toList()
    var minutes = 0L
    var local = 0
    var stream = 0
    val tags = HashMap<String, Int>()
    for (s in all) {
        val sec = s.song.durationSeconds ?: 210
        minutes += s.count.toLong() * sec / 60L
        if (s.song.isLocal) local += s.count else stream += s.count
        for (t in GenreTags.infer(s.song)) tags[t] = (tags[t] ?: 0) + s.count
    }
    return Recap(
        totalPlays = all.sumOf { it.count },
        uniqueSongs = all.size,
        uniqueArtists = all.map { primaryArtist(it.song.artist).lowercase() }.filter { it.isNotBlank() }.toSet().size,
        minutes = minutes,
        localPlays = local,
        streamPlays = stream,
        topSongs = all.sortedWith(compareByDescending<PlayStat> { it.count }.thenByDescending { it.last }).take(10),
        topArtists = topArtists(8, includeLocal = true),
        topTags = tags.entries.sortedByDescending { it.value }.take(8).map { it.key to it.value },
        likedCount = liked.size,
        downloadCount = downloads.size,
    )
}
