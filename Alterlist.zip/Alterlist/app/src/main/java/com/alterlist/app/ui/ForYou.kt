package com.alterlist.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.R
import com.alterlist.app.data.GenreTags
import com.alterlist.app.data.RecoMix
import com.alterlist.app.data.Song
import kotlin.math.abs

/** Judul bagian "Untuk Kamu": tombol segarkan (berputar saat memuat) dan tombol putar radio. */
@Composable
fun ForYouHeader(subtitle: String, loading: Boolean, onRefresh: () -> Unit, onPlay: () -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "refreshSpin")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "spin")
    Row(modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Ic(R.drawable.ic_sparkle, tint = AlterColors.Red, size = 20.dp)
                Spacer(Modifier.width(8.dp))
                Text("Untuk Kamu", style = T.section)
            }
            Text(subtitle, style = T.small, color = AlterColors.Sub, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        IconBtn(
            R.drawable.ic_refresh,
            onRefresh,
            tint = AlterColors.Sub,
            size = 22.dp,
            modifier = Modifier.graphicsLayer { rotationZ = if (loading) angle else 0f },
        )
        Box(
            Modifier.padding(end = 10.dp).size(44.dp).clip(CircleShape).background(AlterColors.Red).bounceClick(onClick = onPlay),
            contentAlignment = Alignment.Center,
        ) { Ic(R.drawable.ic_play, tint = Color.White, size = 24.dp) }
    }
}

/** Kartu besar yang bisa digeser dan berhenti di tengah (mirip FYP). Kartu di tengah sedikit lebih besar. */
@Composable
fun ForYouCarousel(songs: List<Song>, reasons: Map<String, String>, onPlay: (Int) -> Unit) {
    val state = rememberLazyListState()
    LazyRow(
        state = state,
        flingBehavior = rememberSnapFlingBehavior(state),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, song ->
            val tag = reasons[song.id] ?: GenreTags.infer(song).firstOrNull()?.let { "Genre $it" } ?: "Rekomendasi"
            Box(
                Modifier
                    .width(250.dp)
                    .height(330.dp)
                    .graphicsLayer {
                        val info = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == i }
                        val s =
                            if (info == null) {
                                0.92f
                            } else {
                                val viewportCenter = (state.layoutInfo.viewportStartOffset + state.layoutInfo.viewportEndOffset) / 2f
                                val itemCenter = info.offset + info.size / 2f
                                1f - 0.07f * (abs(itemCenter - viewportCenter) / info.size).coerceIn(0f, 1f)
                            }
                        scaleX = s
                        scaleY = s
                    }
                    .clip(RoundedCornerShape(28.dp))
                    .bounceClick { onPlay(i) },
            ) {
                Artwork(song.thumbnail, Modifier.fillMaxSize(), RoundedCornerShape(0.dp), px = 600)
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent, Color.Black.copy(alpha = 0.88f))),
                    ),
                )
                Text(
                    tag,
                    style = T.tiny.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier =
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.45f))
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                )
                Row(Modifier.align(Alignment.BottomStart).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(song.title, style = T.hero.copy(fontSize = 20.sp), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, style = T.body, color = Color.White.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(
                        Modifier.padding(start = 10.dp).size(46.dp).clip(CircleShape).background(AlterColors.Red),
                        contentAlignment = Alignment.Center,
                    ) { Ic(R.drawable.ic_play, tint = Color.White, size = 24.dp) }
                }
            }
        }
    }
}

/** Kartu Daily Mix: kolase 4 cover + warna khas + nama mix. */
@Composable
fun DailyMixTile(mix: RecoMix, onClick: () -> Unit) {
    Column(Modifier.width(166.dp).clip(RoundedCornerShape(10.dp)).bounceClick(onClick = onClick)) {
        Box(Modifier.size(166.dp).clip(RoundedCornerShape(10.dp))) {
            val covers = mix.songs.mapNotNull { it.thumbnail }.distinct().take(4)
            Column(Modifier.fillMaxSize()) {
                for (row in 0 until 2) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (col in 0 until 2) {
                            Artwork(covers.getOrNull(row * 2 + col), Modifier.weight(1f).fillMaxSize(), RoundedCornerShape(0.dp), px = 200)
                        }
                    }
                }
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(mix.color).copy(alpha = 0.30f), Color(mix.color).copy(alpha = 0.92f))),
                ),
            )
            Text(
                mix.name,
                style = T.title.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(mix.blurb, style = T.small, color = AlterColors.Sub, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

/** Baris kerangka pemuatan untuk rak horizontal. */
@Composable
fun SkeletonShelf(count: Int = 4, size: androidx.compose.ui.unit.Dp = 142.dp) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        repeat(count) {
            Column {
                ShimmerBox(Modifier.size(size), RoundedCornerShape(8.dp))
                Spacer(Modifier.height(8.dp))
                ShimmerBox(Modifier.width(size * 0.8f).height(12.dp))
                Spacer(Modifier.height(5.dp))
                ShimmerBox(Modifier.width(size * 0.5f).height(10.dp))
            }
        }
    }
}
