package com.alterlist.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alterlist.app.fx.EqPreset
import com.alterlist.app.fx.EqualizerFx

private val BAND_LABELS = listOf("60 Hz", "230 Hz", "910 Hz", "3,6 kHz", "14 kHz")

/** Equalizer 5 pita + bass booster + virtualizer + penguat volume. Dipakai di tab "Equalizer" pada panel Efek. */
@Composable
fun EqualizerContent() {
    val eq by EqualizerFx.state.collectAsState()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Aktifkan equalizer", style = T.title)
            Text(if (eq.enabled) "Menyesuaikan nada semua lagu" else "Mati", style = T.small, color = AlterColors.Sub)
        }
        AlterSwitch(eq.enabled) { EqualizerFx.setEnabled(it) }
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        EqPreset.entries.forEach { p -> AlterChip(p.label, eq.enabled && eq.preset == p, { EqualizerFx.applyPreset(p) }) }
    }

    val curveColor = if (eq.enabled) AlterColors.Red else AlterColors.Muted
    Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF151518))) {
        Canvas(Modifier.fillMaxSize()) {
            val pad = 18.dp.toPx()
            val mid = size.height / 2f
            drawLine(Color.White.copy(alpha = 0.10f), Offset(0f, mid), Offset(size.width, mid), 2f)
            val colW = size.width / EqualizerFx.BANDS
            val pts = eq.levels.mapIndexed { i, db -> Offset(colW * (i + 0.5f), dbToY(db, size.height, pad)) }
            val path = Path()
            pts.forEachIndexed { i, p ->
                if (i == 0) {
                    path.moveTo(p.x, p.y)
                } else {
                    val prev = pts[i - 1]
                    val cx = (prev.x + p.x) / 2f
                    path.cubicTo(cx, prev.y, cx, p.y, p.x, p.y)
                }
            }
            drawPath(path, curveColor, style = Stroke(width = 5f, cap = StrokeCap.Round))
        }
        Row(Modifier.fillMaxSize()) {
            for (i in 0 until EqualizerFx.BANDS) {
                BandTrack(eq.levels.getOrElse(i) { 0f }, eq.enabled, Modifier.weight(1f).fillMaxHeight()) { EqualizerFx.setBand(i, it) }
            }
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        BAND_LABELS.forEachIndexed { i, label ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label, style = T.tiny, color = AlterColors.Sub)
                Text("%+.0f dB".format(eq.levels.getOrElse(i) { 0f }), style = T.tiny.copy(fontWeight = FontWeight.Bold), color = Color.White)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    EffectSlider("Bass booster", "${(eq.bass * 100).toInt()}%", eq.bass) { EqualizerFx.setBass(it) }
    EffectSlider("Virtualizer (suara melebar)", "${(eq.virtualizer * 100).toInt()}%", eq.virtualizer) { EqualizerFx.setVirtualizer(it) }
    EffectSlider("Penguat volume", "+${(eq.loudness * 9).toInt()} dB", eq.loudness) { EqualizerFx.setLoudness(it) }
    Text(
        "Bass, virtualizer, dan penguat volume memakai efek bawaan Android; hasilnya bisa sedikit berbeda antar HP.",
        style = T.tiny,
        color = AlterColors.Muted,
    )
}

private fun dbToY(db: Float, height: Float, pad: Float): Float {
    val t = ((db + EqualizerFx.RANGE_DB) / (2f * EqualizerFx.RANGE_DB)).coerceIn(0f, 1f)
    return pad + (1f - t) * (height - 2f * pad)
}

private fun yToDb(y: Float, height: Float, pad: Float): Float {
    val t = 1f - ((y - pad) / (height - 2f * pad).coerceAtLeast(1f)).coerceIn(0f, 1f)
    val db = t * 2f * EqualizerFx.RANGE_DB - EqualizerFx.RANGE_DB
    return Math.round(db).toFloat() // langkah 1 dB
}

@Composable
private fun BandTrack(db: Float, enabled: Boolean, modifier: Modifier, onChange: (Float) -> Unit) {
    var h by remember { mutableFloatStateOf(1f) }
    val current by rememberUpdatedState(onChange)
    val active = if (enabled) AlterColors.Red else AlterColors.Muted
    Box(
        modifier
            .onSizeChanged { h = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { o -> current(yToDb(o.y, h, 18.dp.toPx())) } }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { o -> current(yToDb(o.y, h, 18.dp.toPx())) },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        current(yToDb(change.position.y, h, 18.dp.toPx()))
                    },
                )
            },
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val pad = 18.dp.toPx()
            val x = size.width / 2f
            drawLine(Color.White.copy(alpha = 0.16f), Offset(x, pad), Offset(x, size.height - pad), 4f, StrokeCap.Round)
            val y = dbToY(db, size.height, pad)
            drawLine(active.copy(alpha = 0.85f), Offset(x, size.height / 2f), Offset(x, y), 4f, StrokeCap.Round)
            drawCircle(Color.White, 9.dp.toPx(), Offset(x, y))
            drawCircle(active, 5.dp.toPx(), Offset(x, y))
        }
    }
}
