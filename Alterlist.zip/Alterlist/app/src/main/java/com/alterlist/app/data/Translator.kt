package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Bahasa tujuan terjemahan lirik. */
data class TranslateLang(val code: String, val label: String)

val TRANSLATE_LANGS =
    listOf(
        TranslateLang("id", "Indonesia"),
        TranslateLang("en", "English"),
        TranslateLang("ms", "Melayu"),
        TranslateLang("es", "Español"),
        TranslateLang("ja", "日本語"),
        TranslateLang("ko", "한국어"),
    )

/**
 * Terjemahan lirik lewat internet (layanan terjemahan Google tanpa kunci). Hasil disimpan di cache supaya
 * lagu yang sama tidak diterjemahkan dua kali. Mengembalikan null bila lirik sudah berbahasa tujuan atau gagal.
 */
class Translator(context: Context) {
    private val dir = File(context.cacheDir, "translations").apply { mkdirs() }

    private fun fileFor(songId: String, lang: String) = File(dir, songId.replace(Regex("[^A-Za-z0-9_-]"), "_") + "_" + lang + ".json")

    fun cacheBytes(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    fun clearCache() {
        dir.listFiles()?.forEach { it.delete() }
    }

    suspend fun translate(songId: String, lines: List<String>, lang: String): List<String>? =
        withContext(Dispatchers.IO) {
            val cache = fileFor(songId, lang)
            if (cache.exists()) {
                runCatching {
                    val arr = JSONArray(cache.readText())
                    if (arr.length() == 0) return@withContext null
                    return@withContext List(arr.length()) { arr.getString(it) }
                }
            }
            val idx = lines.indices.filter { lines[it].isNotBlank() && lines[it] != "♪" }
            if (idx.isEmpty()) return@withContext null
            val out = MutableList(lines.size) { "" }
            var detected = ""
            var start = 0
            while (start < idx.size) {
                // satu permintaan = beberapa baris (maks ~900 karakter)
                var end = start
                var chars = 0
                while (end < idx.size && (end - start) < 25 && chars + lines[idx[end]].length < 900) {
                    chars += lines[idx[end]].length + 1
                    end++
                }
                if (end == start) end = start + 1
                val batch = idx.subList(start, end)
                val result = requestBatch(batch.map { lines[it].replace('\n', ' ') }, lang) ?: return@withContext null
                if (detected.isEmpty()) detected = result.second
                batch.forEachIndexed { i, lineIndex -> out[lineIndex] = result.first.getOrElse(i) { "" } }
                start = end
            }
            if (detected.equals(lang, ignoreCase = true) || detected.substringBefore('-').equals(lang, ignoreCase = true)) {
                runCatching { cache.writeText("[]") }
                return@withContext null
            }
            runCatching { cache.writeText(JSONArray(out).toString()) }
            out
        }

    /** @return pasangan (terjemahan per baris, kode bahasa asal) atau null bila gagal */
    private fun requestBatch(texts: List<String>, lang: String): Pair<List<String>, String>? {
        val joined = texts.joinToString("\n")
        val url =
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$lang&dt=t&q=" +
                URLEncoder.encode(joined, "UTF-8")
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 10000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            if (conn.responseCode != 200) return null
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONArray(body)
            val segs = root.getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) sb.append(segs.getJSONArray(i).optString(0, ""))
            val detected = if (root.length() > 2) root.optString(2, "") else ""
            val parts = sb.toString().split("\n")
            if (parts.size >= texts.size) {
                Pair(parts.take(texts.size).map { it.trim() }, detected)
            } else {
                // jumlah baris tidak cocok: terjemahkan satu per satu
                val single = texts.map { t -> requestSingle(t, lang) ?: "" }
                Pair(single, detected)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun requestSingle(text: String, lang: String): String? =
        try {
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=$lang&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 10000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val segs = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until segs.length()) sb.append(segs.getJSONArray(i).optString(0, ""))
            sb.toString().trim()
        } catch (e: Exception) {
            null
        }
}
