package com.alterlist.app.system

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Memantau koneksi internet. [online] false berarti tidak ada jaringan sama sekali (mode pesawat, tanpa sinyal, dll).
 * Beranda dan pencarian berhenti memuat data online selama [online] false, lalu otomatis lanjut saat sinyal kembali.
 */
class NetworkMonitor(context: Context) {
    private val manager: ConnectivityManager? = context.getSystemService(ConnectivityManager::class.java)

    private val _online = MutableStateFlow(computeOnline())
    val online: StateFlow<Boolean> = _online.asStateFlow()

    private val _metered = MutableStateFlow(computeMetered())

    /** True saat memakai data seluler (berkuota). */
    val metered: StateFlow<Boolean> = _metered.asStateFlow()

    init {
        try {
            manager?.registerDefaultNetworkCallback(
                object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        _online.value = true
                        _metered.value = computeMetered()
                    }

                    override fun onLost(network: Network) {
                        _online.value = computeOnline()
                        _metered.value = computeMetered()
                    }

                    override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                        _online.value = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        _metered.value = !networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                    }
                },
            )
        } catch (e: Exception) {
            // tanpa izin / layanan tidak tersedia: anggap online supaya aplikasi tetap berfungsi
        }
    }

    private fun computeOnline(): Boolean {
        val cm = manager ?: return true
        return try {
            val net = cm.activeNetwork ?: return false
            cm.getNetworkCapabilities(net)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } catch (e: Exception) {
            true
        }
    }

    private fun computeMetered(): Boolean {
        val cm = manager ?: return false
        return try {
            cm.isActiveNetworkMetered
        } catch (e: Exception) {
            false
        }
    }
}
