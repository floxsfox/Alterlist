package com.alterlist.app.data

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import java.io.IOException
import java.net.URLEncoder
import java.util.Locale

/** Awalan id lagu SoundCloud. Id lagu YouTube adalah videoId polos, lagu perangkat memakai "local:". */
const val SC_PREFIX = "sc:"

/** Awalan browseId untuk artis dan playlist SoundCloud (halaman detailnya dimuat oleh [SoundCloud.browsePage]). */
const val SC_USER_PREFIX = "scu:"
const val SC_PLAYLIST_PREFIX = "scp:"

/**
 * Sumber musik kedua: SoundCloud TIDAK RESMI lewat NewPipeExtractor ([ScNewPipe]), padanan InnerTubeX untuk SoundCloud.
 * Lagu diputar penuh (bukan cuplikan), stream HLS didukung, dan lagunya bisa diunduh. Pemanggilan ke NewPipe dikunci
 * hanya ke ServiceList.SoundCloud supaya tidak bentrok dengan InnerTubeX.
 *
 * Pembagian tugas:
 *  - pencarian lagu, lagu mirip, dan stream: NewPipeExtractor (bila pencarian NewPipe gagal, dipakai pencarian cadangan
 *    langsung ke api-v2 supaya hasil tetap muncul);
 *  - pencarian artis / playlist dan isi halaman artis / playlist: api-v2 langsung dengan Client ID (dari Pengaturan atau
 *    dicari otomatis). Lagu-lagunya tetap diputar dan diunduh lewat NewPipeExtractor.
 */
class SoundCloud(private val settings: AppSettings) {
    private val json = Json { ignoreUnknownKeys = true }

    @Volatile private var discoveredClientId: String? = null

    /** Pesan kesalahan pencarian SoundCloud terakhir (null bila berhasil). Dipakai untuk menampilkan penyebab hasil kosong. */
    @Volatile
    var lastError: String? = null
        private set

    private val base: String get() = settings.state.value.soundcloudApiBase.trimEnd('/')

    init {
        // NewPipe mencari Client ID sendiri; bila gagal, ia diberi Client ID dari sini (lihat ScNewPipe.guarded)
        ScNewPipe.clientIdSource = { force -> clientId(force) }
    }

    // ---------------------------------------------------------------- Client ID

    /** Client ID dari pengaturan; kalau kosong, dicari otomatis dari situs SoundCloud lalu diingat. */
    suspend fun clientId(forceRefresh: Boolean = false): String? {
        val configured = settings.state.value.soundcloudClientId
        if (configured.isNotBlank()) return configured
        if (!forceRefresh) discoveredClientId?.let { return it }
        val home = Net.getText("https://soundcloud.com/") ?: return null
        val scripts =
            Regex("""<script[^>]+src="(https://[^"]*sndcdn\.com/assets/[^"]+\.js)"""")
                .findAll(home)
                .map { it.groupValues[1] }
                .toList()
                .asReversed()
        for (u in scripts) {
            val js = Net.getText(u) ?: continue
            val id = Regex("""client_id\s*[:=]\s*"([A-Za-z0-9]{32})"""").find(js)?.groupValues?.get(1)
            if (id != null) {
                discoveredClientId = id
                return id
            }
        }
        return null
    }

    // ---------------------------------------------------------------- HTTP (api-v2 langsung)

    private suspend fun fetch(url: String): Pair<Int, String?> =
        withContext(Dispatchers.IO) {
            val c = Net.open(url, mapOf("Accept" to "application/json"))
            try {
                val code = c.responseCode
                if (code in 200..299) code to c.inputStream.bufferedReader().use { it.readText() } else code to null
            } catch (e: IOException) {
                -1 to null
            } finally {
                c.disconnect()
            }
        }

    private fun String.withQuery(key: String, value: String): String = this + (if (contains('?')) "&" else "?") + key + "=" + value

    /** GET dengan client_id; kalau ID otomatis ditolak (401/403), cari ID baru sekali lalu coba lagi. */
    private suspend fun get(url: String): String? {
        var id = clientId(false) ?: return null
        var r = fetch(url.withQuery("client_id", id))
        if ((r.first == 401 || r.first == 403) && settings.state.value.soundcloudClientId.isBlank()) {
            id = clientId(true) ?: return null
            r = fetch(url.withQuery("client_id", id))
        }
        return r.second
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun describe(e: Throwable): String {
        val m = e.message?.trim()?.takeIf { it.isNotEmpty() }
        val text = if (m != null) "${e.javaClass.simpleName}: $m" else e.javaClass.simpleName
        return if (text.length > 160) text.take(160) + "..." else text
    }

    // ---------------------------------------------------------------- pencarian

    /**
     * Cari di SoundCloud sesuai filter pencarian aplikasi: Lagu, Artis, atau Playlist (filter lain tidak punya padanan
     * di SoundCloud). Hasil dibungkus sebagai [Entry] supaya UI yang ada bisa memakainya apa adanya.
     */
    suspend fun search(query: String, filter: SearchFilter = SearchFilter.SONG, limit: Int = 20): List<Entry> {
        lastError = null
        return when (filter) {
            SearchFilter.SONG -> searchSongs(query, limit)
            SearchFilter.ARTIST -> direct { searchUsers(query, limit) }
            SearchFilter.PLAYLIST -> direct { searchPlaylists(query, limit) }
            else -> emptyList()
        }
    }

    private suspend fun searchSongs(query: String, limit: Int): List<Entry> {
        try {
            val viaNewPipe = ScNewPipe.search(query, limit)
            if (viaNewPipe.isNotEmpty()) return viaNewPipe
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            lastError = describe(e)
        }
        // cadangan: api-v2 langsung (metadata saja; pemutaran tetap lewat NewPipeExtractor)
        return try {
            searchTracksDirect(query, limit).also { if (it.isNotEmpty()) lastError = null }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            if (lastError == null) lastError = describe(e)
            emptyList()
        }
    }

    private suspend fun direct(block: suspend () -> List<Entry>): List<Entry> =
        try {
            block()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            lastError = describe(e)
            emptyList()
        }

    private suspend fun searchTracksDirect(query: String, limit: Int): List<Entry> {
        val body = get("$base/search/tracks?q=${enc(query)}&limit=$limit&offset=0") ?: throw IOException("SoundCloud tidak bisa dihubungi (periksa koneksi atau Client ID)")
        return items(body).mapNotNull { toTrackEntry(it) }.distinctBy { it.videoId }
    }

    private suspend fun searchUsers(query: String, limit: Int): List<Entry> {
        val body = get("$base/search/users?q=${enc(query)}&limit=$limit&offset=0") ?: throw IOException("SoundCloud tidak bisa dihubungi (periksa koneksi atau Client ID)")
        return items(body).mapNotNull { toUserEntry(it) }.distinctBy { it.browseId }
    }

    private suspend fun searchPlaylists(query: String, limit: Int): List<Entry> {
        val body = get("$base/search/playlists?q=${enc(query)}&limit=$limit&offset=0") ?: throw IOException("SoundCloud tidak bisa dihubungi (periksa koneksi atau Client ID)")
        return items(body).mapNotNull { toPlaylistEntry(it) }.distinctBy { it.browseId }
    }

    /** Lagu mirip untuk radio / putar otomatis. [pageUrl] = tautan halaman lagu (kolom uri) bila ada. */
    suspend fun related(songId: String, pageUrl: String? = null, limit: Int = 25): List<Song> {
        try {
            val viaNewPipe = ScNewPipe.related(songId, pageUrl, limit)
            if (viaNewPipe.isNotEmpty()) return viaNewPipe
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            // lanjut ke cadangan
        }
        val numeric = songId.removePrefix(SC_PREFIX).toLongOrNull() ?: return emptyList()
        return try {
            get("$base/tracks/$numeric/related?limit=$limit")?.let { b -> items(b).mapNotNull { toTrackEntry(it)?.toSong() } }.orEmpty()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            emptyList()
        }
    }

    // ---------------------------------------------------------------- halaman artis / playlist

    /** Isi halaman artis ([SC_USER_PREFIX]) atau playlist ([SC_PLAYLIST_PREFIX]) SoundCloud. */
    suspend fun browsePage(browseId: String, title: String, thumb: String?): BrowsePage {
        val id = browseId.substringAfter(':')
        return if (browseId.startsWith(SC_USER_PREFIX)) userPage(id, title, thumb) else playlistPage(id, title, thumb)
    }

    private suspend fun userPage(id: String, title: String, thumb: String?): BrowsePage {
        val user = get("$base/users/$id")?.let { runCatching { json.parseToJsonElement(it) }.getOrNull() as? JsonObject }
        val tracksBody = get("$base/users/$id/tracks?limit=50") ?: throw IOException("Lagu artis SoundCloud tidak bisa dimuat")
        val songs = items(tracksBody).mapNotNull { toTrackEntry(it)?.toSong() }.distinctBy { it.id }
        val lists =
            try {
                get("$base/users/$id/playlists_without_albums?limit=20")?.let { b -> items(b).mapNotNull { toPlaylistEntry(it) } }.orEmpty()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
        return BrowsePage(
            title = user?.str("username")?.ifBlank { null } ?: title,
            subtitle = followersText(user) ?: "SoundCloud",
            thumbnail = user?.str("avatar_url")?.replace("-large.", "-t500x500.") ?: thumb,
            songs = songs,
            shelves = if (lists.isEmpty()) emptyList() else listOf(Shelf("Playlist", lists)),
        )
    }

    private suspend fun playlistPage(id: String, title: String, thumb: String?): BrowsePage {
        val body = get("$base/playlists/$id") ?: throw IOException("Playlist SoundCloud tidak bisa dimuat")
        val o = runCatching { json.parseToJsonElement(body) }.getOrNull() as? JsonObject ?: throw IOException("Balasan SoundCloud tidak dikenali")
        val raw = (o["tracks"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
        // playlist panjang hanya memuat id untuk sebagian lagu: lengkapi per 30 id (maksimal 200 lagu)
        val missing = raw.filter { it.str("title") == null }.mapNotNull { it.num("id") }.take(200)
        val filled = HashMap<Long, JsonObject>()
        for (chunk in missing.chunked(30)) {
            val b = get("$base/tracks?ids=${chunk.joinToString(",")}") ?: continue
            items(b).forEach { t -> t.num("id")?.let { filled[it] = t } }
        }
        val songs =
            raw.mapNotNull { r ->
                val full = if (r.str("title") != null) r else r.num("id")?.let { filled[it] }
                full?.let { toTrackEntry(it)?.toSong() }
            }.distinctBy { it.id }
        val owner = (o["user"] as? JsonObject)?.str("username")
        return BrowsePage(
            title = o.str("title")?.ifBlank { null } ?: title,
            subtitle = listOfNotNull(owner, "${songs.size} lagu").joinToString(" • "),
            thumbnail = o.str("artwork_url")?.replace("-large.", "-t500x500.") ?: songs.firstOrNull()?.thumbnail ?: thumb,
            songs = songs,
            shelves = emptyList(),
        )
    }

    // ---------------------------------------------------------------- parsing JSON

    private fun items(body: String): List<JsonObject> {
        val root = runCatching { json.parseToJsonElement(body) }.getOrNull()
        val list: List<JsonElement> =
            when (root) {
                is JsonObject -> (root["collection"] as? JsonArray).orEmpty()
                is JsonArray -> root
                else -> emptyList()
            }
        return list.mapNotNull { it as? JsonObject }
    }

    private fun toTrackEntry(o: JsonObject): Entry? {
        val trackId = o.num("id") ?: return null
        val title = o.str("title")?.trim()
        if (title.isNullOrBlank()) return null
        // bukan cuplikan Go+ (SNIP) dan tidak diblokir
        if ((o["streamable"] as? JsonPrimitive)?.booleanOrNull == false) return null
        val policy = o.str("policy")
        if (policy != null && policy != "ALLOW" && policy != "MONETIZE") return null
        val user = o["user"] as? JsonObject
        val meta = o["publisher_metadata"] as? JsonObject
        val artist = meta?.str("artist")?.takeIf { it.isNotBlank() } ?: user?.str("username").orEmpty()
        val art = (o.str("artwork_url")?.takeIf { it.isNotBlank() } ?: user?.str("avatar_url"))?.replace("-large.", "-t500x500.")
        val durMs = o.num("full_duration") ?: o.num("duration")
        return Entry(
            title = title,
            subtitle = artist,
            thumbnail = art,
            videoId = SC_PREFIX + trackId,
            durationText = durMs?.let { formatDurationText(it / 1000L) },
            uri = o.str("permalink_url"),
            explicit = (meta?.get("explicit") as? JsonPrimitive)?.booleanOrNull == true,
        )
    }

    private fun toUserEntry(o: JsonObject): Entry? {
        val id = o.num("id") ?: return null
        val name = o.str("username")?.trim()
        if (name.isNullOrBlank()) return null
        return Entry(
            title = name,
            subtitle = followersText(o) ?: "SoundCloud",
            thumbnail = o.str("avatar_url")?.replace("-large.", "-t300x300."),
            browseId = SC_USER_PREFIX + id,
        )
    }

    private fun toPlaylistEntry(o: JsonObject): Entry? {
        val id = o.num("id") ?: return null
        val title = o.str("title")?.trim()
        if (title.isNullOrBlank()) return null
        val user = o["user"] as? JsonObject
        val firstTrackArt = ((o["tracks"] as? JsonArray)?.firstOrNull() as? JsonObject)?.str("artwork_url")
        val art = o.str("artwork_url")?.takeIf { it.isNotBlank() } ?: firstTrackArt?.takeIf { it.isNotBlank() } ?: user?.str("avatar_url")
        return Entry(
            title = title,
            subtitle = listOfNotNull(user?.str("username"), o.num("track_count")?.let { "$it lagu" }).joinToString(" • "),
            thumbnail = art?.replace("-large.", "-t300x300."),
            browseId = SC_PLAYLIST_PREFIX + id,
        )
    }

    private fun followersText(o: JsonObject?): String? = o?.num("followers_count")?.let { "${compactCount(it)} pengikut" }

    private fun compactCount(n: Long): String =
        when {
            n >= 1_000_000 -> "%.1f jt".format(Locale.US, n / 1_000_000.0).replace('.', ',').replace(",0 ", " ")
            n >= 1_000 -> "%.1f rb".format(Locale.US, n / 1_000.0).replace('.', ',').replace(",0 ", " ")
            else -> n.toString()
        }

    // ---------------------------------------------------------------- stream (NewPipeExtractor)

    /** Stream audio terbaik (MP3 progresif, atau HLS bila tidak ada). Melempar IOException berpesan ramah bila gagal. */
    suspend fun resolve(songId: String, pageUrl: String? = null): ScStream = ScNewPipe.resolve(songId, pageUrl)

    /** Buang alamat stream yang tersimpan (alamatnya bertanda tangan dan kedaluwarsa). */
    fun invalidate(songId: String) = ScNewPipe.invalidate(songId)

    /** Alamat playlist HLS yang sudah di-resolve, null bila lagunya bukan HLS. */
    fun cachedHls(songId: String): String? = ScNewPipe.cachedHls(songId)
}

private fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull

/** Angka JSON sebagai Long (id SoundCloud berupa angka). */
private fun JsonObject.num(key: String): Long? = (this[key] as? JsonPrimitive)?.longOrNull
