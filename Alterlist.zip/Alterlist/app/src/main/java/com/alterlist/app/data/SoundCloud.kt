package com.alterlist.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Awalan id lagu SoundCloud. Id lagu YouTube adalah videoId polos, lagu perangkat memakai "local:". */
const val SC_PREFIX = "sc:"

/**
 * Sumber musik kedua: SoundCloud (API v2 publik). Memakai Client ID dan alamat API yang sama dengan impor playlist
 * (Pengaturan > Sumber musik). Client ID kosong = dicari otomatis dari berkas JavaScript situs SoundCloud.
 *
 * Hanya stream "progressive" (MP3 lewat HTTP biasa) yang dipakai, karena pemutar tidak memuat modul HLS.
 * Lagu yang tidak punya stream progresif, diblokir, atau hanya cuplikan 30 detik disaring dari hasil pencarian.
 */
class SoundCloud(private val settings: AppSettings) {
    private val json = Json { ignoreUnknownKeys = true }

    @Volatile private var discoveredClientId: String? = null

    private class CachedUrl(val url: String, val expiresAtMs: Long)

    private val streamCache = ConcurrentHashMap<String, CachedUrl>()

    private val base: String get() = settings.state.value.soundcloudApiBase.trimEnd('/')

    // ---------------------------------------------------------------- Client ID

    /** Client ID dari pengaturan; kalau kosong, dicari otomatis dari situs SoundCloud lalu diingat. */
    suspend fun clientId(forceRefresh: Boolean = false): String? {
        val configured = settings.state.value.soundcloudClientId
        if (configured.isNotBlank()) return configured
        if (!forceRefresh) discoveredClientId?.let { return it }
        val home = Net.getText("https://soundcloud.com/") ?: return null
        val scripts =
            Regex("""<script[^>]+src="(https://[^"]*sndcdn\.com/assets/[^"]+\.js)"""")
                .findAll(home)
                .map { it.groupValues[1] }
                .toList()
                .asReversed()
        for (u in scripts) {
            val js = Net.getText(u) ?: continue
            val id = Regex("""client_id\s*[:=]\s*"([A-Za-z0-9]{32})"""").find(js)?.groupValues?.get(1)
            if (id != null) {
                discoveredClientId = id
                return id
            }
        }
        return null
    }

    // ---------------------------------------------------------------- HTTP

    private suspend fun fetch(url: String): Pair<Int, String?> =
        withContext(Dispatchers.IO) {
            val c = Net.open(url, mapOf("Accept" to "application/json"))
            try {
                val code = c.responseCode
                if (code in 200..299) code to c.inputStream.bufferedReader().use { it.readText() } else code to null
            } catch (e: IOException) {
                -1 to null
            } finally {
                c.disconnect()
            }
        }

    private fun String.withQuery(key: String, value: String): String = this + (if (contains('?')) "&" else "?") + key + "=" + value

    /** GET dengan client_id; kalau ID otomatis ditolak (401/403), cari ID baru sekali lalu coba lagi. */
    private suspend fun get(url: String): String? {
        var id = clientId(false) ?: return null
        var r = fetch(url.withQuery("client_id", id))
        if ((r.first == 401 || r.first == 403) && settings.state.value.soundcloudClientId.isBlank()) {
            id = clientId(true) ?: return null
            r = fetch(url.withQuery("client_id", id))
        }
        return r.second
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // ---------------------------------------------------------------- pencarian

    /** Cari lagu. Hasil dibungkus sebagai [Entry] (videoId = "sc:<id>") supaya UI yang ada bisa memakainya apa adanya. */
    suspend fun search(query: String, limit: Int = 20): List<Entry> {
        val body = get("$base/search/tracks?q=${enc(query)}&limit=$limit&offset=0") ?: return emptyList()
        return parseCollection(body)
    }

    /** Lagu mirip untuk radio / putar otomatis. */
    suspend fun related(songId: String, limit: Int = 25): List<Song> {
        val id = songId.removePrefix(SC_PREFIX)
        if (id.isBlank()) return emptyList()
        val body = get("$base/tracks/$id/related?limit=$limit") ?: return emptyList()
        return parseCollection(body).mapNotNull { it.toSong() }
    }

    private fun parseCollection(body: String): List<Entry> {
        val root = runCatching { json.parseToJsonElement(body) }.getOrNull()
        val items: List<JsonElement> =
            when (root) {
                is JsonObject -> (root["collection"] as? JsonArray).orEmpty()
                is JsonArray -> root
                else -> emptyList()
            }
        return items.mapNotNull { el -> (el as? JsonObject)?.let { o -> toEntry(o) } }.distinctBy { it.videoId }
    }

    private fun toEntry(o: JsonObject): Entry? {
        val trackId = o.num("id") ?: return null
        val title = o.str("title")?.trim()
        if (title.isNullOrBlank()) return null
        if (!isPlayable(o)) return null
        val user = o["user"] as? JsonObject
        val artist =
            (o["publisher_metadata"] as? JsonObject)?.str("artist")?.takeIf { it.isNotBlank() }
                ?: user?.str("username").orEmpty()
        val art = (o.str("artwork_url")?.takeIf { it.isNotBlank() } ?: user?.str("avatar_url"))?.replace("-large.", "-t300x300.")
        val durMs = o.num("full_duration") ?: o.num("duration")
        return Entry(
            title = title,
            subtitle = artist,
            thumbnail = art,
            videoId = SC_PREFIX + trackId,
            durationText = durMs?.let { formatDurationText(it / 1000L) },
            uri = o.str("permalink_url"),
        )
    }

    /** Bisa diputar penuh lewat stream progresif? (bukan cuplikan / diblokir / hanya HLS) */
    private fun isPlayable(o: JsonObject): Boolean {
        if ((o["streamable"] as? JsonPrimitive)?.booleanOrNull == false) return false
        val policy = o.str("policy")
        if (policy != null && policy != "ALLOW") return false
        val transcodings = (o["media"] as? JsonObject)?.get("transcodings") as? JsonArray ?: return true
        return transcodings.any { progressive(it as? JsonObject) }
    }

    private fun progressive(t: JsonObject?): Boolean =
        t != null && ((t["format"] as? JsonObject)?.str("protocol") == "progressive")

    // ---------------------------------------------------------------- stream

    /** Alamat audio (MP3 progresif) untuk sebuah lagu. Disimpan sementara karena alamatnya bertanda tangan dan kedaluwarsa. */
    suspend fun streamUrl(songId: String): String {
        streamCache[songId]?.let { if (it.expiresAtMs > System.currentTimeMillis()) return it.url }
        val trackId = songId.removePrefix(SC_PREFIX)
        val trackBody = get("$base/tracks/$trackId") ?: throw IOException("Data lagu SoundCloud tidak bisa diambil")
        val track = runCatching { json.parseToJsonElement(trackBody) }.getOrNull() as? JsonObject
            ?: throw IOException("Balasan SoundCloud tidak dikenali")
        val auth = track.str("track_authorization")
        val transcodings = (track["media"] as? JsonObject)?.get("transcodings") as? JsonArray
        val chosen =
            transcodings?.mapNotNull { it as? JsonObject }?.firstOrNull { progressive(it) }
                ?: throw IOException("Lagu SoundCloud ini hanya tersedia sebagai stream HLS (belum didukung)")
        val transcodingUrl = chosen.str("url") ?: throw IOException("Stream SoundCloud tidak ditemukan")
        val withAuth = if (auth.isNullOrBlank()) transcodingUrl else transcodingUrl.withQuery("track_authorization", enc(auth))
        val resolvedBody = get(withAuth) ?: throw IOException("Stream SoundCloud ditolak (coba ganti Client ID)")
        val url =
            (runCatching { json.parseToJsonElement(resolvedBody) }.getOrNull() as? JsonObject)?.str("url")
                ?: throw IOException("Alamat stream SoundCloud kosong")
        streamCache[songId] = CachedUrl(url, System.currentTimeMillis() + STREAM_TTL_MS)
        return url
    }

    fun invalidate(songId: String) {
        streamCache.remove(songId)
    }

    private companion object {
        const val STREAM_TTL_MS = 15 * 60_000L
    }
}

private fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.contentOrNull

/** Angka JSON sebagai Long (id lagu SoundCloud berupa angka). */
private fun JsonObject.num(key: String): Long? = (this[key] as? JsonPrimitive)?.longOrNull
