package com.alterlist.app.data

import kotlinx.coroutines.CancellationException

/** Awalan id lagu SoundCloud. Id lagu YouTube adalah videoId polos, lagu perangkat memakai "local:". */
const val SC_PREFIX = "sc:"

/**
 * Sumber musik kedua: SoundCloud TIDAK RESMI lewat NewPipeExtractor ([ScNewPipe]), padanan InnerTubeX untuk SoundCloud.
 * Lagu diputar penuh (bukan cuplikan), stream HLS didukung, dan lagunya bisa diunduh. Pemanggilan ke NewPipe dikunci
 * hanya ke ServiceList.SoundCloud supaya tidak bentrok dengan InnerTubeX.
 *
 * Client ID + Alamat API di Pengaturan sekarang hanya dipakai impor playlist ([clientId]); pencarian dan pemutaran
 * tidak lagi memakai API publik v2.
 */
class SoundCloud(private val settings: AppSettings) {
    @Volatile private var discoveredClientId: String? = null

    // ---------------------------------------------------------------- Client ID (untuk impor playlist)

    /** Client ID dari pengaturan; kalau kosong, dicari otomatis dari situs SoundCloud lalu diingat. */
    suspend fun clientId(forceRefresh: Boolean = false): String? {
        val configured = settings.state.value.soundcloudClientId
        if (configured.isNotBlank()) return configured
        if (!forceRefresh) discoveredClientId?.let { return it }
        val home = Net.getText("https://soundcloud.com/") ?: return null
        val scripts =
            Regex("""<script[^>]+src="(https://[^"]*sndcdn\.com/assets/[^"]+\.js)"""")
                .findAll(home)
                .map { it.groupValues[1] }
                .toList()
                .asReversed()
        for (u in scripts) {
            val js = Net.getText(u) ?: continue
            val id = Regex("""client_id\s*[:=]\s*"([A-Za-z0-9]{32})"""").find(js)?.groupValues?.get(1)
            if (id != null) {
                discoveredClientId = id
                return id
            }
        }
        return null
    }

    // ---------------------------------------------------------------- pencarian & lagu mirip

    /** Cari lagu. Hasil dibungkus sebagai [Entry] (videoId = "sc:<id>") supaya UI yang ada bisa memakainya apa adanya. */
    suspend fun search(query: String, limit: Int = 20): List<Entry> =
        try {
            ScNewPipe.search(query, limit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }

    /** Lagu mirip untuk radio / putar otomatis. [pageUrl] = tautan halaman lagu (kolom uri) bila ada. */
    suspend fun related(songId: String, pageUrl: String? = null, limit: Int = 25): List<Song> =
        try {
            ScNewPipe.related(songId, pageUrl, limit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }

    // ---------------------------------------------------------------- stream

    /** Stream audio terbaik (MP3 progresif, atau HLS bila tidak ada). Melempar IOException berpesan ramah bila gagal. */
    suspend fun resolve(songId: String, pageUrl: String? = null): ScStream = ScNewPipe.resolve(songId, pageUrl)

    /** Buang alamat stream yang tersimpan (alamatnya bertanda tangan dan kedaluwarsa). */
    fun invalidate(songId: String) = ScNewPipe.invalidate(songId)

    /** Alamat playlist HLS yang sudah di-resolve, null bila lagunya bukan HLS. */
    fun cachedHls(songId: String): String? = ScNewPipe.cachedHls(songId)
}
