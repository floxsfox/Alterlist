package com.alterlist.app.download

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile

/** Metadata yang ditulis ke berkas M4A (cover, judul, artis, album, penerbit, dll). */
class Mp4Tags(
    val title: String?,
    val artist: String?,
    val albumArtist: String? = null,
    val album: String? = null,
    val year: String? = null,
    val comment: String? = null,
    val publisher: String? = null,
    val source: String? = null,
    val cover: ByteArray? = null,
)

/**
 * Penulis tag MP4/M4A tanpa FFmpeg: menyisipkan `udta/meta/ilst` (format iTunes) ke dalam `moov`.
 * Mendukung MP4 biasa (chunk offset ikut digeser) maupun fragmented MP4 seperti yang dikirim YouTube.
 */
object Mp4Tagger {
    private class Box(val type: String, val start: Long, val headerSize: Int, val size: Long) {
        val end: Long get() = start + size
        val payloadStart: Long get() = start + headerSize
    }

    @Throws(IOException::class)
    fun tag(input: File, output: File, tags: Mp4Tags) {
        RandomAccessFile(input, "r").use { raf ->
            val top = readBoxes(raf, 0, raf.length())
            val moov = top.firstOrNull { it.type == "moov" } ?: throw IOException("Berkas ini bukan M4A/MP4 yang valid (moov tidak ada)")
            val firstMdat = top.firstOrNull { it.type == "mdat" }
            if (moov.size > 256L * 1024 * 1024) throw IOException("Header MP4 terlalu besar")

            raf.seek(moov.payloadStart)
            val moovPayload = ByteArray((moov.size - moov.headerSize).toInt())
            raf.readFully(moovPayload)

            // buang udta lama, tambahkan udta baru di akhir moov
            val children = parseChildren(moovPayload)
            val rebuilt = ByteArrayOutputStream()
            for ((type, off, len) in children) {
                if (type == "udta") continue
                rebuilt.write(moovPayload, off, len)
            }
            val newUdta = buildUdta(tags)
            rebuilt.write(newUdta)
            var newMoovPayload = rebuilt.toByteArray()

            val newMoovSize = 8L + newMoovPayload.size
            val delta = newMoovSize - moov.size

            // MP4 non-fragmented dengan moov sebelum mdat: semua chunk offset bergeser sebesar delta
            if (firstMdat != null && moov.start < firstMdat.start && delta != 0L) {
                newMoovPayload = shiftChunkOffsets(newMoovPayload, delta)
            }

            output.parentFile?.mkdirs()
            output.outputStream().buffered(256 * 1024).use { out ->
                copyRange(raf, 0, moov.start, out)
                writeBoxHeader(out, "moov", newMoovPayload.size.toLong() + 8)
                out.write(newMoovPayload)
                copyRange(raf, moov.end, raf.length(), out)
            }
        }
    }

    // ------------------------------------------------------------------ box parsing

    private fun readBoxes(raf: RandomAccessFile, from: Long, to: Long): List<Box> {
        val boxes = ArrayList<Box>()
        var pos = from
        val head = ByteArray(16)
        while (pos + 8 <= to) {
            raf.seek(pos)
            raf.readFully(head, 0, 8)
            var size = u32(head, 0)
            val type = String(head, 4, 4, Charsets.ISO_8859_1)
            var header = 8
            if (size == 1L) {
                raf.readFully(head, 8, 8)
                size = u64(head, 8)
                header = 16
            } else if (size == 0L) {
                size = to - pos
            }
            if (size < header || pos + size > to) break
            boxes.add(Box(type, pos, header, size))
            pos += size
        }
        return boxes
    }

    private data class Child(val type: String, val offset: Int, val length: Int)

    private fun parseChildren(payload: ByteArray): List<Child> {
        val list = ArrayList<Child>()
        var pos = 0
        while (pos + 8 <= payload.size) {
            var size = u32(payload, pos)
            val type = String(payload, pos + 4, 4, Charsets.ISO_8859_1)
            if (size == 1L) {
                if (pos + 16 > payload.size) break
                size = u64(payload, pos + 8)
            } else if (size == 0L) {
                size = (payload.size - pos).toLong()
            }
            if (size < 8 || pos + size > payload.size) break
            list.add(Child(type, pos, size.toInt()))
            pos += size.toInt()
        }
        return list
    }

    /** Telusuri trak -> mdia -> minf -> stbl dan geser isi stco/co64. */
    private fun shiftChunkOffsets(moovPayload: ByteArray, delta: Long): ByteArray {
        val data = moovPayload.copyOf()
        fun walk(start: Int, end: Int, path: List<String>) {
            var pos = start
            while (pos + 8 <= end) {
                var size = u32(data, pos)
                val type = String(data, pos + 4, 4, Charsets.ISO_8859_1)
                var header = 8
                if (size == 1L) { size = u64(data, pos + 8); header = 16 } else if (size == 0L) size = (end - pos).toLong()
                if (size < header || pos + size > end) return
                val bodyStart = pos + header
                val bodyEnd = (pos + size).toInt()
                when (type) {
                    "trak", "mdia", "minf", "stbl" -> walk(bodyStart, bodyEnd, path + type)
                    "stco" -> {
                        val count = u32(data, bodyStart + 4).toInt()
                        var p = bodyStart + 8
                        for (i in 0 until count) {
                            val v = u32(data, p) + delta
                            putU32(data, p, v)
                            p += 4
                        }
                    }
                    "co64" -> {
                        val count = u32(data, bodyStart + 4).toInt()
                        var p = bodyStart + 8
                        for (i in 0 until count) {
                            putU64(data, p, u64(data, p) + delta)
                            p += 8
                        }
                    }
                }
                pos = bodyEnd
            }
        }
        walk(0, data.size, emptyList())
        return data
    }

    // ------------------------------------------------------------------ box building

    private fun buildUdta(t: Mp4Tags): ByteArray {
        val ilst = ByteArrayOutputStream()
        val d = DataOutputStream(ilst)
        fun text(type: ByteArray, value: String?) {
            if (value.isNullOrBlank()) return
            ilst.write(item(type, dataBox(1, value.toByteArray(Charsets.UTF_8))))
        }
        text(byteArrayOf(0xA9.toByte(), 'n'.code.toByte(), 'a'.code.toByte(), 'm'.code.toByte()), t.title)
        text(byteArrayOf(0xA9.toByte(), 'A'.code.toByte(), 'R'.code.toByte(), 'T'.code.toByte()), t.artist)
        text("aART".toByteArray(Charsets.ISO_8859_1), t.albumArtist ?: t.artist)
        text(byteArrayOf(0xA9.toByte(), 'a'.code.toByte(), 'l'.code.toByte(), 'b'.code.toByte()), t.album)
        text(byteArrayOf(0xA9.toByte(), 'd'.code.toByte(), 'a'.code.toByte(), 'y'.code.toByte()), t.year)
        text(byteArrayOf(0xA9.toByte(), 'c'.code.toByte(), 'm'.code.toByte(), 't'.code.toByte()), t.comment)
        text(byteArrayOf(0xA9.toByte(), 't'.code.toByte(), 'o'.code.toByte(), 'o'.code.toByte()), "Alterlist")
        freeform(ilst, "PUBLISHER", t.publisher)
        freeform(ilst, "LABEL", t.publisher)
        freeform(ilst, "SOURCE", t.source)
        t.cover?.takeIf { it.isNotEmpty() }?.let { cover ->
            val isPng = cover.size > 8 && cover[0] == 0x89.toByte() && cover[1] == 'P'.code.toByte()
            ilst.write(item("covr".toByteArray(Charsets.ISO_8859_1), dataBox(if (isPng) 14 else 13, cover)))
        }
        d.flush()

        val hdlr = ByteArrayOutputStream().also { o ->
            val x = DataOutputStream(o)
            x.writeInt(33); x.write("hdlr".toByteArray(Charsets.ISO_8859_1))
            x.writeInt(0) // version + flags
            x.writeInt(0) // pre_defined
            x.write("mdir".toByteArray(Charsets.ISO_8859_1))
            x.write("appl".toByteArray(Charsets.ISO_8859_1))
            x.writeInt(0); x.writeInt(0) // reserved
            x.writeByte(0) // name terminator
            x.flush()
        }.toByteArray()

        val ilstBox = box("ilst", ilst.toByteArray())
        val metaPayload = ByteArrayOutputStream().also {
            it.write(byteArrayOf(0, 0, 0, 0)) // version + flags
            it.write(hdlr)
            it.write(ilstBox)
        }.toByteArray()
        return box("udta", box("meta", metaPayload))
    }

    private fun freeform(out: ByteArrayOutputStream, name: String, value: String?) {
        if (value.isNullOrBlank()) return
        val mean = box("mean", byteArrayOf(0, 0, 0, 0) + "com.apple.iTunes".toByteArray(Charsets.ISO_8859_1))
        val nameBox = box("name", byteArrayOf(0, 0, 0, 0) + name.toByteArray(Charsets.UTF_8))
        val data = dataBox(1, value.toByteArray(Charsets.UTF_8))
        out.write(box("----", mean + nameBox + data))
    }

    private fun item(type: ByteArray, dataBox: ByteArray): ByteArray = box(String(type, Charsets.ISO_8859_1), dataBox)

    private fun dataBox(typeIndicator: Int, payload: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        val x = DataOutputStream(o)
        x.writeInt(0x00000000 or typeIndicator) // version(1)=0 + flags(3)=typeIndicator
        x.writeInt(0) // locale
        x.write(payload)
        x.flush()
        return box("data", o.toByteArray())
    }

    private fun box(type: String, payload: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(payload.size + 8)
        val x = DataOutputStream(o)
        x.writeInt(payload.size + 8)
        x.write(type.toByteArray(Charsets.ISO_8859_1))
        x.write(payload)
        x.flush()
        return o.toByteArray()
    }

    private fun writeBoxHeader(out: OutputStream, type: String, size: Long) {
        val b = ByteArray(8)
        putU32(b, 0, size)
        val t = type.toByteArray(Charsets.ISO_8859_1)
        System.arraycopy(t, 0, b, 4, 4)
        out.write(b)
    }

    private fun copyRange(raf: RandomAccessFile, from: Long, to: Long, out: OutputStream) {
        raf.seek(from)
        val buf = ByteArray(256 * 1024)
        var remaining = to - from
        while (remaining > 0) {
            val n = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
            if (n <= 0) throw IOException("Berkas terpotong saat menyalin")
            out.write(buf, 0, n)
            remaining -= n
        }
    }

    // ------------------------------------------------------------------ bytes

    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u64(b: ByteArray, o: Int): Long = (u32(b, o) shl 32) or u32(b, o + 4)

    private fun putU32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v shr 24).toByte(); b[o + 1] = (v shr 16).toByte(); b[o + 2] = (v shr 8).toByte(); b[o + 3] = v.toByte()
    }

    private fun putU64(b: ByteArray, o: Int, v: Long) {
        putU32(b, o, v ushr 32); putU32(b, o + 4, v and 0xFFFFFFFFL)
    }

    @Suppress("unused")
    private fun InputStream.skipFully(n: Long) {
        var left = n
        while (left > 0) { val s = skip(left); if (s <= 0) break; left -= s }
    }
}
