package com.alterlist.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.animateColorAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import com.alterlist.app.data.LocalArt
import com.alterlist.app.data.Net
import com.alterlist.app.data.Song
import com.alterlist.app.data.withSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

fun formatTime(ms: Long): String {
    val total = (ms / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(total / 60L, total % 60L)
}

fun formatBytes(bytes: Long): String =
    when {
        bytes >= 1024L * 1024L * 1024L -> "%.1f GB".format(bytes / (1024.0 * 1024.0 * 1024.0))
        bytes >= 1024L * 1024L -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
        else -> "%d KB".format(bytes / 1024L)
    }

// ------------------------------------------------------------------ ikon

@Composable
fun Ic(
    @DrawableRes id: Int,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
    size: Dp = 24.dp,
) {
    Icon(painterResource(id), contentDescription = null, tint = tint, modifier = modifier.size(size))
}

@Composable
fun IconBtn(
    @DrawableRes id: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = LocalContentColor.current,
    size: Dp = 24.dp,
    box: Dp = 44.dp,
    enabled: Boolean = true,
) {
    Box(
        modifier.size(box).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Ic(id, tint = if (enabled) tint else tint.copy(alpha = 0.35f), size = size)
    }
}

// ------------------------------------------------------------------ gambar & warna

@Composable
fun Artwork(
    url: String?,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(6.dp),
    px: Int = 256,
) {
    val local = LocalArt.isLocalArt(url)
    Box(modifier.clip(shape).background(AlterColors.Surface2), contentAlignment = Alignment.Center) {
        // ikon nada selalu di bawah: tampil bila lagu tidak punya cover
        if (url == null || local) Ic(R.drawable.ic_music_note, tint = AlterColors.Muted, size = 24.dp)
        if (url != null) {
            if (local) {
                LocalArtImage(url, px.coerceAtMost(512), Modifier.fillMaxSize())
            } else {
                AsyncImage(
                    model = url.withSize(px),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
}

/** Cover lagu dari penyimpanan HP (diambil dari tag audio, di-cache di memori). */
@Composable
fun LocalArtImage(url: String, px: Int, modifier: Modifier = Modifier, alpha: Float = 1f) {
    val bmp by produceState<ImageBitmap?>(initialValue = LocalArt.cached(url, px)?.asImageBitmap(), url, px) {
        if (value == null) {
            value = withContext(Dispatchers.IO) { LocalArt.load(AlterApp.instance, url, px)?.asImageBitmap() }
        }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, alpha = alpha, modifier = modifier)
    } else {
        Box(modifier)
    }
}

private val colorCache = ConcurrentHashMap<String, Int>()

/** Warna dominan dari cover (dipakai untuk latar mini player / pemutar / halaman detail). */
@Composable
fun rememberDominantColor(url: String?, fallback: Color = AlterColors.Surface2): State<Color> {
    val state =
        produceState(initialValue = fallback, key1 = url) {
            if (url == null) {
                value = fallback
                return@produceState
            }
            val cached = colorCache[url]
            if (cached != null) {
                value = Color(cached)
                return@produceState
            }
            val computed =
                withContext(Dispatchers.IO) {
                    val bitmap = loadSmallBitmap(url) ?: return@withContext null
                    extractColor(bitmap)
                }
            if (computed != null) {
                colorCache[url] = computed
                value = Color(computed)
            }
        }
    return animateColorAsState(state.value, label = "dominant")
}

/** Rata-rata warna berbobot (lebih menyukai warna jenuh & terang), lalu digelapkan agar teks putih tetap terbaca. */
private fun extractColor(src: Bitmap): Int? {
    val small = Bitmap.createScaledBitmap(src, 24, 24, true)
    var r = 0.0
    var g = 0.0
    var b = 0.0
    var wSum = 0.0
    val hsv = FloatArray(3)
    for (y in 0 until small.height) {
        for (x in 0 until small.width) {
            val p = small.getPixel(x, y)
            android.graphics.Color.colorToHSV(p, hsv)
            val w = 0.15 + hsv[1] * hsv[2]
            r += android.graphics.Color.red(p) * w
            g += android.graphics.Color.green(p) * w
            b += android.graphics.Color.blue(p) * w
            wSum += w
        }
    }
    if (wSum <= 0.0) return null
    val avg = android.graphics.Color.rgb((r / wSum).toInt(), (g / wSum).toInt(), (b / wSum).toInt())
    android.graphics.Color.colorToHSV(avg, hsv)
    hsv[1] = (hsv[1] * 1.1f).coerceIn(0f, 0.9f)
    hsv[2] = hsv[2].coerceIn(0.28f, 0.58f)
    return android.graphics.Color.HSVToColor(hsv)
}

// ------------------------------------------------------------------ kontrol

@Composable
fun IconBtnSolid(
    @DrawableRes id: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    background: Color = Color.Black.copy(alpha = 0.45f),
    tint: Color = Color.White,
) {
    Box(
        modifier.size(38.dp).clip(CircleShape).background(background).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Ic(id, tint = tint, size = 22.dp)
    }
}

@Composable
fun AlterChip(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) AlterColors.Red else AlterColors.Surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(label, style = T.body.copy(fontWeight = FontWeight.SemiBold), color = Color.White, maxLines = 1)
    }
}

@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    container: Color = AlterColors.Red,
    content: Color = Color.White,
    @DrawableRes icon: Int? = null,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(container)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Ic(icon, tint = content, size = 20.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, style = T.button, color = content, maxLines = 1)
    }
}

@Composable
fun AlterSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val bg by animateColorAsState(if (checked) AlterColors.Red else AlterColors.Surface3, label = "switchBg")
    val pos by animateDpAsState(if (checked) 22.dp else 2.dp, label = "switchPos")
    Box(
        Modifier
            .size(width = 48.dp, height = 28.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .clickable { onCheckedChange(!checked) },
    ) {
        Box(Modifier.offset(x = pos, y = 2.dp).size(24.dp).clip(CircleShape).background(Color.White))
    }
}

/** Seek bar tipis ala Spotify. [value] 0..1. */
@Composable
fun SeekBar(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = Color.White,
    trackColor: Color = Color.White.copy(alpha = 0.25f),
    trackHeight: Dp = 4.dp,
    thumbRadius: Dp = 6.dp,
    enabled: Boolean = true,
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    val pad = with(LocalDensity.current) { thumbRadius.toPx() }
    val currentOnChange by rememberUpdatedState(onValueChange)
    val currentOnFinish by rememberUpdatedState(onValueChangeFinished)

    fun toValue(x: Float): Float = ((x - pad) / (widthPx - 2f * pad).coerceAtLeast(1f)).coerceIn(0f, 1f)

    Box(
        modifier
            .fillMaxWidth()
            .height(32.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { offset ->
                    currentOnChange(toValue(offset.x))
                    currentOnFinish()
                }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectHorizontalDragGestures(
                    onDragStart = { start ->
                        dragging = true
                        currentOnChange(toValue(start.x))
                    },
                    onDragEnd = {
                        dragging = false
                        currentOnFinish()
                    },
                    onDragCancel = {
                        dragging = false
                        currentOnFinish()
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        currentOnChange(toValue(change.position.x))
                    },
                )
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val h = trackHeight.toPx()
            val cy = size.height / 2f
            val v = value.coerceIn(0f, 1f)
            val x0 = pad
            val span = (size.width - 2f * pad).coerceAtLeast(1f)
            drawRoundRect(trackColor, Offset(x0, cy - h / 2f), Size(span, h), CornerRadius(h / 2f))
            drawRoundRect(activeColor, Offset(x0, cy - h / 2f), Size(span * v, h), CornerRadius(h / 2f))
            val r = pad * (if (dragging) 1.3f else 1f)
            drawCircle(activeColor, radius = if (enabled) r else 0f, center = Offset(x0 + span * v, cy))
        }
    }
}

// ------------------------------------------------------------------ teks & status

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, style = T.section, modifier = modifier.padding(horizontal = 16.dp, vertical = 10.dp))
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = AlterColors.Red, strokeWidth = 3.dp, modifier = Modifier.size(32.dp))
    }
}

@Composable
fun EmptyText(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 40.dp), contentAlignment = Alignment.Center) {
        Text(text, style = T.body, color = AlterColors.Sub, textAlign = TextAlign.Center)
    }
}

@Composable
fun ErrorBox(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(message, style = T.body, color = AlterColors.Sub, textAlign = TextAlign.Center)
        PillButton("Coba lagi", onRetry, container = AlterColors.Surface3)
    }
}

// ------------------------------------------------------------------ baris daftar

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(
    song: Song,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isCurrent: Boolean = false,
    playlistId: String? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    val ui = LocalUi.current
    val downloader = AlterApp.instance.downloader
    val libData by AlterApp.instance.library.data.collectAsState()
    val downloaded = remember(libData.downloads) { downloader.isDownloaded(song.id) }
    Row(
        modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = { ui.openMenu(song, playlistId) })
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(song.thumbnail, Modifier.size(50.dp), RoundedCornerShape(5.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isCurrent) {
                    PlayingBars(color = AlterColors.Red)
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    song.title,
                    style = T.title,
                    color = if (isCurrent) AlterColors.Red else Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (downloaded) {
                    Ic(R.drawable.ic_downloaded, tint = AlterColors.Red, size = 14.dp)
                    Spacer(Modifier.width(5.dp))
                } else if (song.isLocal) {
                    Ic(R.drawable.ic_phone, tint = AlterColors.Sub, size = 13.dp)
                    Spacer(Modifier.width(5.dp))
                }
                Text(
                    song.artist,
                    style = T.small,
                    color = AlterColors.Sub,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        if (trailing != null) {
            trailing()
        } else {
            IconBtn(R.drawable.ic_more_vert, { ui.openMenu(song, playlistId) }, tint = AlterColors.Sub, size = 22.dp)
        }
    }
}

/** Baris hasil pencarian: lagu, artis, album, playlist, atau video. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EntryRow(entry: Entry, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val ui = LocalUi.current
    val song = entry.toSong()
    val shape = if (entry.kind == EntryKind.ARTIST) CircleShape else RoundedCornerShape(5.dp)
    Row(
        modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = { song?.let { ui.openMenu(it) } })
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(entry.thumbnail, Modifier.size(54.dp), shape)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(entry.title, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub =
                when (entry.kind) {
                    EntryKind.ARTIST -> "Artis"
                    else -> entry.subtitle
                }
            if (sub.isNotBlank()) {
                Text(sub, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (song != null) {
            IconBtn(R.drawable.ic_more_vert, { ui.openMenu(song) }, tint = AlterColors.Sub, size = 22.dp)
        } else {
            Spacer(Modifier.width(12.dp))
        }
    }
}

fun android.content.Context.toast(message: String) {
    android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
}

/** Klik tanpa efek riak (untuk scrim dialog dan area yang tidak boleh "tembus"). */
fun Modifier.noRippleClickable(onClick: () -> Unit): Modifier =
    composed {
        clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
    }
