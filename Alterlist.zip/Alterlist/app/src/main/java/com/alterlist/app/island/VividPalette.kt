package com.alterlist.app.island

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.Color
import com.alterlist.app.ui.CoverPalette
import com.alterlist.app.ui.loadSmallBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

private val VividDefault = CoverPalette(Color(0xFFB3202A), Color(0xFF2E4BC4))

private val vividCache = ConcurrentHashMap<String, IntArray>()

/**
 * Palet cover versi "lebih jelas": rona sama dengan [com.alterlist.app.ui.rememberCoverPalette], tetapi lebih jenuh
 * dan lebih terang supaya warna album terlihat tegas di bar kecil. Kecerahan dibatasi agar teks putih tetap terbaca.
 */
@Composable
fun rememberVividPalette(url: String?): CoverPalette {
    val target by produceState(initialValue = VividDefault, key1 = url) {
        if (url == null) {
            value = VividDefault
            return@produceState
        }
        val cached = vividCache[url]
        if (cached != null) {
            value = CoverPalette(Color(cached[0]), Color(cached[1]))
            return@produceState
        }
        val computed = withContext(Dispatchers.IO) { loadSmallBitmap(url)?.let { vividFrom(it) } }
        if (computed != null) {
            vividCache[url] = computed
            value = CoverPalette(Color(computed[0]), Color(computed[1]))
        }
    }
    val p by animateColorAsState(targetValue = target.primary, animationSpec = tween(600), label = "vividPrimary")
    val s by animateColorAsState(targetValue = target.secondary, animationSpec = tween(600), label = "vividSecondary")
    return CoverPalette(p, s)
}

private fun vividFrom(src: Bitmap): IntArray {
    val small = Bitmap.createScaledBitmap(src, 24, 24, true)
    val buckets = 12
    val w = DoubleArray(buckets)
    val rs = DoubleArray(buckets)
    val gs = DoubleArray(buckets)
    val bs = DoubleArray(buckets)
    val hsv = FloatArray(3)
    for (y in 0 until small.height) {
        for (x in 0 until small.width) {
            val p = small.getPixel(x, y)
            android.graphics.Color.colorToHSV(p, hsv)
            // piksel jenuh dan terang dihitung jauh lebih berat daripada piksel kusam
            val weight = 0.03 + hsv[1] * hsv[1] * hsv[2]
            val b = (hsv[0] / 30f).toInt().coerceIn(0, buckets - 1)
            w[b] += weight
            rs[b] += android.graphics.Color.red(p) * weight
            gs[b] += android.graphics.Color.green(p) * weight
            bs[b] += android.graphics.Color.blue(p) * weight
        }
    }
    var first = 0
    for (i in 1 until buckets) if (w[i] > w[first]) first = i
    var second = -1
    for (i in 0 until buckets) {
        val dist = minOf((i - first + buckets) % buckets, (first - i + buckets) % buckets)
        if (dist < 2 || w[i] < w[first] * 0.15) continue
        if (second == -1 || w[i] > w[second]) second = i
    }

    fun toColor(i: Int, shift: Float): Int {
        if (w[i] <= 0.0) return android.graphics.Color.rgb(40, 50, 90)
        val avg = android.graphics.Color.rgb((rs[i] / w[i]).toInt(), (gs[i] / w[i]).toInt(), (bs[i] / w[i]).toInt())
        android.graphics.Color.colorToHSV(avg, hsv)
        hsv[0] = (hsv[0] + shift + 360f) % 360f
        if (hsv[1] > 0.12f) {
            hsv[1] = hsv[1].coerceIn(0.68f, 1f)
            hsv[2] = hsv[2].coerceIn(0.58f, 0.92f)
        } else {
            // cover hitam-putih tetap netral, hanya diterangkan sedikit
            hsv[2] = hsv[2].coerceIn(0.40f, 0.80f)
        }
        var c = android.graphics.Color.HSVToColor(hsv)
        val lum =
            (0.2126 * android.graphics.Color.red(c) + 0.7152 * android.graphics.Color.green(c) + 0.0722 * android.graphics.Color.blue(c)) / 255.0
        if (lum > 0.6) {
            hsv[2] = hsv[2] * (0.6 / lum).toFloat()
            c = android.graphics.Color.HSVToColor(hsv)
        }
        return c
    }

    val primary = toColor(first, 0f)
    val secondary = if (second >= 0) toColor(second, 0f) else toColor(first, 42f)
    return intArrayOf(primary, secondary)
}
