package com.alterlist.app.playback

import androidx.media3.common.C
import androidx.media3.common.Player
import com.alterlist.app.data.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Fade lembut di awal dan akhir setiap lagu (pengaturan "Fade antar lagu"). Volume pemutar diturunkan di
 * beberapa detik terakhir lalu dinaikkan lagi di awal lagu berikutnya, jadi pergantian lagu tidak terasa mendadak.
 */
class FadeController(
    private val player: Player,
    private val settings: AppSettings,
    private val scope: CoroutineScope,
) {
    private var job: Job? = null

    fun start() {
        if (job?.isActive == true) return
        job =
            scope.launch {
                var lastApplied = 1f
                while (isActive) {
                    delay(100)
                    val fadeMs = settings.state.value.fadeMs
                    val target =
                        if (fadeMs <= 0 || !player.isPlaying) {
                            1f
                        } else {
                            gain(player.currentPosition, player.duration, fadeMs.toLong())
                        }
                    if (kotlin.math.abs(target - lastApplied) > 0.004f) {
                        player.volume = target
                        lastApplied = target
                    }
                }
            }
    }

    fun stop() {
        job?.cancel()
        job = null
        player.volume = 1f
    }

    companion object {
        /** Gain 0..1 untuk posisi [positionMs] dari lagu berdurasi [durationMs]. */
        fun gain(positionMs: Long, durationMs: Long, fadeMs: Long): Float {
            if (durationMs == C.TIME_UNSET || durationMs <= 0L || fadeMs <= 0L) return 1f
            val fadeIn = minOf(fadeMs, 3_000L)
            val remaining = (durationMs - positionMs).coerceAtLeast(0L)
            val inGain = if (positionMs < fadeIn) smooth(positionMs.toFloat() / fadeIn) else 1f
            val outGain = if (remaining < fadeMs) smooth(remaining.toFloat() / fadeMs) else 1f
            return minOf(inGain, outGain).coerceIn(0f, 1f)
        }

        private fun smooth(x: Float): Float {
            val t = x.coerceIn(0f, 1f)
            return t * t * (3f - 2f * t)
        }
    }
}
