package com.alterlist.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.R

/**
 * Halaman Developer: latar gambar penuh, foto profil bulat 1:1 (sudut transparan, bukan hitam), dan nama pengembang.
 * Dibuka dari Pengaturan > Tentang > Developer.
 */
@Composable
fun DeveloperScreen(padding: PaddingValues, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(AlterColors.Bg)) {
        // latar: gambar lanskap dipotong ke layar tegak; sisi kiri (wajah karakter) yang ditampilkan
        Image(
            painterResource(R.drawable.dev_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
            alignment = Alignment.CenterStart,
        )
        // gelapkan bagian bawah supaya foto profil dan teks tetap terbaca
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.10f),
                        0.45f to Color.Black.copy(alpha = 0.25f),
                        1f to AlterColors.Bg.copy(alpha = 0.96f),
                    ),
                ),
        )

        Box(Modifier.padding(start = 12.dp, top = padding.calculateTopPadding() + 8.dp)) {
            IconBtnSolid(R.drawable.ic_chevron_left, onBack)
        }

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(start = 24.dp, end = 24.dp, bottom = padding.calculateBottomPadding() + 56.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom,
        ) {
            // foto profil 1:1, lingkaran dengan sudut transparan
            Image(
                painterResource(R.drawable.dev_avatar),
                contentDescription = "eliojioDev",
                modifier =
                    Modifier
                        .size(132.dp)
                        .clip(CircleShape)
                        .border(3.dp, Color.White.copy(alpha = 0.85f), CircleShape),
                contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.height(16.dp))
            Text("eliojioDev", style = T.hero.copy(fontSize = 30.sp), color = Color.White)
            Spacer(Modifier.height(4.dp))
            Text("Pengembang Alterlist", style = T.body, color = Color.White.copy(alpha = 0.72f))
        }
    }
}
