package com.alterlist.app.island

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.alterlist.app.AlterApp

/**
 * Layanan aksesibilitas yang HANYA dipakai untuk menggambar dynamic bar. Jendela overlay biasa
 * (TYPE_APPLICATION_OVERLAY) selalu berada di bawah status bar, sehingga ikon jam dan notifikasi menimpa bar.
 * Jendela milik layanan aksesibilitas (TYPE_ACCESSIBILITY_OVERLAY) berada di atas status bar, jadi bar bisa menutupnya
 * seperti dynamic bar resmi. Layanan ini tidak meminta event dan tidak membaca isi layar.
 */
class IslandAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AlterApp.instance.dynamicBar.onWindowSourceChanged()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        AlterApp.instance.dynamicBar.onWindowSourceChanged()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: IslandAccessibilityService? = null
            private set
    }
}
