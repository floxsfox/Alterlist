package com.alterlist.app.system

import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import com.alterlist.app.AlterApp
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Gyro bidik: gerakan ponsel diubah menjadi geseran jari virtual di area kamera/bidik game (sisi kanan layar).
 * Android tidak mengizinkan aplikasi menyuntik data sensor ke aplikasi lain, jadi satu-satunya cara tanpa root adalah
 * menggeser layar lewat layanan Aksesibilitas ([GyroAimService]).
 *
 * Stabilisasi (berlaku untuk gyro asli maupun "gyro virtual"):
 *  1. zona mati: getaran tangan di bawah ambang diabaikan,
 *  2. penghalus eksponensial: kecepatan gerak dihaluskan, kekuatannya diatur di panel,
 *  3. batas kecepatan: gerakan mendadak (mis. ponsel terguncang) tidak membuat bidikan melompat.
 *
 * Jari virtual hanya menempel saat ada gerakan dan diangkat begitu diam, supaya tidak mengunci kontrol kamera
 * game saat jari asli dipakai.
 */
object GyroAim : MotionSensor.Listener {
    private val main = Handler(Looper.getMainLooper())

    private var appContext: Context? = null
    private var active = false

    // keadaan filter
    private var vYaw = 0f
    private var vPitch = 0f

    // gerak yang belum dikirim (piksel)
    private var accX = 0f
    private var accY = 0f

    // keadaan stroke gestur
    private var stroke: GestureDescription.StrokeDescription? = null
    private var curX = 0f
    private var curY = 0f
    private var dispatching = false
    private var lastDispatchAt = 0L
    private var lastMoveAt = 0L
    private var pumping = false

    private var screenW = 0
    private var screenH = 0

    private val pumpRunnable =
        object : Runnable {
            override fun run() {
                if (!active) return
                pump()
                main.postDelayed(this, PUMP_MS)
            }
        }

    /** Jenis sensor yang dipakai di ponsel ini (untuk status di panel). */
    fun kind(context: Context): MotionSensor.Kind = MotionSensor.detect(context)

    /** Nyalakan / matikan. Dipanggil layanan overlay sesuai pengaturan, game di depan, dan panel terbuka/tertutup. */
    fun setActive(context: Context, on: Boolean) {
        val shouldRun = on && GyroAimService.instance != null
        if (shouldRun == active) return
        appContext = context.applicationContext
        if (shouldRun) {
            val (w, h) = realSize(context)
            screenW = w
            screenH = h
            vYaw = 0f
            vPitch = 0f
            accX = 0f
            accY = 0f
            stroke = null
            dispatching = false
            active = true
            MotionSensor.register(context, this)
            main.post(pumpRunnable)
        } else {
            active = false
            main.removeCallbacks(pumpRunnable)
            MotionSensor.unregister(this)
            endStroke()
        }
    }

    fun onServiceLost() {
        if (active) {
            active = false
            main.removeCallbacks(pumpRunnable)
            MotionSensor.unregister(this)
        }
        stroke = null
        dispatching = false
    }

    // ---------------------------------------------------------------- pengolahan sensor

    override fun onMotion(yawDeg: Float, pitchDeg: Float, dtSec: Float) {
        if (!active) return
        val st = AlterApp.instance.settings.state.value
        val virtual = MotionSensor.kind == MotionSensor.Kind.VIRTUAL
        // gyro virtual lebih berisik: stabilisasi minimal dinaikkan
        val smooth = if (virtual) max(st.gyroSmooth, 0.55f) else st.gyroSmooth

        val rawYaw = (yawDeg / dtSec).coerceIn(-MAX_RATE, MAX_RATE)
        val rawPitch = (pitchDeg / dtSec).coerceIn(-MAX_RATE, MAX_RATE)

        // 1) zona mati: makin kuat stabilisasi, makin besar getaran tangan yang diabaikan (derajat/detik)
        val dead = 0.35f + 2.2f * smooth
        val yaw = if (abs(rawYaw) < dead) 0f else rawYaw - dead * (if (rawYaw > 0) 1f else -1f)
        val pitch = if (abs(rawPitch) < dead) 0f else rawPitch - dead * (if (rawPitch > 0) 1f else -1f)

        // 2) penghalus eksponensial yang tidak bergantung pada laju sampel
        val tau = 0.004f + 0.075f * smooth // detik
        val a = 1f - Math.exp((-dtSec / tau).toDouble()).toFloat()
        vYaw += (yaw - vYaw) * a
        vPitch += (pitch - vPitch) * a

        // 3) derajat -> piksel. Sensitivitas 0..1 dipetakan ke 0.4x..2.0x
        val pxPerDeg = (max(screenW, screenH) / 110f) * (0.4f + 1.6f * st.gyroSensitivity)
        var dx = -vYaw * dtSec * pxPerDeg // putar ponsel ke kiri -> geser jari ke kiri (kamera menoleh kiri)
        var dy = vPitch * dtSec * pxPerDeg
        if (st.gyroInvertX) dx = -dx
        if (st.gyroInvertY) dy = -dy
        accX += dx
        accY += dy
    }

    // ---------------------------------------------------------------- gestur

    private fun pump() {
        val svc = GyroAimService.instance ?: return
        if (dispatching || pumping) return
        pumping = true
        try {
            val now = SystemClock.uptimeMillis()
            val moving = abs(accX) + abs(accY) >= MIN_MOVE_PX
            if (!moving) {
                if (stroke != null && now - lastMoveAt > IDLE_END_MS) endStroke()
                return
            }
            lastMoveAt = now

            // titik tengah area bidik: sisi kanan layar
            val cx = screenW * 0.72f
            val cy = screenH * 0.52f
            val rx = screenW * 0.11f
            val ry = screenH * 0.22f
            if (stroke == null) {
                curX = cx
                curY = cy
            }
            val tx = curX + accX
            val ty = curY + accY
            val nx = tx.coerceIn(cx - rx, cx + rx)
            val ny = ty.coerceIn(cy - ry, cy + ry)
            val hitEdge = nx != tx || ny != ty
            // sisa gerak yang melewati batas tetap disimpan untuk stroke berikutnya
            accX = tx - nx
            accY = ty - ny
            if (!hitEdge) {
                accX = 0f
                accY = 0f
            }

            val dur = (now - lastDispatchAt).coerceIn(MIN_SEG_MS, MAX_SEG_MS)
            val path = Path().apply {
                moveTo(curX, curY)
                lineTo(nx, ny)
            }
            val willContinue = !hitEdge
            val prev = stroke
            val s =
                try {
                    if (prev == null) {
                        GestureDescription.StrokeDescription(path, 0, dur, willContinue)
                    } else {
                        prev.continueStroke(path, 0, dur, willContinue)
                    }
                } catch (e: IllegalArgumentException) {
                    stroke = null
                    return
                }
            curX = nx
            curY = ny
            stroke = if (willContinue) s else null
            sendStroke(svc, s)
        } finally {
            pumping = false
        }
    }

    private fun sendStroke(svc: GyroAimService, s: GestureDescription.StrokeDescription) {
        dispatching = true
        lastDispatchAt = SystemClock.uptimeMillis()
        val ok =
            svc.dispatchGesture(
                GestureDescription.Builder().addStroke(s).build(),
                object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        dispatching = false
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        dispatching = false
                        stroke = null
                    }
                },
                null,
            )
        if (!ok) {
            dispatching = false
            stroke = null
        }
    }

    /** Angkat jari virtual (stroke yang sedang berjalan diselesaikan dengan geseran sangat kecil). */
    private fun endStroke() {
        val svc = GyroAimService.instance ?: run {
            stroke = null
            return
        }
        val prev = stroke ?: return
        stroke = null
        try {
            val path = Path().apply {
                moveTo(curX, curY)
                lineTo(min(curX + 0.5f, screenW - 1f), curY)
            }
            val last = prev.continueStroke(path, 0, MIN_SEG_MS, false)
            if (!dispatching) sendStroke(svc, last)
        } catch (e: Exception) {
            // stroke sudah selesai / tidak valid: tidak ada yang perlu dilakukan
        }
    }

    @Suppress("DEPRECATION")
    private fun realSize(context: Context): Pair<Int, Int> {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (android.os.Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private const val PUMP_MS = 16L
    private const val MIN_MOVE_PX = 0.6f
    private const val IDLE_END_MS = 90L
    private const val MIN_SEG_MS = 8L
    private const val MAX_SEG_MS = 60L
    private const val MAX_RATE = 420f
}
