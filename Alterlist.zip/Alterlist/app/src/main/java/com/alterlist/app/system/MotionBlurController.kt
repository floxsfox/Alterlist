package com.alterlist.app.system

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.WindowManager
import com.alterlist.app.AlterApp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Motion blur stabil untuk game.
 *
 * Android tidak memberi aplikasi akses ke gambar game, jadi motion blur sungguhan (menyeret piksel searah gerakan)
 * tidak mungkin. Yang dipakai adalah blur-behind milik compositor (Android 12+): satu jendela transparan tanpa sentuhan
 * di atas game dengan radius blur yang mengikuti seberapa cepat ponsel diputar. Karena blurnya merata (bukan
 * searah), tidak ada "garis panjang" di layar, dan agar tidak berkedip ada tiga peredam:
 *  - zona mati: putaran pelan tidak memicu blur,
 *  - naik cepat tapi turun pelan (seperti rana kamera), sehingga tidak berdenyut,
 *  - radius dibatasi kecil dan dibulatkan per langkah, update jendela maksimal ~30 kali per detik.
 */
@android.annotation.SuppressLint("NewApi")
class MotionBlurController(
    private val context: Context,
    private val wm: WindowManager,
) : MotionSensor.Listener {
    private val main = Handler(Looper.getMainLooper())
    private var view: View? = null
    private var params: WindowManager.LayoutParams? = null
    private var active = false
    private var level = 0f
    private var lastRadius = -1
    private var lastApplyAt = 0L
    private var testStart = 0L

    /** Perangkat mendukung blur lintas jendela? (Android 12+ dan tidak dimatikan pabrikan / mode hemat daya) */
    fun supported(): Boolean = Build.VERSION.SDK_INT >= 31 && runCatching { wm.isCrossWindowBlurEnabled }.getOrDefault(false)

    fun setActive(on: Boolean) {
        val want = on && supported()
        if (want == active) return
        active = want
        if (want) {
            attach()
            MotionSensor.register(context, this)
        } else {
            MotionSensor.unregister(this)
            level = 0f
            if (testStart == 0L) detach()
        }
    }

    /** Pratinjau 1,6 detik: blur naik lalu turun, supaya pengguna tahu apakah ponselnya mendukung. */
    fun test() {
        if (!supported()) return
        testStart = SystemClock.uptimeMillis()
        attach()
        main.post(testTick)
    }

    private val testTick =
        object : Runnable {
            override fun run() {
                val t = (SystemClock.uptimeMillis() - testStart) / 1600f
                if (t >= 1f) {
                    testStart = 0L
                    applyRadius(0f, force = true)
                    if (!active) detach()
                    return
                }
                applyRadius(sin(Math.PI * t).toFloat(), force = false)
                main.postDelayed(this, 33)
            }
        }

    override fun onMotion(yawDeg: Float, pitchDeg: Float, dtSec: Float) {
        if (!active || testStart != 0L) return
        val speed = hypot(yawDeg, pitchDeg) / max(dtSec, 0.001f) // derajat/detik
        val target = ((speed - DEAD_DEG_PER_SEC) / FULL_DEG_PER_SEC).coerceIn(0f, 1f)
        val tau = if (target > level) 0.05f else 0.20f
        level += (target - level) * (1f - Math.exp((-dtSec / tau).toDouble()).toFloat())
        applyRadius(level, force = false)
    }

    @Suppress("DEPRECATION")
    private fun attach() {
        if (view != null) return
        val v = View(context).apply { setBackgroundColor(Color.TRANSPARENT) }
        val p =
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                layoutInDisplayCutoutMode =
                    if (Build.VERSION.SDK_INT >= 30) {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    } else {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
            }
        try {
            wm.addView(v, p)
            view = v
            params = p
            lastRadius = -1
        } catch (e: Exception) {
            view = null
            params = null
        }
    }

    private fun detach() {
        val v = view ?: return
        runCatching { wm.removeView(v) }
        view = null
        params = null
        lastRadius = -1
    }

    @Suppress("DEPRECATION")
    private fun applyRadius(lv: Float, force: Boolean) {
        if (Build.VERSION.SDK_INT < 31) return
        val v = view ?: return
        val p = params ?: return
        val strength = AlterApp.instance.settings.state.value.blurStrength
        // radius maksimum 4..14 dp menurut kekuatan; langkah 1 px
        val density = context.resources.displayMetrics.density
        val radius = (lv * (4f + 10f * strength) * density).toInt().coerceAtLeast(0)
        val now = SystemClock.uptimeMillis()
        if (!force && (radius == lastRadius || now - lastApplyAt < 33)) return
        lastRadius = radius
        lastApplyAt = now
        p.blurBehindRadius = radius
        p.flags = if (radius > 0) p.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND else p.flags and WindowManager.LayoutParams.FLAG_BLUR_BEHIND.inv()
        runCatching { wm.updateViewLayout(v, p) }
    }

    private companion object {
        const val DEAD_DEG_PER_SEC = 12f
        const val FULL_DEG_PER_SEC = 180f
    }
}
