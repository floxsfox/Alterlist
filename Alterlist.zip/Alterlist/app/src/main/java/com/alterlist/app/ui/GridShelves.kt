package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/** Satu sel di rak grid: cover + judul + keterangan. */
class GridCell(
    val title: String,
    val subtitle: String,
    val thumbnail: String?,
    val onClick: () -> Unit,
)

/**
 * Rak "Pilihan cepat" ala YouTube Music: lagu disusun dalam kolom berisi [rows] baris yang sejajar, digeser ke
 * samping per kolom (berhenti pas di tiap kolom, kolom berikutnya mengintip di tepi kanan). Dipakai untuk
 * Quick picks dan Rekomendasi. [title] boleh null bila judul sudah ada di atasnya.
 */
@Composable
fun PagedGridShelf(title: String?, cells: List<GridCell>, rows: Int = 4) {
    if (cells.isEmpty()) return
    val pages = cells.chunked(rows)
    val state = rememberLazyListState()
    // lebar kolom = layar dikurangi margin kiri dan sisa kecil kolom berikutnya
    val pageWidth = (LocalConfiguration.current.screenWidthDp - 56).dp
    Column(Modifier.padding(top = if (title != null) 14.dp else 4.dp)) {
        if (title != null) SectionTitle(title)
        LazyRow(
            state = state,
            flingBehavior = rememberSnapFlingBehavior(state),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            itemsIndexed(pages) { _, page ->
                Column(Modifier.width(pageWidth)) {
                    page.forEach { c -> SongGridRow(c) }
                }
            }
        }
    }
}

@Composable
private fun SongGridRow(cell: GridCell) {
    Row(
        Modifier.fillMaxWidth().height(62.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = cell.onClick).padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(cell.thumbnail, Modifier.size(52.dp), RoundedCornerShape(6.dp), px = 120)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(cell.title, style = T.body.copy(fontWeight = FontWeight.SemiBold), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (cell.subtitle.isNotBlank()) {
                Text(cell.subtitle, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/**
 * Rak Mix ala Spotify: ubin kecil (cover di kiri, nama di kanan) tersusun [columns] kolom dan beberapa baris
 * yang sejajar rapi, bukan satu baris panjang yang digeser.
 */
@Composable
fun TileGridShelf(title: String, cells: List<GridCell>, columns: Int = 2, maxItems: Int = 8) {
    if (cells.isEmpty()) return
    Column(Modifier.padding(top = 14.dp)) {
        SectionTitle(title)
        Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            cells.take(maxItems).chunked(columns).forEach { rowCells ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowCells.forEach { c -> MixGridTile(c, Modifier.weight(1f)) }
                    // baris terakhir yang tidak penuh: sisakan ruang kosong supaya lebar ubin tetap sama
                    repeat(columns - rowCells.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

@Composable
private fun MixGridTile(cell: GridCell, modifier: Modifier) {
    val shape = RoundedCornerShape(minOf(Skin.cardCorner, 16.dp))
    Row(
        modifier.height(68.dp).clip(shape).background(AlterColors.Surface2).clickable(onClick = cell.onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(cell.thumbnail, Modifier.size(68.dp), RoundedCornerShape(0.dp), px = 160)
        Column(Modifier.weight(1f).padding(horizontal = 10.dp), verticalArrangement = Arrangement.Center) {
            Text(cell.title, style = T.small.copy(fontWeight = FontWeight.Bold), maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (cell.subtitle.isNotBlank()) {
                Text(cell.subtitle, style = T.tiny, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Judul rak dari beranda YouTube Music yang berisi lagu pilihan (Quick picks / Rekomendasi) dan cocok ditata sebagai grid lagu. */
fun isSongGridShelf(title: String): Boolean {
    val t = title.lowercase()
    return listOf("quick", "pilihan cepat", "cepat", "picks", "recommend", "rekomendasi", "untuk kamu", "untuk anda", "for you").any { it in t }
}

/** Judul rak Mix dari beranda YouTube Music ("Mixed for you", "Mix untuk kamu", dst.). */
fun isMixShelf(title: String): Boolean = "mix" in title.lowercase()
