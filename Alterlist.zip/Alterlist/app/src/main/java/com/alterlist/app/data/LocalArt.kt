package com.alterlist.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size

/**
 * Cover lagu dari penyimpanan HP. Mengambil gambar yang tertanam di berkas audio (ID3 / FLAC / M4A)
 * lewat MediaStore atau MediaMetadataRetriever, lalu menyimpannya di cache memori.
 */
object LocalArt {
    private val cache =
        object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
            override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
        }

    private fun key(url: String, px: Int) = "$url@$px"

    /** Alamat cover lagu lokal selalu content:// (bukan http), jadi bisa dibedakan dari cover YouTube. */
    fun isLocalArt(url: String?): Boolean = url != null && url.startsWith("content://")

    fun cached(url: String, px: Int): Bitmap? = cache.get(key(url, px))

    /** Panggil dari thread latar. Mengembalikan null kalau lagu tidak punya cover. */
    fun load(context: Context, url: String, px: Int): Bitmap? {
        val k = key(url, px)
        cache.get(k)?.let { return it }
        val bmp = runCatching { decode(context, url, px.coerceIn(32, 640)) }.getOrNull() ?: return null
        cache.put(k, bmp)
        return bmp
    }

    private fun decode(context: Context, url: String, px: Int): Bitmap? {
        val uri = Uri.parse(url)
        val isMedia = uri.authority == "media"
        val track = if (isMedia && url.endsWith("/albumart")) Uri.parse(url.removeSuffix("/albumart")) else uri

        if (isMedia && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                return context.contentResolver.loadThumbnail(track, Size(px, px), null)
            } catch (_: Exception) {
                // lanjut ke cara lain
            }
        }
        val embedded = embeddedBytes(context, track)
        if (embedded != null) {
            decodeScaled(embedded, px)?.let { return it }
        }
        if (isMedia) {
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readBytes()
                    decodeScaled(bytes, px)?.let { return it }
                }
            } catch (_: Exception) {
                // tidak ada cover
            }
        }
        return null
    }

    private fun embeddedBytes(context: Context, uri: Uri): ByteArray? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.embeddedPicture
        } catch (_: Exception) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun decodeScaled(bytes: ByteArray, px: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }
}
