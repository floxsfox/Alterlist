package com.alterlist.app.data

import com.alterlist.app.AlterApp

/** Memutar tautan YouTube / YouTube Music (lagu atau playlist), dari kolom cari atau dari aplikasi lain. */
object LinkHandler {
    private val VIDEO = Regex("(?:youtu\\.be/|[?&]v=|/shorts/|/embed/)([A-Za-z0-9_-]{11})")
    private val LIST = Regex("[?&]list=([A-Za-z0-9_-]+)")

    fun isLink(text: String): Boolean = text.contains("youtu.be/") || text.contains("youtube.com/")

    fun videoId(text: String): String? = VIDEO.find(text)?.groupValues?.get(1)

    fun listId(text: String): String? = LIST.find(text)?.groupValues?.get(1)

    /** @return true bila ada yang diputar */
    suspend fun play(app: AlterApp, text: String): Boolean {
        val id = videoId(text)
        if (id != null) {
            val songs = runCatching { app.yt.upNext(id, null) }.getOrDefault(emptyList())
            if (songs.isNotEmpty()) {
                app.player.playSongs(songs)
                return true
            }
        }
        val list = listId(text)
        if (list != null) {
            app.player.playPlaylistId(list)
            return true
        }
        return false
    }
}
