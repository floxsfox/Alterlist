package com.alterlist.app.system

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.alterlist.app.island.IslandAccessibilityService

/** Izin yang dipakai fitur musik di perangkat dan dynamic bar. */
object PermissionHelper {
    /** Izin baca audio: READ_MEDIA_AUDIO di Android 13+, READ_EXTERNAL_STORAGE di versi lama. */
    fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioAccess(context: Context): Boolean =
        context.checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED

    /** Izin "Tampil di atas aplikasi lain": dibutuhkan dynamic bar supaya bisa muncul di sekitar kamera. */
    fun canDrawOverlays(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun overlaySettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))

    /** Layanan aksesibilitas dynamic bar sudah diaktifkan di Pengaturan (bar bisa tampil di atas status bar). */
    fun isIslandServiceEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(context, IslandAccessibilityService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    /** Dynamic bar bisa tampil: lewat layanan aksesibilitas (di atas status bar) atau izin overlay biasa (di bawahnya). */
    fun canShowIsland(context: Context): Boolean = IslandAccessibilityService.instance != null || canDrawOverlays(context)

    fun accessibilitySettingsIntent(): Intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    fun appDetailsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
}
