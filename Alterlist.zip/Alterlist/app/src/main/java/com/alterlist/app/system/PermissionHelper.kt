package com.alterlist.app.system

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/** Izin yang dipakai fitur musik di perangkat. */
object PermissionHelper {
    /** Izin baca audio: READ_MEDIA_AUDIO di Android 13+, READ_EXTERNAL_STORAGE di versi lama. */
    fun audioPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasAudioAccess(context: Context): Boolean =
        context.checkSelfPermission(audioPermission()) == PackageManager.PERMISSION_GRANTED
}
