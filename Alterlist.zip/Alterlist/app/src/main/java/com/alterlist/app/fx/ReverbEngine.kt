package com.alterlist.app.fx

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.tanh

/**
 * Reverb stereo berbasis Freeverb (8 comb + 4 allpass per kanal), dibuat konservatif supaya stabil:
 *  - umpan balik dibatasi (< 0.97) sehingga tidak pernah "meledak"
 *  - ada pre-delay, high-pass (buang gemuruh bass) dan low-pass (buang desis metalik) di jalur wet
 *  - semua parameter dihaluskan per-sampel (tanpa bunyi klik saat slider digeser)
 *  - soft limiter di keluaran untuk mencegah clipping
 */
class ReverbEngine(private val sampleRate: Int) {
    private class Comb(size: Int) {
        val buf = FloatArray(max(1, size))
        var idx = 0
        var store = 0f
    }

    private class Allpass(size: Int) {
        val buf = FloatArray(max(1, size))
        var idx = 0
    }

    private val scale = sampleRate / 44100.0
    private val combL = Array(COMB_TUNING.size) { Comb((COMB_TUNING[it] * scale).toInt()) }
    private val combR = Array(COMB_TUNING.size) { Comb(((COMB_TUNING[it] + SPREAD) * scale).toInt()) }
    private val apL = Array(ALLPASS_TUNING.size) { Allpass((ALLPASS_TUNING[it] * scale).toInt()) }
    private val apR = Array(ALLPASS_TUNING.size) { Allpass(((ALLPASS_TUNING[it] + SPREAD) * scale).toInt()) }

    private val preSize = (0.12 * sampleRate).toInt() + 2
    private val preL = FloatArray(preSize)
    private val preR = FloatArray(preSize)
    private var preWrite = 0

    // filter jalur wet
    private val hpCoef = exp(-2.0 * PI * HP_HZ / sampleRate).toFloat()
    private val lpCoef = exp(-2.0 * PI * LP_HZ / sampleRate).toFloat()
    private var hpInL = 0f
    private var hpOutL = 0f
    private var hpInR = 0f
    private var hpOutR = 0f
    private var lpL = 0f
    private var lpR = 0f

    // parameter target (dari UI) dan nilai yang sudah dihaluskan
    @Volatile private var targetFeedback = 0.80f
    @Volatile private var targetDamp = 0.5f
    @Volatile private var targetWet = 0f
    @Volatile private var targetPreDelaySamples = (0.02 * sampleRate).toFloat()
    private var feedback = targetFeedback
    private var damp = targetDamp
    private var wet = 0f
    private var dry = 1f
    private var outGain = 1f
    private var preDelay = targetPreDelaySamples
    private val smooth = (1.0 - exp(-1.0 / (0.03 * sampleRate))).toFloat() // ~30 ms

    /** room 0..1, damping 0..1, mix 0..1, preDelayMs 0..80 */
    fun setParams(room: Float, damping: Float, mix: Float, preDelayMs: Float) {
        targetFeedback = 0.70f + 0.27f * room.coerceIn(0f, 1f) // 0.70 .. 0.97
        targetDamp = damping.coerceIn(0f, 1f)
        targetWet = mix.coerceIn(0f, 1f)
        targetPreDelaySamples = (preDelayMs.coerceIn(0f, 80f) * sampleRate / 1000f)
    }

    fun reset() {
        for (c in combL) { c.buf.fill(0f); c.store = 0f; c.idx = 0 }
        for (c in combR) { c.buf.fill(0f); c.store = 0f; c.idx = 0 }
        for (a in apL) { a.buf.fill(0f); a.idx = 0 }
        for (a in apR) { a.buf.fill(0f); a.idx = 0 }
        preL.fill(0f); preR.fill(0f); preWrite = 0
        hpInL = 0f; hpOutL = 0f; hpInR = 0f; hpOutR = 0f; lpL = 0f; lpR = 0f
    }

    /** Proses in-place. [left] dan [right] berisi sampel float -1..1 sepanjang [frames]. */
    fun process(left: FloatArray, right: FloatArray, frames: Int) {
        val tFeedback = targetFeedback
        val tDamp = targetDamp
        // ruang yang lebih panjang menyimpan lebih banyak energi, jadi wet dikompensasi supaya volume tetap wajar
        val norm = kotlin.math.sqrt(0.19f / (1f - tFeedback * tFeedback))
        val tWet = targetWet * WET_SCALE * norm
        val tDry = 1f - 0.22f * targetWet
        val tOut = 1f - 0.12f * targetWet // sedikit headroom saat reverb aktif
        val tPre = targetPreDelaySamples

        for (n in 0 until frames) {
            feedback += (tFeedback - feedback) * smooth
            damp += (tDamp - damp) * smooth
            wet += (tWet - wet) * smooth
            dry += (tDry - dry) * smooth
            outGain += (tOut - outGain) * smooth
            preDelay += (tPre - preDelay) * smooth

            val inL = left[n]
            val inR = right[n]

            // pre-delay (interpolasi linear)
            preL[preWrite] = inL
            preR[preWrite] = inR
            var readPos = preWrite - preDelay
            if (readPos < 0f) readPos += preSize
            val i0 = readPos.toInt() % preSize
            val i1 = (i0 + 1) % preSize
            val frac = readPos - readPos.toInt()
            val dL = preL[i0] * (1f - frac) + preL[i1] * frac
            val dR = preR[i0] * (1f - frac) + preR[i1] * frac
            preWrite = (preWrite + 1) % preSize

            val input = (dL + dR) * INPUT_GAIN
            val damp1 = damp * 0.4f
            val damp2 = 1f - damp1

            var outL = 0f
            var outR = 0f
            for (c in combL) {
                val o = c.buf[c.idx]
                c.store = flush(o * damp2 + c.store * damp1)
                c.buf[c.idx] = input + c.store * feedback
                if (++c.idx >= c.buf.size) c.idx = 0
                outL += o
            }
            for (c in combR) {
                val o = c.buf[c.idx]
                c.store = flush(o * damp2 + c.store * damp1)
                c.buf[c.idx] = input + c.store * feedback
                if (++c.idx >= c.buf.size) c.idx = 0
                outR += o
            }
            for (a in apL) {
                val b = a.buf[a.idx]
                val o = -outL + b
                a.buf[a.idx] = flush(outL + b * 0.5f)
                if (++a.idx >= a.buf.size) a.idx = 0
                outL = o
            }
            for (a in apR) {
                val b = a.buf[a.idx]
                val o = -outR + b
                a.buf[a.idx] = flush(outR + b * 0.5f)
                if (++a.idx >= a.buf.size) a.idx = 0
                outR = o
            }

            // high-pass lalu low-pass pada jalur wet
            val hL = hpCoef * (hpOutL + outL - hpInL)
            hpInL = outL
            hpOutL = flush(hL)
            val hR = hpCoef * (hpOutR + outR - hpInR)
            hpInR = outR
            hpOutR = flush(hR)
            lpL = flush(hpOutL * (1f - lpCoef) + lpL * lpCoef)
            lpR = flush(hpOutR * (1f - lpCoef) + lpR * lpCoef)

            // sedikit stereo-width: campur ringan antar kanal
            val wl = lpL * 0.85f + lpR * 0.15f
            val wr = lpR * 0.85f + lpL * 0.15f

            left[n] = softLimit((inL * dry + wl * wet) * outGain)
            right[n] = softLimit((inR * dry + wr * wet) * outGain)
        }
    }

    private fun flush(v: Float): Float = if (abs(v) < 1e-15f) 0f else v

    private fun softLimit(x: Float): Float {
        val ax = abs(x)
        if (ax <= LIMIT_KNEE) return x
        val over = tanh((ax - LIMIT_KNEE) / (1f - LIMIT_KNEE)) * (1f - LIMIT_KNEE)
        val y = LIMIT_KNEE + over
        return if (x < 0f) -y else y
    }

    private companion object {
        val COMB_TUNING = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617)
        val ALLPASS_TUNING = intArrayOf(556, 441, 341, 225)
        const val SPREAD = 23
        const val INPUT_GAIN = 0.015f
        const val WET_SCALE = 3.2f
        const val HP_HZ = 180.0
        const val LP_HZ = 6500.0
        const val LIMIT_KNEE = 0.86f
    }
}
