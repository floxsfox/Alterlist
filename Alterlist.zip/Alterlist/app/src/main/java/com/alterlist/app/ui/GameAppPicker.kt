package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.alterlist.app.R
import com.alterlist.app.system.GameApp
import com.alterlist.app.system.GameDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Dialog pilih game untuk mode game: semua aplikasi berikon peluncur, game yang dikenali sistem diberi tanda. */
@Composable
fun GameAppPickerDialog(selected: Set<String>, onDismiss: () -> Unit, onSave: (Set<String>) -> Unit) {
    val context = LocalContext.current
    val apps by produceState<List<GameApp>?>(initialValue = null) {
        value = withContext(Dispatchers.IO) { GameDetector.launchableApps(context) }
    }
    var picked by remember { mutableStateOf(selected) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(16.dp))
                .background(AlterColors.Surface)
                .padding(vertical = 14.dp),
        ) {
            Text("Pilih game", style = T.section.copy(fontSize = 18.sp), modifier = Modifier.padding(horizontal = 18.dp))
            Text(
                "Aplikasi bertanda GAME dikenali otomatis oleh sistem. Centang yang lain untuk menambahkannya sebagai game.",
                style = T.small,
                color = AlterColors.Sub,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp),
            )
            val list = apps
            if (list == null) {
                Box(Modifier.fillMaxWidth().heightIn(min = 120.dp), contentAlignment = Alignment.Center) { LoadingBox() }
            } else {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(list, key = { it.pkg }) { app ->
                        val on = app.pkg in picked
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { picked = if (on) picked - app.pkg else picked + app.pkg }
                                .padding(horizontal = 18.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(app.label, style = T.body, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(app.pkg, style = T.tiny, color = AlterColors.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (app.isGame) {
                                Text(
                                    "GAME",
                                    style = T.tiny.copy(fontWeight = FontWeight.Bold),
                                    color = AlterColors.RedSoft,
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                )
                            }
                            Box(
                                Modifier
                                    .size(22.dp)
                                    .clip(RoundedCornerShape(5.dp))
                                    .background(if (on) AlterColors.Red else AlterColors.Surface3),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (on) Ic(R.drawable.ic_check, tint = Color.White, size = 16.dp)
                            }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp).padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                Text(
                    "Batal",
                    style = T.button,
                    color = AlterColors.Sub,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onDismiss).padding(horizontal = 14.dp, vertical = 10.dp),
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    "Simpan",
                    style = T.button,
                    color = AlterColors.Red,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { onSave(picked) }.padding(horizontal = 14.dp, vertical = 10.dp),
                )
            }
        }
    }
}
