package com.alterlist.app

import android.app.Application
import com.alterlist.app.data.AccountStore
import com.alterlist.app.data.AppSettings
import com.alterlist.app.data.Library
import com.alterlist.app.data.LocalMusic
import com.alterlist.app.data.LyricsRepo
import com.alterlist.app.data.Recommender
import com.alterlist.app.data.YtMusic
import com.alterlist.app.download.Downloader
import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.EqualizerFx
import com.alterlist.app.playback.PlayerConnection
import com.alterlist.app.playback.QueueStore
import com.alterlist.app.system.AudioOutputMonitor
import com.alterlist.app.system.NetworkMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class AlterApp : Application() {
    /** Scope aplikasi untuk pekerjaan latar yang tidak terikat layar (sinkronisasi like, impor akun). */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var yt: YtMusic
        private set
    lateinit var library: Library
        private set
    lateinit var account: AccountStore
        private set
    lateinit var downloader: Downloader
        private set
    lateinit var lyrics: LyricsRepo
        private set
    lateinit var player: PlayerConnection
        private set
    lateinit var settings: AppSettings
        private set
    lateinit var network: NetworkMonitor
        private set
    lateinit var audioOutput: AudioOutputMonitor
        private set
    lateinit var localMusic: LocalMusic
        private set
    lateinit var recommender: Recommender
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        AudioFx.init(this)
        EqualizerFx.init(this)
        settings = AppSettings(this)
        network = NetworkMonitor(this)
        audioOutput = AudioOutputMonitor(this)
        yt = YtMusic()
        library = Library(this)
        account = AccountStore(this)
        yt.setAccount(account.session())
        downloader = Downloader(this, yt, library)
        lyrics = LyricsRepo(this)
        player = PlayerConnection(this, library, yt, downloader, QueueStore(this))
        localMusic = LocalMusic(this, settings)
        recommender = Recommender(this, yt)
    }

    companion object {
        lateinit var instance: AlterApp
            private set
    }
}
