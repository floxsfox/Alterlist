package com.alterlist.app

import android.app.Application
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import com.alterlist.app.data.AccountStore
import com.alterlist.app.data.DeviceProfiles
import com.alterlist.app.data.AppSettings
import com.alterlist.app.data.Library
import com.alterlist.app.data.LocalMusic
import com.alterlist.app.data.LyricsRepo
import com.alterlist.app.data.Recommender
import com.alterlist.app.data.YtMusic
import com.alterlist.app.download.Downloader
import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.EqualizerFx
import com.alterlist.app.playback.PlayerConnection
import com.alterlist.app.playback.QueueStore
import com.alterlist.app.system.AudioOutputMonitor
import com.alterlist.app.system.NetworkMonitor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class AlterApp : Application() {
    /** Scope aplikasi untuk pekerjaan latar yang tidak terikat layar (sinkronisasi like, impor akun). */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var yt: YtMusic
        private set
    lateinit var library: Library
        private set
    lateinit var account: AccountStore
        private set
    lateinit var downloader: Downloader
        private set
    lateinit var lyrics: LyricsRepo
        private set
    lateinit var translator: com.alterlist.app.data.Translator
        private set
    lateinit var player: PlayerConnection
        private set
    lateinit var settings: AppSettings
        private set
    lateinit var network: NetworkMonitor
        private set
    lateinit var audioOutput: AudioOutputMonitor
        private set
    lateinit var localMusic: LocalMusic
        private set
    lateinit var recommender: Recommender
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        AudioFx.init(this)
        EqualizerFx.init(this)
        settings = AppSettings(this)
        network = NetworkMonitor(this)
        audioOutput = AudioOutputMonitor(this)
        yt = YtMusic()
        library = Library(this)
        account = AccountStore(this)
        yt.setAccount(account.session())
        downloader = Downloader(this, yt, library)
        lyrics = LyricsRepo(this)
        translator = com.alterlist.app.data.Translator(this)
        player = PlayerConnection(this, library, yt, downloader, QueueStore(this))
        localMusic = LocalMusic(this, settings)
        recommender = Recommender(this, yt)

        // profil audio otomatis per perangkat (Bluetooth / berkabel / speaker)
        scope.launch {
            audioOutput.active.map { it.kind }.distinctUntilChanged().collect { kind ->
                DeviceProfiles.apply(settings.state.value, kind)
            }
        }
        // unduh otomatis lagu disukai (hanya Wi-Fi / jaringan tanpa kuota)
        scope.launch {
            combine(
                library.data.map { d -> d.liked }.distinctUntilChanged(),
                settings.state.map { it.autoDownloadLiked }.distinctUntilChanged(),
                network.online,
                network.metered,
            ) { liked, auto, online, metered -> if (auto && online && !metered) liked else emptyList() }
                .collect { liked ->
                    liked.filter { !it.isLocal && !downloader.isDownloaded(it.id) }.take(30).forEach { downloader.enqueue(it) }
                }
        }
    }

    companion object {
        lateinit var instance: AlterApp
            private set
    }
}
