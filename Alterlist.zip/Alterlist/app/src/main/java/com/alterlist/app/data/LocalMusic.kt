package com.alterlist.app.data

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.util.Locale

/** Awalan id untuk lagu dari penyimpanan HP. */
const val LOCAL_PREFIX = "local:"

private const val UNKNOWN_ARTIST = "Artis tidak dikenal"

data class LocalAlbum(val name: String, val artist: String, val songs: List<Song>) {
    val thumbnail: String? get() = songs.firstNotNullOfOrNull { it.thumbnail }
}

data class LocalArtist(val name: String, val songs: List<Song>) {
    val thumbnail: String? get() = songs.firstNotNullOfOrNull { it.thumbnail }
}

data class LocalFolder(val name: String, val path: String, val songs: List<Song>)

data class LocalState(
    val loading: Boolean = false,
    val scanned: Boolean = false,
    val songs: List<Song> = emptyList(),
    val albums: List<LocalAlbum> = emptyList(),
    val artists: List<LocalArtist> = emptyList(),
    val folders: List<LocalFolder> = emptyList(),
    val totalBytes: Long = 0L,
    /** Ekstensi berkas (mp3, flac, ...) -> jumlah lagu. */
    val formats: Map<String, Int> = emptyMap(),
    val error: String? = null,
)

/** Rincian teknis sebuah berkas audio lokal (untuk layar Info lagu). */
data class LocalFileInfo(
    val displayName: String?,
    val mime: String?,
    val bytes: Long?,
    val bitrateKbps: Int?,
    val path: String?,
)

/**
 * Musik di penyimpanan HP. Membaca semua audio dari MediaStore (mp3, flac, wav, ogg, opus, m4a, aac, amr, mka, dan lain-lain
 * selama didukung Android), ditambah berkas yang dipilih manual lewat pemilih berkas.
 * Lagu lokal punya id "local:..." dan dimainkan langsung dari content:// tanpa internet.
 */
class LocalMusic(private val context: Context, private val settings: AppSettings) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val extraFile = File(context.filesDir, "local_extra.json")
    private val json =
        Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }

    private var extras: List<Song> = loadExtras()
    private var mediaSongs: List<Song> = emptyList()
    private var folderMap: Map<String, Pair<String, String>> = emptyMap() // id lagu -> (nama folder, path)
    private var sizeMap: Map<String, Long> = emptyMap()
    private var formatMap: Map<String, String> = emptyMap()
    private var observerJob: Job? = null
    private var observerRegistered = false

    private val _state = MutableStateFlow(LocalState())
    val state: StateFlow<LocalState> = _state.asStateFlow()

    private fun loadExtras(): List<Song> =
        try {
            if (extraFile.exists()) json.decodeFromString(ListSerializer(Song.serializer()), extraFile.readText()) else emptyList()
        } catch (e: Exception) {
            emptyList()
        }

    private fun saveExtras() {
        try {
            extraFile.writeText(json.encodeToString(ListSerializer(Song.serializer()), extras))
        } catch (e: Exception) {
            // gagal menyimpan tidak boleh menghentikan aplikasi
        }
    }

    // ---------------------------------------------------------------- pemindaian

    /** Pindai ulang. [withMediaStore] false hanya menyusun ulang daftar (mis. setelah menambah berkas manual). */
    suspend fun refresh(withMediaStore: Boolean = true) {
        mutex.withLock {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                if (withMediaStore) {
                    val minMs = settings.state.value.localMinSeconds * 1000L
                    val scan = withContext(Dispatchers.IO) { queryMediaStore(minMs) }
                    mediaSongs = scan.songs
                    folderMap = scan.folders
                    sizeMap = scan.sizes
                    formatMap = scan.formats
                }
                publish()
                registerObserver()
            } catch (e: SecurityException) {
                _state.value = _state.value.copy(loading = false, error = "Izin akses musik belum diberikan")
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, error = e.message ?: "Gagal memindai musik")
            }
        }
    }

    private fun publish() {
        val all = (mediaSongs + extras).distinctBy { it.id }
        val albums =
            all.filter { !it.album.isNullOrBlank() }
                .groupBy { it.album.orEmpty().lowercase(Locale.ROOT) }
                .map { (_, list) ->
                    LocalAlbum(
                        name = list.first().album.orEmpty(),
                        artist = list.map { primaryArtist(it.artist) }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key.orEmpty(),
                        songs = list,
                    )
                }
                .sortedBy { it.name.lowercase(Locale.ROOT) }
        val artists =
            all.groupBy { primaryArtist(it.artist).ifBlank { UNKNOWN_ARTIST }.lowercase(Locale.ROOT) }
                .map { (_, list) -> LocalArtist(primaryArtist(list.first().artist).ifBlank { UNKNOWN_ARTIST }, list) }
                .sortedBy { it.name.lowercase(Locale.ROOT) }
        val folders =
            all.groupBy { folderMap[it.id]?.second ?: "" }
                .filterKeys { it.isNotEmpty() }
                .map { (path, list) -> LocalFolder(folderMap[list.first().id]?.first ?: path.substringAfterLast('/'), path, list) }
                .sortedBy { it.name.lowercase(Locale.ROOT) }
        val formats = HashMap<String, Int>()
        for (s in all) {
            val ext = formatMap[s.id] ?: continue
            formats[ext] = (formats[ext] ?: 0) + 1
        }
        _state.value =
            LocalState(
                loading = false,
                scanned = true,
                songs = all,
                albums = albums,
                artists = artists,
                folders = folders,
                totalBytes = all.sumOf { sizeMap[it.id] ?: 0L },
                formats = formats.entries.sortedByDescending { it.value }.associate { it.key to it.value },
            )
    }

    private class Scan(
        val songs: List<Song>,
        val folders: Map<String, Pair<String, String>>,
        val sizes: Map<String, Long>,
        val formats: Map<String, String>,
    )

    @Suppress("DEPRECATION")
    private fun queryMediaStore(minMs: Long): Scan {
        val collection =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }
        val projection =
            arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATA,
            )
        // semua jenis audio, kecuali nada dering / notifikasi / alarm
        val selection =
            "${MediaStore.Audio.Media.DURATION} >= ? AND " +
                "${MediaStore.Audio.Media.IS_RINGTONE} = 0 AND " +
                "${MediaStore.Audio.Media.IS_NOTIFICATION} = 0 AND " +
                "${MediaStore.Audio.Media.IS_ALARM} = 0"
        val songs = ArrayList<Song>()
        val folders = HashMap<String, Pair<String, String>>()
        val sizes = HashMap<String, Long>()
        val formats = HashMap<String, String>()

        context.contentResolver.query(
            collection,
            projection,
            selection,
            arrayOf(minMs.toString()),
            "${MediaStore.Audio.Media.DATE_ADDED} DESC",
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iDuration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val iData = c.getColumnIndex(MediaStore.Audio.Media.DATA)
            while (c.moveToNext()) {
                val rowId = c.getLong(iId)
                val displayName = c.getString(iName).orEmpty()
                val title = c.getString(iTitle)?.takeIf { it.isNotBlank() } ?: displayName.substringBeforeLast('.')
                val artist = cleanTag(c.getString(iArtist))
                val album = cleanTag(c.getString(iAlbum))
                val durationMs = c.getLong(iDuration)
                val id = LOCAL_PREFIX + rowId
                val song =
                    Song(
                        id = id,
                        title = title.ifBlank { "Tanpa judul" },
                        artist = artist ?: UNKNOWN_ARTIST,
                        album = album,
                        thumbnail = "content://media/external/audio/media/$rowId/albumart",
                        durationText = formatDurationText(durationMs / 1000L),
                        uri = ContentUris.withAppendedId(collection, rowId).toString(),
                    )
                songs.add(song)
                sizes[id] = c.getLong(iSize)
                val ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (ext.isNotEmpty() && ext.length <= 5) formats[id] = ext
                if (iData >= 0) {
                    val path = c.getString(iData).orEmpty()
                    val dir = path.substringBeforeLast('/', "")
                    if (dir.isNotEmpty()) folders[id] = dir.substringAfterLast('/') to dir
                }
            }
        }
        return Scan(songs, folders, sizes, formats)
    }

    private fun cleanTag(value: String?): String? {
        val v = value?.trim()
        if (v.isNullOrEmpty()) return null
        if (v.equals("<unknown>", true) || v.equals("unknown", true)) return null
        return v
    }

    private fun registerObserver() {
        if (observerRegistered) return
        observerRegistered = true
        try {
            context.contentResolver.registerContentObserver(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                true,
                object : ContentObserver(Handler(Looper.getMainLooper())) {
                    override fun onChange(selfChange: Boolean) {
                        // ada lagu baru / terhapus: pindai ulang setelah tenang 2 detik
                        observerJob?.cancel()
                        observerJob =
                            scope.launch {
                                delay(2_000)
                                refresh()
                            }
                    }
                },
            )
        } catch (e: Exception) {
            observerRegistered = false
        }
    }

    // ---------------------------------------------------------------- berkas pilihan manual

    /** Tambahkan berkas yang dipilih lewat pemilih berkas. @return jumlah lagu baru yang ditambahkan */
    suspend fun addPicked(uris: List<Uri>): Int =
        withContext(Dispatchers.IO) {
            val have = extras.mapNotNull { it.uri }.toHashSet()
            val added = ArrayList<Song>()
            for (uri in uris) {
                if (uri.toString() in have) continue
                try {
                    context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                    // tidak semua penyedia berkas mengizinkan akses permanen
                }
                readPicked(uri)?.let { added.add(it) }
            }
            if (added.isNotEmpty()) {
                extras = added + extras
                saveExtras()
                refresh(withMediaStore = false)
            }
            added.size
        }

    suspend fun removePicked(id: String) {
        extras = extras.filterNot { it.id == id }
        saveExtras()
        refresh(withMediaStore = false)
    }

    fun isPicked(id: String): Boolean = extras.any { it.id == id }

    private fun readPicked(uri: Uri): Song? {
        var displayName: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) displayName = c.getString(0)
            }
        } catch (e: Exception) {
            // nama berkas tidak wajib
        }
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
            val artist = cleanTag(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST))
            val album = cleanTag(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM))
            val durMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val hasArt = retriever.embeddedPicture != null
            val name = displayName
            val fallbackTitle = name?.substringBeforeLast('.') ?: "Berkas audio"
            return Song(
                id = LOCAL_PREFIX + "doc:" + Integer.toHexString(uri.toString().hashCode()),
                title = title ?: fallbackTitle,
                artist = artist ?: UNKNOWN_ARTIST,
                album = album,
                thumbnail = if (hasArt) uri.toString() else null,
                durationText = if (durMs > 0L) formatDurationText(durMs / 1000L) else null,
                uri = uri.toString(),
            )
        } catch (e: Exception) {
            return null
        } finally {
            runCatching { retriever.release() }
        }
    }

    // ---------------------------------------------------------------- pencarian & info

    fun search(query: String, limit: Int = 40): List<Song> {
        val q = query.trim().lowercase(Locale.ROOT)
        if (q.isEmpty()) return emptyList()
        return _state.value.songs
            .filter {
                it.title.lowercase(Locale.ROOT).contains(q) ||
                    it.artist.lowercase(Locale.ROOT).contains(q) ||
                    (it.album?.lowercase(Locale.ROOT)?.contains(q) == true)
            }
            .take(limit)
    }

    /** Rincian teknis berkas (format, ukuran, bitrate). Panggil dari thread latar. */
    fun describe(song: Song): LocalFileInfo? {
        val raw = song.uri ?: return null
        val uri = Uri.parse(raw)
        var name: String? = null
        var size: Long? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0)
                    size = c.getLong(1)
                }
            }
        } catch (e: Exception) {
            // abaikan
        }
        var mime: String? = null
        var bitrate: Int? = null
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()?.let { (it / 1000L).toInt() }
        } catch (e: Exception) {
            // abaikan
        } finally {
            runCatching { retriever.release() }
        }
        return LocalFileInfo(name, mime, size, bitrate, folderMap[song.id]?.second)
    }

    fun songsOf(ids: Collection<String>): List<Song> {
        val set = ids.toHashSet()
        return _state.value.songs.filter { it.id in set }
    }
}
