package com.alterlist.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.alterlist.app.AlterApp
import com.alterlist.app.data.LocalArt
import com.alterlist.app.data.Net
import com.alterlist.app.data.withSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Dua warna khas sebuah cover: dipakai untuk mewarnai bar kaca dan latar. */
data class CoverPalette(val primary: Color, val secondary: Color)

val DefaultPalette = CoverPalette(Color(0xFF4A1013), Color(0xFF1B2540))

private val paletteCache = ConcurrentHashMap<String, IntArray>()

/** Bitmap kecil (64 px) dari cover, baik cover YouTube maupun cover lagu lokal. */
internal suspend fun loadSmallBitmap(url: String): Bitmap? {
    if (LocalArt.isLocalArt(url)) {
        return withContext(Dispatchers.IO) { LocalArt.load(AlterApp.instance, url, 64) }
    }
    val bytes = Net.getBytes(url.withSize(64), maxBytes = 512 * 1024) ?: return null
    return withContext(Dispatchers.Default) { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
}

/** Palet dua warna dari metadata cover lagu (animasi halus saat lagu berganti). */
@Composable
fun rememberCoverPalette(url: String?): CoverPalette {
    val target by produceState(initialValue = DefaultPalette, key1 = url) {
        if (url == null) {
            value = DefaultPalette
            return@produceState
        }
        val cached = paletteCache[url]
        if (cached != null) {
            value = CoverPalette(Color(cached[0]), Color(cached[1]))
            return@produceState
        }
        val computed = withContext(Dispatchers.IO) { loadSmallBitmap(url)?.let { paletteFrom(it) } }
        if (computed != null) {
            paletteCache[url] = computed
            value = CoverPalette(Color(computed[0]), Color(computed[1]))
        }
    }
    val p by animateColorAsState(targetValue = target.primary, animationSpec = tween(700), label = "palPrimary")
    val s by animateColorAsState(targetValue = target.secondary, animationSpec = tween(700), label = "palSecondary")
    return CoverPalette(p, s)
}

/** Kelompokkan piksel per rona; ambil rona paling dominan dan rona kedua yang cukup berbeda. */
private fun paletteFrom(src: Bitmap): IntArray {
    val small = Bitmap.createScaledBitmap(src, 24, 24, true)
    val buckets = 12
    val w = DoubleArray(buckets)
    val rs = DoubleArray(buckets)
    val gs = DoubleArray(buckets)
    val bs = DoubleArray(buckets)
    val hsv = FloatArray(3)
    for (y in 0 until small.height) {
        for (x in 0 until small.width) {
            val p = small.getPixel(x, y)
            android.graphics.Color.colorToHSV(p, hsv)
            val weight = 0.05 + hsv[1] * hsv[2]
            val b = (hsv[0] / 30f).toInt().coerceIn(0, buckets - 1)
            w[b] += weight
            rs[b] += android.graphics.Color.red(p) * weight
            gs[b] += android.graphics.Color.green(p) * weight
            bs[b] += android.graphics.Color.blue(p) * weight
        }
    }
    var first = 0
    for (i in 1 until buckets) if (w[i] > w[first]) first = i
    var second = -1
    for (i in 0 until buckets) {
        val dist = minOf((i - first + buckets) % buckets, (first - i + buckets) % buckets)
        if (dist < 2 || w[i] < w[first] * 0.18) continue
        if (second == -1 || w[i] > w[second]) second = i
    }

    fun toColor(i: Int, shift: Float): Int {
        if (w[i] <= 0.0) return android.graphics.Color.rgb(40, 40, 60)
        val avg = android.graphics.Color.rgb((rs[i] / w[i]).toInt(), (gs[i] / w[i]).toInt(), (bs[i] / w[i]).toInt())
        android.graphics.Color.colorToHSV(avg, hsv)
        hsv[0] = (hsv[0] + shift + 360f) % 360f
        if (hsv[1] > 0.12f) hsv[1] = hsv[1].coerceIn(0.35f, 0.95f)
        hsv[2] = hsv[2].coerceIn(0.38f, 0.82f)
        return android.graphics.Color.HSVToColor(hsv)
    }

    val primary = toColor(first, 0f)
    val secondary = if (second >= 0) toColor(second, 0f) else toColor(first, 38f)
    return intArrayOf(primary, secondary)
}

/** Pil kecil bergaya kaca (mis. info perangkat audio). */
@Composable
fun GlassChip(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.08f))))
            .border(1.dp, Color.White.copy(alpha = 0.28f), shape)
            .bounceClick(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        content = content,
    )
}
