package com.alterlist.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.alterlist.app.AlterApp
import com.alterlist.app.data.LocalArt
import com.alterlist.app.data.Net
import com.alterlist.app.data.withSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

/** Dua warna khas sebuah cover: dipakai untuk mewarnai bar kaca dan latar. */
data class CoverPalette(val primary: Color, val secondary: Color)

val DefaultPalette = CoverPalette(Color(0xFF4A1013), Color(0xFF1B2540))

private val paletteCache = ConcurrentHashMap<String, IntArray>()

/** Bitmap kecil (64 px) dari cover, baik cover YouTube maupun cover lagu lokal. */
internal suspend fun loadSmallBitmap(url: String): Bitmap? {
    if (LocalArt.isLocalArt(url)) {
        return withContext(Dispatchers.IO) { LocalArt.load(AlterApp.instance, url, 64) }
    }
    val bytes = Net.getBytes(url.withSize(64), maxBytes = 512 * 1024) ?: return null
    return withContext(Dispatchers.Default) { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }
}

/** Palet dua warna dari metadata cover lagu (animasi halus saat lagu berganti). */
@Composable
fun rememberCoverPalette(url: String?): CoverPalette {
    val target by produceState(initialValue = DefaultPalette, key1 = url) {
        if (url == null) {
            value = DefaultPalette
            return@produceState
        }
        val cached = paletteCache[url]
        if (cached != null) {
            value = CoverPalette(Color(cached[0]), Color(cached[1]))
            return@produceState
        }
        val computed = withContext(Dispatchers.IO) { loadSmallBitmap(url)?.let { paletteFrom(it) } }
        if (computed != null) {
            paletteCache[url] = computed
            value = CoverPalette(Color(computed[0]), Color(computed[1]))
        }
    }
    val p by animateColorAsState(targetValue = target.primary, animationSpec = tween(700), label = "palPrimary")
    val s by animateColorAsState(targetValue = target.secondary, animationSpec = tween(700), label = "palSecondary")
    return CoverPalette(p, s)
}

/** Kelompokkan piksel per rona; ambil rona paling dominan dan rona kedua yang cukup berbeda. */
private fun paletteFrom(src: Bitmap): IntArray {
    val small = Bitmap.createScaledBitmap(src, 24, 24, true)
    val buckets = 12
    val w = DoubleArray(buckets)
    val rs = DoubleArray(buckets)
    val gs = DoubleArray(buckets)
    val bs = DoubleArray(buckets)
    val hsv = FloatArray(3)
    for (y in 0 until small.height) {
        for (x in 0 until small.width) {
            val p = small.getPixel(x, y)
            android.graphics.Color.colorToHSV(p, hsv)
            val weight = 0.05 + hsv[1] * hsv[2]
            val b = (hsv[0] / 30f).toInt().coerceIn(0, buckets - 1)
            w[b] += weight
            rs[b] += android.graphics.Color.red(p) * weight
            gs[b] += android.graphics.Color.green(p) * weight
            bs[b] += android.graphics.Color.blue(p) * weight
        }
    }
    var first = 0
    for (i in 1 until buckets) if (w[i] > w[first]) first = i
    var second = -1
    for (i in 0 until buckets) {
        val dist = minOf((i - first + buckets) % buckets, (first - i + buckets) % buckets)
        if (dist < 2 || w[i] < w[first] * 0.18) continue
        if (second == -1 || w[i] > w[second]) second = i
    }

    fun toColor(i: Int, shift: Float): Int {
        if (w[i] <= 0.0) return android.graphics.Color.rgb(40, 40, 60)
        val avg = android.graphics.Color.rgb((rs[i] / w[i]).toInt(), (gs[i] / w[i]).toInt(), (bs[i] / w[i]).toInt())
        android.graphics.Color.colorToHSV(avg, hsv)
        hsv[0] = (hsv[0] + shift + 360f) % 360f
        if (hsv[1] > 0.12f) hsv[1] = hsv[1].coerceIn(0.35f, 0.95f)
        hsv[2] = hsv[2].coerceIn(0.38f, 0.82f)
        return android.graphics.Color.HSVToColor(hsv)
    }

    val primary = toColor(first, 0f)
    val secondary = if (second >= 0) toColor(second, 0f) else toColor(first, 38f)
    return intArrayOf(primary, secondary)
}

/** Cover yang di-blur sebagai latar kaca (blur asli di Android 12+, redup di versi lama). */
@Composable
fun ArtBlur(url: String?, modifier: Modifier = Modifier, alpha: Float = 0.5f) {
    if (url == null) return
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val m = if (canBlur) modifier.blur(26.dp) else modifier
    val a = if (canBlur) alpha else alpha * 0.4f
    if (LocalArt.isLocalArt(url)) {
        LocalArtImage(url, 96, m, a)
    } else {
        AsyncImage(
            model = url.withSize(120),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alpha = a,
            modifier = m,
        )
    }
}

/**
 * Permukaan "liquid glass": cover di-blur sebagai dasar, blob warna dari metadata cover yang melayang pelan,
 * kilau kaca di bagian atas, garis tepi mengilap, dan sapuan cahaya yang bergerak saat [animated] true.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    palette: CoverPalette,
    art: String? = null,
    shape: Shape = RoundedCornerShape(24.dp),
    animated: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    val transition = rememberInfiniteTransition(label = "glass")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "glassDrift",
    )
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 4800, easing = LinearEasing)),
        label = "glassSweep",
    )
    val bright = lerp(palette.primary, Color.White, 0.35f)

    Box(
        modifier
            .shadow(14.dp, shape, ambientColor = palette.primary, spotColor = palette.primary)
            .clip(shape)
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.24f))),
                shape,
            ),
    ) {
        Box(Modifier.matchParentSize().background(Color(0xFF111114)))
        ArtBlur(art, Modifier.matchParentSize(), alpha = 0.55f)
        Box(
            Modifier
                .matchParentSize()
                .drawBehind {
                    val w = size.width
                    val h = size.height
                    val d = drift
                    drawRect(palette.primary.copy(alpha = 0.55f))
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(palette.secondary.copy(alpha = 0.78f), Color.Transparent),
                            center = Offset(w * (0.12f + 0.6f * d), h * (0.1f + 0.6f * d)),
                            radius = w * 0.7f,
                        ),
                    )
                    drawRect(
                        Brush.radialGradient(
                            colors = listOf(bright.copy(alpha = 0.5f), Color.Transparent),
                            center = Offset(w * (0.95f - 0.6f * d), h * (1.0f - 0.5f * d)),
                            radius = w * 0.6f,
                        ),
                    )
                },
        )
        Box(
            Modifier
                .matchParentSize()
                .drawWithContent {
                    drawContent()
                    val w = size.width
                    val h = size.height
                    drawRect(
                        Brush.verticalGradient(
                            colors = listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.04f), Color.Transparent),
                            endY = h * 0.65f,
                        ),
                    )
                    if (animated) {
                        val x = sweep * (w * 2.2f) - w * 0.6f
                        drawRect(
                            Brush.linearGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.15f), Color.Transparent),
                                start = Offset(x, 0f),
                                end = Offset(x + w * 0.35f, h),
                            ),
                        )
                    }
                },
        )
        content()
    }
}

/** Pil kecil bergaya kaca (mis. info perangkat audio). */
@Composable
fun GlassChip(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.White.copy(alpha = 0.08f))))
            .border(1.dp, Color.White.copy(alpha = 0.28f), shape)
            .bounceClick(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
        content = content,
    )
}

data class NavItem(@DrawableRes val icon: Int, @DrawableRes val iconActive: Int, val label: String)

/** Bar navigasi bawah kaca: indikator cairan meluncur ke tab terpilih, warna mengikuti cover lagu yang diputar. */
@Composable
fun GlassNavBar(
    items: List<NavItem>,
    selected: Int,
    palette: CoverPalette,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    art: String? = null,
) {
    GlassSurface(modifier.fillMaxWidth(), palette, art, RoundedCornerShape(30.dp), animated = false) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(64.dp)) {
            val tabW = maxWidth / items.size
            val x by animateDpAsState(
                targetValue = tabW * selected,
                animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
                label = "navIndicator",
            )
            val pill = RoundedCornerShape(22.dp)
            Box(
                Modifier
                    .offset(x = x + 6.dp, y = 6.dp)
                    .size(width = tabW - 12.dp, height = 52.dp)
                    .clip(pill)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.10f))))
                    .border(1.dp, Color.White.copy(alpha = 0.38f), pill),
            )
            Row(Modifier.fillMaxWidth().fillMaxHeight()) {
                items.forEachIndexed { i, item ->
                    val active = i == selected
                    val iconScale by animateFloatAsState(
                        targetValue = if (active) 1.14f else 1f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
                        label = "navIcon$i",
                    )
                    Column(
                        Modifier.weight(1f).fillMaxHeight().noRippleClickable { onSelect(i) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Ic(
                            if (active) item.iconActive else item.icon,
                            tint = if (active) Color.White else Color.White.copy(alpha = 0.72f),
                            size = 24.dp,
                            modifier = Modifier.graphicsLayer {
                                scaleX = iconScale
                                scaleY = iconScale
                            },
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            item.label,
                            style = T.tiny,
                            color = if (active) Color.White else Color.White.copy(alpha = 0.72f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}
