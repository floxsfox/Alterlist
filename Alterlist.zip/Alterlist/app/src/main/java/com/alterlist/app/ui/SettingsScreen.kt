package com.alterlist.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Backup
import com.alterlist.app.data.DeviceProfile
import com.alterlist.app.data.LinkHandler
import com.alterlist.app.data.TRANSLATE_LANGS
import com.alterlist.app.system.PermissionHelper
import kotlinx.coroutines.launch
import java.io.File

private enum class Section(val title: String, @DrawableRes val icon: Int) {
    PLAYBACK("Pemutaran", R.drawable.ic_play),
    AUDIO("Audio", R.drawable.ic_sliders),
    LYRICS("Lirik", R.drawable.ic_music_note),
    LOCAL("Musik di perangkat", R.drawable.ic_phone),
    RECO("Rekomendasi", R.drawable.ic_sparkle),
    DOWNLOADS("Unduhan dan penyimpanan", R.drawable.ic_download),
    DATA("Data", R.drawable.ic_history),
    ABOUT("Tentang", R.drawable.ic_info),
}

/** Pengaturan dikelompokkan per kategori: halaman utama berisi daftar kategori, tiap kategori membuka halamannya sendiri. */
@Composable
fun SettingsScreen(padding: PaddingValues, onBack: () -> Unit, onLogin: () -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val account by app.account.state.collectAsState()
    val lib by app.library.data.collectAsState()
    val scope = rememberCoroutineScope()
    val st by app.settings.state.collectAsState()
    val output by app.audioOutput.active.collectAsState()
    val local by app.localMusic.state.collectAsState()
    var section by rememberSaveable { mutableStateOf<Section?>(null) }
    var pickerOpen by remember { mutableStateOf(false) }
    var linkOpen by remember { mutableStateOf(false) }
    var audioGranted by remember { mutableStateOf(PermissionHelper.hasAudioAccess(context)) }
    var confirmSignOut by remember { mutableStateOf(false) }
    var confirmClearStats by remember { mutableStateOf(false) }
    var cacheTick by remember { mutableStateOf(0) }

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            audioGranted = granted
            if (granted) scope.launch { app.localMusic.refresh() }
        }
    val exportLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                scope.launch {
                    val ok = Backup.exportTo(context, app.library, uri)
                    context.toast(if (ok) "Cadangan tersimpan" else "Gagal menyimpan")
                }
            }
        }
    val importLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                scope.launch {
                    val n = Backup.restore(context, app.library, uri)
                    context.toast(if (n != null) "Dipulihkan ($n item)" else "Berkas tidak valid")
                }
            }
        }

    BackHandler(enabled = section != null) { section = null }
    val current = section

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = padding.calculateBottomPadding() + 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.ic_chevron_left, { if (current != null) section = null else onBack() })
                Text(current?.title ?: "Pengaturan", style = T.section, modifier = Modifier.weight(1f))
            }
        }

        if (current == null) {
            // ------------------------------------------------ halaman utama: akun + daftar kategori
            item {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(12.dp)).background(AlterColors.Surface).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (account.mode == AccountMode.GOOGLE && account.photo != null) {
                        Artwork(account.photo, Modifier.size(56.dp), CircleShape, px = 160)
                    } else {
                        Box(Modifier.size(56.dp).clip(CircleShape).background(AlterColors.Surface3), contentAlignment = Alignment.Center) {
                            Ic(R.drawable.ic_user, size = 28.dp)
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (account.mode == AccountMode.GOOGLE) account.name.ifBlank { "Akun Google" } else "Tamu",
                            style = T.title,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (account.mode == AccountMode.GOOGLE && account.email.isNotBlank()) {
                            Text(account.email, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            item {
                Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                    if (account.mode == AccountMode.GOOGLE) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(50))
                                .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(50))
                                .clickable { confirmSignOut = true }
                                .padding(vertical = 13.dp),
                            contentAlignment = Alignment.Center,
                        ) { Text("Keluar", style = T.button) }
                    } else {
                        PillButton("Masuk dengan Google", onLogin, Modifier.fillMaxWidth())
                    }
                }
            }
            item { Spacer(Modifier.size(8.dp)) }
            Section.entries.forEach { sec ->
                item(key = sec.name) {
                    Row(
                        Modifier.fillMaxWidth().clickable { section = sec }.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(AlterColors.Surface2), contentAlignment = Alignment.Center) {
                            Ic(sec.icon, tint = Color.White, size = 20.dp)
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(sec.title, style = T.title, modifier = Modifier.weight(1f))
                        Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub)
                    }
                }
            }
        } else {
            when (current) {
                Section.PLAYBACK -> {
                    item { SettingRow("Putar otomatis") { AlterSwitch(lib.autoplay) { app.library.setAutoplay(it) } } }
                    item { SettingRow("Sesi pribadi") { AlterSwitch(lib.privateSession) { app.library.setPrivateSession(it) } } }
                    item { SettingRow("Lewati bagian hening") { AlterSwitch(st.skipSilence) { app.settings.setSkipSilence(it) } } }
                    item {
                        ChipSetting("Fade antar lagu") {
                            listOf(0 to "Mati", 2000 to "2 dtk", 4000 to "4 dtk", 6000 to "6 dtk", 8000 to "8 dtk").forEach { (ms, label) ->
                                AlterChip(label, st.fadeMs == ms, { app.settings.setFadeMs(ms) })
                            }
                        }
                    }
                    item { SettingRow("Putar dari tautan", onClick = { linkOpen = true }) { Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub) } }
                }
                Section.AUDIO -> {
                    item { SettingRow("Efek suara, 3D dan 8D", onClick = { ui.fxOpen = true }) { Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub) } }
                    item {
                        SettingRow("Perangkat audio", value = output.name, onClick = { ui.outputOpen = true }) {
                            Ic(outputIcon(output.kind), tint = if (output.isBluetooth) Color(0xFF6FB6FF) else AlterColors.Sub)
                        }
                    }
                    item { SettingRow("Notifikasi perangkat audio") { AlterSwitch(st.outputToast) { app.settings.setOutputToast(it) } } }
                    item { SettingsHeader("Profil otomatis") }
                    item {
                        ChipSetting("Bluetooth") {
                            DeviceProfile.options.forEach { (v, label) -> AlterChip(label, st.profileBluetooth == v, { app.settings.setProfileBluetooth(v) }) }
                        }
                    }
                    item {
                        ChipSetting("Headset berkabel") {
                            DeviceProfile.options.forEach { (v, label) -> AlterChip(label, st.profileWired == v, { app.settings.setProfileWired(v) }) }
                        }
                    }
                    item {
                        ChipSetting("Speaker ponsel") {
                            DeviceProfile.options.forEach { (v, label) -> AlterChip(label, st.profilePhone == v, { app.settings.setProfilePhone(v) }) }
                        }
                    }
                }
                Section.LYRICS -> {
                    item {
                        ChipSetting("Terjemahan") {
                            AlterChip("Mati", st.translateLang.isEmpty(), { app.settings.setTranslateLang("") })
                            TRANSLATE_LANGS.forEach { l -> AlterChip(l.label, st.translateLang == l.code, { app.settings.setTranslateLang(l.code) }) }
                        }
                    }
                    item {
                        ChipSetting("Geser waktu lirik") {
                            listOf(-1000 to "-1,0", -500 to "-0,5", 0 to "0", 500 to "+0,5", 1000 to "+1,0").forEach { (ms, label) ->
                                AlterChip(label, st.lyricOffsetMs == ms, { app.settings.setLyricOffsetMs(ms) })
                            }
                        }
                    }
                }
                Section.LOCAL -> {
                    item {
                        SettingRow("Pindai ulang", value = "${local.songs.size} lagu", onClick = {
                            scope.launch { app.localMusic.refresh() }
                            context.toast("Memindai...")
                        }) { Ic(R.drawable.ic_refresh, tint = AlterColors.Sub) }
                    }
                    item {
                        SettingRow(
                            "Izin akses musik",
                            value = if (audioGranted) "Diizinkan" else "Belum",
                            onClick = if (audioGranted) null else ({ permissionLauncher.launch(PermissionHelper.audioPermission()) }),
                        ) { Ic(if (audioGranted) R.drawable.ic_check else R.drawable.ic_chevron_right, tint = AlterColors.Sub) }
                    }
                    item {
                        ChipSetting("Abaikan audio pendek") {
                            listOf(0 to "Semua", 10 to "< 10 dtk", 20 to "< 20 dtk", 30 to "< 30 dtk", 60 to "< 1 mnt").forEach { (sec, label) ->
                                AlterChip(label, st.localMinSeconds == sec, {
                                    app.settings.setLocalMinSeconds(sec)
                                    scope.launch { app.localMusic.refresh() }
                                })
                            }
                        }
                    }
                    item { SettingRow("Buka musik di perangkat", onClick = { ui.navigate(Route.Local) }) { Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub) } }
                }
                Section.RECO -> {
                    item {
                        SettingRow("Genre favorit", value = if (lib.tastePicks.isEmpty()) "Belum dipilih" else "${lib.tastePicks.size} dipilih", onClick = { pickerOpen = true }) {
                            Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub)
                        }
                    }
                    item { SettingRow("Rekap musikmu", onClick = { ui.navigate(Route.Stats) }) { Ic(R.drawable.ic_chart, tint = AlterColors.Sub) } }
                    item { SettingRow("Atur ulang rekomendasi", onClick = { confirmClearStats = true }) {} }
                }
                Section.DOWNLOADS -> {
                    item {
                        SettingRow(
                            "Unduhan",
                            value = "${lib.downloads.size} lagu • ${formatBytes(lib.downloads.sumOf { it.bytes })}",
                            onClick = { ui.navigate(Route.Downloads) },
                        ) { Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub) }
                    }
                    item { SettingRow("Unduh otomatis lagu disukai (Wi-Fi)") { AlterSwitch(st.autoDownloadLiked) { app.settings.setAutoDownloadLiked(it) } } }
                    item {
                        val cacheBytes =
                            remember(cacheTick) {
                                (File(context.cacheDir, "lyrics").listFiles()?.sumOf { it.length() } ?: 0L) + app.translator.cacheBytes()
                            }
                        SettingRow("Cache lirik dan terjemahan", value = formatBytes(cacheBytes), onClick = {
                            File(context.cacheDir, "lyrics").listFiles()?.forEach { it.delete() }
                            app.translator.clearCache()
                            cacheTick++
                            context.toast("Cache dibersihkan")
                        }) { Ic(R.drawable.ic_trash, tint = AlterColors.Sub) }
                    }
                }
                Section.DATA -> {
                    item {
                        SettingRow("Hapus riwayat putar", value = "${lib.recent.size}", onClick = {
                            app.library.clearRecent()
                            context.toast("Dihapus")
                        }) {}
                    }
                    item {
                        SettingRow("Hapus riwayat pencarian", value = "${lib.searches.size}", onClick = {
                            app.library.clearSearches()
                            context.toast("Dihapus")
                        }) {}
                    }
                    item { SettingRow("Cadangkan pustaka", onClick = { exportLauncher.launch("alterlist-cadangan.json") }) { Ic(R.drawable.ic_arrow_up, tint = AlterColors.Sub) } }
                    item { SettingRow("Pulihkan pustaka", onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) }) { Ic(R.drawable.ic_download, tint = AlterColors.Sub) } }
                }
                Section.ABOUT -> {
                    item { SettingRow("Tentang Alterlist", onClick = { ui.navigate(Route.About) }) { Ic(R.drawable.ic_info, tint = AlterColors.Sub) } }
                }
            }
        }
    }

    if (pickerOpen) {
        BottomSheetDialog({ pickerOpen = false }) {
            Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
                TastePickerCard(
                    initial = lib.tastePicks,
                    onSave = {
                        app.library.setTastePicks(it)
                        pickerOpen = false
                        context.toast("Disimpan")
                    },
                    title = "Genre favorit",
                )
            }
        }
    }
    if (linkOpen) {
        TextInputDialog(
            title = "Putar dari tautan",
            initial = "",
            confirmLabel = "Putar",
            placeholder = "Tempel tautan YouTube",
            onDismiss = { linkOpen = false },
            onConfirm = { text ->
                linkOpen = false
                scope.launch {
                    val ok = LinkHandler.play(app, text)
                    if (!ok) context.toast("Tautan tidak dikenali")
                }
            },
        )
    }
    if (confirmSignOut) {
        ConfirmDialog(
            title = "Keluar dari akun?",
            message = "Kamu akan kembali menjadi tamu.",
            confirmLabel = "Keluar",
            onDismiss = { confirmSignOut = false },
            onConfirm = {
                confirmSignOut = false
                app.account.signOut()
                app.yt.setAccount(null)
            },
        )
    }
    if (confirmClearStats) {
        ConfirmDialog(
            title = "Atur ulang rekomendasi?",
            message = "Statistik putar dihapus.",
            confirmLabel = "Atur ulang",
            onDismiss = { confirmClearStats = false },
            onConfirm = {
                confirmClearStats = false
                app.library.clearStats()
                app.recommender.clear()
            },
        )
    }
}

@Composable
private fun SettingsHeader(text: String) {
    Text(text, style = T.small.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Bold), color = AlterColors.Sub, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 4.dp))
}

@Composable
private fun SettingRow(
    title: String,
    value: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = T.title, modifier = Modifier.weight(1f))
        if (value != null) {
            Text(value, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 8.dp))
            Spacer(Modifier.width(8.dp))
        }
        trailing()
    }
}

@Composable
private fun ChipSetting(title: String, chips: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(title, style = T.title)
        Spacer(Modifier.size(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { chips() }
    }
}
