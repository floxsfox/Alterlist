package com.alterlist.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Backup
import com.alterlist.app.system.PermissionHelper
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(padding: PaddingValues, onBack: () -> Unit, onLogin: () -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val account by app.account.state.collectAsState()
    val lib by app.library.data.collectAsState()
    val scope = rememberCoroutineScope()
    val st by app.settings.state.collectAsState()
    val output by app.audioOutput.active.collectAsState()
    val local by app.localMusic.state.collectAsState()
    var pickerOpen by remember { mutableStateOf(false) }
    var audioGranted by remember { mutableStateOf(PermissionHelper.hasAudioAccess(context)) }
    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            audioGranted = granted
            if (granted) scope.launch { app.localMusic.refresh() }
        }
    val exportLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                scope.launch {
                    val ok = Backup.exportTo(context, app.library, uri)
                    context.toast(if (ok) "Cadangan tersimpan" else "Gagal menyimpan cadangan")
                }
            }
        }
    val importLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                scope.launch {
                    val n = Backup.restore(context, app.library, uri)
                    context.toast(if (n != null) "Pustaka dipulihkan ($n item)" else "Berkas cadangan tidak valid")
                }
            }
        }
    var confirmSignOut by remember { mutableStateOf(false) }
    var confirmClearStats by remember { mutableStateOf(false) }
    val version = remember { runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0" }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = padding.calculateBottomPadding() + 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.ic_chevron_left, onBack)
                Text("Pengaturan", style = T.section, modifier = Modifier.weight(1f))
            }
        }

        // akun
        item {
            Row(
                Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(12.dp)).background(AlterColors.Surface).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (account.mode == AccountMode.GOOGLE && account.photo != null) {
                    Artwork(account.photo, Modifier.size(56.dp), CircleShape, px = 160)
                } else {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(AlterColors.Surface3), contentAlignment = Alignment.Center) {
                        Ic(R.drawable.ic_user, size = 28.dp)
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (account.mode == AccountMode.GOOGLE) account.name.ifBlank { "Akun Google" } else "Tamu",
                        style = T.title,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        if (account.mode == AccountMode.GOOGLE) account.email.ifBlank { "Terhubung ke YouTube Music" } else "Masuk agar beranda mengikuti akun YouTube Music-mu",
                        style = T.small,
                        color = AlterColors.Sub,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                if (account.mode == AccountMode.GOOGLE) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(50))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(50))
                            .clickable { confirmSignOut = true }
                            .padding(vertical = 13.dp),
                        contentAlignment = Alignment.Center,
                    ) { Text("Keluar", style = T.button) }
                } else {
                    PillButton("Masuk dengan Google", onLogin, Modifier.fillMaxWidth())
                }
            }
        }

        // pemutaran
        item { SettingsHeader("Pemutaran") }
        item {
            SettingRow(
                "Putar otomatis",
                "Saat antrean habis, putar lagu yang mirip.",
            ) { AlterSwitch(lib.autoplay) { app.library.setAutoplay(it) } }
        }
        item {
            SettingRow(
                "Sesi pribadi",
                "Riwayat, statistik, dan pencarian tidak disimpan selama aktif.",
            ) { AlterSwitch(lib.privateSession) { app.library.setPrivateSession(it) } }
        }

        // audio
        item { SettingsHeader("Audio") }
        item {
            SettingRow("Efek suara, 3D dan 8D", "Preset, audio spasial, reverb, equalizer", onClick = { ui.fxOpen = true }) {
                Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub)
            }
        }
        item {
            SettingRow("Perangkat audio", "${output.name} • ${output.kind.label}", onClick = { ui.outputOpen = true }) {
                Ic(outputIcon(output.kind), tint = if (output.isBluetooth) Color(0xFF6FB6FF) else AlterColors.Sub)
            }
        }
        item {
            SettingRow("Notifikasi perangkat audio", "Tampilkan pesan saat speaker atau earphone Bluetooth tersambung.") {
                AlterSwitch(st.outputToast) { app.settings.setOutputToast(it) }
            }
        }
        item {
            SettingRow("Lewati bagian hening", "Hilangkan jeda sunyi di dalam lagu.") {
                AlterSwitch(st.skipSilence) { app.settings.setSkipSilence(it) }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("Fade antar lagu", style = T.title)
                Text("Suara mengecil di akhir lagu dan naik pelan di awal lagu berikutnya.", style = T.small, color = AlterColors.Sub)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Mati", 2000 to "2 detik", 4000 to "4 detik", 6000 to "6 detik", 8000 to "8 detik").forEach { (ms, label) ->
                        AlterChip(label, st.fadeMs == ms, { app.settings.setFadeMs(ms) })
                    }
                }
            }
        }

        // musik di perangkat
        item { SettingsHeader("Musik di perangkat") }
        item {
            SettingRow("Pindai ulang", "${local.songs.size} lagu ditemukan", onClick = {
                scope.launch { app.localMusic.refresh() }
                context.toast("Memindai musik...")
            }) { Ic(R.drawable.ic_refresh, tint = AlterColors.Sub) }
        }
        item {
            SettingRow(
                "Izin akses musik",
                if (audioGranted) "Diizinkan" else "Belum diizinkan. Ketuk untuk mengizinkan.",
                onClick = if (audioGranted) null else ({ permissionLauncher.launch(PermissionHelper.audioPermission()) }),
            ) { Ic(if (audioGranted) R.drawable.ic_check else R.drawable.ic_chevron_right, tint = AlterColors.Sub) }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("Abaikan audio pendek", style = T.title)
                Text("Sembunyikan rekaman pendek (suara notifikasi, pesan suara) dari daftar.", style = T.small, color = AlterColors.Sub)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0 to "Tampilkan semua", 10 to "< 10 dtk", 20 to "< 20 dtk", 30 to "< 30 dtk", 60 to "< 1 menit").forEach { (sec, label) ->
                        AlterChip(label, st.localMinSeconds == sec, {
                            app.settings.setLocalMinSeconds(sec)
                            scope.launch { app.localMusic.refresh() }
                        })
                    }
                }
            }
        }

        // rekomendasi
        item { SettingsHeader("Rekomendasi") }
        item {
            SettingRow(
                "Genre favorit",
                if (lib.tastePicks.isEmpty()) "Belum dipilih" else lib.tastePicks.joinToString(", "),
                onClick = { pickerOpen = true },
            ) { Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub) }
        }
        item {
            SettingRow("Rekap musikmu", "Lagu, artis, dan genre teratas", onClick = { ui.navigate(Route.Stats) }) {
                Ic(R.drawable.ic_chart, tint = AlterColors.Sub)
            }
        }

        // cadangan
        item { SettingsHeader("Cadangan") }
        item {
            SettingRow("Cadangkan pustaka", "Simpan lagu disukai, playlist, riwayat, dan statistik ke berkas.", onClick = {
                exportLauncher.launch("alterlist-cadangan.json")
            }) { Ic(R.drawable.ic_arrow_up, tint = AlterColors.Sub) }
        }
        item {
            SettingRow("Pulihkan pustaka", "Muat kembali dari berkas cadangan.", onClick = {
                importLauncher.launch(arrayOf("application/json", "*/*"))
            }) { Ic(R.drawable.ic_download, tint = AlterColors.Sub) }
        }

        // penyimpanan
        item { SettingsHeader("Data & penyimpanan") }
        item {
            SettingRow(
                "Unduhan",
                "${lib.downloads.size} lagu • ${formatBytes(lib.downloads.sumOf { it.bytes })}",
                onClick = { ui.navigate(Route.Downloads) },
            ) { Ic(R.drawable.ic_chevron_right, tint = AlterColors.Sub) }
        }
        item {
            SettingRow("Hapus riwayat putar", "${lib.recent.size} lagu", onClick = {
                app.library.clearRecent()
                context.toast("Riwayat putar dihapus")
            }) {}
        }
        item {
            SettingRow("Hapus riwayat pencarian", "${lib.searches.size} pencarian", onClick = {
                app.library.clearSearches()
                context.toast("Riwayat pencarian dihapus")
            }) {}
        }
        item {
            SettingRow(
                "Atur ulang rekomendasi",
                "Hapus statistik yang dipakai Beranda untuk mengenali seleramu.",
                onClick = { confirmClearStats = true },
            ) {}
        }

        item { SettingsHeader("Tentang") }
        item {
            SettingRow("Tentang Alterlist", "Fitur, info sistem, dan lisensi", onClick = { ui.navigate(Route.About) }) {
                Ic(R.drawable.ic_info, tint = AlterColors.Sub)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text("Alterlist $version", style = T.title)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Alterlist memakai API tidak resmi YouTube Music lewat library InnerTubeX (GPL-3.0). " +
                        "Pakai untuk keperluan pribadi dan atas tanggung jawab sendiri. Font: Figtree (SIL OFL).",
                    style = T.small,
                    color = AlterColors.Sub,
                )
            }
        }
    }

    if (pickerOpen) {
        BottomSheetDialog({ pickerOpen = false }) {
            Column(Modifier.heightIn(max = 600.dp).verticalScroll(rememberScrollState())) {
                TastePickerCard(
                    initial = lib.tastePicks,
                    onSave = {
                        app.library.setTastePicks(it)
                        pickerOpen = false
                        context.toast("Genre favorit disimpan")
                    },
                    title = "Genre favoritmu",
                )
            }
        }
    }
    if (confirmSignOut) {
        ConfirmDialog(
            title = "Keluar dari akun?",
            message = "Kamu akan kembali menjadi tamu. Lagu disukai, playlist, dan unduhan di HP ini tetap tersimpan.",
            confirmLabel = "Keluar",
            onDismiss = { confirmSignOut = false },
            onConfirm = {
                confirmSignOut = false
                app.account.signOut()
                app.yt.setAccount(null)
            },
        )
    }
    if (confirmClearStats) {
        ConfirmDialog(
            title = "Atur ulang rekomendasi?",
            message = "Mix dan artis favorit di Beranda akan dibangun ulang dari nol.",
            confirmLabel = "Atur ulang",
            onDismiss = { confirmClearStats = false },
            onConfirm = {
                confirmClearStats = false
                app.library.clearStats()
                app.recommender.clear()
            },
        )
    }
}

@Composable
private fun SettingsHeader(text: String) {
    Text(text, style = T.section.copy(fontSize = 18.sp), modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 6.dp))
}

@Composable
private fun SettingRow(
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = T.title)
            Text(subtitle, style = T.small, color = AlterColors.Sub)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}
