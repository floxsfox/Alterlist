package com.alterlist.app.download

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.alterlist.app.data.DownloadedSong
import com.alterlist.app.data.Library
import com.alterlist.app.data.Net
import com.alterlist.app.data.ScStream
import com.alterlist.app.data.Song
import com.alterlist.app.data.SoundCloud
import com.alterlist.app.data.YtMusic
import com.alterlist.app.data.primaryArtist
import com.alterlist.app.data.watchUrl
import com.alterlist.app.data.withSize
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Mengunduh lagu lengkap dengan informasi: cover, judul, artis, album, penerbit, sumber.
 *  - YouTube Music: M4A. Tanpa FFmpeg: kemasan DASH diubah jadi M4A biasa lalu tag ditulis langsung ([Mp4Defrag], [Mp4Tagger]).
 *  - SoundCloud (NewPipeExtractor): MP3 progresif disimpan apa adanya + tag ID3 ([Id3Tagger]); stream HLS segmennya
 *    disambung lalu (bila fMP4) dijadikan M4A lewat jalur yang sama dengan YouTube.
 */
class Downloader(
    private val context: Context,
    private val yt: YtMusic,
    private val library: Library,
    private val soundcloud: SoundCloud,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dir = File(context.filesDir, "downloads").apply { mkdirs() }
    private val queue = Channel<Song>(Channel.UNLIMITED)
    private val titles = ConcurrentHashMap<String, String>()
    private val cancelled = ConcurrentHashMap.newKeySet<String>()
    private var worker: Job? = null

    private val _progress = MutableStateFlow<Map<String, Int>>(emptyMap())

    /** id lagu -> persen (0..100); -1 artinya masih antre. Kosong bila tidak ada unduhan berjalan. */
    val progress: StateFlow<Map<String, Int>> = _progress.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        // versi lama menyalin unduhan ke Music/Alterlist; salinan itu dibersihkan sekali saja
        scope.launch { purgeLegacyExports() }
    }

    private fun purgeLegacyExports() {
        val prefs = context.getSharedPreferences("alterlist_downloads", Context.MODE_PRIVATE)
        if (prefs.getBoolean("exports_purged", false)) return
        library.data.value.downloads.forEach { d ->
            d.exportUri?.let { runCatching { context.contentResolver.delete(Uri.parse(it), null, null) } }
        }
        prefs.edit().putBoolean("exports_purged", true).apply()
    }

    fun titleOf(id: String): String = titles[id].orEmpty()

    fun fileFor(id: String): File? {
        val item = library.data.value.downloads.firstOrNull { it.song.id == id } ?: return null
        val f = File(dir, item.fileName)
        return f.takeIf { it.exists() && it.length() > 0 }
    }

    fun isDownloaded(id: String): Boolean = fileFor(id) != null

    fun enqueue(song: Song) {
        // YouTube Music dan SoundCloud bisa diunduh; musik perangkat sudah ada di penyimpanan
        if (song.isLocal) return
        if (isDownloaded(song.id) || _progress.value.containsKey(song.id)) return
        titles[song.id] = song.title
        _progress.update { it + (song.id to -1) }
        queue.trySend(song)
        ensureWorker()
        DownloadService.start(context)
    }

    fun enqueueAll(songs: List<Song>) = songs.forEach { enqueue(it) }

    fun cancel(id: String) {
        cancelled.add(id)
        _progress.update { it - id }
    }

    fun delete(id: String) {
        val item = library.data.value.downloads.firstOrNull { it.song.id == id }
        if (item != null) {
            File(dir, item.fileName).delete()
            item.exportUri?.let { runCatching { context.contentResolver.delete(Uri.parse(it), null, null) } }
        }
        library.removeDownload(id)
    }

    fun totalBytes(): Long = library.data.value.downloads.sumOf { it.bytes }

    private fun ensureWorker() {
        if (worker?.isActive == true) return
        worker =
            scope.launch {
                for (song in queue) {
                    if (cancelled.remove(song.id)) {
                        finish(song.id)
                        continue
                    }
                    try {
                        downloadOne(song)
                    } catch (e: Exception) {
                        if (!cancelled.contains(song.id)) {
                            _messages.tryEmit("Gagal mengunduh \"${song.title}\": ${e.message ?: "kesalahan tidak diketahui"}")
                        }
                    } finally {
                        cancelled.remove(song.id)
                        File(dir, "${fileKey(song.id)}.part").delete()
                        File(dir, "${fileKey(song.id)}.dash.tmp").delete()
                        finish(song.id)
                    }
                }
            }
    }

    private fun finish(id: String) {
        titles.remove(id)
        _progress.update { it - id }
    }

    private fun setProgress(id: String, percent: Int) {
        _progress.update { if (it.containsKey(id)) it + (id to percent.coerceIn(0, 100)) else it }
    }

    /** Nama dasar berkas di disk. Id YouTube sudah aman; id lain (mis. "sc:...") diubah jadi hash supaya valid sebagai nama berkas. */
    private fun fileKey(id: String): String =
        if (SAFE_ID.matches(id)) {
            id
        } else {
            "x" + MessageDigest.getInstance("SHA-1").digest(id.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
        }

    private suspend fun downloadOne(song: Song) {
        if (song.isSoundCloud) {
            downloadSoundCloud(song)
            return
        }
        setProgress(song.id, 0)
        val key = fileKey(song.id)
        val stream = yt.resolveForDownload(song.id)
        val part = File(dir, "$key.part")
        downloadTo(part, stream.url, stream.headers, stream.contentLength) { percent ->
            if (cancelled.contains(song.id)) throw IOException("Dibatalkan")
            setProgress(song.id, percent)
        }

        val isMp4 = stream.mimeType.contains("mp4", true) || stream.mimeType.contains("m4a", true) || stream.mimeType.contains("aac", true)
        val publisher = stream.author?.takeIf { it.isNotBlank() } ?: primaryArtist(song.artist).ifBlank { null }
        val finalFile: File
        if (isMp4) {
            finalFile = finishM4a(song, key, part, publisher, "YouTube Music", fetchCover(song))
        } else {
            // format cadangan (mis. WebM): disimpan apa adanya, informasi tetap tercatat di aplikasi
            finalFile = File(dir, "$key.webm")
            if (finalFile.exists()) finalFile.delete()
            if (!part.renameTo(finalFile)) throw IOException("Gagal menyimpan berkas")
        }
        // Lagu hanya disimpan di penyimpanan privat aplikasi (ikut terhapus saat aplikasi dihapus), tidak disalin ke folder Musik.
        val exportUri: String? = null
        library.addDownload(
            DownloadedSong(
                song = song,
                fileName = finalFile.name,
                bytes = finalFile.length(),
                addedAt = System.currentTimeMillis(),
                publisher = publisher,
                exportUri = exportUri,
            ),
        )
    }

    /** DASH/fMP4 -> M4A biasa lalu tulis tag. Kalau konversi atau tag gagal, berkas apa adanya tetap disimpan. */
    private fun finishM4a(song: Song, key: String, part: File, publisher: String?, sourceLabel: String, cover: ByteArray?): File {
        val dash = File(dir, "$key.dash.tmp")
        val source =
            try {
                if (Mp4Defrag.defragment(part, dash)) dash else part
            } catch (e: Exception) {
                dash.delete()
                part
            }
        val finalFile = File(dir, "$key.m4a")
        try {
            Mp4Tagger.tag(
                source,
                finalFile,
                Mp4Tags(
                    title = song.title,
                    artist = song.artist,
                    albumArtist = primaryArtist(song.artist).ifBlank { song.artist },
                    album = song.album,
                    comment = song.watchUrl(),
                    publisher = publisher,
                    source = sourceLabel,
                    cover = cover,
                ),
            )
        } catch (e: Exception) {
            // tag gagal ditulis: simpan audio apa adanya supaya unduhan tidak sia-sia
            source.copyTo(finalFile, overwrite = true)
        }
        return finalFile
    }

    // ---------------------------------------------------------------- SoundCloud

    private suspend fun downloadSoundCloud(song: Song) {
        setProgress(song.id, 0)
        val key = fileKey(song.id)
        val stream = soundcloud.resolve(song.id, song.uri)
        val part = File(dir, "$key.part")
        val ext: String =
            if (stream.hls) {
                downloadHls(stream, part, song.id)
            } else {
                downloadTo(part, stream.url, emptyMap(), null) { percent ->
                    if (cancelled.contains(song.id)) throw IOException("Dibatalkan")
                    setProgress(song.id, percent)
                }
                if (stream.ext == "m4a") "m4a" else "mp3"
            }
        val publisher = primaryArtist(song.artist).ifBlank { null }
        val cover = fetchCover(song)
        val finalFile: File =
            when (ext) {
                "m4a" -> finishM4a(song, key, part, publisher, "SoundCloud", cover)
                "mp3" -> {
                    val out = File(dir, "$key.mp3")
                    try {
                        Id3Tagger.tag(part, out, song.title, song.artist, primaryArtist(song.artist).ifBlank { song.artist }, song.album, song.watchUrl(), cover)
                    } catch (e: Exception) {
                        // tag gagal ditulis: simpan MP3 apa adanya
                        part.copyTo(out, overwrite = true)
                    }
                    out
                }
                else -> {
                    val out = File(dir, "$key.$ext")
                    if (out.exists()) out.delete()
                    if (!part.renameTo(out)) throw IOException("Gagal menyimpan berkas")
                    out
                }
            }
        library.addDownload(
            DownloadedSong(
                song = song,
                fileName = finalFile.name,
                bytes = finalFile.length(),
                addedAt = System.currentTimeMillis(),
                publisher = publisher,
                exportUri = null,
            ),
        )
    }

    /**
     * Unduh stream HLS SoundCloud dengan menyambung semua segmennya (init fMP4 lebih dulu bila ada).
     * Mengembalikan jenis berkas hasilnya: "m4a" (fMP4), "ts", "aac" (ADTS), atau "mp3".
     */
    private suspend fun downloadHls(stream: ScStream, target: File, id: String): String {
        var playlistUrl = stream.url
        var text = Net.getText(playlistUrl) ?: throw IOException("Playlist HLS tidak bisa diambil")
        if (text.contains("#EXT-X-STREAM-INF")) {
            // playlist induk: ambil varian pertama
            val variant =
                text.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
                    ?: throw IOException("Playlist HLS tidak berisi stream")
            playlistUrl = absoluteUrl(playlistUrl, variant)
            text = Net.getText(playlistUrl) ?: throw IOException("Playlist HLS tidak bisa diambil")
        }
        val lines = text.lines().map { it.trim() }
        if (lines.any { it.startsWith("#EXT-X-KEY") && !it.contains("METHOD=NONE") }) {
            throw IOException("Stream HLS terenkripsi belum bisa diunduh")
        }
        val initUrl =
            lines.firstOrNull { it.startsWith("#EXT-X-MAP") }
                ?.let { Regex("URI=\"([^\"]+)\"").find(it)?.groupValues?.get(1) }
                ?.let { absoluteUrl(playlistUrl, it) }
        val segments = lines.filter { it.isNotEmpty() && !it.startsWith("#") }.map { absoluteUrl(playlistUrl, it) }
        if (segments.isEmpty()) throw IOException("Playlist HLS kosong")
        val all = listOfNotNull(initUrl) + segments
        FileOutputStream(target).use { out ->
            all.forEachIndexed { i, u ->
                if (cancelled.contains(id)) throw IOException("Dibatalkan")
                appendUrl(out, u)
                setProgress(id, ((i + 1) * 100) / all.size)
            }
        }
        if (target.length() == 0L) throw IOException("Berkas kosong")
        return when {
            initUrl != null -> "m4a"
            segments.first().substringBefore('?').endsWith(".ts") -> "ts"
            stream.ext == "m4a" -> "aac"
            else -> "mp3"
        }
    }

    private fun absoluteUrl(base: String, ref: String): String = if (ref.startsWith("http")) ref else URL(URL(base), ref).toString()

    private fun appendUrl(out: OutputStream, url: String) {
        val conn = Net.open(url, emptyMap(), 30_000)
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Server menolak (HTTP $code)")
            conn.inputStream.use { it.copyTo(out) }
        } finally {
            conn.disconnect()
        }
    }

    private fun downloadTo(
        target: File,
        url: String,
        headers: Map<String, String>,
        knownTotal: Long?,
        onPercent: (Int) -> Unit,
    ) {
        var offset = 0L
        var total = knownTotal
        FileOutputStream(target).use { out ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val end = offset + CHUNK - 1
                val rangeEnd = if (total != null) minOf(end, total - 1) else end
                val conn = Net.open(url, headers + ("Range" to "bytes=$offset-$rangeEnd"), 30_000)
                try {
                    val code = conn.responseCode
                    if (code != 206 && code != 200) throw IOException("Server menolak (HTTP $code)")
                    if (total == null) {
                        total = conn.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull()
                            ?: if (code == 200) conn.contentLengthLong.takeIf { it > 0 } else null
                    }
                    var read = 0L
                    conn.inputStream.use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n <= 0) break
                            out.write(buf, 0, n)
                            read += n
                            val t = total
                            if (t != null && t > 0) onPercent(((offset + read) * 100 / t).toInt())
                        }
                    }
                    offset += read
                    val t = total
                    if (code == 200) break // server mengirim seluruh berkas sekaligus
                    if (read == 0L) break
                    if (t != null && offset >= t) break
                } finally {
                    conn.disconnect()
                }
            }
        }
        if (target.length() == 0L) throw IOException("Berkas kosong")
    }

    /** Ambil cover beresolusi tinggi; kalau gagal pakai thumbnail video. Selalu dikonversi ke JPEG. */
    private suspend fun fetchCover(song: Song): ByteArray? {
        val candidates =
            if (song.isSoundCloud) {
                listOfNotNull(song.thumbnail)
            } else {
                listOfNotNull(song.thumbnail?.withSize(1000), "https://i.ytimg.com/vi/${song.id}/hqdefault.jpg")
            }
        for (url in candidates) {
            val bytes = Net.getBytes(url) ?: continue
            return toJpeg(bytes) ?: continue
        }
        return null
    }

    private fun toJpeg(bytes: ByteArray): ByteArray? {
        // JPEG asli langsung dipakai
        if (bytes.size > 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte()) return bytes
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        return ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }.toByteArray()
    }

    /** Salin juga ke folder Musik (Android 10+) supaya terlihat di pemutar lain dan aplikasi File. */
    private fun exportToMusic(file: File, song: Song): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val name = sanitize("${primaryArtist(song.artist).ifBlank { "Artis" }} - ${song.title}") + ".m4a"
        val values =
            ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, name)
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Alterlist")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: throw IOException("tidak bisa menulis")
            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            uri.toString()
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            null
        }
    }

    private fun sanitize(s: String): String = s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(120)

    private companion object {
        const val CHUNK = 2L * 1024 * 1024
        val SAFE_ID = Regex("[A-Za-z0-9_-]{1,64}")
    }
}
