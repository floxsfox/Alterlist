package com.alterlist.app.system

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.alterlist.app.AlterApp
import com.alterlist.app.MainActivity
import com.alterlist.app.R
import com.alterlist.app.ui.AlterOverlayTheme
import com.alterlist.app.ui.BarCutout
import com.alterlist.app.ui.DynamicBarContent
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.max

/**
 * Dynamic bar: pil musik melayang di sekitar kamera depan (ala Dynamic Island). Jendela dibuat sekecil isinya
 * (WRAP_CONTENT) dan tidak merebut fokus, jadi area di luar pil tetap bisa disentuh seperti biasa.
 */
class DynamicBarService : Service() {
    private lateinit var wm: WindowManager
    private val owner = BarOwner()
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate + CoroutineExceptionHandler { _, _ -> })

    private var view: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null
    private var cutout by mutableStateOf(BarCutout.None)
    private var expandedNow = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startInForeground()
        val st = AlterApp.instance.settings.state.value
        if (!st.dynamicBar || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        owner.create()
        AlterApp.instance.player.connect()
        attach()
        scope.launch {
            AlterApp.instance.settings.state.map { it.dynamicBar to it.dynamicBarCamera }.distinctUntilChanged().collect { (on, _) ->
                if (!on) {
                    stopSelf()
                } else {
                    refreshCutout()
                    applyWindow(expandedNow)
                }
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        view?.post {
            refreshCutout()
            applyWindow(expandedNow)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        view?.let {
            runCatching { it.disposeComposition() }
            runCatching { wm.removeView(it) }
        }
        view = null
        owner.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- jendela

    private fun attach() {
        val v =
            ComposeView(this).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
                setContent {
                    AlterOverlayTheme {
                        DynamicBarContent(cutout) { expanded ->
                            expandedNow = expanded
                            handler.post { applyWindow(expanded) }
                        }
                    }
                }
            }
        val p =
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                layoutInDisplayCutoutMode =
                    if (Build.VERSION.SDK_INT >= 30) {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    } else {
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
            }
        try {
            wm.addView(v, p)
            view = v
            params = p
            refreshCutout()
            applyWindow(false)
            // Android 10: info kamera baru tersedia setelah jendela terpasang
            v.post {
                refreshCutout()
                applyWindow(expandedNow)
            }
        } catch (e: Exception) {
            view = null
            params = null
            stopSelf()
        }
    }

    /** Baca posisi kamera dari sistem; mode manual "Tompel" / "Menyatu" dipakai bila sistem tidak melaporkannya. */
    private fun refreshCutout() {
        val dm = resources.displayMetrics
        val d = dm.density
        val mode = AlterApp.instance.settings.state.value.dynamicBarCamera
        var rect: Rect? = null
        try {
            val insets = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.windowInsets else view?.rootWindowInsets
            rect = insets?.displayCutout?.boundingRectTop
        } catch (e: Exception) {
            rect = null
        }
        if (rect != null && rect.isEmpty) rect = null
        val punch =
            when (mode) {
                "tompel" -> true
                "menyatu" -> false
                else -> rect != null && rect.top > 2 * d
            }
        cutout =
            when {
                rect != null ->
                    BarCutout(true, punch, rect.width() / d, rect.height() / d, rect.top / d, rect.bottom / d, (rect.exactCenterX() - dm.widthPixels / 2f) / d)
                mode == "tompel" -> BarCutout(true, true, 22f, 22f, 10f, 32f, 0f)
                mode == "menyatu" -> BarCutout(true, false, 64f, 28f, 0f, 28f, 0f)
                else -> BarCutout.None
            }
    }

    /** Tertutup: pas di sekitar kamera. Terbuka: kartu di tengah, tepat di bawah kamera / bilah status. */
    private fun applyWindow(expanded: Boolean) {
        val p = params ?: return
        val v = view ?: return
        val d = resources.displayMetrics.density
        val c = cutout
        if (expanded) {
            p.x = 0
            p.y = (((if (c.present) c.bottomDp else 30f) + 8f) * d).toInt()
        } else {
            p.x = (c.offsetDp * d).toInt()
            p.y = (if (!c.present) 8f * d else if (c.punch) max(0f, c.topDp - 5f) * d else 0f).toInt()
        }
        runCatching { wm.updateViewLayout(v, p) }
    }

    // ---------------------------------------------------------------- foreground

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Dynamic bar", NotificationManager.IMPORTANCE_MIN).apply { setShowBadge(false) })
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification =
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_alterlist)
                .setContentTitle("Dynamic bar aktif")
                .setContentText("Kontrol musik melayang di sekitar kamera.")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /** Pemilik lifecycle / saved state untuk ComposeView yang hidup di dalam Service (bukan Activity). */
    private class BarOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        fun create() {
            controller.performAttach()
            controller.performRestore(null)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }

        fun destroy() {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
            store.clear()
        }
    }

    private companion object {
        const val CHANNEL_ID = "alterlist_dynamic_bar"
        const val NOTIFICATION_ID = 7421
    }
}

/** Satu pintu untuk menyalakan / mematikan dynamic bar sesuai pengaturan dan izin "Tampil di atas aplikasi lain". */
object DynamicBarController {
    fun sync(context: android.content.Context) {
        val st = AlterApp.instance.settings.state.value
        val intent = Intent(context, DynamicBarService::class.java)
        if (st.dynamicBar && Settings.canDrawOverlays(context)) {
            try {
                context.startForegroundService(intent)
            } catch (e: Exception) {
                // dilarang memulai foreground service dari latar belakang: dicoba lagi saat aplikasi dibuka
            }
        } else {
            context.stopService(intent)
        }
    }
}
