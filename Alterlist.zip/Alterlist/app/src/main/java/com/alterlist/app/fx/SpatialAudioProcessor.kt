package com.alterlist.app.fx

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * Audio spasial untuk PCM 16-bit stereo, dipasang sebelum reverb.
 *
 *  - **3D**: sinyal samping dilebarkan (mid/side) dan ditambah pantulan awal ruang yang saling silang antar kanal,
 *    sehingga suara terasa lebih lebar dan "keluar" dari kepala.
 *  - **8D**: sumber suara berputar mengelilingi kepala. Posisi ditiru dengan panning daya-sama, jeda antar-telinga
 *    (sampai ~0,6 ms), peredaman nada tinggi di telinga yang jauh dan saat sumber berada di belakang, plus sedikit
 *    suara ambient dari sinyal samping. Paling terasa dengan headphone / earphone.
 *
 * Perpindahan mode dihaluskan (~50 ms) sehingga tidak ada bunyi klik. Saat mati, audio dilewatkan apa adanya.
 */
class SpatialAudioProcessor : BaseAudioProcessor() {
    private var sampleRate = 44100
    private var smooth = 0.001f

    // 3D
    private var refL = DelayLine(2)
    private var refR = DelayLine(2)
    private val refLpL = OnePole()
    private val refLpR = OnePole()

    // 8D
    private var itd = DelayLine(2)
    private val farLpL = OnePole()
    private val farLpR = OnePole()
    private var phase = 0.0

    private var a3 = 0f
    private var a8 = 0f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        sampleRate = inputAudioFormat.sampleRate
        smooth = Dsp.smoothCoef(0.05f, sampleRate)
        val refSize = (0.05f * sampleRate).toInt() + 4
        refL = DelayLine(refSize)
        refR = DelayLine(refSize)
        itd = DelayLine((0.004f * sampleRate).toInt() + 4)
        clearState()
        return inputAudioFormat
    }

    private fun clearState() {
        refL.clear()
        refR.clear()
        itd.clear()
        refLpL.clear()
        refLpR.clear()
        farLpL.clear()
        farLpR.clear()
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val fx = AudioFx.state.value
        val t3 = if (fx.spatial == SpatialMode.WIDE_3D) fx.depth.coerceIn(0f, 1f) else 0f
        val t8 = if (fx.spatial == SpatialMode.ORBIT_8D) fx.depth.coerceIn(0f, 1f) else 0f

        if (t3 == 0f && t8 == 0f && a3 < 0.001f && a8 < 0.001f) {
            a3 = 0f
            a8 = 0f
            out.put(inputBuffer)
            out.flip()
            return
        }

        val frames = size / 4
        val phaseInc = Dsp.TWO_PI / (fx.orbitSeconds.toDouble() * sampleRate)
        val fs = sampleRate.toFloat()
        val tap1 = 0.0073f * fs
        val tap2 = 0.0139f * fs
        val tap3 = 0.0227f * fs
        val tap1b = 0.0089f * fs
        val tap2b = 0.0163f * fs
        val tap3b = 0.0251f * fs
        val refCoef = Dsp.lpCoef(5200f, sampleRate)
        val maxItd = 0.00062f * fs
        val quarterPi = (PI / 4.0).toFloat()

        var pos = inputBuffer.position()
        for (i in 0 until frames) {
            a3 += (t3 - a3) * smooth
            a8 += (t8 - a8) * smooth

            val inL = inputBuffer.getShort(pos) / 32768f
            val inR = inputBuffer.getShort(pos + 2) / 32768f
            pos += 4
            var l = inL
            var r = inR

            if (a3 > 0.0005f) {
                val m = (l + r) * 0.5f
                val s = (l - r) * 0.5f
                val wide = s * (1f + 1.1f * a3)
                refL.write(l)
                refR.write(r)
                val eL = refR.read(tap1) * 0.30f + refL.read(tap2) * 0.18f + refR.read(tap3) * 0.12f
                val eR = refL.read(tap1b) * 0.30f + refR.read(tap2b) * 0.18f + refL.read(tap3b) * 0.12f
                val fL = refLpL.lowpass(eL, refCoef)
                val fR = refLpR.lowpass(eR, refCoef)
                val wl = m + wide + fL * 0.9f
                val wr = m - wide + fR * 0.9f
                l += (wl - l) * a3
                r += (wr - r) * a3
                val g = 1f - 0.12f * a3
                l *= g
                r *= g
            }

            if (a8 > 0.0005f) {
                val m = (l + r) * 0.5f
                val s = (l - r) * 0.5f
                phase += phaseInc
                if (phase >= Dsp.TWO_PI) phase -= Dsp.TWO_PI
                val sinT = sin(phase).toFloat() // -1 kiri ... +1 kanan
                val cosT = cos(phase).toFloat() // +1 depan ... -1 belakang
                val back = (1f - cosT) * 0.5f // 0 depan ... 1 belakang

                // panning daya-sama
                val ang = (sinT + 1f) * quarterPi
                val gl = cos(ang)
                val gr = sin(ang)

                // jeda antar-telinga: telinga yang jauh mendengar lebih lambat
                itd.write(m)
                val dl = max(0f, sinT) * maxItd
                val dr = max(0f, -sinT) * maxItd
                var pl = itd.read(dl) * gl
                var pr = itd.read(dr) * gr

                // bayangan kepala: telinga jauh dan posisi belakang lebih redup
                val shadowL = max(0f, sinT)
                val shadowR = max(0f, -sinT)
                val cutL = 18000f * (1f - 0.86f * shadowL) * (1f - 0.55f * back)
                val cutR = 18000f * (1f - 0.86f * shadowR) * (1f - 0.55f * back)
                pl = farLpL.lowpass(pl, Dsp.lpCoef(cutL, sampleRate))
                pr = farLpR.lowpass(pr, Dsp.lpCoef(cutR, sampleRate))

                val dist = (1f - 0.22f * back) * 1.3f
                val amb = s * 0.4f
                val wl = pl * dist + amb
                val wr = pr * dist - amb
                l += (wl - l) * a8
                r += (wr - r) * a8
            }

            out.putShort((Dsp.softLimit(l).coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            out.putShort((Dsp.softLimit(r).coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        }
        inputBuffer.position(pos)
        // sisa byte (bila ada) disalin apa adanya supaya panjang keluaran = panjang masukan
        out.put(inputBuffer)
        out.flip()
    }

    override fun onFlush() {
        clearState()
    }

    override fun onReset() {
        refL = DelayLine(2)
        refR = DelayLine(2)
        itd = DelayLine(2)
        a3 = 0f
        a8 = 0f
    }
}
