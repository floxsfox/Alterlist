package com.alterlist.app.ui

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.importer.ImportDetect
import com.alterlist.app.importer.ImportState

/** Baris di atas daftar playlist Koleksi yang membuka sheet impor. */
@Composable
fun ImportEntryRow(onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().bounceClick(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)).background(AlterColors.Surface2),
            contentAlignment = Alignment.Center,
        ) {
            Ic(R.drawable.ic_download, tint = Color.White, size = 26.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Impor playlist", style = T.title)
            Text("Dari Spotify, Apple Music, SoundCloud, YouTube", style = T.small, color = AlterColors.Sub)
        }
    }
}

private fun readClipboard(context: Context): String? {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
    return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString()
}

@Composable
private fun ImportButton(
    label: String,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    val base = if (filled) AlterColors.Red else AlterColors.Surface3
    Box(
        modifier
            .height(46.dp)
            .clip(RoundedCornerShape(23.dp))
            .background(base.copy(alpha = if (enabled) 1f else 0.4f))
            .then(if (enabled) Modifier.bounceClick(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = T.button, color = Color.White.copy(alpha = if (enabled) 1f else 0.6f))
    }
}

/**
 * Impor playlist dari platform lain. Impor berjalan di latar (lihat PlaylistImporter), jadi sheet ini boleh ditutup
 * dan dibuka lagi untuk melihat kemajuannya.
 */
@Composable
fun ImportSheet(onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val state by app.importer.state.collectAsState()
    var text by remember { mutableStateOf("") }
    val platform = remember(text) { ImportDetect.platformOf(text) }

    BottomSheetDialog(onDismiss) {
        Text(
            "Impor playlist",
            style = T.section.copy(fontSize = 19.sp),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
        )
        Column(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, bottom = 22.dp)) {
            when (val s = state) {
                is ImportState.Idle -> {
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(AlterColors.Surface3).padding(14.dp)) {
                        if (text.isEmpty()) {
                            Text("Tempel tautan playlist atau daftar lagu (satu per baris)", style = T.small, color = AlterColors.Muted)
                        }
                        BasicTextField(
                            value = text,
                            onValueChange = { text = it },
                            minLines = 3,
                            maxLines = 6,
                            textStyle = T.body.copy(color = Color.White),
                            cursorBrush = SolidColor(AlterColors.Red),
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    val hint =
                        when {
                            text.isBlank() -> "Didukung: YouTube Music, Spotify, Apple Music, SoundCloud, atau daftar judul lagu."
                            platform == null -> "Tautan ini belum didukung."
                            else -> "Terdeteksi: ${platform.label}"
                        }
                    Text(hint, style = T.small, color = if (platform == null && text.isNotBlank()) AlterColors.Red else AlterColors.Sub)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Playlist harus publik. Impor SoundCloud memakai API yang bisa diganti di Pengaturan > Impor playlist.",
                        style = T.tiny,
                        color = AlterColors.Muted,
                    )
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ImportButton("Tempel", Modifier.weight(1f), filled = false) {
                            val clip = readClipboard(context)
                            if (clip.isNullOrBlank()) context.toast("Papan klip kosong") else text = clip
                        }
                        ImportButton("Mulai impor", Modifier.weight(1.4f), enabled = platform != null && text.isNotBlank()) {
                            app.importer.start(text)
                        }
                    }
                }
                is ImportState.Reading -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Membaca playlist ${s.platform?.label.orEmpty()}...", style = T.body)
                    }
                    Spacer(Modifier.height(18.dp))
                    ImportButton("Batal", Modifier.fillMaxWidth(), filled = false) { app.importer.cancel() }
                }
                is ImportState.Matching -> {
                    Text(s.name, style = T.title.copy(fontWeight = FontWeight.Bold), maxLines = 1)
                    Spacer(Modifier.height(4.dp))
                    Text("Mencocokkan ${s.done} dari ${s.total} lagu • ${s.found} ditemukan", style = T.small, color = AlterColors.Sub)
                    Spacer(Modifier.height(12.dp))
                    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(AlterColors.Surface3)) {
                        Box(
                            Modifier
                                .fillMaxWidth(if (s.total > 0) s.done.toFloat() / s.total else 0f)
                                .height(6.dp)
                                .background(AlterColors.Red),
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Kamu boleh menutup jendela ini, impor tetap berjalan.", style = T.tiny, color = AlterColors.Muted)
                    Spacer(Modifier.height(16.dp))
                    ImportButton("Batal", Modifier.fillMaxWidth(), filled = false) { app.importer.cancel() }
                }
                is ImportState.Done -> {
                    Text("Selesai", style = T.title.copy(fontWeight = FontWeight.Bold))
                    Spacer(Modifier.height(6.dp))
                    Text("${s.found} dari ${s.total} lagu masuk ke playlist \"${s.name}\".", style = T.body)
                    if (s.missed.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text("Tidak ditemukan (${s.total - s.found}):", style = T.small, color = AlterColors.Sub)
                        s.missed.take(5).forEach { Text(it, style = T.tiny, color = AlterColors.Muted, maxLines = 1) }
                        if (s.missed.size > 5) Text("dan ${s.missed.size - 5} lainnya", style = T.tiny, color = AlterColors.Muted)
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ImportButton("Impor lagi", Modifier.weight(1f), filled = false) {
                            app.importer.reset()
                            text = ""
                        }
                        ImportButton("Buka playlist", Modifier.weight(1.4f)) {
                            ui.navigate(Route.LocalPlaylist(s.playlistId))
                            app.importer.reset()
                            onDismiss()
                        }
                    }
                }
                is ImportState.Failed -> {
                    Text("Impor gagal", style = T.title.copy(fontWeight = FontWeight.Bold))
                    Spacer(Modifier.height(6.dp))
                    Text(s.message, style = T.body, color = AlterColors.Sub)
                    Spacer(Modifier.height(18.dp))
                    ImportButton("Coba lagi", Modifier.fillMaxWidth()) { app.importer.reset() }
                }
            }
        }
    }
}
