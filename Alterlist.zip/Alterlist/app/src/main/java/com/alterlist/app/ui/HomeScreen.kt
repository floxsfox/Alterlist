package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.style.TextOverflow
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import com.alterlist.app.data.Shelf
import com.alterlist.app.data.Song
import com.alterlist.app.data.UiLoad
import com.alterlist.app.data.topArtists
import com.alterlist.app.data.topSongs
import kotlinx.coroutines.CancellationException
import java.util.Calendar

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 11 -> "Selamat pagi"
        h < 15 -> "Selamat siang"
        h < 18 -> "Selamat sore"
        else -> "Selamat malam"
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, onEntry: (Entry) -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val lib by app.library.data.collectAsState()
    val account by app.account.state.collectAsState()
    val greet = remember { greeting() }

    var yt by remember { mutableStateOf<UiLoad<List<Shelf>>>(UiLoad.Loading) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(account.mode, reload) {
        yt = UiLoad.Loading
        yt =
            try {
                val shelves = app.yt.home(force = reload > 0)
                if (shelves.isEmpty()) UiLoad.Error("Beranda YouTube Music kosong.") else UiLoad.Data(shelves)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error(e.message ?: "Gagal memuat beranda")
            }
    }

    val topArtists = remember(lib.stats) { lib.topArtists(10) }
    val topSongs = remember(lib.stats) { lib.topSongs(15) }
    val recent = remember(lib.recent) { lib.recent.take(15) }

    val quick = remember(lib.recent, lib.downloads, lib.playlists) {
        val items = ArrayList<QuickItem>()
        items.add(QuickItem("Lagu disukai", null, QuickKind.LIKED))
        if (lib.downloads.isNotEmpty()) items.add(QuickItem("Diunduh", null, QuickKind.DOWNLOADS))
        lib.playlists.take(2).forEach { items.add(QuickItem(it.name, it.songs.firstOrNull()?.thumbnail, QuickKind.PLAYLIST, playlistId = it.id)) }
        lib.recent.forEach { s -> if (items.size < 6) items.add(QuickItem(s.title, s.thumbnail, QuickKind.SONG, song = s)) }
        items.take(6)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = padding) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(greet, style = T.screen, modifier = Modifier.weight(1f))
                IconBtn(R.drawable.ic_history, { ui.navigate(Route.Recent) })
                Box(
                    Modifier.padding(start = 2.dp, end = 6.dp).size(36.dp).clip(CircleShape).clickable { ui.navigate(Route.Settings) },
                ) {
                    if (account.mode == AccountMode.GOOGLE && account.photo != null) {
                        Artwork(account.photo, Modifier.size(36.dp), CircleShape, px = 96)
                    } else {
                        Box(Modifier.size(36.dp).background(AlterColors.Surface3), contentAlignment = Alignment.Center) {
                            Ic(R.drawable.ic_user, size = 20.dp)
                        }
                    }
                }
            }
        }

        // grid cepat 2 kolom ala Spotify
        items(quick.chunked(2)) { pair ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                pair.forEach { q ->
                    QuickTile(q, Modifier.weight(1f)) {
                        when (q.kind) {
                            QuickKind.LIKED -> ui.navigate(Route.Liked)
                            QuickKind.DOWNLOADS -> ui.navigate(Route.Downloads)
                            QuickKind.PLAYLIST -> q.playlistId?.let { ui.navigate(Route.LocalPlaylist(it)) }
                            QuickKind.SONG -> q.song?.let { app.player.playRadio(it) }
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        if (recent.isNotEmpty()) {
            item {
                ShelfSection("Putar ulang") {
                    items(recent) { s ->
                        MediaCard(s.title, s.artist, s.thumbnail) { app.player.playRadio(s) }
                    }
                }
            }
        }

        if (topArtists.isNotEmpty()) {
            item {
                ShelfSection("Mix untukmu") {
                    items(topArtists.take(4)) { a ->
                        MixCard(a.name, a.topSong.thumbnail, "Mulai dari ${a.topSong.title}") {
                            app.player.playPlaylistId("RDAMVM${a.topSong.id}")
                        }
                    }
                }
            }
            item {
                ShelfSection("Artis favoritmu") {
                    items(topArtists) { a ->
                        MediaCard(a.name, "Artis", a.topSong.thumbnail, shape = CircleShape) {
                            if (a.id != null) {
                                onEntry(Entry(title = a.name, thumbnail = a.topSong.thumbnail, browseId = a.id))
                            } else {
                                app.player.playRadio(a.topSong)
                            }
                        }
                    }
                }
            }
        }

        if (topSongs.isNotEmpty()) {
            item {
                ShelfSection("Paling sering kamu putar") {
                    items(topSongs) { s ->
                        MediaCard(s.title, s.artist, s.thumbnail) { app.player.playRadio(s) }
                    }
                }
            }
        }

        when (val s = yt) {
            is UiLoad.Data ->
                items(s.value) { shelf ->
                    ShelfSection(shelf.title) {
                        items(shelf.entries) { e ->
                            MediaCard(
                                e.title,
                                e.subtitle,
                                e.thumbnail,
                                shape = if (e.kind == EntryKind.ARTIST) CircleShape else RoundedCornerShape(6.dp),
                            ) { onEntry(e) }
                        }
                    }
                }
            is UiLoad.Error -> item { ErrorBox(s.message, onRetry = { reload++ }) }
            else -> item { LoadingBox() }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

private enum class QuickKind { LIKED, DOWNLOADS, PLAYLIST, SONG }

private class QuickItem(
    val title: String,
    val thumbnail: String?,
    val kind: QuickKind,
    val playlistId: String? = null,
    val song: Song? = null,
)

@Composable
private fun QuickTile(item: QuickItem, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(56.dp).clip(RoundedCornerShape(6.dp)).background(AlterColors.Surface2).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when (item.kind) {
            QuickKind.LIKED ->
                Box(
                    Modifier.size(56.dp).background(Brush.linearGradient(listOf(AlterColors.Red, Color(0xFF5A0003)))),
                    contentAlignment = Alignment.Center,
                ) { Ic(R.drawable.ic_heart_fill, tint = Color.White, size = 24.dp) }
            QuickKind.DOWNLOADS ->
                Box(
                    Modifier.size(56.dp).background(Brush.linearGradient(listOf(Color(0xFF3A3A3F), Color(0xFF1C1C1F)))),
                    contentAlignment = Alignment.Center,
                ) { Ic(R.drawable.ic_download, tint = Color.White, size = 24.dp) }
            else -> Artwork(item.thumbnail, Modifier.size(56.dp), RoundedCornerShape(0.dp))
        }
        Text(
            item.title,
            style = T.small.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Bold),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp).weight(1f),
        )
    }
}

/** Satu rak horizontal dengan judul. Isi diberikan lewat [content] (LazyRow). */
@Composable
fun ShelfSection(title: String, content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    Column(Modifier.padding(top = 14.dp)) {
        SectionTitle(title)
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            content = content,
        )
    }
}

@Composable
fun MediaCard(
    title: String,
    subtitle: String,
    thumbnail: String?,
    modifier: Modifier = Modifier,
    size: Dp = 142.dp,
    shape: Shape = RoundedCornerShape(6.dp),
    onClick: () -> Unit,
) {
    Column(modifier.width(size).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick)) {
        Artwork(thumbnail, Modifier.size(size), shape, px = 360)
        Spacer(Modifier.height(8.dp))
        Text(
            title,
            style = T.body.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = if (shape == CircleShape) androidx.compose.ui.text.style.TextAlign.Center else null,
            modifier = Modifier.fillMaxWidth(),
        )
        if (subtitle.isNotBlank()) {
            Text(
                subtitle,
                style = T.small,
                color = AlterColors.Sub,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = if (shape == CircleShape) androidx.compose.ui.text.style.TextAlign.Center else null,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** Kartu "Mix" bergaya Daily Mix: cover + label di bawah dengan gradasi merah. */
@Composable
fun MixCard(name: String, thumbnail: String?, hint: String, onClick: () -> Unit) {
    Column(Modifier.width(160.dp).clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick)) {
        Box(Modifier.size(160.dp).clip(RoundedCornerShape(6.dp))) {
            Artwork(thumbnail, Modifier.fillMaxSize(), RoundedCornerShape(0.dp), px = 400)
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, AlterColors.Red.copy(alpha = 0.85f)))),
            )
            Text(
                "Mix $name",
                style = T.title.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Bold),
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.BottomStart).padding(10.dp),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(hint, style = T.small, color = AlterColors.Sub, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
