package com.alterlist.app.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.alterlist.app.data.LOCAL_PREFIX
import com.alterlist.app.data.Library
import com.alterlist.app.data.Song
import com.alterlist.app.data.YtMusic
import com.alterlist.app.data.watchUrl
import com.alterlist.app.download.Downloader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executor

data class PlayerUiState(
    val current: Song? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val queue: List<Song> = emptyList(),
    val index: Int = 0,
    val hasNext: Boolean = false,
    val hasPrevious: Boolean = false,
)

data class SleepState(val endAtMs: Long? = null, val endOfTrack: Boolean = false) {
    val active: Boolean get() = endAtMs != null || endOfTrack
}

/** Jembatan antara UI (Compose) dan [PlaybackService] lewat MediaController. */
class PlayerConnection(
    private val context: Context,
    private val library: Library,
    private val yt: YtMusic,
    private val downloader: Downloader,
    private val queueStore: QueueStore,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainExecutor = Executor { runnable -> Handler(Looper.getMainLooper()).post(runnable) }

    private var controller: MediaController? = null
    private var connecting = false
    private val pending = mutableListOf<(MediaController) -> Unit>()
    private var lastErrorId: String? = null

    // pelacakan lama diputar (untuk statistik "sering diputar")
    private var trackedId: String? = null
    private var trackedMs = 0L
    private var trackedCounted = false

    // autoplay: tambahkan lagu mirip saat antrean hampir habis
    private var autoplaySeed: String? = null

    private var sleepJob: Job? = null

    private val _state = MutableStateFlow(PlayerUiState())
    val state: StateFlow<PlayerUiState> = _state.asStateFlow()

    private val _sleep = MutableStateFlow(SleepState())
    val sleep: StateFlow<SleepState> = _sleep.asStateFlow()

    private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val listener =
        object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                refresh(player)
                maybeAutoplay(player)
                if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
                    (events.contains(Player.EVENT_IS_PLAYING_CHANGED) && !player.isPlaying)
                ) {
                    persistQueue()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // saat antrean dipulihkan (belum diputar) lagu tidak dihitung sebagai "baru diputar"
                val restoredOnly = reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED && controller?.playWhenReady != true
                if (!restoredOnly) mediaItem?.let { library.addRecent(it.toSong()) }
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && _sleep.value.endOfTrack) {
                    controller?.pause()
                    _sleep.value = SleepState()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val id = controller?.currentMediaItem?.mediaId
                // Error pertama untuk sebuah lagu dicoba ulang otomatis oleh service; tampilkan pesan kalau berulang.
                if (id != null && id == lastErrorId) {
                    val cause = error.cause?.message ?: error.message
                    _events.tryEmit("Gagal memutar: ${cause ?: "kesalahan tidak diketahui"}")
                }
                lastErrorId = id
            }
        }

    init {
        scope.launch {
            var tick = 0
            while (isActive) {
                delay(400)
                val c = controller ?: continue
                tick++
                if (tick % 38 == 0 && c.isPlaying) persistQueue()
                val currentId = c.currentMediaItem?.mediaId
                if (currentId != trackedId) {
                    trackedId = currentId
                    trackedMs = 0L
                    trackedCounted = false
                }
                if (c.isPlaying) {
                    trackedMs += 400L
                    if (!trackedCounted && trackedMs >= COUNT_AFTER_MS) {
                        trackedCounted = true
                        c.currentMediaItem?.let { library.recordPlay(it.toSong()) }
                    }
                    _state.update {
                        it.copy(
                            positionMs = c.currentPosition,
                            durationMs = c.duration.takeIf { d -> d != C.TIME_UNSET } ?: it.durationMs,
                        )
                    }
                }
            }
        }
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                connecting = false
                try {
                    val c = future.get()
                    controller = c
                    c.addListener(listener)
                    restoreQueue(c)
                    refresh(c)
                    val callbacks = pending.toList()
                    pending.clear()
                    callbacks.forEach { it(c) }
                } catch (e: Exception) {
                    _events.tryEmit("Gagal terhubung ke pemutar: ${e.message}")
                }
            },
            mainExecutor,
        )
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) {
            block(c)
        } else {
            pending.add(block)
            connect()
        }
    }

    private fun refresh(player: Player) {
        val queue = (0 until player.mediaItemCount).map { player.getMediaItemAt(it).toSong() }
        _state.value =
            PlayerUiState(
                current = player.currentMediaItem?.toSong(),
                isPlaying = player.isPlaying,
                isBuffering = player.playbackState == Player.STATE_BUFFERING,
                positionMs = player.currentPosition,
                durationMs = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L,
                shuffle = player.shuffleModeEnabled,
                repeatMode = player.repeatMode,
                queue = queue,
                index = player.currentMediaItemIndex,
                hasNext = player.hasNextMediaItem(),
                hasPrevious = player.hasPreviousMediaItem(),
            )
    }

    /** Muat antrean terakhir (tanpa memutar) supaya mini player langsung menampilkan lagu terakhir. */
    private fun restoreQueue(c: MediaController) {
        if (c.mediaItemCount > 0) return
        val q = queueStore.load() ?: return
        c.setMediaItems(q.songs.map { toMediaItem(it) }, q.index.coerceIn(0, q.songs.lastIndex), q.positionMs)
        c.shuffleModeEnabled = q.shuffle
        c.repeatMode = q.repeatMode
    }

    private fun persistQueue() {
        val c = controller ?: return
        val s = _state.value
        if (s.queue.isEmpty()) return
        val saved = SavedQueue(s.queue, s.index, c.currentPosition, s.shuffle, s.repeatMode)
        scope.launch(Dispatchers.IO) { queueStore.save(saved) }
    }

    /** Saat lagu terakhir di antrean diputar, tambahkan lagu mirip (seperti Autoplay di Spotify). */
    private fun maybeAutoplay(player: Player) {
        if (!library.data.value.autoplay) return
        val count = player.mediaItemCount
        if (count == 0 || player.currentMediaItemIndex != count - 1) return
        if (player.repeatMode != Player.REPEAT_MODE_OFF) return
        val id = player.currentMediaItem?.mediaId ?: return
        if (id.startsWith(LOCAL_PREFIX)) return // musik di perangkat tidak punya "lagu mirip" online
        if (autoplaySeed == id) return
        autoplaySeed = id
        scope.launch {
            val more = runCatching { yt.upNext(id, null) }.getOrDefault(emptyList())
            if (more.isEmpty()) return@launch
            withController { c ->
                val have = (0 until c.mediaItemCount).map { c.getMediaItemAt(it).mediaId }.toHashSet()
                val fresh = more.filter { it.id !in have }.take(25)
                if (fresh.isNotEmpty()) c.addMediaItems(fresh.map { toMediaItem(it) })
            }
        }
    }

    // ---------------------------------------------------------------- aksi

    fun playSongs(songs: List<Song>, startIndex: Int = 0, shuffle: Boolean = false) {
        if (songs.isEmpty()) return
        autoplaySeed = null
        val (list, start) = limitQueue(songs, startIndex, shuffle)
        withController { c ->
            c.setMediaItems(list.map { toMediaItem(it) }, start, 0L)
            c.shuffleModeEnabled = shuffle
            c.prepare()
            c.play()
        }
    }

    /** Putar satu lagu, lalu tambahkan lagu mirip (radio) ke antrean. */
    fun playRadio(seed: Song) {
        playSongs(listOf(seed))
        if (seed.isLocal) return
        scope.launch {
            val more =
                runCatching { yt.upNext(seed.id, null) }
                    .getOrDefault(emptyList())
                    .filter { it.id != seed.id }
            if (more.isEmpty()) return@launch
            withController { c ->
                if (c.mediaItemCount == 1 && c.currentMediaItem?.mediaId == seed.id) {
                    c.addMediaItems(more.map { toMediaItem(it) })
                }
            }
        }
    }

    /** Putar sebuah mix / playlist radio YouTube Music berdasarkan playlistId. */
    fun playPlaylistId(playlistId: String) {
        scope.launch {
            val songs = runCatching { yt.upNext(null, playlistId) }.getOrDefault(emptyList())
            if (songs.isEmpty()) {
                _events.tryEmit("Playlist ini tidak bisa diputar")
            } else {
                playSongs(songs)
            }
        }
    }

    fun togglePlay() =
        withController { c ->
            if (c.isPlaying) {
                c.pause()
            } else {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }

    fun next() = withController { it.seekToNextMediaItem() }

    fun previous() = withController { it.seekToPreviousMediaItem() }

    fun seekTo(positionMs: Long) = withController { it.seekTo(positionMs) }

    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() =
        withController {
            it.repeatMode =
                when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
        }

    fun playQueueIndex(index: Int) =
        withController {
            it.seekToDefaultPosition(index)
            it.play()
        }

    fun removeFromQueue(index: Int) = withController { it.removeMediaItem(index) }

    fun clearUpcoming() =
        withController { c ->
            val from = c.currentMediaItemIndex + 1
            if (from < c.mediaItemCount) c.removeMediaItems(from, c.mediaItemCount)
        }

    fun moveInQueue(from: Int, to: Int) =
        withController { c ->
            if (from in 0 until c.mediaItemCount && to in 0 until c.mediaItemCount) c.moveMediaItem(from, to)
        }

    fun addToQueue(song: Song) =
        withController { c ->
            if (c.mediaItemCount == 0) {
                playSongs(listOf(song))
            } else {
                c.addMediaItem(toMediaItem(song))
            }
        }

    fun playNext(song: Song) =
        withController { c ->
            if (c.mediaItemCount == 0) {
                playSongs(listOf(song))
            } else {
                c.addMediaItem(c.currentMediaItemIndex + 1, toMediaItem(song))
            }
        }

    // ---------------------------------------------------------------- sleep timer

    fun startSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        val millis = minutes * 60_000L
        _sleep.value = SleepState(endAtMs = System.currentTimeMillis() + millis)
        sleepJob =
            scope.launch {
                delay(millis)
                withController { it.pause() }
                _sleep.value = SleepState()
            }
    }

    fun sleepAtEndOfTrack() {
        sleepJob?.cancel()
        _sleep.value = SleepState(endOfTrack = true)
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel()
        _sleep.value = SleepState()
    }

    // ---------------------------------------------------------------- MediaItem

    /** Antrean sangat panjang (mis. ribuan lagu lokal) dipotong supaya tetap ringan. */
    private fun limitQueue(songs: List<Song>, startIndex: Int, shuffle: Boolean): Pair<List<Song>, Int> {
        if (songs.size <= MAX_QUEUE) return songs to startIndex.coerceIn(0, songs.lastIndex)
        if (shuffle) return songs.shuffled().take(MAX_QUEUE) to 0
        val from = (startIndex - 50).coerceAtLeast(0)
        val list = songs.subList(from, (from + MAX_QUEUE).coerceAtMost(songs.size))
        return list to (startIndex - from).coerceIn(0, list.lastIndex)
    }

    /** Hanya alamat albumart MediaStore yang bisa dimuat notifikasi sebagai gambar. */
    private fun artworkFor(song: Song): Uri? {
        val t = song.thumbnail ?: return null
        if (!song.isLocal) return Uri.parse(t)
        return if (t.startsWith("content://media/")) Uri.parse(t) else null
    }

    private fun toMediaItem(song: Song): MediaItem {
        val local = if (song.isLocal) null else downloader.fileFor(song.id)
        val extras =
            Bundle().apply {
                putString("artistId", song.artistId)
                putString("album", song.album)
                putString("albumId", song.albumId)
                putString("duration", song.durationText)
                if (song.isLocal) {
                    putString("uri", song.uri)
                    putString("thumb", song.thumbnail)
                }
            }
        val builder =
            MediaItem.Builder()
                .setMediaId(song.id)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(song.title)
                        .setArtist(song.artist)
                        .setAlbumTitle(song.album)
                        .setArtworkUri(artworkFor(song))
                        .setExtras(extras)
                        .build(),
                )
        val localUri = song.uri
        if (song.isLocal && localUri != null) {
            builder.setUri(Uri.parse(localUri))
        } else if (local != null) {
            builder.setUri(Uri.fromFile(local))
        } else {
            builder.setUri(song.watchUrl()).setCustomCacheKey(song.id)
        }
        return builder.build()
    }

    private companion object {
        const val COUNT_AFTER_MS = 30_000L
        const val MAX_QUEUE = 500
    }
}

private fun MediaItem.toSong(): Song {
    val x = mediaMetadata.extras
    return Song(
        id = mediaId,
        title = mediaMetadata.title?.toString().orEmpty(),
        artist = mediaMetadata.artist?.toString().orEmpty(),
        artistId = x?.getString("artistId"),
        album = x?.getString("album") ?: mediaMetadata.albumTitle?.toString(),
        albumId = x?.getString("albumId"),
        thumbnail = x?.getString("thumb") ?: mediaMetadata.artworkUri?.toString(),
        durationText = x?.getString("duration"),
        uri = x?.getString("uri"),
    )
}
