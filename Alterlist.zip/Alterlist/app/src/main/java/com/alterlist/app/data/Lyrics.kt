package com.alterlist.app.data

import android.content.Context
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.Json
import java.io.File
import java.net.URLEncoder
import kotlin.math.abs

/** Parser berkas LRC ("[mm:ss.xx] teks"). */
object Lrc {
    private val TIMESTAMP = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")
    /** Tag waktu per kata pada LRC "enhanced": <mm:ss.xx>kata */
    private val WORD_TAG = Regex("""<(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?>""")

    private fun millisOf(min: String, sec: String, frac: String): Long {
        val f =
            when (frac.length) {
                0 -> 0L
                1 -> frac.toLong() * 100
                2 -> frac.toLong() * 10
                else -> frac.take(3).toLong()
            }
        return (min.toLong() * 60 + sec.toLong()) * 1000 + f
    }

    /** Pisahkan tag kata dari teks. Mengembalikan teks polos dan daftar kata berwaktu (null bila tidak ada tag). */
    private fun splitWords(content: String, lineStartMs: Long): Pair<String, List<LyricWord>?> {
        val tags = WORD_TAG.findAll(content).toList()
        if (tags.isEmpty()) return content to null
        val words = ArrayList<LyricWord>()
        val head = content.substring(0, tags[0].range.first)
        if (head.isNotEmpty()) words.add(LyricWord(lineStartMs, head))
        for ((k, t) in tags.withIndex()) {
            val end = if (k + 1 < tags.size) tags[k + 1].range.first else content.length
            val seg = content.substring(t.range.last + 1, end)
            if (seg.isNotEmpty()) words.add(LyricWord(millisOf(t.groupValues[1], t.groupValues[2], t.groupValues[3]), seg))
        }
        val plain = words.joinToString("") { it.text }.trim()
        return plain to words.takeIf { it.size >= 2 }
    }

    fun parse(text: String): List<LyricLine> {
        val out = ArrayList<LyricLine>()
        for (raw in text.lines()) {
            val matches = TIMESTAMP.findAll(raw).toList()
            if (matches.isEmpty()) continue
            val rawContent = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val minutes = m.groupValues[1].toLong()
                val seconds = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val millis =
                    when (frac.length) {
                        0 -> 0L
                        1 -> frac.toLong() * 100
                        2 -> frac.toLong() * 10
                        else -> frac.take(3).toLong()
                    }
                val start = (minutes * 60 + seconds) * 1000 + millis
                val (content, words) = splitWords(rawContent, start)
                out.add(LyricLine(start, content, words))
            }
        }
        return out.sortedBy { it.timeMs }
    }
}

/** Lirik dari LRCLIB (gratis, tanpa kunci API). Hasil disimpan di cache supaya tidak diunduh ulang. */
class LyricsRepo(context: Context) {
    private val dir = File(context.cacheDir, "lyrics").apply { mkdirs() }
    private val headers = mapOf("User-Agent" to "Alterlist/1.0 (aplikasi musik Android)", "Lrclib-Client" to "Alterlist")

    suspend fun get(song: Song): Lyrics? {
        val synced = File(dir, "${song.id}.lrc")
        val plain = File(dir, "${song.id}.txt")
        val none = File(dir, "${song.id}.none")
        if (synced.exists()) return Lyrics(Lrc.parse(synced.readText()), true)
        if (plain.exists()) return Lyrics(plain.readText().lines().map { LyricLine(0L, it) }, false)
        if (none.exists() && System.currentTimeMillis() - none.lastModified() < 6L * 3600_000L) return null

        val artist = primaryArtist(song.artist)
        val found = fetchExact(song, artist) ?: fetchSearch(song, artist)
        if (found == null) {
            none.writeText("")
            return null
        }
        val (syncedText, plainText) = found
        return when {
            !syncedText.isNullOrBlank() && Lrc.parse(syncedText).isNotEmpty() -> {
                synced.writeText(syncedText)
                Lyrics(Lrc.parse(syncedText), true)
            }
            !plainText.isNullOrBlank() -> {
                plain.writeText(plainText)
                Lyrics(plainText.lines().map { LyricLine(0L, it) }, false)
            }
            else -> {
                none.writeText("")
                null
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private suspend fun fetchExact(song: Song, artist: String): Pair<String?, String?>? {
        val sb = StringBuilder("https://lrclib.net/api/get?track_name=${enc(song.title)}&artist_name=${enc(artist)}")
        song.album?.takeIf { it.isNotBlank() }?.let { sb.append("&album_name=").append(enc(it)) }
        song.durationSeconds?.let { sb.append("&duration=").append(it) }
        val body = Net.getText(sb.toString(), headers) ?: return null
        return extract(runCatching { Json.parseToJsonElement(body) }.getOrNull())
    }

    private suspend fun fetchSearch(song: Song, artist: String): Pair<String?, String?>? {
        val url = "https://lrclib.net/api/search?track_name=${enc(song.title)}&artist_name=${enc(artist)}"
        val body = Net.getText(url, headers) ?: return null
        val arr = runCatching { Json.parseToJsonElement(body) }.getOrNull() as? JsonArray ?: return null
        val wanted = song.durationSeconds
        val candidates = arr.toList()
        val best =
            candidates.firstOrNull { c ->
                val synced = c.at("syncedLyrics").text()
                val dur = c.at("duration").text()?.toDoubleOrNull()
                !synced.isNullOrBlank() && (wanted == null || dur == null || abs(dur - wanted) <= 6)
            } ?: candidates.firstOrNull { !it.at("plainLyrics").text().isNullOrBlank() }
        return extract(best)
    }

    private fun extract(e: JsonElement?): Pair<String?, String?>? {
        if (e == null) return null
        val synced = e.at("syncedLyrics").text()
        val plain = e.at("plainLyrics").text()
        if (synced.isNullOrBlank() && plain.isNullOrBlank()) return null
        return Pair(synced, plain)
    }
}
