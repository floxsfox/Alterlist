package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.playback.PlayerUiState
import kotlinx.coroutines.launch

/** Mini player ala Spotify: warna latar mengikuti cover, geser kiri/kanan untuk ganti lagu. */
@Composable
fun MiniPlayer(state: PlayerUiState, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val app = AlterApp.instance
    val song = state.current ?: return
    val lib by app.library.data.collectAsState()
    val liked = lib.liked.any { it.id == song.id }
    val dominant by rememberDominantColor(song.thumbnail)
    val background = lerp(dominant, Color.Black, 0.30f)
    val progress = if (state.durationMs > 0L) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(background)
            .clickable(onClick = onOpen)
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -110f) app.player.next() else if (total > 110f) app.player.previous()
                        total = 0f
                    },
                    onDragCancel = { total = 0f },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        total += dx
                    },
                )
            },
    ) {
        Row(Modifier.padding(start = 8.dp, end = 2.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(song.thumbnail, Modifier.size(42.dp), RoundedCornerShape(4.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, style = T.body.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, style = T.small, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconBtn(
                if (liked) R.drawable.ic_heart_fill else R.drawable.ic_heart,
                {
                    val nowLiked = app.library.toggleLike(song)
                    app.scope.launch { app.yt.likeOnAccount(song.id, nowLiked) }
                },
                tint = if (liked) AlterColors.Red else Color.White,
                size = 24.dp,
                box = 42.dp,
            )
            Box(Modifier.size(42.dp).clip(androidx.compose.foundation.shape.CircleShape).clickable { app.player.togglePlay() }, contentAlignment = Alignment.Center) {
                if (state.isBuffering && !state.isPlaying) {
                    CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Ic(if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, tint = Color.White, size = 26.dp)
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = 0.22f))) {
            Box(Modifier.fillMaxWidth(progress).height(2.dp).background(Color.White))
        }
    }
}
