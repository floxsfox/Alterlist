package com.alterlist.app.poster

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Isi satu poster: sampul-sampul playlist, (opsional) potongan subjek dari foto, dan warna aksen. */
class PosterData(
    val title: String,
    val subtitle: String,
    val covers: List<Bitmap>,
    val cutout: Bitmap?,
    val accent: Int,
)

/** Poster terakhir disimpan di penyimpanan privat aplikasi supaya wallpaper hidup bisa memuatnya tanpa internet. */
object PosterStore {
    private fun dir(context: Context): File = File(context.filesDir, "poster").apply { mkdirs() }

    /** Penanda versi: berubah setiap poster baru disimpan (dipakai wallpaper untuk memuat ulang). */
    fun version(context: Context): Long = File(dir(context), "meta.json").lastModified()

    fun save(context: Context, data: PosterData) {
        val d = dir(context)
        d.listFiles()?.forEach { it.delete() }
        data.covers.forEachIndexed { i, b ->
            FileOutputStream(File(d, "cover_$i.jpg")).use { b.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        }
        data.cutout?.let { cut -> FileOutputStream(File(d, "cutout.png")).use { cut.compress(Bitmap.CompressFormat.PNG, 100, it) } }
        val meta =
            JSONObject()
                .put("title", data.title)
                .put("subtitle", data.subtitle)
                .put("accent", data.accent)
                .put("covers", data.covers.size)
        // ditulis paling akhir: berkas ini penanda bahwa semuanya sudah lengkap
        File(d, "meta.json").writeText(meta.toString())
    }

    fun load(context: Context): PosterData? {
        val d = dir(context)
        val metaFile = File(d, "meta.json")
        if (!metaFile.exists()) return null
        return try {
            val m = JSONObject(metaFile.readText())
            val n = m.optInt("covers", 0)
            val covers = (0 until n).mapNotNull { BitmapFactory.decodeFile(File(d, "cover_$it.jpg").path) }
            val cut = File(d, "cutout.png").takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }
            if (covers.isEmpty() && cut == null) {
                null
            } else {
                PosterData(m.optString("title"), m.optString("subtitle"), covers, cut, m.optInt("accent", 0xFFE5333A.toInt()))
            }
        } catch (e: Exception) {
            null
        }
    }
}
