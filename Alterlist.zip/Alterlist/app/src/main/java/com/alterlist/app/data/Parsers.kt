package com.alterlist.app.data

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement

private const val SEP = " • "
private val DURATION_REGEX = Regex("""^\d{1,2}(:\d{2}){1,2}$""")
private val YEAR_REGEX = Regex("""^(19|20)\d{2}$""")
private val ARTIST_TYPES = setOf("MUSIC_PAGE_TYPE_ARTIST", "MUSIC_PAGE_TYPE_USER_CHANNEL")
private const val ALBUM_TYPE = "MUSIC_PAGE_TYPE_ALBUM"

private fun lastThumb(thumbs: JsonElement?): String? =
    (thumbs as? JsonArray)?.lastOrNull().at("url").text()

private fun runList(runs: JsonElement?): List<JsonElement> = (runs as? JsonArray).orEmpty()

/** Pecah runs "A • B • C" menjadi ["A", "B", "C"]. */
private fun groupTexts(runs: List<JsonElement>): List<String> {
    val groups = mutableListOf(StringBuilder())
    for (run in runs) {
        val t = run.at("text").text().orEmpty()
        if (t == SEP) groups.add(StringBuilder()) else groups.last().append(t)
    }
    return groups.map { it.toString().trim() }.filter { it.isNotEmpty() }
}

private fun pageType(run: JsonElement): String? =
    run.at(
        "navigationEndpoint",
        "browseEndpoint",
        "browseEndpointContextSupportedConfigs",
        "browseEndpointContextMusicConfig",
        "pageType",
    ).text()

private class Credits(val artist: String, val artistId: String?, val album: String?, val albumId: String?, val year: String?)

/** Ambil artis, album, dan tahun dari baris keterangan (tidak tergantung bahasa). */
private fun credits(runs: List<JsonElement>): Credits {
    val artistRuns = runs.filter { r -> pageType(r)?.let { it in ARTIST_TYPES } == true }
    val artist = artistRuns.joinToString(", ") { it.at("text").text().orEmpty() }
    val artistId = artistRuns.firstOrNull()?.at("navigationEndpoint", "browseEndpoint", "browseId").text()
    val albumRun = runs.firstOrNull { r -> pageType(r) == ALBUM_TYPE }
    val year = groupTexts(runs).firstOrNull { YEAR_REGEX.matches(it) }
    return Credits(
        artist = artist,
        artistId = artistId,
        album = albumRun?.at("text").text(),
        albumId = albumRun?.at("navigationEndpoint", "browseEndpoint", "browseId").text(),
        year = year,
    )
}

/** musicResponsiveListItemRenderer: baris hasil pencarian / daftar lagu. */
internal fun parseListEntry(r: JsonElement): Entry? {
    val videoId = r.at("playlistItemData", "videoId").text()
    val browseId = r.at("navigationEndpoint", "browseEndpoint", "browseId").text()
    if (videoId == null && browseId == null) return null

    val cols = r.at("flexColumns") as? JsonArray ?: return null
    val title = cols.getOrNull(0).at("musicResponsiveListItemFlexColumnRenderer", "text").runsText()
    if (title.isBlank()) return null

    val subRuns = runList(cols.getOrNull(1).at("musicResponsiveListItemFlexColumnRenderer", "text", "runs"))
    val groups = groupTexts(subRuns)
    val c = credits(subRuns)

    val fixedText = r.at("fixedColumns", 0, "musicResponsiveListItemFixedColumnRenderer", "text").runsText()
    val duration =
        fixedText.takeIf { DURATION_REGEX.matches(it) }
            ?: groups.lastOrNull()?.takeIf { DURATION_REGEX.matches(it) }

    val subtitle =
        if (videoId != null) {
            c.artist.ifBlank { groups.firstOrNull().orEmpty() }
        } else {
            groups.joinToString(SEP)
        }

    return Entry(
        title = title,
        subtitle = subtitle,
        thumbnail = lastThumb(r.at("thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails")),
        videoId = videoId,
        browseId = if (videoId == null) browseId else null,
        params = if (videoId == null) r.at("navigationEndpoint", "browseEndpoint", "params").text() else null,
        durationText = duration,
        artistId = c.artistId,
        album = c.album,
        albumId = c.albumId,
    )
}

/** musicTwoRowItemRenderer: kartu di carousel beranda / halaman artis. */
internal fun parseTwoRow(r: JsonElement): Entry? {
    val title = r.at("title").runsText()
    if (title.isBlank()) return null
    val subRuns = runList(r.at("subtitle", "runs"))
    val nav = r.at("navigationEndpoint")
    val videoId = nav.at("watchEndpoint", "videoId").text()
    val browseId = nav.at("browseEndpoint", "browseId").text()
    val playlistId = nav.at("watchPlaylistEndpoint", "playlistId").text()
    if (videoId == null && browseId == null && playlistId == null) return null

    val c = credits(subRuns)
    val subtitleFull = r.at("subtitle").runsText()
    val subtitle = if (videoId != null) c.artist.ifBlank { subtitleFull } else subtitleFull

    return Entry(
        title = title,
        subtitle = subtitle,
        thumbnail = lastThumb(r.at("thumbnailRenderer", "musicThumbnailRenderer", "thumbnail", "thumbnails")),
        videoId = videoId,
        browseId = if (videoId == null) browseId else null,
        playlistId = if (videoId == null && browseId == null) playlistId else null,
        params = if (videoId == null) nav.at("browseEndpoint", "params").text() else null,
        artistId = c.artistId,
        album = c.album,
        albumId = c.albumId,
    )
}

/** playlistPanelVideoRenderer: item di "Up next" / radio. */
internal fun parsePanelSong(r: JsonElement): Song? {
    val id = r.at("videoId").text() ?: return null
    val title = r.at("title").runsText()
    if (title.isBlank()) return null
    val runs = runList(r.at("longBylineText", "runs"))
    val c = credits(runs)
    return Song(
        id = id,
        title = title,
        artist = c.artist.ifBlank { groupTexts(runs).firstOrNull().orEmpty() },
        artistId = c.artistId,
        album = c.album,
        albumId = c.albumId,
        thumbnail = lastThumb(r.at("thumbnail", "thumbnails")),
        durationText = r.at("lengthText").runsText().takeIf { it.isNotBlank() },
    )
}

/** Semua carousel (musicCarouselShelfRenderer) di sebuah halaman, jadi daftar rak. */
internal fun parseShelves(root: JsonElement, defaultTitle: String = "Pilihan untukmu"): List<Shelf> =
    root.findAll("musicCarouselShelfRenderer").mapNotNull { shelf ->
        val title = shelf.at("header", "musicCarouselShelfBasicHeaderRenderer", "title").runsText()
        val items =
            (shelf.at("contents") as? JsonArray).orEmpty().mapNotNull { content ->
                content.at("musicTwoRowItemRenderer")?.let { parseTwoRow(it) }
                    ?: content.at("musicResponsiveListItemRenderer")?.let { parseListEntry(it) }
            }
        if (items.isEmpty()) null else Shelf(title.ifBlank { defaultTitle }, items)
    }

/** Kartu mood & genre ("Jelajahi semua"). */
internal fun parseCategories(root: JsonElement): List<Category> =
    root.findAll("musicNavigationButtonRenderer").mapNotNull { b ->
        val title = b.at("buttonText").runsText()
        val browseId = b.at("clickCommand", "browseEndpoint", "browseId").text()
        if (title.isBlank() || browseId == null) return@mapNotNull null
        val color = b.at("solid", "leftStripeColor").text()?.toLongOrNull()?.toInt() ?: 0xFF5A5A5A.toInt()
        Category(title, color, browseId, b.at("clickCommand", "browseEndpoint", "params").text())
    }.distinctBy { it.browseId + it.params }

/** Halaman album / playlist / artis: daftar lagu utama + rak-rak lain. */
internal fun parseBrowsePage(root: JsonElement, fallbackTitle: String, fallbackThumb: String?): BrowsePage {
    val headerKeys =
        listOf(
            "musicImmersiveHeaderRenderer",
            "musicVisualHeaderRenderer",
            "musicResponsiveHeaderRenderer",
            "musicDetailHeaderRenderer",
            "musicEditablePlaylistDetailHeaderRenderer",
        )
    var header: JsonElement? = null
    for (k in headerKeys) {
        header = root.findAll(k).firstOrNull()
        if (header != null) break
    }
    val title = header.at("title").runsText().ifBlank { fallbackTitle }
    val subtitle =
        header.at("subtitle").runsText().ifBlank { header.at("straplineTextOne").runsText() }
    val thumb =
        lastThumb(header.at("thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails"))
            ?: lastThumb(header.at("foregroundThumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails"))
            ?: fallbackThumb
    val strapline = header.at("straplineTextOne").runsText()

    val shelfNodes = root.findAll("musicShelfRenderer") + root.findAll("musicPlaylistShelfRenderer")
    val songs =
        shelfNodes
            .flatMap { shelf ->
                (shelf.at("contents") as? JsonArray).orEmpty().mapNotNull { content ->
                    content.at("musicResponsiveListItemRenderer")?.let { parseListEntry(it)?.toSong() }
                }
            }
            .distinctBy { it.id }
            .map { s ->
                s.copy(
                    artist = s.artist.ifBlank { strapline },
                    thumbnail = s.thumbnail ?: thumb,
                )
            }
    return BrowsePage(title, subtitle, thumb, songs, parseShelves(root))
}

/** Respon accountMenu -> nama, email, foto akun. */
internal fun parseAccount(root: JsonElement): AccountInfo? {
    val h = root.findAll("activeAccountHeaderRenderer").firstOrNull() ?: return null
    val name = h.at("accountName").runsText()
    if (name.isBlank()) return null
    val email = h.at("email").runsText()
    val photo = (h.at("accountPhoto", "thumbnails") as? JsonArray)?.lastOrNull().at("url").text()
    return AccountInfo(name, email, photo)
}

/** Token halaman berikutnya dari respons pencarian / browse (format lama `nextContinuationData`, format baru `continuationCommand`). */
internal fun parseContinuation(root: JsonElement): String? {
    root.findAll("nextContinuationData").firstOrNull()?.at("continuation").text()?.let { if (it.isNotBlank()) return it }
    root.findAll("continuationCommand").firstOrNull()?.at("token").text()?.let { if (it.isNotBlank()) return it }
    return null
}
