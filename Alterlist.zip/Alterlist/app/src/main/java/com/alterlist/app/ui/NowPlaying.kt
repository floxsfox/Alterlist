package com.alterlist.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.alterlist.app.AlterApp
import com.alterlist.app.data.TRANSLATE_LANGS
import com.alterlist.app.R
import com.alterlist.app.data.Lyrics
import com.alterlist.app.data.Song
import com.alterlist.app.data.UiLoad
import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.FxPreset
import com.alterlist.app.fx.FxState
import com.alterlist.app.playback.PlayerUiState
import kotlinx.coroutines.launch

private enum class Panel { NONE, LYRICS, QUEUE }

/** Layar "Sedang diputar" penuh: gradasi dari cover, kontrol, lirik, antrean, dan efek suara. */
@Composable
fun NowPlayingScreen(state: PlayerUiState, onClose: () -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val lib by app.library.data.collectAsState()
    val fx by AudioFx.state.collectAsState()
    val sleep by app.player.sleep.collectAsState()
    val downloads by app.downloader.progress.collectAsState()
    var panel by rememberSaveable { mutableStateOf(Panel.NONE) }
    val song = state.current

    BackHandler(enabled = panel != Panel.NONE) { panel = Panel.NONE }

    val dominant by rememberDominantColor(song?.thumbnail, Color(0xFF3A1214))
    val brush =
        Brush.verticalGradient(
            listOf(dominant, lerp(dominant, AlterColors.Bg, 0.7f), AlterColors.Bg),
        )

    Box(Modifier.fillMaxSize().background(AlterColors.Bg).background(brush)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // bar atas (tarik ke bawah untuk menutup)
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total > 160f) onClose() },
                            onDragCancel = { total = 0f },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                total += dy
                            },
                        )
                    },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconBtn(R.drawable.ic_chevron_down, onClose)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "SEDANG DIPUTAR",
                        style = T.tiny.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp),
                        color = Color.White.copy(alpha = 0.72f),
                    )
                    val sub = song?.album ?: song?.artist.orEmpty()
                    if (sub.isNotBlank()) {
                        Text(sub, style = T.small.copy(fontWeight = FontWeight.SemiBold), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                IconBtn(R.drawable.ic_more_vert, { song?.let { ui.openMenu(it) } }, enabled = song != null)
            }

            if (song != null) {
                Box(Modifier.fillMaxWidth().padding(top = 2.dp), contentAlignment = Alignment.Center) { OutputPill() }
            }

            if (song == null) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Belum ada lagu yang diputar", style = T.body, color = AlterColors.Sub)
                }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Crossfade(targetState = panel, label = "panel") { p ->
                        when (p) {
                            Panel.NONE -> ArtworkPane(song, state.isPlaying)
                            Panel.LYRICS -> LyricsPanel(song, state.positionMs)
                            Panel.QUEUE -> QueuePanel(state)
                        }
                    }
                }

                // judul + suka
                val liked = lib.liked.any { it.id == song.id }
                Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(song.title, style = T.hero.copy(fontSize = 22.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(song.artist, style = T.title.copy(fontWeight = FontWeight.Medium), color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconBtn(
                        if (liked) R.drawable.ic_heart_fill else R.drawable.ic_heart,
                        {
                            val nowLiked = app.library.toggleLike(song)
                            if (!song.isLocal) app.scope.launch { app.yt.likeOnAccount(song.id, nowLiked) }
                        },
                        tint = if (liked) AlterColors.Red else Color.White,
                        size = 28.dp,
                        box = 48.dp,
                    )
                }

                // seek bar
                var dragging by remember { mutableStateOf(false) }
                var dragValue by remember { mutableFloatStateOf(0f) }
                val progress = if (state.durationMs > 0L) (state.positionMs.toFloat() / state.durationMs).coerceIn(0f, 1f) else 0f
                SeekBar(
                    value = if (dragging) dragValue else progress,
                    onValueChange = {
                        dragging = true
                        dragValue = it
                    },
                    onValueChangeFinished = {
                        app.player.seekTo((dragValue * state.durationMs).toLong())
                        dragging = false
                    },
                    enabled = state.durationMs > 0L,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                    val shown = if (dragging) (dragValue * state.durationMs).toLong() else state.positionMs
                    Text(formatTime(shown), style = T.tiny, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(state.durationMs), style = T.tiny, color = Color.White.copy(alpha = 0.7f))
                }

                // kontrol utama
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconBtn(R.drawable.ic_shuffle, { app.player.toggleShuffle() }, tint = if (state.shuffle) AlterColors.Red else Color.White, size = 26.dp, box = 50.dp)
                    IconBtn(R.drawable.ic_prev, { app.player.previous() }, size = 34.dp, box = 56.dp, enabled = state.hasPrevious || state.positionMs > 3000)
                    Box(
                        Modifier.size(70.dp).clip(CircleShape).background(Color.White).clickable { app.player.togglePlay() },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (state.isBuffering && !state.isPlaying) {
                            CircularProgressIndicator(Modifier.size(30.dp), color = Color.Black, strokeWidth = 3.dp)
                        } else {
                            Ic(if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, tint = Color.Black, size = 34.dp)
                        }
                    }
                    IconBtn(R.drawable.ic_next, { app.player.next() }, size = 34.dp, box = 56.dp, enabled = state.hasNext)
                    IconBtn(
                        if (state.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                        { app.player.cycleRepeat() },
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) AlterColors.Red else Color.White,
                        size = 26.dp,
                        box = 50.dp,
                    )
                }

                // baris bawah: efek, lirik, antrean, timer, unduh
                val downloaded = lib.downloads.any { it.song.id == song.id }
                val pct = downloads[song.id]
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    BottomAction(R.drawable.ic_sliders, if (fx.isNormal) "Efek" else (fx.preset?.label ?: "Kustom"), !fx.isNormal) {
                        ui.fxOpen = true
                    }
                    BottomAction(R.drawable.ic_lyrics, "Lirik", panel == Panel.LYRICS) {
                        panel = if (panel == Panel.LYRICS) Panel.NONE else Panel.LYRICS
                    }
                    BottomAction(R.drawable.ic_queue, "Antrean", panel == Panel.QUEUE) {
                        panel = if (panel == Panel.QUEUE) Panel.NONE else Panel.QUEUE
                    }
                    BottomAction(R.drawable.ic_timer, if (sleep.active) "Aktif" else "Timer", sleep.active) { ui.sleepOpen = true }
                    val loop by app.player.loop.collectAsState()
                    BottomAction(
                        R.drawable.ic_repeat,
                        when {
                            loop == null -> "Loop A-B"
                            loop?.second == null -> "Tandai B"
                            else -> "Loop aktif"
                        },
                        loop != null,
                    ) { app.player.cycleLoop() }
                    BottomAction(
                        if (downloaded) R.drawable.ic_downloaded else R.drawable.ic_download,
                        when {
                            downloaded -> "Diunduh"
                            pct != null -> if (pct >= 0) "$pct%" else "Antre"
                            else -> "Unduh"
                        },
                        downloaded || pct != null,
                    ) {
                        when {
                            downloaded -> context.toast("Sudah diunduh. Hapus lewat menu ⋮")
                            pct != null -> app.downloader.cancel(song.id)
                            else -> {
                                app.downloader.enqueue(song)
                                context.toast("Mengunduh \"${song.title}\"...")
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun RowScope.BottomAction(icon: Int, label: String, active: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Ic(icon, tint = if (active) AlterColors.Red else Color.White, size = 24.dp)
        Spacer(Modifier.height(3.dp))
        Text(
            label,
            style = T.tiny,
            color = if (active) AlterColors.Red else Color.White.copy(alpha = 0.75f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ArtworkPane(song: Song, playing: Boolean) {
    val app = AlterApp.instance
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (playing) 1f else 0.88f,
        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.6f, stiffness = 120f),
        label = "artScale",
    )
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val side = if (maxWidth < maxHeight) maxWidth else maxHeight
        Artwork(
            song.thumbnail,
            Modifier
                .size(side)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .shadow(28.dp, RoundedCornerShape(8.dp))
                .pointerInput(song.id) {
                    var total = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = {
                            if (total < -120f) app.player.next() else if (total > 120f) app.player.previous()
                            total = 0f
                        },
                        onDragCancel = { total = 0f },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            total += dx
                        },
                    )
                },
            RoundedCornerShape(8.dp),
            px = 800,
        )
    }
}

@Composable
private fun LyricsPanel(song: Song, positionMs: Long) {
    val app = AlterApp.instance
    val settings by app.settings.state.collectAsState()
    var load by remember(song.id) { mutableStateOf<UiLoad<Lyrics>>(UiLoad.Loading) }
    LaunchedEffect(song.id) {
        load = UiLoad.Loading
        val result = runCatching { app.lyrics.get(song) }.getOrNull()
        load = if (result != null && result.lines.isNotEmpty()) UiLoad.Data(result) else UiLoad.Idle
    }
    // layar tetap menyala selama lirik dibuka
    val view = androidx.compose.ui.platform.LocalView.current
    androidx.compose.runtime.DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    when (val l = load) {
        is UiLoad.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp, modifier = Modifier.size(30.dp)) }
        is UiLoad.Data -> {
            val lyrics = l.value
            val lang = settings.translateLang
            val translated by androidx.compose.runtime.produceState<List<String>?>(initialValue = null, song.id, lang, lyrics) {
                value = null
                if (lang.isNotEmpty()) value = app.translator.translate(song.id, lyrics.lines.map { it.text }, lang)
            }
            val listState = rememberLazyListState()
            val shifted = positionMs + 250L + settings.lyricOffsetMs
            val index = if (lyrics.synced) lyrics.lines.indexOfLast { it.timeMs <= shifted } else -1
            LaunchedEffect(index) {
                if (index >= 0) listState.animateScrollToItem((index - 2).coerceAtLeast(0))
            }
            Column(Modifier.fillMaxSize()) {
                LyricsToolbar(lang, settings.lyricOffsetMs, lyrics.synced, translated != null || lang.isEmpty())
                LazyColumn(Modifier.fillMaxWidth().weight(1f), state = listState) {
                    itemsIndexed(lyrics.lines) { i, line ->
                        val current = i == index
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .then(if (lyrics.synced) Modifier.clickable { app.player.seekTo(line.timeMs) } else Modifier)
                                .padding(vertical = 9.dp),
                        ) {
                            Text(
                                line.text.ifBlank { "♪" },
                                style = T.hero.copy(fontSize = if (current) 25.sp else 22.sp, lineHeight = 30.sp),
                                color = if (!lyrics.synced) Color.White.copy(alpha = 0.9f) else if (current) Color.White else Color.White.copy(alpha = 0.42f),
                            )
                            val tr = translated?.getOrNull(i)
                            if (!tr.isNullOrBlank()) {
                                Text(
                                    tr,
                                    style = T.title.copy(fontSize = 16.sp, lineHeight = 21.sp),
                                    color = if (current || !lyrics.synced) Color(0xFFFFB4B8) else Color(0xFFFFB4B8).copy(alpha = 0.45f),
                                    modifier = Modifier.padding(top = 2.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        else ->
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Lirik tidak tersedia", style = T.body, color = Color.White.copy(alpha = 0.75f), textAlign = TextAlign.Center)
            }
    }
}

/** Baris kontrol lirik: pilih bahasa terjemahan dan geser waktu lirik. */
@Composable
private fun LyricsToolbar(lang: String, offsetMs: Int, synced: Boolean, translationReady: Boolean) {
    val app = AlterApp.instance
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        val label =
            when {
                lang.isEmpty() -> "Terjemahan"
                !translationReady -> "Menerjemahkan..."
                else -> TRANSLATE_LANGS.firstOrNull { it.code == lang }?.label ?: lang
            }
        Text(
            label,
            style = T.small.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
            modifier =
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (lang.isEmpty()) Color.White.copy(alpha = 0.16f) else AlterColors.Red)
                    .clickable {
                        // putar: Mati -> Indonesia -> English -> ... -> Mati
                        val codes = listOf("") + TRANSLATE_LANGS.map { it.code }
                        app.settings.setTranslateLang(codes[(codes.indexOf(lang) + 1) % codes.size])
                    }
                    .padding(horizontal = 14.dp, vertical = 7.dp),
        )
        Spacer(Modifier.weight(1f))
        if (synced) {
            Text(
                "-",
                style = T.title,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)).clickable { app.settings.setLyricOffsetMs(offsetMs - 500) }.padding(top = 4.dp),
            )
            Text(
                (if (offsetMs > 0) "+" else "") + "%.1f dtk".format(offsetMs / 1000f),
                style = T.small,
                color = Color.White.copy(alpha = 0.8f),
                modifier = Modifier.clickable { app.settings.setLyricOffsetMs(0) },
            )
            Text(
                "+",
                style = T.title,
                color = Color.White,
                textAlign = TextAlign.Center,
                modifier = Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)).clickable { app.settings.setLyricOffsetMs(offsetMs + 500) }.padding(top = 4.dp),
            )
        }
    }
}

@Composable
private fun QueuePanel(state: PlayerUiState) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = state.index.coerceAtLeast(0))
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Antrean • ${state.queue.size} lagu", style = T.section.copy(fontSize = 18.sp), modifier = Modifier.weight(1f))
            if (state.queue.any { !it.isLocal }) {
                Text(
                    "Simpan",
                    style = T.small.copy(fontWeight = FontWeight.Bold),
                    color = AlterColors.Sub,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { ui.queueSaveOpen = true }.padding(8.dp),
                )
            }
            if (state.hasNext) {
                Text(
                    "Kosongkan",
                    style = T.small.copy(fontWeight = FontWeight.Bold),
                    color = AlterColors.Sub,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { app.player.clearUpcoming() }.padding(8.dp),
                )
            }
        }
        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            itemsIndexed(state.queue) { i, s ->
                SongRow(
                    s,
                    onClick = { app.player.playQueueIndex(i) },
                    isCurrent = i == state.index,
                    trailing = {
                        IconBtn(R.drawable.ic_close, { app.player.removeFromQueue(i) }, tint = AlterColors.Sub, size = 18.dp)
                    },
                )
            }
        }
    }
}
