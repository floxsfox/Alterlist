package com.alterlist.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.FxPreset
import com.alterlist.app.fx.SpatialMode
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private enum class FxTab(val label: String) { PRESET("Preset"), SPATIAL("3D & 8D"), REVERB("Reverb & Tempo"), EQ("Equalizer") }

private class PresetStyle(val icon: Int, val tagline: String, val a: Color, val b: Color)

private fun styleOf(p: FxPreset): PresetStyle =
    when (p) {
        FxPreset.NORMAL -> PresetStyle(R.drawable.ic_music_note, "Suara asli, tanpa efek", Color(0xFF3A3A3F), Color(0xFF232326))
        FxPreset.SLOWED -> PresetStyle(R.drawable.ic_timer, "Lebih pelan dan dalam", Color(0xFF2B4C7E), Color(0xFF162338))
        FxPreset.SLOWED_REVERB -> PresetStyle(R.drawable.ic_wave, "Pelan dengan ruang luas", Color(0xFF5A3E8F), Color(0xFF241A3C))
        FxPreset.REVERB -> PresetStyle(R.drawable.ic_wave, "Gema lembut seperti aula", Color(0xFF7A3E7A), Color(0xFF301A30))
        FxPreset.SPED_UP -> PresetStyle(R.drawable.ic_next, "Lebih cepat dan ceria", Color(0xFFB5651D), Color(0xFF3F250A))
        FxPreset.SURROUND_3D -> PresetStyle(R.drawable.ic_cube, "Suara melebar ke samping", Color(0xFF117A74), Color(0xFF08312F))
        FxPreset.CONCERT_3D -> PresetStyle(R.drawable.ic_cube, "Seperti duduk di aula konser", Color(0xFF1B6E9C), Color(0xFF0A2A3D))
        FxPreset.AUDIO_8D -> PresetStyle(R.drawable.ic_orbit, "Suara berputar di kepalamu", Color(0xFFC2410C), Color(0xFF3A1505))
        FxPreset.SLOWED_8D -> PresetStyle(R.drawable.ic_orbit, "Pelan, berputar, berreverb", Color(0xFF9D2B6B), Color(0xFF330C22))
    }

/**
 * Panel efek suara (menu "Kustom"): preset siap pakai, audio spasial 3D dan 8D dengan pratinjau animasi,
 * reverb dan tempo, serta equalizer 5 pita. Semua bekerja di lagu YouTube, unduhan, maupun musik lokal.
 */
@Composable
fun EffectsSheet(onDismiss: () -> Unit) {
    val fx by AudioFx.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(FxTab.PRESET) }
    BottomSheetDialog(onDismiss) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Efek suara", style = T.hero)
                Text(
                    if (fx.isNormal) "Mati • suara asli" else "Aktif • ${fx.preset?.label ?: "Kustom"}",
                    style = T.small,
                    color = if (fx.isNormal) AlterColors.Sub else AlterColors.RedSoft,
                )
            }
            Text(
                "Reset",
                style = T.small.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(AlterColors.Surface3).bounceClick { AudioFx.reset() }.padding(horizontal = 14.dp, vertical = 8.dp),
            )
            Spacer(Modifier.width(6.dp))
            IconBtn(R.drawable.ic_close, onDismiss)
        }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FxTab.entries.forEach { t -> AlterChip(t.label, tab == t, { tab = t }) }
        }
        Crossfade(targetState = tab, label = "fxTab") { current ->
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
                when (current) {
                    FxTab.PRESET -> PresetGrid(fx.preset)
                    FxTab.SPATIAL -> SpatialTab(fx.spatial, fx.depth, fx.orbit, fx.orbitSeconds)
                    FxTab.REVERB -> ReverbTab()
                    FxTab.EQ -> EqualizerContent()
                }
            }
        }
    }
}

@Composable
private fun PresetGrid(selected: FxPreset?) {
    FxPreset.entries.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            pair.forEach { p -> PresetCard(p, p == selected, Modifier.weight(1f)) }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

@Composable
private fun PresetCard(p: FxPreset, selected: Boolean, modifier: Modifier) {
    val st = styleOf(p)
    val border by animateColorAsState(if (selected) Color.White else Color.Transparent, label = "presetBorder")
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .height(108.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(st.a, st.b)))
            .border(2.dp, border, shape)
            .bounceClick { AudioFx.applyPreset(p) }
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Ic(st.icon, tint = Color.White, size = 20.dp)
            }
            Spacer(Modifier.weight(1f))
            if (selected) Ic(R.drawable.ic_check, tint = Color.White, size = 20.dp)
        }
        Spacer(Modifier.weight(1f))
        Text(p.label, style = T.title.copy(fontWeight = FontWeight.Bold), color = Color.White, maxLines = 1)
        Text(st.tagline, style = T.tiny, color = Color.White.copy(alpha = 0.75f), maxLines = 2)
    }
}

@Composable
private fun SpatialTab(mode: SpatialMode, depth: Float, orbit: Float, orbitSeconds: Float) {
    val output by AlterApp.instance.audioOutput.active.collectAsState()
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        SpatialMode.entries.forEach { m ->
            val on = m == mode
            val icon =
                when (m) {
                    SpatialMode.OFF -> R.drawable.ic_music_note
                    SpatialMode.WIDE_3D -> R.drawable.ic_cube
                    SpatialMode.ORBIT_8D -> R.drawable.ic_orbit
                }
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (on) AlterColors.Red else AlterColors.Surface3)
                    .bounceClick { AudioFx.setSpatial(m) }
                    .padding(vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Ic(icon, tint = Color.White, size = 26.dp)
                Spacer(Modifier.height(6.dp))
                Text(if (m == SpatialMode.OFF) "Mati" else m.label, style = T.title.copy(fontWeight = FontWeight.Bold), color = Color.White)
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    SpatialStage(mode, depth, orbitSeconds, Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xFF151518)))
    Spacer(Modifier.height(8.dp))
    Text(
        when (mode) {
            SpatialMode.OFF -> "Pilih 3D untuk suara yang lebih lebar, atau 8D agar suara berputar mengelilingi kepalamu."
            SpatialMode.WIDE_3D -> "3D: suara dilebarkan dan diberi pantulan ruang sehingga terasa keluar dari kepala."
            SpatialMode.ORBIT_8D -> "8D: suara bergerak memutar (kiri, belakang, kanan, depan) dengan jeda antar-telinga dan redaman nada tinggi."
        },
        style = T.small,
        color = AlterColors.Sub,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth(),
    )
    if (mode != SpatialMode.OFF) {
        Spacer(Modifier.height(8.dp))
        EffectSlider("Kekuatan efek", "${(depth * 100).toInt()}%", depth) { AudioFx.setDepth(it) }
        if (mode == SpatialMode.ORBIT_8D) {
            EffectSlider("Kecepatan putar", "%.1f detik / putaran".format(orbitSeconds), orbit) { AudioFx.setOrbit(it) }
        }
        if (!output.isHeadphoneLike) {
            Spacer(Modifier.height(4.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF3A2A12)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Ic(R.drawable.ic_headphones, tint = Color(0xFFFFC46B), size = 22.dp)
                Spacer(Modifier.width(10.dp))
                Text("Efek ini paling terasa dengan headphone atau earphone. Sekarang kamu memakai ${output.name}.", style = T.small, color = Color(0xFFFFE2B0))
            }
        }
    }
}

/** Pratinjau animasi: kepala di tengah, titik sumber suara berputar (8D) atau gelombang melebar (3D). */
@Composable
private fun SpatialStage(mode: SpatialMode, depth: Float, orbitSeconds: Float, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "stage")
    val millis = (orbitSeconds * 1000f).toInt().coerceAtLeast(1500)
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(millis, easing = LinearEasing)), label = "angle")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Restart), label = "pulse")
    val accent = AlterColors.Red
    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = min(size.width, size.height) / 2f * 0.80f
        drawCircle(Color.White.copy(alpha = 0.07f), r, c, style = Stroke(2f))
        drawCircle(Color.White.copy(alpha = 0.05f), r * 0.62f, c, style = Stroke(2f))
        // kepala + telinga
        drawCircle(Color(0xFF34343A), r * 0.20f, c)
        drawCircle(Color(0xFF4A4A52), r * 0.055f, Offset(c.x - r * 0.21f, c.y))
        drawCircle(Color(0xFF4A4A52), r * 0.055f, Offset(c.x + r * 0.21f, c.y))
        when (mode) {
            SpatialMode.ORBIT_8D -> {
                val rad = (angle - 90f) * PI.toFloat() / 180f
                val px = c.x + cos(rad) * r
                val py = c.y + sin(rad) * r * 0.62f
                drawOval(
                    Color.White.copy(alpha = 0.10f),
                    topLeft = Offset(c.x - r, c.y - r * 0.62f),
                    size = Size(r * 2f, r * 1.24f),
                    style = Stroke(2f),
                )
                drawCircle(
                    Brush.radialGradient(listOf(accent.copy(alpha = 0.55f), Color.Transparent), center = Offset(px, py), radius = r * 0.30f),
                    r * 0.30f,
                    Offset(px, py),
                )
                drawCircle(accent, r * 0.075f, Offset(px, py))
            }
            SpatialMode.WIDE_3D -> {
                for (i in 0..2) {
                    val k = ((pulse + i / 3f) % 1f)
                    val rr = r * (0.35f + 0.55f * k * (0.5f + 0.5f * depth))
                    val a = (1f - k) * 0.55f
                    val stroke = Stroke(width = 5f, cap = StrokeCap.Round)
                    drawArc(accent.copy(alpha = a), -48f, 96f, false, Offset(c.x - rr, c.y - rr), Size(rr * 2f, rr * 2f), style = stroke)
                    drawArc(accent.copy(alpha = a), 132f, 96f, false, Offset(c.x - rr, c.y - rr), Size(rr * 2f, rr * 2f), style = stroke)
                }
            }
            SpatialMode.OFF -> {
                drawCircle(Color.White.copy(alpha = 0.55f), r * 0.07f, Offset(c.x - r * 0.45f, c.y))
                drawCircle(Color.White.copy(alpha = 0.55f), r * 0.07f, Offset(c.x + r * 0.45f, c.y))
            }
        }
    }
}

@Composable
private fun ReverbTab() {
    val fx by AudioFx.state.collectAsState()
    val span = AudioFx.SPEED_MAX - AudioFx.SPEED_MIN
    EffectSlider("Kecepatan", "%.2fx".format(fx.speed), (fx.speed - AudioFx.SPEED_MIN) / span) { AudioFx.setSpeed(AudioFx.SPEED_MIN + it * span) }
    EffectSlider("Reverb (campuran)", "${(fx.mix / AudioFx.MIX_MAX * 100).toInt()}%", fx.mix / AudioFx.MIX_MAX) { AudioFx.setMix(it * AudioFx.MIX_MAX) }
    EffectSlider("Ukuran ruang", "${(fx.room * 100).toInt()}%", fx.room) { AudioFx.setRoom(it) }
    EffectSlider("Peredam nada tinggi", "${(fx.damp * 100).toInt()}%", fx.damp) { AudioFx.setDamp(it) }
    EffectSlider("Pre-delay", "${fx.pre.toInt()} ms", fx.pre / 60f) { AudioFx.setPre(it * 60f) }
}

/** Slider efek: [value] 0..1. */
@Composable
internal fun EffectSlider(label: String, valueText: String, value: Float, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, style = T.body, modifier = Modifier.weight(1f))
            Text(valueText, style = T.small, color = AlterColors.Sub)
        }
        SeekBar(
            value = value.coerceIn(0f, 1f),
            onValueChange = onChange,
            onValueChangeFinished = {},
            modifier = Modifier.fillMaxWidth(),
            activeColor = AlterColors.Red,
        )
    }
}
