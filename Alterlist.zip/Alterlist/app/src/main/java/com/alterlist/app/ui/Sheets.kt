package com.alterlist.app.ui

import android.content.Intent
import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.Entry
import com.alterlist.app.data.Song
import com.alterlist.app.data.watchUrl
import kotlinx.coroutines.launch

@Composable
internal fun BottomSheetDialog(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().noRippleClickable(onDismiss), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .noRippleClickable {}
                    .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                    .background(AlterColors.Surface2)
                    .navigationBarsPadding()
                    .padding(top = 6.dp, bottom = 10.dp),
                content = content,
            )
        }
    }
}

@Composable
internal fun MenuItem(@DrawableRes icon: Int, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Ic(icon, tint = tint, size = 24.dp)
        Spacer(Modifier.width(18.dp))
        Text(label, style = T.title, color = Color.White)
    }
}

/** Menu lagu (ketuk ⋮ atau tahan lama pada lagu). */
@Composable
fun SongMenuSheet(song: Song, playlistId: String?, onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val lib by app.library.data.collectAsState()
    val progress by app.downloader.progress.collectAsState()
    val liked = lib.liked.any { it.id == song.id }
    val downloaded = lib.downloads.any { it.song.id == song.id }
    val downloading = progress.containsKey(song.id)

    BottomSheetDialog(onDismiss) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Artwork(song.thumbnail, Modifier.size(56.dp), RoundedCornerShape(5.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(AlterColors.Divider))

        MenuItem(
            if (liked) R.drawable.ic_heart_fill else R.drawable.ic_heart,
            if (liked) "Hapus dari Lagu disukai" else "Suka",
            tint = if (liked) AlterColors.Red else Color.White,
        ) {
            val nowLiked = app.library.toggleLike(song)
            if (!song.isLocal) app.scope.launch { app.yt.likeOnAccount(song.id, nowLiked) }
            context.toast(if (nowLiked) "Ditambahkan ke Lagu disukai" else "Dihapus dari Lagu disukai")
            onDismiss()
        }
        MenuItem(R.drawable.ic_plus, "Tambah ke playlist") {
            ui.addToPlaylistSong = song
            onDismiss()
        }
        MenuItem(R.drawable.ic_queue, "Tambah ke antrean") {
            app.player.addToQueue(song)
            context.toast("Ditambahkan ke antrean")
            onDismiss()
        }
        MenuItem(R.drawable.ic_play, "Putar berikutnya") {
            app.player.playNext(song)
            context.toast("Akan diputar berikutnya")
            onDismiss()
        }
        if (!song.isLocal) {
            MenuItem(R.drawable.ic_sparkle, "Mulai radio dari lagu ini") {
                app.player.playRadio(song)
                context.toast("Memutar radio \"${song.title}\"")
                onDismiss()
            }
        }
        when {
            song.isLocal -> Unit
            downloaded ->
                MenuItem(R.drawable.ic_trash, "Hapus unduhan") {
                    app.downloader.delete(song.id)
                    context.toast("Unduhan dihapus")
                    onDismiss()
                }
            downloading ->
                MenuItem(R.drawable.ic_close, "Batalkan unduhan") {
                    app.downloader.cancel(song.id)
                    onDismiss()
                }
            else ->
                MenuItem(R.drawable.ic_download, "Unduh") {
                    app.downloader.enqueue(song)
                    context.toast("Mengunduh \"${song.title}\"...")
                    onDismiss()
                }
        }
        if (song.artistId != null) {
            MenuItem(R.drawable.ic_user, "Lihat artis") {
                onDismiss()
                ui.closePlayer()
                ui.navigate(Route.Browse(Entry(title = song.artist.ifBlank { "Artis" }, browseId = song.artistId)))
            }
        }
        if (song.albumId != null) {
            MenuItem(R.drawable.ic_album, "Lihat album") {
                onDismiss()
                ui.closePlayer()
                ui.navigate(Route.Browse(Entry(title = song.album ?: "Album", thumbnail = song.thumbnail, browseId = song.albumId)))
            }
        }
        MenuItem(R.drawable.ic_info, "Info lagu") {
            ui.infoSong = song
            onDismiss()
        }
        MenuItem(R.drawable.ic_share, "Bagikan") {
            val send =
                Intent(Intent.ACTION_SEND).apply {
                    val fileUri = song.uri
                    if (song.isLocal && fileUri != null) {
                        // berkas audio dibagikan sebagai berkas, bukan tautan
                        type = "audio/*"
                        putExtra(Intent.EXTRA_STREAM, android.net.Uri.parse(fileUri))
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    } else {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${song.title} - ${song.artist}\n${song.watchUrl()}")
                    }
                }
            context.startActivity(Intent.createChooser(send, "Bagikan lagu").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            onDismiss()
        }
        if (song.isLocal && app.localMusic.isPicked(song.id)) {
            MenuItem(R.drawable.ic_trash, "Hapus dari daftar perangkat", tint = AlterColors.RedSoft) {
                app.scope.launch { app.localMusic.removePicked(song.id) }
                context.toast("Dihapus dari daftar (berkas asli tetap ada)")
                onDismiss()
            }
        }
        if (playlistId != null) {
            MenuItem(R.drawable.ic_trash, "Hapus dari playlist ini", tint = AlterColors.RedSoft) {
                app.library.removeFromPlaylist(playlistId, song.id)
                context.toast("Dihapus dari playlist")
                onDismiss()
            }
        }
    }
}

@Composable
fun AddToPlaylistSheet(song: Song, onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val lib by app.library.data.collectAsState()

    BottomSheetDialog(onDismiss) {
        Text("Tambahkan ke playlist", style = T.section.copy(fontSize = 19.sp), modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        MenuItem(R.drawable.ic_plus, "Playlist baru") {
            ui.createPlaylistSong = song
            ui.createPlaylistOpen = true
            onDismiss()
        }
        LazyColumn(Modifier.heightIn(max = 360.dp)) {
            items(lib.playlists) { p ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            val added = app.library.addToPlaylist(p.id, song)
                            context.toast(if (added) "Ditambahkan ke ${p.name}" else "Sudah ada di ${p.name}")
                            onDismiss()
                        }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Artwork(p.songs.firstOrNull()?.thumbnail, Modifier.size(48.dp), RoundedCornerShape(5.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${p.songs.size} lagu", style = T.small, color = AlterColors.Sub)
                    }
                }
            }
        }
    }
}

@Composable
fun SleepTimerSheet(onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val sleep by app.player.sleep.collectAsState()
    BottomSheetDialog(onDismiss) {
        Text("Pengatur waktu tidur", style = T.section.copy(fontSize = 19.sp), modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp))
        listOf(5, 10, 15, 30, 45, 60).forEach { minutes ->
            MenuItem(R.drawable.ic_timer, "$minutes menit") {
                app.player.startSleepTimer(minutes)
                context.toast("Musik berhenti dalam $minutes menit")
                onDismiss()
            }
        }
        MenuItem(R.drawable.ic_timer, "Sampai lagu ini selesai") {
            app.player.sleepAtEndOfTrack()
            context.toast("Musik berhenti setelah lagu ini")
            onDismiss()
        }
        if (sleep.active) {
            MenuItem(R.drawable.ic_close, "Matikan timer", tint = AlterColors.RedSoft) {
                app.player.cancelSleepTimer()
                onDismiss()
            }
        }
    }
}

@Composable
fun TextInputDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
    placeholder: String = "",
) {
    var text by remember { mutableStateOf(initial) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(RoundedCornerShape(16.dp)).background(AlterColors.Surface2).padding(20.dp)) {
            Text(title, style = T.title.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(AlterColors.Surface3).padding(14.dp)) {
                if (text.isEmpty() && placeholder.isNotEmpty()) {
                    Text(placeholder, style = T.title, color = AlterColors.Muted)
                }
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    textStyle = T.title.copy(color = Color.White),
                    cursorBrush = SolidColor(AlterColors.Red),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                )
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("Batal", style = T.button, color = AlterColors.Sub, modifier = Modifier.clickable(onClick = onDismiss).padding(10.dp))
                Spacer(Modifier.width(10.dp))
                Text(confirmLabel, style = T.button, color = AlterColors.Red, modifier = Modifier.clickable { onConfirm(text.trim()) }.padding(10.dp))
            }
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(RoundedCornerShape(16.dp)).background(AlterColors.Surface2).padding(20.dp)) {
            Text(title, style = T.title.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold))
            Spacer(Modifier.height(10.dp))
            Text(message, style = T.body, color = AlterColors.Sub)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Text("Batal", style = T.button, color = AlterColors.Sub, modifier = Modifier.clickable(onClick = onDismiss).padding(10.dp))
                Spacer(Modifier.width(10.dp))
                Text(confirmLabel, style = T.button, color = AlterColors.Red, modifier = Modifier.clickable(onClick = onConfirm).padding(10.dp))
            }
        }
    }
}
