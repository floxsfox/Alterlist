package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Entry
import com.alterlist.app.data.UiLoad
import com.alterlist.app.data.topArtists
import kotlinx.coroutines.CancellationException

@Composable
fun LibraryScreen(padding: PaddingValues, onEntry: (Entry) -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val lib by app.library.data.collectAsState()
    val account by app.account.state.collectAsState()
    val player by app.player.state.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    var ytPlaylists by remember { mutableStateOf<UiLoad<List<Entry>>>(UiLoad.Idle) }
    LaunchedEffect(account.mode, tab) {
        if (account.mode != AccountMode.GOOGLE || tab != 0) return@LaunchedEffect
        ytPlaylists = UiLoad.Loading
        ytPlaylists =
            try {
                UiLoad.Data(app.yt.accountPlaylists())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error("Playlist akun tidak bisa dimuat")
            }
    }

    val suggestedArtists = remember(lib.stats) { lib.topArtists(8) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = padding) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 14.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Koleksi", style = T.screen, modifier = Modifier.weight(1f))
                IconBtn(R.drawable.ic_plus, { ui.createPlaylistOpen = true })
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AlterChip("Playlist", tab == 0, { tab = 0 })
                AlterChip("Artis", tab == 1, { tab = 1 })
                AlterChip("Unduhan", tab == 2, { tab = 2 })
            }
            Spacer(Modifier.height(6.dp))
        }

        when (tab) {
            0 -> {
                item {
                    LibraryTile(
                        "Lagu disukai",
                        "Playlist • ${lib.liked.size} lagu",
                        null,
                        RoundedCornerShape(5.dp),
                        { ui.navigate(Route.Liked) },
                        leading = { GradientIcon(R.drawable.ic_heart_fill, listOf(AlterColors.Red, Color(0xFF5A0003))) },
                    )
                }
                item {
                    LibraryTile(
                        "Riwayat putar",
                        "${lib.recent.size} lagu terakhir",
                        null,
                        RoundedCornerShape(5.dp),
                        { ui.navigate(Route.Recent) },
                        leading = { GradientIcon(R.drawable.ic_history, listOf(Color(0xFF3A3A3F), Color(0xFF1C1C1F))) },
                    )
                }
                item {
                    LibraryTile(
                        "Di perangkat",
                        "Musik di penyimpanan",
                        null,
                        RoundedCornerShape(5.dp),
                        { ui.navigate(Route.Local) },
                        leading = { GradientIcon(R.drawable.ic_phone, listOf(Color(0xFF1B6E9C), Color(0xFF0A2A3D))) },
                    )
                }
                items(lib.playlists) { p ->
                    LibraryTile(
                        p.name,
                        "Playlist • ${p.songs.size} lagu",
                        p.songs.firstOrNull()?.thumbnail,
                        RoundedCornerShape(5.dp),
                        { ui.navigate(Route.LocalPlaylist(p.id)) },
                    )
                }
                if (account.mode == AccountMode.GOOGLE) {
                    item { SectionTitle("Dari YouTube Music") }
                    when (val y = ytPlaylists) {
                        is UiLoad.Data ->
                            if (y.value.isEmpty()) {
                                item { EmptyText("Belum ada playlist di akunmu.") }
                            } else {
                                items(y.value) { e ->
                                    LibraryTile(e.title, e.subtitle, e.thumbnail, RoundedCornerShape(5.dp), { onEntry(e) })
                                }
                            }
                        is UiLoad.Loading -> item { LoadingBox() }
                        is UiLoad.Error -> item { EmptyText(y.message) }
                        is UiLoad.Idle -> Unit
                    }
                }
            }
            1 -> {
                if (lib.artists.isEmpty() && suggestedArtists.isEmpty()) {
                    item { EmptyText("Belum ada artis") }
                }
                items(lib.artists) { a ->
                    LibraryTile(a.name, "Artis", a.thumbnail, CircleShape, { onEntry(Entry(title = a.name, thumbnail = a.thumbnail, browseId = a.id)) })
                }
                if (suggestedArtists.isNotEmpty()) {
                    item { SectionTitle("Sering kamu putar") }
                    items(suggestedArtists) { a ->
                        LibraryTile(
                            a.name,
                            "${a.plays}x diputar",
                            a.thumbnail,
                            CircleShape,
                            {
                                if (a.id != null) onEntry(Entry(title = a.name, thumbnail = a.thumbnail, browseId = a.id))
                                else app.player.playRadio(a.topSong)
                            },
                        )
                    }
                }
            }
            else -> {
                if (lib.downloads.isEmpty()) {
                    item { EmptyText("Belum ada unduhan") }
                } else {
                    item {
                        Text(
                            "${lib.downloads.size} lagu • ${formatBytes(lib.downloads.sumOf { it.bytes })}",
                            style = T.small,
                            color = AlterColors.Sub,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                        )
                    }
                    val songs = lib.downloads.map { it.song }
                    itemsIndexed(songs) { i, s ->
                        SongRow(s, onClick = { app.player.playSongs(songs, i) }, isCurrent = player.current?.id == s.id)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun GradientIcon(iconRes: Int, colors: List<Color>) {
    Box(Modifier.size(56.dp).background(Brush.linearGradient(colors)), contentAlignment = Alignment.Center) {
        Ic(iconRes, tint = Color.White, size = 26.dp)
    }
}

@Composable
fun LibraryTile(
    title: String,
    subtitle: String,
    thumbnail: String?,
    shape: Shape,
    onClick: () -> Unit,
    leading: (@Composable () -> Unit)? = null,
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            Box(Modifier.size(56.dp).clip(shape)) { leading() }
        } else {
            Artwork(thumbnail, Modifier.size(56.dp), shape)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
