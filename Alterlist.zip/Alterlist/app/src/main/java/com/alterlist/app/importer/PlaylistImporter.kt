package com.alterlist.app.importer

import android.widget.Toast
import com.alterlist.app.AlterApp
import com.alterlist.app.data.LinkHandler
import com.alterlist.app.data.Net
import com.alterlist.app.data.SearchFilter
import com.alterlist.app.data.Song
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger

/** Sumber playlist yang didukung. */
enum class ImportPlatform(val label: String) {
    YOUTUBE("YouTube Music"),
    SPOTIFY("Spotify"),
    APPLE("Apple Music"),
    SOUNDCLOUD("SoundCloud"),
    TEXT("Daftar lagu"),
}

/** Satu lagu dari platform lain (judul + artis), yang akan dicocokkan ke YouTube Music. */
data class ImportTrack(val title: String, val artist: String = "")

/** Hasil membaca satu tautan: nama playlist + daftar lagu mentah, atau lagu yang sudah siap putar (YouTube). */
class ImportSource(
    val platform: ImportPlatform,
    val name: String,
    val tracks: List<ImportTrack> = emptyList(),
    val songs: List<Song> = emptyList(),
)

sealed interface ImportState {
    data object Idle : ImportState

    data class Reading(val platform: ImportPlatform?) : ImportState

    data class Matching(val name: String, val done: Int, val found: Int, val total: Int) : ImportState

    data class Done(val playlistId: String, val name: String, val found: Int, val total: Int, val missed: List<String>) : ImportState

    data class Failed(val message: String) : ImportState
}

private class ImportException(message: String) : Exception(message)

private fun fail(message: String): Nothing = throw ImportException(message)

/** Mengenali platform dari teks yang ditempel. */
object ImportDetect {
    private val URL = Regex("""https?://[^\s"'<>]+""")

    fun firstUrl(text: String): String? = URL.find(text)?.value?.trimEnd('.', ',', ')', ']')

    fun platformOf(input: String): ImportPlatform? {
        val t = input.trim()
        if (t.isEmpty()) return null
        val link = firstUrl(t)
        if (link != null) {
            val host = runCatching { java.net.URI(link).host.orEmpty().lowercase() }.getOrDefault("")
            return when {
                host.endsWith("youtube.com") || host == "youtu.be" -> ImportPlatform.YOUTUBE
                host.endsWith("spotify.com") || host.endsWith("spotify.link") -> ImportPlatform.SPOTIFY
                host.endsWith("apple.com") -> ImportPlatform.APPLE
                host.endsWith("soundcloud.com") || host == "snd.sc" -> ImportPlatform.SOUNDCLOUD
                else -> null
            }
        }
        return ImportPlatform.TEXT
    }
}

/**
 * Impor playlist dari platform lain. Playlist dibaca dari tautan publik (tanpa login), tiap lagu dicari di YouTube Music,
 * lalu semuanya disimpan sebagai playlist baru di Koleksi. Berjalan di latar: menutup sheet tidak membatalkan impor.
 */
class PlaylistImporter(private val app: AlterApp) {
    private val _state = MutableStateFlow<ImportState>(ImportState.Idle)
    val state: StateFlow<ImportState> = _state.asStateFlow()
    private var job: Job? = null

    val busy: Boolean get() = job?.isActive == true

    fun start(input: String) {
        if (busy) return
        job = app.scope.launch { run(input) }
    }

    fun cancel() {
        job?.cancel()
        _state.value = ImportState.Idle
    }

    /** Kembali ke formulir (setelah selesai / gagal). */
    fun reset() {
        if (!busy) _state.value = ImportState.Idle
    }

    private suspend fun run(input: String) {
        try {
            val platform = ImportDetect.platformOf(input) ?: fail("Tempel tautan playlist atau daftar lagu")
            _state.value = ImportState.Reading(platform)
            val link = ImportDetect.firstUrl(input)
            val source =
                when (platform) {
                    ImportPlatform.YOUTUBE -> fromYoutube(link ?: fail("Tautan tidak valid"))
                    ImportPlatform.SPOTIFY -> fromSpotify(link ?: fail("Tautan tidak valid"))
                    ImportPlatform.APPLE -> fromApple(link ?: fail("Tautan tidak valid"))
                    ImportPlatform.SOUNDCLOUD -> fromSoundCloud(link ?: fail("Tautan tidak valid"))
                    ImportPlatform.TEXT -> fromText(input)
                }
            val name = source.name.ifBlank { "Impor ${platform.label}" }
            val total = if (source.songs.isNotEmpty()) source.songs.size else source.tracks.size
            if (total == 0) fail("Tidak ada lagu yang terbaca. Pastikan playlist-nya publik.")

            val found: List<Song>
            val missed = mutableListOf<String>()
            if (source.songs.isNotEmpty()) {
                found = source.songs
            } else {
                _state.value = ImportState.Matching(name, 0, 0, total)
                val results = arrayOfNulls<Song>(total)
                val done = AtomicInteger(0)
                val hit = AtomicInteger(0)
                val gate = Semaphore(3)
                coroutineScope {
                    source.tracks
                        .mapIndexed { i, t ->
                            async {
                                gate.withPermit {
                                    val s = matchTrack(t)
                                    results[i] = s
                                    if (s != null) hit.incrementAndGet()
                                    val d = done.incrementAndGet()
                                    _state.value = ImportState.Matching(name, d, hit.get(), total)
                                }
                            }
                        }.awaitAll()
                }
                found = results.filterNotNull()
                source.tracks.forEachIndexed { i, t -> if (results[i] == null) missed += listOf(t.title, t.artist).filter { it.isNotBlank() }.joinToString(" - ") }
            }
            if (found.isEmpty()) fail("Tidak satu pun lagu ditemukan di YouTube Music")

            val playlist = app.library.createPlaylistWith(name, found)
            _state.value = ImportState.Done(playlist.id, playlist.name, found.distinctBy { it.id }.size, total, missed.take(40))
            toast("\"${playlist.name}\" diimpor: ${found.size} dari $total lagu")
        } catch (e: CancellationException) {
            throw e
        } catch (e: ImportException) {
            _state.value = ImportState.Failed(e.message.orEmpty())
        } catch (e: Exception) {
            _state.value = ImportState.Failed("Impor gagal: ${e.message ?: "periksa koneksi internetmu"}")
        }
    }

    private suspend fun toast(text: String) =
        withContext(Dispatchers.Main) { Toast.makeText(app, text, Toast.LENGTH_LONG).show() }

    // ---------------------------------------------------------------- pencocokan ke YouTube Music

    private suspend fun matchTrack(t: ImportTrack): Song? {
        val query = "${t.title} ${t.artist}".replace(Regex("""\s+"""), " ").trim()
        if (query.isEmpty()) return null
        val songs = runCatching { app.yt.search(query, SearchFilter.SONG) }.getOrNull().orEmpty()
        songs.firstNotNullOfOrNull { it.toSong() }?.let { return it }
        val videos = runCatching { app.yt.search(query, SearchFilter.VIDEO) }.getOrNull().orEmpty()
        return videos.firstNotNullOfOrNull { it.toSong() }
    }

    // ---------------------------------------------------------------- YouTube / YouTube Music

    private suspend fun fromYoutube(link: String): ImportSource {
        val list = LinkHandler.listId(link)
        if (list != null) {
            val page = runCatching { app.yt.browsePage("VL$list") }.getOrNull()
            var songs = page?.songs.orEmpty()
            if (songs.isEmpty()) songs = runCatching { app.yt.upNext(null, list) }.getOrDefault(emptyList())
            if (songs.isEmpty()) fail("Playlist YouTube kosong atau bersifat pribadi")
            return ImportSource(ImportPlatform.YOUTUBE, page?.title.orEmpty().ifBlank { "Playlist YouTube" }, songs = songs)
        }
        val browse = Regex("""/browse/([A-Za-z0-9_-]+)""").find(link)?.groupValues?.get(1)
        if (browse != null) {
            val page = runCatching { app.yt.browsePage(browse) }.getOrNull()
            if (page != null && page.songs.isNotEmpty()) return ImportSource(ImportPlatform.YOUTUBE, page.title, songs = page.songs)
        }
        fail("Tautan YouTube ini bukan playlist atau album")
    }

    // ---------------------------------------------------------------- Spotify

    private suspend fun fromSpotify(link: String): ImportSource {
        val full = expandShortLink(link)
        val m = Regex("""open\.spotify\.com/(?:intl-[a-z]+/)?(playlist|album|track)/([A-Za-z0-9]+)""").find(full) ?: fail("Tautan Spotify tidak dikenali")
        val (type, id) = m.destructured
        val (code, html) = httpGet("https://open.spotify.com/embed/$type/$id")
        if (html == null) fail(if (code == 404) "Playlist Spotify tidak ditemukan atau bersifat pribadi" else "Spotify tidak bisa dihubungi (kode $code)")
        val data =
            Regex("""<script id="__NEXT_DATA__" type="application/json">(.*?)</script>""", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)
                ?: fail("Spotify mengubah halamannya. Tempel daftar lagu sebagai teks sebagai gantinya.")
        val root = Json.parseToJsonElement(data)
        val entity = root.findKey("entity") as? JsonObject
        val name = entity?.str("name") ?: entity?.str("title") ?: "Playlist Spotify"
        val list = (entity?.get("trackList") ?: root.findKey("trackList")) as? JsonArray
        var tracks =
            list.orEmpty().mapNotNull { it as? JsonObject }.mapNotNull { t ->
                val title = t.str("title")
                if (title.isNullOrBlank()) null else ImportTrack(title, t.str("subtitle").orEmpty().replace('\u00a0', ' '))
            }
        if (tracks.isEmpty() && entity != null) {
            // satu lagu
            val title = entity.str("name") ?: entity.str("title")
            val artists = (entity["artists"] as? JsonArray).orEmpty().mapNotNull { (it as? JsonObject)?.str("name") }.joinToString(", ")
            if (!title.isNullOrBlank()) tracks = listOf(ImportTrack(title, artists))
        }
        return ImportSource(ImportPlatform.SPOTIFY, name, tracks)
    }

    // ---------------------------------------------------------------- Apple Music

    private suspend fun fromApple(link: String): ImportSource {
        val (code, html) = httpGet(link, mapOf("Accept-Language" to "en-US,en;q=0.8"))
        if (html == null) fail("Apple Music tidak bisa dibuka (kode $code). Pastikan playlist-nya publik.")
        // 1) JSON-LD (schema.org MusicPlaylist / MusicAlbum)
        for (m in Regex("""<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL).findAll(html)) {
            val el = runCatching { Json.parseToJsonElement(m.groupValues[1]) }.getOrNull() ?: continue
            val holder = el.findObjectWith("track") ?: continue
            val tracks =
                (holder["track"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }.mapNotNull { t ->
                    val title = t.str("name")
                    if (title.isNullOrBlank()) null else ImportTrack(title, artistNames(t["byArtist"]))
                }
            if (tracks.isNotEmpty()) return ImportSource(ImportPlatform.APPLE, holder.str("name") ?: "Playlist Apple Music", tracks)
        }
        // 2) data server yang diserialisasi
        val data =
            Regex("""<script[^>]*id="serialized-server-data"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL).find(html)?.groupValues?.get(1)
        if (data != null) {
            val root = runCatching { Json.parseToJsonElement(data) }.getOrNull()
            if (root != null) {
                val found = LinkedHashMap<String, ImportTrack>()
                root.walkObjects { o ->
                    val title = o.str("title")
                    val artist = o.str("artistName")
                    val kind = ((o["contentDescriptor"] as? JsonObject)?.str("kind"))
                    if (!title.isNullOrBlank() && !artist.isNullOrBlank() && (kind == null || kind == "song")) {
                        found.putIfAbsent("$title|$artist", ImportTrack(title, artist))
                    }
                }
                if (found.isNotEmpty()) {
                    val name = Regex("""<meta property="og:title" content="([^"]+)"""").find(html)?.groupValues?.get(1) ?: "Playlist Apple Music"
                    return ImportSource(ImportPlatform.APPLE, htmlDecode(name), found.values.toList())
                }
            }
        }
        fail("Apple Music mengubah halamannya. Tempel daftar lagu sebagai teks sebagai gantinya.")
    }

    private fun artistNames(el: JsonElement?): String =
        when (el) {
            is JsonObject -> el.str("name").orEmpty()
            is JsonArray -> el.mapNotNull { (it as? JsonObject)?.str("name") ?: (it as? JsonPrimitive)?.content }.joinToString(", ")
            is JsonPrimitive -> el.content
            else -> ""
        }

    private fun htmlDecode(s: String): String =
        s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")

    // ---------------------------------------------------------------- SoundCloud

    @Volatile private var discoveredClientId: String? = null

    /** Client ID dari pengaturan; kalau kosong, dicari otomatis dari berkas JavaScript situs SoundCloud. */
    private suspend fun soundCloudClientId(forceRefresh: Boolean): String? {
        val configured = app.settings.state.value.soundcloudClientId
        if (configured.isNotBlank()) return configured
        if (!forceRefresh) discoveredClientId?.let { return it }
        val home = Net.getText("https://soundcloud.com/") ?: return null
        val scripts =
            Regex("""<script[^>]+src="(https://[^"]*sndcdn\.com/assets/[^"]+\.js)"""").findAll(home).map { it.groupValues[1] }.toList().asReversed()
        for (u in scripts) {
            val js = Net.getText(u) ?: continue
            val id = Regex("""client_id\s*[:=]\s*"([A-Za-z0-9]{32})"""").find(js)?.groupValues?.get(1)
            if (id != null) {
                discoveredClientId = id
                return id
            }
        }
        return null
    }

    private suspend fun fromSoundCloud(link: String): ImportSource {
        val base = app.settings.state.value.soundcloudApiBase.trimEnd('/')
        val full = expandShortLink(link)
        var id = soundCloudClientId(false) ?: fail("Client ID SoundCloud tidak ditemukan. Isi manual di Pengaturan > Impor playlist.")
        var (code, body) = httpGet("$base/resolve?url=${enc(full)}&client_id=$id")
        if ((code == 401 || code == 403) && app.settings.state.value.soundcloudClientId.isBlank()) {
            // ID otomatis kedaluwarsa: cari yang baru sekali lagi
            id = soundCloudClientId(true) ?: fail("Client ID SoundCloud tidak ditemukan. Isi manual di Pengaturan > Impor playlist.")
            val retry = httpGet("$base/resolve?url=${enc(full)}&client_id=$id")
            code = retry.first
            body = retry.second
        }
        if (body == null) {
            fail(
                when (code) {
                    401, 403 -> "Client ID SoundCloud ditolak. Ganti di Pengaturan > Impor playlist."
                    404 -> "Playlist SoundCloud tidak ditemukan atau bersifat pribadi"
                    else -> "SoundCloud tidak bisa dihubungi (kode $code). Periksa alamat API di Pengaturan."
                },
            )
        }
        val root = Json.parseToJsonElement(body) as? JsonObject ?: fail("Balasan SoundCloud tidak dikenali")
        return when (root.str("kind")) {
            "playlist", "system-playlist" -> {
                val raw = (root["tracks"] as? JsonArray).orEmpty().mapNotNull { it as? JsonObject }
                // sebagian entri hanya berisi id; lengkapi lewat /tracks?ids=
                val stubIds = raw.filter { it.str("title").isNullOrBlank() }.mapNotNull { it.str("id") }
                val filled = HashMap<String, JsonObject>()
                for (chunk in stubIds.chunked(30)) {
                    val (_, b) = httpGet("$base/tracks?ids=${chunk.joinToString(",")}&client_id=$id")
                    (b?.let { runCatching { Json.parseToJsonElement(it) }.getOrNull() } as? JsonArray)
                        ?.mapNotNull { it as? JsonObject }
                        ?.forEach { o -> o.str("id")?.let { k -> filled[k] = o } }
                }
                val tracks =
                    raw.mapNotNull { o -> if (o.str("title").isNullOrBlank()) o.str("id")?.let { filled[it] } else o }
                        .mapNotNull { soundCloudTrack(it) }
                ImportSource(ImportPlatform.SOUNDCLOUD, root.str("title") ?: "Playlist SoundCloud", tracks)
            }
            "track" -> ImportSource(ImportPlatform.SOUNDCLOUD, root.str("title") ?: "Lagu SoundCloud", listOfNotNull(soundCloudTrack(root)))
            else -> fail("Tautan SoundCloud harus berupa playlist (set) atau lagu")
        }
    }

    private fun soundCloudTrack(o: JsonObject): ImportTrack? {
        val title = o.str("title")?.trim()
        if (title.isNullOrBlank()) return null
        val artist = (o["publisher_metadata"] as? JsonObject)?.str("artist") ?: (o["user"] as? JsonObject)?.str("username").orEmpty()
        return ImportTrack(title, artist)
    }

    // ---------------------------------------------------------------- daftar teks / CSV

    private fun fromText(text: String): ImportSource {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) fail("Daftar lagu kosong")
        val head = lines.first().lowercase()
        if (head.contains("track name") || (head.contains("title") && head.contains("artist"))) {
            val header = parseCsvLine(lines.first()).map { it.lowercase() }
            val ti = header.indexOfFirst { it.contains("track name") || it == "title" || it == "song" || it.contains("track") }
            val ai = header.indexOfFirst { it.contains("artist") }
            if (ti >= 0) {
                val tracks =
                    lines.drop(1).mapNotNull { l ->
                        val c = parseCsvLine(l)
                        val title = c.getOrNull(ti)?.trim().orEmpty()
                        if (title.isEmpty()) null else ImportTrack(title, c.getOrNull(ai)?.trim().orEmpty())
                    }
                return ImportSource(ImportPlatform.TEXT, "Impor daftar lagu", tracks)
            }
        }
        val numbering = Regex("""^\s*(\d{1,3}[.)]|[-*•])\s+""")
        val tracks = lines.map { numbering.replace(it, "").trim() }.filter { it.isNotEmpty() }.map { ImportTrack(it) }
        return ImportSource(ImportPlatform.TEXT, "Impor daftar lagu", tracks)
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    cur.append('"')
                    i++
                }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> {
                    out += cur.toString()
                    cur.clear()
                }
                else -> cur.append(ch)
            }
            i++
        }
        out += cur.toString()
        return out
    }

    // ---------------------------------------------------------------- jaringan & JSON

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** GET dengan kode status: (kode, isi) — isi null bila kode bukan 2xx atau jaringan gagal (kode -1). */
    private suspend fun httpGet(url: String, headers: Map<String, String> = emptyMap()): Pair<Int, String?> =
        withContext(Dispatchers.IO) {
            val c = Net.open(url, headers)
            try {
                val code = c.responseCode
                val body = if (code in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
                code to body
            } catch (e: IOException) {
                -1 to null
            } finally {
                c.disconnect()
            }
        }

    /** Ikuti tautan pendek (spotify.link, on.soundcloud.com, snd.sc) sampai alamat akhirnya. */
    private suspend fun expandShortLink(url: String): String {
        val host = runCatching { java.net.URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        if (host != "spotify.link" && host != "on.soundcloud.com" && host != "snd.sc") return url
        return withContext(Dispatchers.IO) {
            val c = Net.open(url)
            try {
                c.responseCode
                c.url.toString()
            } catch (e: IOException) {
                url
            } finally {
                c.disconnect()
            }
        }
    }
}

// ---------------------------------------------------------------- helper JSON

private fun JsonObject.str(key: String): String? = (this[key] as? JsonPrimitive)?.takeIf { it !is JsonNull }?.content

private fun JsonArray?.orEmpty(): List<JsonElement> = this?.toList() ?: emptyList()

/** Nilai pertama dari [key] di mana pun di dalam pohon JSON. */
private fun JsonElement.findKey(key: String): JsonElement? =
    when (this) {
        is JsonObject -> this[key] ?: values.firstNotNullOfOrNull { it.findKey(key) }
        is JsonArray -> firstNotNullOfOrNull { it.findKey(key) }
        else -> null
    }

/** Objek pertama (di mana pun) yang punya properti [key] berupa array. */
private fun JsonElement.findObjectWith(key: String): JsonObject? =
    when (this) {
        is JsonObject -> if (this[key] is JsonArray) this else values.firstNotNullOfOrNull { it.findObjectWith(key) }
        is JsonArray -> firstNotNullOfOrNull { it.findObjectWith(key) }
        else -> null
    }

private fun JsonElement.walkObjects(visit: (JsonObject) -> Unit) {
    when (this) {
        is JsonObject -> {
            visit(this)
            values.forEach { it.walkObjects(visit) }
        }
        is JsonArray -> forEach { it.walkObjects(visit) }
        else -> {}
    }
}
