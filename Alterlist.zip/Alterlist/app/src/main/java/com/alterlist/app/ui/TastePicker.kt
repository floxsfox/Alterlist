package com.alterlist.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.R
import com.alterlist.app.data.GenreChoice
import com.alterlist.app.data.GenreTags

/**
 * Kartu "Pilih genre favoritmu" (seperti saat pertama kali memakai Spotify). Dipakai untuk pengguna baru supaya
 * Beranda langsung punya rekomendasi sebelum ada riwayat putar.
 */
@Composable
fun TastePickerCard(initial: List<String>, onSave: (List<String>) -> Unit, modifier: Modifier = Modifier, title: String = "Pilih genre favoritmu") {
    val selected = remember { mutableStateListOf<String>().apply { addAll(initial) } }
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(AlterColors.Surface)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Ic(R.drawable.ic_sparkle, tint = AlterColors.Red, size = 22.dp)
            Spacer(Modifier.width(8.dp))
            Text(title, style = T.section.copy(fontSize = 19.sp))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Pilih beberapa supaya Beranda langsung berisi lagu yang cocok. Makin sering kamu memutar lagu, makin tepat rekomendasinya.",
            style = T.small,
            color = AlterColors.Sub,
        )
        Spacer(Modifier.height(14.dp))
        GenreTags.CHOICES.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { g ->
                    GenreTile(
                        g,
                        selected = g.label in selected,
                        modifier = Modifier.weight(1f),
                    ) {
                        if (g.label in selected) selected.remove(g.label) else selected.add(g.label)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(12.dp))
        PillButton(
            if (selected.isEmpty()) "Pilih minimal satu" else "Simpan (${selected.size} dipilih)",
            { if (selected.isNotEmpty()) onSave(selected.toList()) },
            Modifier.fillMaxWidth(),
            container = if (selected.isEmpty()) AlterColors.Surface3 else AlterColors.Red,
        )
    }
}

@Composable
private fun GenreTile(g: GenreChoice, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Color(g.color) else Color(g.color).copy(alpha = 0.32f), label = "genreBg")
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.04f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "genreScale",
    )
    Box(
        modifier
            .height(54.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .bounceClick(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selected) {
                Ic(R.drawable.ic_check, tint = Color.White, size = 16.dp)
                Spacer(Modifier.width(4.dp))
            }
            Text(
                g.label,
                style = T.small.copy(fontWeight = FontWeight.Bold),
                color = Color.White,
                maxLines = 1,
            )
        }
    }
}
