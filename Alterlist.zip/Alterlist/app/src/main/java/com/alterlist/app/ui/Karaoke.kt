package com.alterlist.app.ui

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp
import com.alterlist.app.data.LyricLine

/** Satu kata lirik dengan jendela waktunya. [text] sudah termasuk spasi di belakang kata. */
class KWord(val text: String, val startMs: Long, val endMs: Long)

private val TOKEN = Regex("""\S+\s*""")

/**
 * Susun waktu per kata untuk satu baris lirik. Bila sumbernya memuat waktu kata (LRC enhanced) dipakai apa adanya.
 * Bila tidak (LRCLIB hanya punya waktu per baris), waktu diperkirakan: durasi nyanyi baris dibagi ke tiap kata
 * menurut panjang hurufnya, dibatasi supaya tidak melar saat ada jeda instrumen sebelum baris berikutnya.
 */
fun karaokeWords(line: LyricLine, nextStartMs: Long?): List<KWord> {
    val lineEnd = nextStartMs ?: (line.timeMs + 5000L)
    val real = line.words
    if (real != null && real.size >= 2) {
        return real.mapIndexed { i, w ->
            val end = if (i + 1 < real.size) real[i + 1].startMs else lineEnd.coerceAtLeast(w.startMs + 300L)
            KWord(w.text, w.startMs, end)
        }
    }
    val tokens = TOKEN.findAll(line.text).map { it.value }.toList()
    if (tokens.isEmpty()) return emptyList()
    val gap = (lineEnd - line.timeMs).coerceAtLeast(600L)
    val chars = tokens.sumOf { it.trim().length.coerceAtLeast(1) }
    val sung = minOf((gap * 0.92).toLong(), maxOf(900L, chars * 85L))
    var acc = 0
    return tokens.map { tk ->
        val start = line.timeMs + sung * acc / chars
        acc += tk.trim().length.coerceAtLeast(1)
        val end = line.timeMs + sung * acc / chars
        KWord(tk, start, end)
    }
}

/**
 * Posisi putar yang mulus untuk lirik. Posisi dari pemutar hanya datang tiap ~0,4 dtk, terlalu kasar untuk
 * menyorot kata, jadi di antara laporan waktu dimajukan sendiri tiap frame (dikali kecepatan putar). Laporan baru
 * hanya menimpa bila posisinya maju atau melompat jauh (seek), supaya sorotan tidak mundur-mundur.
 */
@Composable
fun rememberPlayhead(key: Any, positionMs: Long, playing: Boolean, speed: Float): FloatState {
    val head = remember(key) { mutableFloatStateOf(positionMs.toFloat()) }
    LaunchedEffect(key, positionMs) {
        val diff = positionMs - head.floatValue
        if (diff > 0f || diff < -700f) head.floatValue = positionMs.toFloat()
    }
    LaunchedEffect(key, playing, speed) {
        if (!playing) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            head.floatValue += (now - last) / 1_000_000f * speed
            last = now
        }
    }
    return head
}

/**
 * Baris lirik yang sedang dinyanyikan: tiap kata menyala dari redup ke putih sesuai waktunya, kata yang sudah
 * lewat putih penuh, kata berikutnya masih redup. [now] dibaca di sini, jadi hanya baris ini yang menggambar ulang.
 */
@Composable
fun KaraokeText(words: List<KWord>, now: () -> Long, modifier: Modifier = Modifier) {
    val t = now()
    val dim = Color.White.copy(alpha = 0.42f)
    val text =
        buildAnnotatedString {
            for (w in words) {
                val p =
                    when {
                        t >= w.endMs -> 1f
                        t <= w.startMs -> 0f
                        else -> (t - w.startMs).toFloat() / (w.endMs - w.startMs).coerceAtLeast(1L).toFloat()
                    }
                withStyle(SpanStyle(color = lerp(dim, Color.White, p))) { append(w.text) }
            }
        }
    Text(text, modifier = modifier, style = T.hero.copy(fontSize = 25.sp, lineHeight = 30.sp))
}
