package com.alterlist.app.fx

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.tanh

/** Penunda sampel (buffer melingkar) dengan pembacaan pecahan untuk jeda antar-telinga (ITD) dan pantulan awal ruang. */
class DelayLine(size: Int) {
    private val buf = FloatArray(if (size < 2) 2 else size)
    private var w = 0

    fun write(x: Float) {
        buf[w] = x
        w++
        if (w >= buf.size) w = 0
    }

    /** [delay] dalam sampel, relatif terhadap sampel terakhir yang ditulis. */
    fun read(delay: Float): Float {
        val d = delay.coerceIn(0f, (buf.size - 2).toFloat())
        var pos = w - 1 - d
        while (pos < 0f) pos += buf.size
        var i0 = pos.toInt()
        if (i0 >= buf.size) i0 -= buf.size
        val frac = pos - i0
        val i1 = if (i0 + 1 >= buf.size) 0 else i0 + 1
        return buf[i0] * (1f - frac) + buf[i1] * frac
    }

    fun clear() {
        buf.fill(0f)
        w = 0
    }
}

/** Low-pass satu kutub. */
class OnePole {
    private var y = 0f

    fun lowpass(x: Float, a: Float): Float {
        y += a * (x - y)
        if (abs(y) < 1e-15f) y = 0f
        return y
    }

    fun clear() {
        y = 0f
    }
}

object Dsp {
    /** Koefisien low-pass satu kutub untuk frekuensi potong [fc] Hz. Cukup akurat untuk fc jauh di bawah fs/2. */
    fun lpCoef(fc: Float, sampleRate: Int): Float = (6.2831853f * fc / sampleRate).coerceIn(0.0005f, 1f)

    /** Koefisien penghalusan per sampel untuk konstanta waktu [seconds]. */
    fun smoothCoef(seconds: Float, sampleRate: Int): Float = (1.0 - exp(-1.0 / (seconds * sampleRate))).toFloat()

    fun softLimit(x: Float): Float {
        val ax = abs(x)
        if (ax <= KNEE) return x
        val over = tanh((ax - KNEE) / (1f - KNEE)) * (1f - KNEE)
        val y = KNEE + over
        return if (x < 0f) -y else y
    }

    const val TWO_PI = (2.0 * PI)
    private const val KNEE = 0.88f
}
