package com.alterlist.app.playback

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.ContentMetadata
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.Extractor
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.mkv.MatroskaExtractor
import androidx.media3.extractor.mp4.FragmentedMp4Extractor
import androidx.media3.extractor.mp3.Mp3Extractor
import androidx.media3.extractor.mp4.Mp4Extractor
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.alterlist.app.AlterApp
import com.alterlist.app.MainActivity
import com.alterlist.app.R
import com.alterlist.app.data.SC_PREFIX
import com.alterlist.app.data.SoundCloud
import com.alterlist.app.data.YtMusic
import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.EqualizerFx
import com.alterlist.app.fx.ReverbAudioProcessor
import com.alterlist.app.fx.SpatialAudioProcessor
import com.alterlist.app.fx.WaveTap
import com.metrolist.innertubex.extraction.StreamResolveException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.IOException

/**
 * Layanan pemutar: ExoPlayer + MediaSession (notifikasi, layar kunci, Bluetooth).
 * URL audio YouTube di-resolve lazy tepat sebelum diunduh lewat [ResolvingDataSource]; lagu yang sudah diunduh
 * dimainkan langsung dari berkas lokal. Efek reverb dipasang sebagai AudioProcessor, efek slowed lewat PlaybackParameters.
 */
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var cache: SimpleCache? = null
    private val retried = HashSet<String>()

    // lagu SoundCloud HLS yang alamatnya sudah pernah diperbarui sekali pada lagu yang sedang diputar
    private val hlsRefreshed = HashSet<String>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var fade: FadeController? = null

    override fun onCreate() {
        super.onCreate()
        AudioFx.init(this)
        EqualizerFx.init(this)
        val alterApp = application as AlterApp
        val yt = alterApp.yt

        val simpleCache =
            SimpleCache(
                File(cacheDir, "audio"),
                LeastRecentlyUsedCacheEvictor(CACHE_BYTES),
                StandaloneDatabaseProvider(this),
            )
        cache = simpleCache

        val httpFactory =
            DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(20_000)

        val cacheFactory =
            CacheDataSource.Factory()
                .setCache(simpleCache)
                .setUpstreamDataSourceFactory(httpFactory)
                .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        val resolvingFactory = ResolvingDataSource.Factory(cacheFactory) { dataSpec -> resolve(yt, alterApp.soundcloud, simpleCache, dataSpec) }
        // file:// (lagu unduhan) langsung dibaca dari disk; http(s) lewat resolver + cache
        val dataSourceFactory: DataSource.Factory = DefaultDataSource.Factory(this, resolvingFactory)

        // Stream YouTube: daftar extractor ringkas. Berkas lokal / unduhan (file://, content://): semua format
        // yang dikenal ExoPlayer (MP3, FLAC, WAV, OGG/Opus, AAC, AMR, M4A, MKA, ...), seek tetap jalan di MP3 tanpa tabel seek.
        // Mp3Extractor untuk stream progresif SoundCloud (MP3); yang lain untuk stream YouTube.
        val streamExtractors =
            ExtractorsFactory {
                arrayOf(
                    MatroskaExtractor(),
                    FragmentedMp4Extractor(),
                    Mp4Extractor(),
                    Mp3Extractor(Mp3Extractor.FLAG_ENABLE_CONSTANT_BITRATE_SEEKING),
                )
            }
        val fileExtractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val extractorsFactory =
            object : ExtractorsFactory {
                override fun createExtractors(): Array<Extractor> = streamExtractors.createExtractors()

                override fun createExtractors(uri: Uri, responseHeaders: Map<String, List<String>>): Array<Extractor> {
                    val scheme = uri.scheme
                    return if (scheme == "http" || scheme == "https") {
                        streamExtractors.createExtractors(uri, responseHeaders)
                    } else {
                        fileExtractors.createExtractors(uri, responseHeaders)
                    }
                }
            }

        val spatial = SpatialAudioProcessor()
        val reverb = ReverbAudioProcessor()
        val renderersFactory =
            object : DefaultRenderersFactory(this) {
                override fun buildAudioSink(
                    context: Context,
                    enableFloatOutput: Boolean,
                    enableAudioOutputPlaybackParams: Boolean,
                ): AudioSink? =
                    DefaultAudioSink.Builder(context)
                        .setEnableFloatOutput(enableFloatOutput)
                        .setEnableAudioOutputPlaybackParameters(enableAudioOutputPlaybackParams)
                        // TeeAudioProcessor di ujung: menyadap suara akhir untuk visualizer Wave Candy (WaveTap)
                        .setAudioProcessors(arrayOf<AudioProcessor>(spatial, reverb, TeeAudioProcessor(WaveTap)))
                        .build()
            }

        // Lagu SoundCloud yang hanya punya stream HLS: resolver melempar ScHlsRequired, dan kesalahan itu TIDAK diulang
        // (percobaan ulang bawaan memakan beberapa detik) supaya langsung dialihkan ke sumber HLS di onPlayerError.
        val loadPolicy =
            object : DefaultLoadErrorHandlingPolicy() {
                override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long =
                    if (loadErrorInfo.exception is ScHlsRequired) C.TIME_UNSET else super.getRetryDelayMsFor(loadErrorInfo)
            }

        val player =
            ExoPlayer.Builder(this, renderersFactory)
                .setMediaSourceFactory(
                    DefaultMediaSourceFactory(dataSourceFactory, extractorsFactory).setLoadErrorHandlingPolicy(loadPolicy),
                )
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    true,
                )
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()

        // Kecepatan + nada. Bawaan gaya kaset (nada ikut kecepatan, halus). Kalau "Nada ikut kecepatan" dimatikan
        // atau geser semiton dipakai, nada diatur sendiri dan kecepatan hanya mengubah tempo (time-stretch Sonic).
        scope.launch {
            AudioFx.state.map { it.speed to it.playbackPitch }.distinctUntilChanged().collect { (speed, pitch) ->
                player.playbackParameters = PlaybackParameters(speed, pitch)
            }
        }

        // Equalizer / bass / virtualizer dipasang pada sesi audio pemutar
        EqualizerFx.attach(player.audioSessionId)

        // Fade antar lagu + lewati keheningan (diatur dari Pengaturan)
        fade = FadeController(player, alterApp.settings, scope).also { it.start() }
        scope.launch {
            alterApp.settings.state.map { it.skipSilence }.distinctUntilChanged().collect { on ->
                player.setSkipSilenceEnabled(on)
            }
        }

        player.addListener(
            object : Player.Listener {
                override fun onAudioSessionIdChanged(audioSessionId: Int) {
                    EqualizerFx.attach(audioSessionId)
                }

                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    retried.clear()
                    // mengganti item aktif ke HLS juga memicu transisi (PLAYLIST_CHANGED): jangan hitung sebagai lagu baru
                    if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) hlsRefreshed.clear()
                }

                override fun onPlayerError(error: PlaybackException) {
                    val item = player.currentMediaItem
                    val id = item?.mediaId
                    val scheme = item?.localConfiguration?.uri?.scheme
                    val local = scheme == "file" || scheme == "content"
                    // lagu SoundCloud HLS: ganti item ke alamat playlist HLS (butuh modul HLS ExoPlayer)
                    if (!local && item != null && id != null && id.startsWith(SC_PREFIX) && handleSoundCloudHls(player, item, id)) return
                    if (!local && id != null && retried.add(id)) {
                        // URL kemungkinan kedaluwarsa / ditolak: buang cache URL lalu coba sekali lagi.
                        yt.invalidateStream(id)
                        alterApp.soundcloud.invalidate(id)
                        player.prepare()
                    } else if (player.hasNextMediaItem()) {
                        player.seekToNextMediaItem()
                        player.prepare()
                        player.play()
                    }
                }
            },
        )

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_alterlist) },
        )

        val sessionActivity =
            PendingIntent.getActivity(
                this,
                0,
                Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )

        mediaSession =
            MediaSession.Builder(this, player)
                .setSessionActivity(sessionActivity)
                .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        fade?.stop()
        EqualizerFx.release()
        scope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        cache?.release()
        cache = null
        super.onDestroy()
    }

    private fun resolve(yt: YtMusic, sc: SoundCloud, cache: SimpleCache, dataSpec: DataSpec): DataSpec {
        val id = dataSpec.key ?: return dataSpec

        // Kalau bagian yang diminta sudah ada di cache disk, tidak perlu resolve URL (hemat kuota & bisa offline).
        val knownLength = ContentMetadata.getContentLength(cache.getContentMetadata(id))
        val requiredLength =
            when {
                dataSpec.length >= 0 -> dataSpec.length
                knownLength > 0 -> (knownLength - dataSpec.position).coerceAtLeast(1L)
                else -> PROBE_LENGTH
            }
        if (cache.isCached(id, dataSpec.position, requiredLength)) return dataSpec

        // Lagu SoundCloud (NewPipeExtractor): MP3 progresif dipakai langsung (seek lewat Range, tanpa potongan chunk).
        // Alamat halaman lagu ada di uri MediaItem sebagai petunjuk.
        if (id.startsWith(SC_PREFIX)) {
            val stream =
                try {
                    runBlocking(Dispatchers.IO) { sc.resolve(id, dataSpec.uri.toString()) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    throw IOException(describe(e), e)
                }
            // hanya HLS: extractor progresif tidak bisa membacanya, alihkan lewat onPlayerError
            if (stream.hls) throw ScHlsRequired()
            return dataSpec.withUri(Uri.parse(stream.url))
        }

        val stream =
            try {
                runBlocking(Dispatchers.IO) { yt.resolveStream(id) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                throw IOException(describe(e), e)
            }

        var spec = dataSpec.withUri(Uri.parse(stream.url)).withAdditionalHeaders(stream.headers)
        if (stream.bounded && stream.chunkBytes > 0L) {
            val length =
                if (dataSpec.length == C.LENGTH_UNSET.toLong()) {
                    stream.chunkBytes
                } else {
                    minOf(dataSpec.length, stream.chunkBytes)
                }
            spec = spec.subrange(0L, length)
        }
        return spec
    }

    /**
     * Dipanggil saat lagu SoundCloud gagal diputar. Bila lagunya HLS-only, item aktif diganti dengan alamat playlist
     * HLS (mimeType m3u8). Item HLS yang gagal (alamat kedaluwarsa) diperbarui satu kali. True = kesalahan sudah ditangani.
     */
    private fun handleSoundCloudHls(player: Player, item: MediaItem, id: String): Boolean {
        val sc = (application as AlterApp).soundcloud
        val isHlsItem = item.localConfiguration?.mimeType == MimeTypes.APPLICATION_M3U8
        val cached = sc.cachedHls(id)
        if (!isHlsItem && cached != null) {
            applyHls(player, id, cached)
            return true
        }
        if (isHlsItem && hlsRefreshed.add(id)) {
            val page = item.mediaMetadata.extras?.getString("uri")
            scope.launch {
                sc.invalidate(id)
                val fresh = runCatching { sc.resolve(id, page) }.getOrNull()
                if (fresh != null && fresh.hls && player.currentMediaItem?.mediaId == id) {
                    applyHls(player, id, fresh.url)
                } else if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem()
                    player.prepare()
                    player.play()
                }
            }
            return true
        }
        return false
    }

    private fun applyHls(player: Player, id: String, url: String) {
        val current = player.currentMediaItem ?: return
        if (current.mediaId != id) return
        val hlsItem =
            current.buildUpon()
                .setUri(url)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .setCustomCacheKey(null)
                .build()
        player.replaceMediaItem(player.currentMediaItemIndex, hlsItem)
        player.prepare()
    }

    /** Penanda internal: lagu ini hanya punya stream HLS. Tidak boleh diulang oleh kebijakan percobaan ulang. */
    private class ScHlsRequired : IOException("Stream SoundCloud berupa HLS")

    private fun describe(e: Exception): String =
        when {
            e is StreamResolveException && e.reason == StreamResolveException.Reason.NETWORK ->
                "Tidak ada koneksi internet"
            e is StreamResolveException && e.reason == StreamResolveException.Reason.AGE_RESTRICTED ->
                "Konten dibatasi usia"
            e is StreamResolveException && e.reason == StreamResolveException.Reason.UNAVAILABLE ->
                "Lagu tidak tersedia"
            e is java.net.UnknownHostException || e is java.net.ConnectException ->
                "Tidak ada koneksi internet"
            else -> e.message ?: "Gagal mengambil stream audio"
        }

    private companion object {
        const val CACHE_BYTES = 512L * 1024L * 1024L
        const val PROBE_LENGTH = 512L * 1024L
    }
}
