package com.alterlist.app.island

import android.app.Activity
import android.app.Application
import android.content.ComponentCallbacks
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.alterlist.app.AlterApp
import com.alterlist.app.data.DynamicBarShape
import com.alterlist.app.system.PermissionHelper
import com.alterlist.app.ui.AlterTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.transformLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Dynamic bar musik: jendela overlay kecil di sekitar kamera depan (menyatu dengan waterdrop, atau melingkari tompel).
 *
 * Jendela hanya sebesar pilnya saat diciutkan (supaya tidak menghalangi sentuhan ke aplikasi lain), dan membesar
 * selama kartu terbuka. Perpindahan ukuran jendela dikerjakan di pesan main-thread yang sama dengan perubahan state
 * Compose, jadi keduanya jatuh di frame yang sama.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class DynamicBarController(private val app: AlterApp) {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val wm: WindowManager = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private var root: OverlayRoot? = null
    private var composeView: ComposeView? = null
    private var owner: OverlayLifecycleOwner? = null
    private var params: WindowManager.LayoutParams? = null

    private var geometry: BarGeometry? = null
    private var shapeSetting: String = DynamicBarShape.AUTO
    private var startedActivities = 0

    private val _layout = MutableStateFlow<BarLayout?>(null)
    val layout: StateFlow<BarLayout?> = _layout.asStateFlow()

    /** Pengguna meminta kartu terbuka (ketuk pil). */
    private val _expanded = MutableStateFlow(false)
    val expanded: StateFlow<Boolean> = _expanded.asStateFlow()

    /** Bingkai jendela sedang dalam ukuran "kartu terbuka" (tetap true sampai animasi menciut selesai). */
    private val _windowExpanded = MutableStateFlow(false)
    val windowExpanded: StateFlow<Boolean> = _windowExpanded.asStateFlow()

    private val appVisible = MutableStateFlow(false)
    private val envTick = MutableStateFlow(0)

    private val fallbackGeometry = Runnable {
        if (geometry == null && root != null) {
            val (w, h) = screenSize()
            geometry = BarGeometry(w, h, false, 0, 0, 0, 0)
            recompute()
        }
    }

    fun start() {
        app.registerActivityLifecycleCallbacks(
            object : Application.ActivityLifecycleCallbacks {
                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

                override fun onActivityStarted(activity: Activity) {
                    startedActivities++
                    appVisible.value = true
                }

                override fun onActivityResumed(activity: Activity) {
                    // pengguna mungkin baru saja memberi / mencabut izin overlay
                    envTick.update { it + 1 }
                }

                override fun onActivityPaused(activity: Activity) {}

                override fun onActivityStopped(activity: Activity) {
                    startedActivities = (startedActivities - 1).coerceAtLeast(0)
                    appVisible.value = startedActivities > 0
                }

                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

                override fun onActivityDestroyed(activity: Activity) {}
            },
        )
        app.registerComponentCallbacks(
            object : ComponentCallbacks {
                override fun onConfigurationChanged(newConfig: Configuration) {
                    // rotasi / ukuran layar berubah: baca ulang kamera dari awal
                    geometry = null
                    _layout.value = null
                    hide()
                    envTick.update { it + 1 }
                }

                override fun onLowMemory() {}
            },
        )

        scope.launch {
            app.settings.state.map { it.dynamicBarShape }.distinctUntilChanged().collect {
                shapeSetting = it
                recompute()
            }
        }

        val enabled = app.settings.state.map { it.dynamicBar }.distinctUntilChanged()
        val hasSong = app.player.state.map { it.current != null }.distinctUntilChanged()
        // saat musik dijeda, bar tetap muncul sebentar supaya bisa dilanjutkan, lalu menghilang
        var hadPlayed = false
        val playingGrace =
            app.player.state
                .map { it.isPlaying || it.isBuffering }
                .distinctUntilChanged()
                .transformLatest { playing ->
                    if (playing) {
                        hadPlayed = true
                        emit(true)
                    } else if (hadPlayed) {
                        emit(true)
                        delay(PAUSE_GRACE_MS)
                        emit(false)
                    } else {
                        emit(false)
                    }
                }
        val base =
            combine(enabled, hasSong, appVisible, envTick) { on, song, visible, _ ->
                on && song && !visible && isPortrait() && PermissionHelper.canDrawOverlays(app)
            }
        scope.launch {
            combine(base, playingGrace, _expanded) { b, grace, exp -> b && (grace || exp) }
                .collect { shouldShow -> if (shouldShow) show() else hide() }
        }
    }

    // ---------------------------------------------------------------- aksi dari UI

    fun setExpanded(on: Boolean) {
        _expanded.value = on
    }

    /** Dipanggil UI tepat sebelum animasi membuka (true) / setelah animasi menutup selesai (false). */
    fun setWindowExpanded(on: Boolean) {
        if (_windowExpanded.value == on) return
        _windowExpanded.value = on
        applyFrame()
    }

    // ---------------------------------------------------------------- jendela

    private fun isPortrait(): Boolean = app.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    private fun show() {
        if (root != null) return
        val lifecycleOwner = OverlayLifecycleOwner().also { it.start() }
        val r = OverlayRoot(app)
        r.onInsets = { insets -> onInsets(insets, r) }
        r.onOutside = { setExpanded(false) }
        r.onBackgroundTap = { if (_expanded.value) setExpanded(false) }
        val cv =
            ComposeView(app).apply {
                setContent { AlterTheme { DynamicBarRoot(this@DynamicBarController) } }
            }
        r.addView(cv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        r.setViewTreeLifecycleOwner(lifecycleOwner)
        r.setViewTreeSavedStateRegistryOwner(lifecycleOwner)
        r.setViewTreeViewModelStoreOwner(lifecycleOwner)

        val lp = baseParams()
        root = r
        composeView = cv
        owner = lifecycleOwner
        params = lp
        try {
            wm.addView(r, lp)
        } catch (e: Exception) {
            // izin dicabut tepat sebelum ditambahkan, atau sistem menolak
            teardown()
            return
        }
        if (geometry == null) main.postDelayed(fallbackGeometry, 800L)
    }

    private fun hide() {
        if (root == null) return
        teardown()
    }

    private fun teardown() {
        main.removeCallbacks(fallbackGeometry)
        val r = root
        if (r != null) {
            composeView?.disposeComposition()
            runCatching { wm.removeViewImmediate(r) }
        }
        owner?.destroy()
        root = null
        composeView = null
        owner = null
        params = null
        _expanded.value = false
        _windowExpanded.value = false
    }

    /** Bingkai awal: kalau kamera sudah diketahui langsung seukuran pil; kalau belum, jendela sonde yang tak terlihat. */
    private fun baseParams(): WindowManager.LayoutParams {
        val l = _layout.value
        val lp =
            WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (120f * app.resources.displayMetrics.density).roundToInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                TOUCHABLE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT,
            )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = 0
        lp.alpha = 0f
        lp.title = "AlterlistDynamicBar"
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (l != null) fillFrame(lp, l)
        return lp
    }

    private fun fillFrame(lp: WindowManager.LayoutParams, l: BarLayout) {
        if (_windowExpanded.value) {
            lp.x = 0
            lp.y = 0
            lp.width = l.screenWidth
            lp.height = l.expandedWindowHeight
        } else {
            lp.x = l.collapsed.left.roundToInt()
            lp.y = l.collapsed.top.roundToInt()
            lp.width = l.collapsed.width.roundToInt()
            lp.height = l.collapsed.height.roundToInt()
        }
        lp.flags = TOUCHABLE_FLAGS
        lp.alpha = 1f
    }

    private fun applyFrame() {
        val r = root ?: return
        val lp = params ?: return
        val l = _layout.value ?: return
        fillFrame(lp, l)
        runCatching { wm.updateViewLayout(r, lp) }
    }

    private fun recompute() {
        val g = geometry ?: return
        _layout.value = computeLayout(g, shapeSetting, app.resources.displayMetrics.density)
        applyFrame()
    }

    // ---------------------------------------------------------------- baca kamera

    private fun onInsets(insets: WindowInsets, view: View) {
        if (geometry != null) return
        main.removeCallbacks(fallbackGeometry)
        geometry = readGeometry(insets, view)
        recompute()
    }

    private fun readGeometry(insets: WindowInsets, view: View): BarGeometry {
        val (sw, sh) = screenSize()
        var rect: Rect? = null
        val cut = insets.displayCutout
        if (cut != null) {
            val top = cut.boundingRectTop
            rect =
                if (!top.isEmpty()) {
                    top
                } else {
                    cut.boundingRects.firstOrNull { !it.isEmpty() && it.top < sh / 5 }
                }
        }
        if (rect == null && Build.VERSION.SDK_INT >= 31) {
            val top = view.display?.cutout?.boundingRectTop
            if (top != null && !top.isEmpty()) rect = top
        }
        return if (rect != null) {
            BarGeometry(sw, sh, true, rect.left, rect.top, rect.right, rect.bottom)
        } else {
            BarGeometry(sw, sh, false, 0, 0, 0, 0)
        }
    }

    /** Ukuran layar dalam posisi potret (lebar = sisi pendek). */
    private fun screenSize(): Pair<Int, Int> {
        val w: Int
        val h: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            w = b.width()
            h = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            w = m.widthPixels
            h = m.heightPixels
        }
        return min(w, h) to max(w, h)
    }

    private companion object {
        const val PAUSE_GRACE_MS = 6_000L

        /** Tidak mengambil fokus (keyboard tetap milik aplikasi di bawah), boleh melewati batas layar, dan memberi tahu saat ada sentuhan di luar. */
        const val TOUCHABLE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
    }
}

/** Akar jendela overlay: meneruskan insets (untuk membaca kamera) dan sentuhan di luar kartu. */
private class OverlayRoot(context: Context) : FrameLayout(context) {
    var onInsets: ((WindowInsets) -> Unit)? = null
    var onOutside: (() -> Unit)? = null
    var onBackgroundTap: (() -> Unit)? = null

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        onInsets?.invoke(insets)
        return super.onApplyWindowInsets(insets)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
            onOutside?.invoke()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // area transparan di samping kartu yang terbuka: ketuk = tutup
        if (event.actionMasked == MotionEvent.ACTION_DOWN) {
            onBackgroundTap?.invoke()
            return true
        }
        return super.onTouchEvent(event)
    }
}

/** Compose di luar Activity membutuhkan pemilik lifecycle, saved state, dan view model sendiri. */
private class OverlayLifecycleOwner : SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    init {
        savedStateController.performRestore(null)
    }

    fun start() {
        registry.currentState = Lifecycle.State.CREATED
        registry.currentState = Lifecycle.State.STARTED
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}
