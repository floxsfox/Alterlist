package com.alterlist.app.island

import com.alterlist.app.data.DynamicBarShape
import kotlin.math.max
import kotlin.math.min

/** Hasil baca kamera depan dari sistem (semua dalam piksel, koordinat layar). */
data class BarGeometry(
    val screenWidth: Int,
    val screenHeight: Int,
    val hasCutout: Boolean,
    val cutLeft: Int,
    val cutTop: Int,
    val cutRight: Int,
    val cutBottom: Int,
)

/** Persegi dalam piksel layar. */
data class PxBox(val left: Float, val top: Float, val width: Float, val height: Float)

/** Isi pil saat diciutkan: cover di satu sisi kamera, visualizer di sisi lain (atau keduanya di satu sisi bila kamera dekat tepi). */
enum class ZonePlan { BOTH, LEFT_ONLY, RIGHT_ONLY }

/**
 * Ukuran dan posisi dynamic bar. Dua versi bentuk:
 * - **Waterdrop** ([isDrop] = true): pil menempel di tepi atas layar, sudut atasnya melebar ("telinga" [ear]) seperti tetesan air.
 * - **Tompel** ([isDrop] = false): pil melayang mengelilingi lubang kamera, tidak menyentuh tepi layar.
 */
data class BarLayout(
    val isDrop: Boolean,
    val screenWidth: Int,
    val collapsed: PxBox,
    val expanded: PxBox,
    val ear: Float,
    val leftZone: Float,
    val gap: Float,
    val rightZone: Float,
    val plan: ZonePlan,
    /** Jarak dari tepi atas kartu yang membesar ke isi kartu (supaya isi tidak tertimpa kamera). */
    val expandedContentTop: Float,
    val density: Float,
) {
    /** Tinggi jendela overlay saat kartu membesar (plus cadangan 12dp untuk efek membal saat membuka). */
    val expandedWindowHeight: Int get() = (expanded.top + expanded.height + 12f * density).toInt()
}

/**
 * Tinggi kartu yang membesar (dp), sama dengan dynamic bar resmi: padding 16 + cover 58 + 4 + progres 25 + 3 +
 * tombol 44 + padding bawah 12 = 162. Kartu selebar layar dan mulai dari tepi atas (menutup status bar).
 */
internal const val EXPANDED_CARD_DP = 162f

/** Lebar zona kiri (gelombang) dan kanan (cover) pil. Total pil sekitar 146dp seperti dynamic bar resmi. */
private const val LEFT_ZONE_DP = 52f
private const val RIGHT_ZONE_DP = 34f

internal fun computeLayout(g: BarGeometry, shapeSetting: String, d: Float): BarLayout {
    val screenW = g.screenWidth.toFloat()
    val cutW = (g.cutRight - g.cutLeft).toFloat()
    val cutH = (g.cutBottom - g.cutTop).toFloat()

    // Otomatis: kamera yang menyentuh tepi atas dan cukup lebar = waterdrop; selain itu tompel.
    val drop =
        when (shapeSetting) {
            DynamicBarShape.DROP -> true
            DynamicBarShape.HOLE -> false
            else -> g.hasCutout && g.cutTop <= (2f * d) && max(cutW, cutH) >= 22f * d
        }

    // Bila sistem tidak melaporkan kamera (atau pengguna memaksa bentuk lain), pakai kamera tengah perkiraan.
    val useReal = g.hasCutout
    val cutCenterX = if (useReal) (g.cutLeft + g.cutRight) / 2f else screenW / 2f
    val effW = if (useReal) cutW else if (drop) 26f * d else 12f * d
    val effTop = if (useReal) g.cutTop.toFloat() else if (drop) 0f else 8f * d
    val effBottom = if (useReal) g.cutBottom.toFloat() else if (drop) 22f * d else 20f * d

    val gap = effW + (if (drop) 12f * d else 14f * d)
    val ear = if (drop) 12f * d else 0f
    val minZone = 22f * d

    val h =
        if (drop) max(33f * d, effBottom + 5f * d) else 32f * d

    // ruang yang tersedia di kiri / kanan kamera
    val availLeft = cutCenterX - gap / 2f - ear - 3f * d
    val availRight = screenW - cutCenterX - gap / 2f - ear - 3f * d
    var left = min(LEFT_ZONE_DP * d, availLeft)
    var right = min(RIGHT_ZONE_DP * d, availRight)
    var plan = ZonePlan.BOTH
    if (left < minZone) {
        plan = ZonePlan.RIGHT_ONLY
        left = 0f
        right = min(RIGHT_ZONE_DP * d + 40f * d, availRight)
    } else if (right < minZone) {
        plan = ZonePlan.LEFT_ONLY
        right = 0f
        left = min(LEFT_ZONE_DP * d + 28f * d, availLeft)
    }

    val w = ear * 2f + left + gap + right
    val colLeft = cutCenterX - (ear + left + gap / 2f)
    val colTop =
        if (drop) 0f else (((effTop + effBottom) / 2f) - h / 2f).coerceAtLeast(3f * d)
    val collapsed = PxBox(colLeft, colTop, w, h)

    // kartu yang membesar: selebar layar dari tepi atas (menutup status bar, seperti dynamic bar resmi)
    val expanded = PxBox(0f, 0f, screenW, EXPANDED_CARD_DP * d)

    return BarLayout(
        isDrop = drop,
        screenWidth = g.screenWidth,
        collapsed = collapsed,
        expanded = expanded,
        ear = ear,
        leftZone = left,
        gap = gap,
        rightZone = right,
        plan = plan,
        expandedContentTop = 16f * d,
        density = d,
    )
}
