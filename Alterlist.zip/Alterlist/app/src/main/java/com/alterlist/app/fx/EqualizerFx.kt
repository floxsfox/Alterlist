package com.alterlist.app.fx

import android.content.Context
import android.content.SharedPreferences
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.math.ln

data class EqState(
    val enabled: Boolean = false,
    /** Level 5 pita dalam dB (-12..+12). */
    val levels: List<Float> = List(EqualizerFx.BANDS) { 0f },
    val preset: EqPreset? = EqPreset.FLAT,
    /** Penguat bass 0..1. */
    val bass: Float = 0f,
    /** Virtualizer (pelebar suara bawaan Android) 0..1. */
    val virtualizer: Float = 0f,
    /** Penguat volume 0..1 (sampai +9 dB). */
    val loudness: Float = 0f,
)

/**
 * Equalizer, penguat bass, virtualizer, dan penguat volume memakai efek audio bawaan Android yang dipasang pada
 * sesi audio ExoPlayer. Pengaturan tersimpan dan diterapkan ulang otomatis kalau sesi audio berganti.
 */
object EqualizerFx {
    const val BANDS = 5
    const val RANGE_DB = 12f
    val CENTERS = intArrayOf(60, 230, 910, 3600, 14000)

    private val _state = MutableStateFlow(EqState())
    val state: StateFlow<EqState> = _state.asStateFlow()

    private var prefs: SharedPreferences? = null
    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences("alterlist_eq", Context.MODE_PRIVATE)
        prefs = sp
        val levels =
            sp.getString("levels", null)
                ?.split(",")
                ?.mapNotNull { it.toFloatOrNull() }
                ?.takeIf { it.size == BANDS }
                ?.map { it.coerceIn(-RANGE_DB, RANGE_DB) }
                ?: List(BANDS) { 0f }
        val presetName = sp.getString("preset", null)
        _state.value =
            EqState(
                enabled = sp.getBoolean("enabled", false),
                levels = levels,
                preset = EqPreset.entries.firstOrNull { it.name == presetName },
                bass = sp.getFloat("bass", 0f).coerceIn(0f, 1f),
                virtualizer = sp.getFloat("virt", 0f).coerceIn(0f, 1f),
                loudness = sp.getFloat("loud", 0f).coerceIn(0f, 1f),
            )
    }

    // ---------------------------------------------------------------- pengaturan dari UI

    fun setEnabled(on: Boolean) = change { it.copy(enabled = on) }

    fun applyPreset(p: EqPreset) = change { it.copy(levels = p.levels, preset = p, enabled = true) }

    fun setBand(index: Int, db: Float) =
        change { s ->
            val list = s.levels.toMutableList()
            if (index in list.indices) list[index] = db.coerceIn(-RANGE_DB, RANGE_DB)
            s.copy(levels = list, preset = null, enabled = true)
        }

    fun setBass(v: Float) = change { it.copy(bass = v.coerceIn(0f, 1f)) }

    fun setVirtualizer(v: Float) = change { it.copy(virtualizer = v.coerceIn(0f, 1f)) }

    fun setLoudness(v: Float) = change { it.copy(loudness = v.coerceIn(0f, 1f)) }

    fun resetAll() = change { EqState(enabled = false) }

    private fun change(block: (EqState) -> EqState) {
        _state.update(block)
        persist()
        applyEffects()
    }

    private fun persist() {
        val sp = prefs ?: return
        val s = _state.value
        sp.edit()
            .putBoolean("enabled", s.enabled)
            .putString("levels", s.levels.joinToString(","))
            .putString("preset", s.preset?.name)
            .putFloat("bass", s.bass)
            .putFloat("virt", s.virtualizer)
            .putFloat("loud", s.loudness)
            .apply()
    }

    // ---------------------------------------------------------------- efek pada sesi audio

    /** Dipanggil layanan pemutar tiap kali sesi audio ExoPlayer dibuat / berganti. */
    @Synchronized
    fun attach(sessionId: Int) {
        releaseEffects()
        if (sessionId == 0 || sessionId == -1) return
        eq = runCatching { Equalizer(0, sessionId) }.getOrNull()
        bassBoost = runCatching { BassBoost(0, sessionId) }.getOrNull()
        virtualizer = runCatching { Virtualizer(0, sessionId) }.getOrNull()
        loudness = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()
        applyEffects()
    }

    @Synchronized
    fun release() {
        releaseEffects()
    }

    private fun releaseEffects() {
        runCatching { eq?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { loudness?.release() }
        eq = null
        bassBoost = null
        virtualizer = null
        loudness = null
    }

    @Synchronized
    private fun applyEffects() {
        val s = _state.value
        runCatching {
            val e = eq
            if (e != null) {
                val flat = !s.enabled || s.levels.all { it == 0f }
                val range = e.bandLevelRange
                val minMb = range[0].toInt()
                val maxMb = range[1].toInt()
                val n = e.numberOfBands.toInt()
                for (b in 0 until n) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    val db = if (flat) 0f else interpolate(s.levels, hz)
                    val mb = (db * 100f).toInt().coerceIn(minMb, maxMb)
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
                e.setEnabled(s.enabled)
            }
        }
        runCatching {
            val b = bassBoost
            if (b != null && b.strengthSupported) {
                b.setStrength((s.bass * 1000f).toInt().coerceIn(0, 1000).toShort())
                b.setEnabled(s.bass > 0.01f)
            }
        }
        runCatching {
            val v = virtualizer
            if (v != null && v.strengthSupported) {
                v.setStrength((s.virtualizer * 1000f).toInt().coerceIn(0, 1000).toShort())
                v.setEnabled(s.virtualizer > 0.01f)
            }
        }
        runCatching {
            val l = loudness
            if (l != null) {
                l.setTargetGain((s.loudness * 900f).toInt())
                l.setEnabled(s.loudness > 0.01f)
            }
        }
    }

    /** Interpolasi level antar pita pada skala logaritmik frekuensi. */
    private fun interpolate(levels: List<Float>, hz: Float): Float {
        val x = ln(hz.coerceAtLeast(20f))
        val pts = CENTERS.map { ln(it.toFloat()) }
        if (x <= pts.first()) return levels.first()
        if (x >= pts.last()) return levels.last()
        for (i in 0 until pts.size - 1) {
            if (x <= pts[i + 1]) {
                val t = (x - pts[i]) / (pts[i + 1] - pts[i])
                return levels[i] + (levels[i + 1] - levels[i]) * t
            }
        }
        return 0f
    }
}
