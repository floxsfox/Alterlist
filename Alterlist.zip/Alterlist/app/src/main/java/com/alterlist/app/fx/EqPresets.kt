package com.alterlist.app.fx

/**
 * Preset equalizer 5 pita (60 Hz, 230 Hz, 910 Hz, 3,6 kHz, 14 kHz) dalam dB.
 * Nilainya dipetakan ke jumlah pita yang dimiliki HP, jadi bekerja di semua perangkat.
 */
enum class EqPreset(val label: String, val levels: List<Float>) {
    FLAT("Datar", listOf(0f, 0f, 0f, 0f, 0f)),
    BASS("Bass Booster", listOf(6f, 4f, 0.5f, 0f, 0f)),
    BASS_TREBLE("Bass + Treble", listOf(5f, 2f, -1f, 2.5f, 5f)),
    VOCAL("Vokal Jernih", listOf(-2f, -1f, 3f, 4f, 1f)),
    TREBLE("Treble", listOf(-1f, 0f, 1f, 4f, 6f)),
    POP("Pop", listOf(-1f, 2f, 4f, 2f, -1f)),
    ROCK("Rock", listOf(5f, 3f, -1f, 3f, 4f)),
    HIPHOP("Hip-hop", listOf(5f, 4f, 0f, 1.5f, 2f)),
    ELECTRONIC("Elektronik", listOf(5f, 2f, 0f, 2.5f, 4.5f)),
    JAZZ("Jazz", listOf(3f, 1.5f, -1.5f, 1.5f, 3.5f)),
    CLASSICAL("Klasik", listOf(4f, 2f, -1f, 2f, 3f)),
    ACOUSTIC("Akustik", listOf(3.5f, 2.5f, 1f, 2f, 2.5f)),
    LOUNGE("Lounge", listOf(-2f, 1f, 3f, 1f, -1f)),
    LATE_NIGHT("Malam Hari", listOf(3f, 1f, 0f, -1.5f, -3f)),
}
