package com.alterlist.app.system

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import com.alterlist.app.data.AppSettingsState
import com.alterlist.app.data.GameDetect
import java.util.concurrent.ConcurrentHashMap

/** Satu aplikasi yang bisa dipilih sebagai game di Pengaturan. */
data class GameApp(val label: String, val pkg: String, val isGame: Boolean)

/**
 * Mengenali apakah aplikasi yang sedang di depan adalah game.
 *
 * Android tidak punya API publik untuk membaca "mode game" bawaan tiap merek (vivo iBoost, Samsung Game Launcher,
 * Xiaomi Game Turbo, dst.), jadi pengenalan memakai cara yang sama untuk semua ponsel:
 *  1. kategori aplikasi dari sistem (CATEGORY_GAME / FLAG_IS_GAME) - dipasang oleh Play Store dan sebagian besar installer,
 *  2. daftar paket game populer (cadangan untuk game yang dipasang dari APK),
 *  3. game yang dipilih sendiri di Pengaturan.
 */
object GameDetector {
    private val KNOWN_GAMES =
        setOf(
            "com.dts.freefireth", "com.dts.freefiremax", "com.mobile.legends", "com.tencent.ig", "com.pubg.imobile",
            "com.vng.pubgmobile", "com.activision.callofduty.shooter", "com.garena.game.codm", "com.miHoYo.GenshinImpact",
            "com.HoYoverse.hkrpgoversea", "com.HoYoverse.Nap", "com.kurogame.wutheringwaves.global", "com.roblox.client",
            "com.mojang.minecraftpe", "com.supercell.clashofclans", "com.supercell.clashroyale", "com.supercell.brawlstars",
            "com.innersloth.spacemafia", "com.riotgames.league.wildrift", "com.netease.newspike", "com.kitkagames.fallbuddies",
            "com.kiloo.subwaysurf", "com.levelinfinite.sgameGlobal", "jp.konami.pesam",
        )

    private val autoCache = ConcurrentHashMap<String, Boolean>()

    fun hasOverlayPermission(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** Izin "Akses penggunaan aplikasi" - dipakai untuk tahu aplikasi mana yang sedang di depan. */
    fun hasUsageAccess(context: Context): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Game menurut kategori sistem atau daftar paket populer. */
    @Suppress("DEPRECATION")
    fun isAutoGame(context: Context, pkg: String): Boolean =
        autoCache.getOrPut(pkg) {
            if (pkg in KNOWN_GAMES) {
                true
            } else {
                val info = runCatching { context.packageManager.getApplicationInfo(pkg, 0) }.getOrNull()
                info != null &&
                    (info.category == ApplicationInfo.CATEGORY_GAME || (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
            }
        }

    /** Haruskah pemicu panel tampil untuk aplikasi di depan [pkg]? */
    fun shouldShow(context: Context, pkg: String?, st: AppSettingsState): Boolean {
        if (pkg == null || pkg == context.packageName) return false
        return when (st.gameDetect) {
            GameDetect.ALWAYS -> true
            GameDetect.MANUAL -> pkg in st.gameApps
            else -> pkg in st.gameApps || isAutoGame(context, pkg)
        }
    }

    /** Semua aplikasi berikon peluncur, game di urutan atas. Untuk dialog pilih game manual. */
    @Suppress("DEPRECATION")
    fun launchableApps(context: Context): List<GameApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found =
            if (Build.VERSION.SDK_INT >= 33) {
                pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
            } else {
                pm.queryIntentActivities(intent, 0)
            }
        return found
            .mapNotNull { ri ->
                val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) null else GameApp(ri.loadLabel(pm).toString(), pkg, isAutoGame(context, pkg))
            }
            .distinctBy { it.pkg }
            .sortedWith(compareByDescending<GameApp> { it.isGame }.thenBy { it.label.lowercase() })
    }
}

/** Melacak aplikasi yang sedang di depan lewat UsageStatsManager (butuh izin Akses penggunaan). */
class ForegroundTracker(context: Context) {
    private val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private var lastQuery = 0L

    /** Paket aplikasi di depan terakhir yang diketahui; null kalau belum ada data. */
    var current: String? = null
        private set

    fun poll(): String? {
        val now = System.currentTimeMillis()
        // pertama kali: lihat 1 jam ke belakang; berikutnya hanya selang baru (tumpang tindih 1 detik agar tak ada yang terlewat)
        val from = if (lastQuery == 0L) now - 60 * 60_000L else lastQuery - 1_000L
        val events = runCatching { usm.queryEvents(from, now) }.getOrNull() ?: return current
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) current = e.packageName
        }
        lastQuery = now
        return current
    }
}
