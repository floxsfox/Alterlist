package com.alterlist.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Visual nada (percobaan): 12 nada (Do, Do#, Re ... Si) berjajar melingkar. Tiap nada menyala sesuai seberapa kuat
 * nada itu terdengar di lagu (energi kelas-nada dari analisis Goertzel pada oktaf 3 sampai 6), nada yang menyala
 * bersamaan dihubungkan garis tipis, dan nada paling kuat ditulis di tengah. Disuapi suara akhir dari [com.alterlist.app.fx.WaveTap].
 */
class NoteRingView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    companion object {
        const val WINDOW = 4096
        private const val RING = 1 shl 15
        private const val RING_MASK = (RING - 1).toLong()
        private const val FIRST_OCTAVE = 3
        private const val OCTAVES = 4
        private val NAMES = arrayOf("Do", "Do\u266F", "Re", "Re\u266F", "Mi", "Fa", "Fa\u266F", "Sol", "Sol\u266F", "La", "La\u266F", "Si")
        private val SHARP = booleanArrayOf(false, true, false, true, false, false, true, false, true, false, true, false)
        private val GLOW_SCALE = floatArrayOf(2.7f, 1.95f, 1.45f)
        private val GLOW_ALPHA = floatArrayOf(0.10f, 0.17f, 0.30f)
    }

    /** Laju sampel suara (diisi dari penyadap). */
    @Volatile var sampleRate: Int = 44100

    /** Suara tiba di penyadap sedikit lebih awal dari yang terdengar (buffer perangkat audio). */
    @Volatile var syncOffsetMs: Int = 150

    /** Warna dasar (cincin dan pusat), biasanya dari sampul. */
    var accent: Int = Color.WHITE
        set(v) {
            field = v
            invalidate()
        }

    var playing: Boolean = false
        set(v) {
            field = v
            postInvalidateOnAnimation()
        }

    private val ring = FloatArray(RING)
    @Volatile private var ringWrite = 0L
    private val win = FloatArray(WINDOW)
    private val hann = FloatArray(WINDOW) { (0.5 - 0.5 * cos(2.0 * PI * it / (WINDOW - 1))).toFloat() }
    private val nFreq = 12 * OCTAVES
    private val coeffs = DoubleArray(nFreq)
    private var coeffRate = 0
    private val raw = FloatArray(12)
    private val targets = FloatArray(12)
    private val levels = FloatArray(12)
    private var ref = 1e-6f
    private var rms = 0f
    private var lastCompute = 0L
    private val px = FloatArray(12)
    private val py = FloatArray(12)

    // satu warna per nada (pelangi), dihitung sekali
    private val noteColors = IntArray(12) { Color.HSVToColor(floatArrayOf(it * 30f, 0.60f, 1f)) }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val label =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
        }

    // ------------------------------------------------------------------ suara masuk
    /** Buffer PCM little-endian. encoding: 2 = PCM 16-bit, 4 = PCM float (nilai sama dengan C.ENCODING_PCM_*). */
    fun feedPcm(buffer: ByteBuffer, channels: Int, encoding: Int) {
        val b = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val ch = if (channels < 1) 1 else channels
        var w = ringWrite
        if (encoding == 4) {
            val frames = b.remaining() / (4 * ch)
            for (f in 0 until frames) {
                var sum = 0f
                for (c in 0 until ch) sum += b.getFloat()
                ring[(w and RING_MASK).toInt()] = sum / ch
                w++
            }
        } else if (encoding == 2) {
            val frames = b.remaining() / (2 * ch)
            for (f in 0 until frames) {
                var sum = 0
                for (c in 0 until ch) sum += b.getShort().toInt()
                ring[(w and RING_MASK).toInt()] = sum.toFloat() / (32768f * ch)
                w++
            }
        } else {
            return
        }
        ringWrite = w
    }

    /** Kosongkan buffer (panggil saat ganti lagu atau seek). */
    fun reset() {
        ringWrite = 0L
        java.util.Arrays.fill(ring, 0f)
        java.util.Arrays.fill(targets, 0f)
        java.util.Arrays.fill(levels, 0f)
        ref = 1e-6f
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------------ analisis nada
    private fun rebuildCoeffs(rate: Int) {
        for (idx in 0 until nFreq) {
            val oct = idx / 12
            val note = idx % 12
            val midi = 12 * (FIRST_OCTAVE + oct + 1) + note
            val f = 440.0 * 2.0.pow((midi - 69) / 12.0)
            coeffs[idx] = 2.0 * cos(2.0 * PI * f / rate)
        }
        coeffRate = rate
    }

    /** Hitung energi tiap kelas-nada dari jendela terbaru, lalu ubah jadi target terang 0..1. */
    private fun analyze() {
        val written = ringWrite
        val rate = sampleRate
        if (rate != coeffRate) rebuildCoeffs(rate)
        var delay = syncOffsetMs.toLong() * rate.toLong() / 1000L
        val maxDelay = (RING - WINDOW - 1024).toLong()
        if (delay < 0L) delay = 0L
        if (delay > maxDelay) delay = maxDelay
        val start = written - delay - WINDOW
        if (written <= 0L || start < 0L) {
            java.util.Arrays.fill(targets, 0f)
            rms = 0f
            return
        }
        var sq = 0f
        for (k in 0 until WINDOW) {
            val s = ring[((start + k) and RING_MASK).toInt()]
            sq += s * s
            win[k] = s * hann[k]
        }
        rms = sqrt(sq / WINDOW)
        java.util.Arrays.fill(raw, 0f)
        for (idx in 0 until nFreq) {
            val coeff = coeffs[idx]
            var s1 = 0.0
            var s2 = 0.0
            for (k in 0 until WINDOW) {
                val s0 = win[k] + coeff * s1 - s2
                s2 = s1
                s1 = s0
            }
            val p = s1 * s1 + s2 * s2 - coeff * s1 * s2
            raw[idx % 12] += sqrt(max(p, 0.0)).toFloat()
        }
        // kontras: buang rata-rata supaya hanya nada yang menonjol yang menyala
        var mean = 0f
        for (i in 0 until 12) mean += raw[i]
        mean /= 12f
        var mx = 0f
        for (i in 0 until 12) {
            val v = max(0f, raw[i] - 0.55f * mean)
            raw[i] = v
            if (v > mx) mx = v
        }
        ref = max(max(ref * 0.992f, mx), 1e-6f)
        val gate = rms > 0.004f
        for (i in 0 until 12) {
            targets[i] = if (gate) (raw[i] / ref).coerceIn(0f, 1f).pow(1.5f) else 0f
        }
    }

    // ------------------------------------------------------------------ menggambar
    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun blend(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt()
        return Color.rgb(r, g, bl)
    }

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val now = System.nanoTime() / 1_000_000L
        if (playing) {
            if (now - lastCompute >= 30L) {
                lastCompute = now
                analyze()
            }
        } else {
            java.util.Arrays.fill(targets, 0f)
        }
        var any = false
        var dom = 0
        var energy = 0f
        for (i in 0 until 12) {
            val l = levels[i]
            val t = targets[i]
            val n = l + (t - l) * (if (t > l) 0.38f else 0.09f)
            levels[i] = n
            energy += n
            if (n > levels[dom]) dom = i
            if (n > 0.01f) any = true
        }
        energy /= 12f

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r0 = min(w, h) / 2f
        val ringR = r0 * 0.74f
        val nodeR = r0 * 0.13f

        // jalur cincin
        stroke.color = withAlpha(accent, 46)
        stroke.strokeWidth = 1.2f * d
        canvas.drawCircle(cx, cy, ringR, stroke)
        stroke.color = withAlpha(accent, 22)
        canvas.drawCircle(cx, cy, ringR * 0.5f, stroke)

        for (i in 0 until 12) {
            val ang = Math.toRadians(-90.0 + i * 30.0)
            px[i] = cx + ringR * cos(ang).toFloat()
            py[i] = cy + ringR * sin(ang).toFloat()
        }

        // garis penghubung antar nada yang menyala bersamaan
        for (a in 0 until 12) {
            if (levels[a] < 0.3f) continue
            for (b in a + 1 until 12) {
                val m = min(levels[a], levels[b])
                if (m < 0.3f) continue
                stroke.color = withAlpha(blend(noteColors[a], noteColors[b], 0.5f), (m * 120f).toInt())
                stroke.strokeWidth = (1f + 1.2f * m) * d
                canvas.drawLine(px[a], py[a], px[b], py[b], stroke)
            }
        }

        // pusat: denyut halus mengikuti energi keseluruhan
        val coreR = r0 * 0.30f * (0.9f + 0.25f * energy)
        for (k in 0 until 3) {
            fill.color = withAlpha(accent, (255f * GLOW_ALPHA[k] * (0.5f + energy * 1.5f)).toInt())
            canvas.drawCircle(cx, cy, coreR * (1f + (GLOW_SCALE[k] - 1f) * 0.45f), fill)
        }
        fill.color = withAlpha(blend(Color.BLACK, accent, 0.18f + 0.35f * energy), 255)
        canvas.drawCircle(cx, cy, coreR, fill)
        val domLevel = levels[dom]
        val centerText = if (domLevel > 0.35f) NAMES[dom] else "\u266A"
        label.color = withAlpha(Color.WHITE, if (domLevel > 0.35f) 255 else 120)
        label.textSize = coreR * 0.78f
        val cfm = label.fontMetrics
        canvas.drawText(centerText, cx, cy - (cfm.ascent + cfm.descent) / 2f, label)

        // nada-nada
        for (i in 0 until 12) {
            val l = levels[i]
            val rr = if (SHARP[i]) nodeR * 0.8f else nodeR
            val col = noteColors[i]
            if (l > 0.02f) {
                for (k in 0 until 3) {
                    fill.color = withAlpha(col, (255f * GLOW_ALPHA[k] * l).toInt())
                    canvas.drawCircle(px[i], py[i], rr * (1f + (GLOW_SCALE[k] - 1f) * l), fill)
                }
            }
            fill.color = blend(0xFF1B1B20.toInt(), col, 0.12f + 0.88f * l)
            canvas.drawCircle(px[i], py[i], rr, fill)
            stroke.color = withAlpha(col, 90 + (165f * l).toInt())
            stroke.strokeWidth = (1.4f + 1.4f * l) * d
            canvas.drawCircle(px[i], py[i], rr, stroke)

            val name = NAMES[i]
            label.color = withAlpha(Color.WHITE, 150 + (105f * l).toInt())
            label.textSize = rr * 0.72f
            val mw = label.measureText(name)
            if (mw > rr * 1.7f) label.textSize = label.textSize * (rr * 1.7f / mw)
            val fm = label.fontMetrics
            canvas.drawText(name, px[i], py[i] - (fm.ascent + fm.descent) / 2f, label)
        }

        if (playing || any) postInvalidateOnAnimation()
    }
}
