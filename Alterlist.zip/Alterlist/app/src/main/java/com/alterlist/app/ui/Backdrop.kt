package com.alterlist.app.ui

import android.os.Build
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.graphics.layer.*
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Latar untuk efek kaca tembus: isi layar (daftar lagu, cover, teks) direkam ke satu layer grafis,
 * lalu bar kaca menggambar potongan layer yang tepat di belakangnya dengan blur tipis.
 */
class BackdropState(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)

    /** Naik setiap kali isi layar digambar ulang (mis. saat scroll) supaya kaca ikut menyegarkan latarnya. */
    var version by androidx.compose.runtime.mutableIntStateOf(0)
}

@Composable
fun rememberBackdropState(): BackdropState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { BackdropState(layer) }
}

/** Tandai area yang jadi "latar" untuk kaca (taruh di konten layar, bukan di bar kacanya). */
fun Modifier.backdropSource(state: BackdropState): Modifier =
    this
        .onGloballyPositioned { state.origin = it.positionInWindow() }
        .drawWithContent {
            state.layer.record { this@drawWithContent.drawContent() }
            androidx.compose.runtime.snapshots.Snapshot.withoutReadObservation { state.version = state.version + 1 }
            drawLayer(state.layer)
        }

/** Gambar potongan latar di belakang elemen ini, dengan blur [blur] (Android 12+). */
fun Modifier.backdropGlass(state: BackdropState, blur: Dp = 10.dp): Modifier =
    composed {
        val blurLayer = rememberGraphicsLayer()
        var self by remember { mutableStateOf(Offset.Zero) }
        val radius = with(LocalDensity.current) { blur.toPx() }
        this
            .onGloballyPositioned { self = it.positionInWindow() }
            .drawWithContent {
                @Suppress("UNUSED_VARIABLE") val v = state.version
                val off = state.origin - self
                blurLayer.record {
                    translate(off.x, off.y) { drawLayer(state.layer) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && radius > 0f) {
                    blurLayer.renderEffect = BlurEffect(radius, radius, TileMode.Clamp)
                }
                drawLayer(blurLayer)
                drawContent()
            }
    }

/**
 * Kaca cair: isi layar di belakangnya tembus dengan blur tipis, diberi tint warna cover lagu (tipis),
 * kilau di sudut, dan garis tepi mengilap. Tidak ada animasi terus-menerus supaya scroll tetap mulus.
 */
@Composable
fun LiquidGlass(
    state: BackdropState,
    palette: CoverPalette,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(26.dp),
    content: @Composable BoxScope.() -> Unit,
) {
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val tintAlpha = if (canBlur) 0.42f else 0.60f
    Box(
        modifier
            .clip(shape)
            .backdropGlass(state, 10.dp)
            .drawBehind {
                // tint warna dari metadata cover, dibuat tipis supaya UI di belakang tetap terlihat
                drawRect(
                    Brush.verticalGradient(
                        listOf(
                            palette.primary.copy(alpha = tintAlpha),
                            Color.Black.copy(alpha = 0.18f),
                        ),
                    ),
                )
                // kilau seperti pantulan cahaya di sudut kiri atas
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.12f, 0f),
                        radius = size.width * 0.55f,
                    ),
                )
                // bias warna kedua di sisi kanan bawah
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(palette.secondary.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height),
                        radius = size.width * 0.5f,
                    ),
                )
            }
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.35f))),
                shape,
            ),
    ) {
        content()
    }
}
