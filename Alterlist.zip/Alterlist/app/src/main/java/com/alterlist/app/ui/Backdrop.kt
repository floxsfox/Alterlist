package com.alterlist.app.ui

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.graphics.layer.*
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Latar untuk efek kaca tembus: isi layar (daftar lagu, cover, teks) direkam ke satu layer grafis,
 * lalu bar kaca menggambar potongan layer yang tepat di belakangnya dengan blur tipis.
 */
class BackdropState(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)

    /** Naik setiap kali isi layar digambar ulang (mis. saat scroll) supaya kaca ikut menyegarkan latarnya. */
    var version by androidx.compose.runtime.mutableIntStateOf(0)
}

@Composable
fun rememberBackdropState(): BackdropState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { BackdropState(layer) }
}

/** Tandai area yang jadi "latar" untuk kaca (taruh di konten layar, bukan di bar kacanya). */
fun Modifier.backdropSource(state: BackdropState): Modifier =
    this
        .onGloballyPositioned { state.origin = it.positionInWindow() }
        .drawWithContent {
            state.layer.record { this@drawWithContent.drawContent() }
            androidx.compose.runtime.snapshots.Snapshot.withoutReadObservation { state.version = state.version + 1 }
            drawLayer(state.layer)
        }

/**
 * Shader pembias (AGSL, Android 13+): tepi kaca membelokkan isi di belakangnya seperti lensa air,
 * dengan sedikit pemisahan warna (dispersi), warna dipekatkan, dan kilau cahaya di tepi kiri atas.
 */
private const val GLASS_AGSL = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float bezel;
uniform float strength;

float sdRound(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r);
    return length(max(q, float2(0.0))) + min(max(q.x, q.y), 0.0) - r;
}

half4 main(float2 fc) {
    float2 ctr = size * 0.5;
    float2 p = fc - ctr;
    float d = sdRound(p, ctr, radius);
    float t = clamp(-d / bezel, 0.0, 1.0);
    float edge = 1.0 - t;
    float2 g = float2(
        sdRound(p + float2(1.0, 0.0), ctr, radius) - sdRound(p - float2(1.0, 0.0), ctr, radius),
        sdRound(p + float2(0.0, 1.0), ctr, radius) - sdRound(p - float2(0.0, 1.0), ctr, radius));
    float2 n = g / max(length(g), 0.0001);
    float bend = edge * edge * strength;
    float2 hi = size - float2(1.0);
    float2 sr = clamp(fc - n * bend, float2(0.0), hi);
    float2 sg = clamp(fc - n * bend * 0.92, float2(0.0), hi);
    float2 sb = clamp(fc - n * bend * 0.84, float2(0.0), hi);
    half3 col = half3(content.eval(sr).r, content.eval(sg).g, content.eval(sb).b);
    half luma = dot(col, half3(0.299, 0.587, 0.114));
    col = mix(half3(luma), col, half(1.55));
    float2 ld = normalize(float2(-0.55, -0.85));
    float facing = dot(n, ld);
    float rim = pow(edge, 3.0);
    col += half3(rim * (0.10 + 0.50 * max(facing, 0.0)));
    col -= half3(rim * 0.10 * max(-facing, 0.0));
    col += half3(0.035);
    return half4(clamp(col, half3(0.0), half3(1.0)), 1.0);
}
"""

/** Shader pembias; null bila perangkat tidak mendukung atau kode AGSL ditolak (jatuh ke blur biasa). */
@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun createGlassShader(): RuntimeShader? = runCatching { RuntimeShader(GLASS_AGSL) }.getOrNull()

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
private fun refractEffect(
    shader: RuntimeShader,
    blurPx: Float,
    w: Float,
    h: Float,
    corner: Float,
    bezel: Float,
): android.graphics.RenderEffect {
    shader.setFloatUniform("size", w, h)
    shader.setFloatUniform("radius", corner.coerceAtMost(minOf(w, h) / 2f))
    shader.setFloatUniform("bezel", bezel)
    shader.setFloatUniform("strength", bezel * 0.62f)
    val blur = android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
    val lens = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
    // blur dulu, baru dibelokkan di tepi
    return android.graphics.RenderEffect.createChainEffect(lens, blur)
}

@RequiresApi(Build.VERSION_CODES.S)
private fun frostedEffect(blurPx: Float): android.graphics.RenderEffect {
    val blur = android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
    val cm = ColorMatrix().apply { setSaturation(1.45f) }
    return android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(cm), blur)
}

private class GlassCache {
    var w = -1f
    var h = -1f
    var applied = false
}

/**
 * Gambar potongan latar di belakang elemen ini dengan blur [blur] (Android 12+).
 * Jika [corner] > 0 dan perangkat Android 13+, tepinya membiaskan latar seperti kaca cair sungguhan.
 */
fun Modifier.backdropGlass(state: BackdropState, blur: Dp = 10.dp, corner: Dp = 0.dp): Modifier =
    composed {
        val blurLayer = rememberGraphicsLayer()
        var self by remember { mutableStateOf(Offset.Zero) }
        val density = LocalDensity.current
        val radius = with(density) { blur.toPx() }
        val cornerPx = with(density) { corner.toPx() }
        val bezelPx = with(density) { 22.dp.toPx() }
        val shader =
            remember {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) createGlassShader() else null
            }
        val cache = remember { GlassCache() }
        this
            .onGloballyPositioned { self = it.positionInWindow() }
            .drawWithContent {
                @Suppress("UNUSED_VARIABLE") val v = state.version
                val off = state.origin - self
                blurLayer.record {
                    translate(off.x, off.y) { drawLayer(state.layer) }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && radius > 0f) {
                    // efek dibuat ulang hanya saat ukuran berubah, bukan tiap frame scroll
                    if (!cache.applied || cache.w != size.width || cache.h != size.height) {
                        val effect =
                            if (shader != null && cornerPx > 0f && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                runCatching { refractEffect(shader, radius, size.width, size.height, cornerPx, bezelPx) }
                                    .getOrElse { frostedEffect(radius) }
                            } else {
                                frostedEffect(radius)
                            }
                        blurLayer.renderEffect = effect.asComposeRenderEffect()
                        cache.w = size.width
                        cache.h = size.height
                        cache.applied = true
                    }
                }
                drawLayer(blurLayer)
                drawContent()
            }
    }

/**
 * Kaca cair: isi layar di belakangnya dibiaskan di tepi seperti lensa air (Android 13+), diblur halus,
 * warnanya dipekatkan, diberi tint tipis warna cover, kilau lembut di atas, cahaya dalam di tepi, dan garis
 * tepi mengilap. [light] (-1..1) menggeser titik cahaya mengikuti geseran jari.
 * Tidak ada animasi terus-menerus supaya scroll tetap mulus.
 */
@Composable
fun LiquidGlass(
    state: BackdropState,
    palette: CoverPalette,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(26.dp),
    corner: Dp = 26.dp,
    light: () -> Float = { 0f },
    content: @Composable BoxScope.() -> Unit,
) {
    val canBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    val tintAlpha = if (canBlur) 0.20f else 0.55f
    Box(
        modifier
            .clip(shape)
            .backdropGlass(state, 6.dp, corner)
            .drawBehind {
                // tint warna dari metadata cover, dibuat tipis supaya latar yang dibiaskan tetap terlihat
                drawRect(
                    Brush.verticalGradient(
                        listOf(
                            palette.primary.copy(alpha = tintAlpha),
                            palette.secondary.copy(alpha = tintAlpha * 0.55f),
                        ),
                    ),
                )
                // kilau lembut seperti pantulan lampu di bagian atas kaca
                drawRect(
                    Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.20f), Color.Transparent),
                        startY = 0f,
                        endY = size.height * 0.55f,
                    ),
                )
                // titik cahaya yang ikut bergeser saat mini player digeser
                val lx = (0.16f + light() * 0.30f).coerceIn(0.02f, 0.98f)
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(Color.White.copy(alpha = 0.30f), Color.Transparent),
                        center = Offset(size.width * lx, 0f),
                        radius = size.width * 0.50f,
                    ),
                )
                // bias warna kedua di sisi kanan bawah
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(palette.secondary.copy(alpha = 0.26f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height),
                        radius = size.width * 0.5f,
                    ),
                )
                // cahaya dalam tipis di sepanjang tepi, memberi kesan kaca tebal
                val inset = 1.6.dp.toPx()
                val cr = (corner.toPx() - inset).coerceAtLeast(0f)
                drawRoundRect(
                    brush =
                        Brush.linearGradient(
                            listOf(Color.White.copy(alpha = 0.34f), Color.Transparent, Color.White.copy(alpha = 0.14f)),
                        ),
                    topLeft = Offset(inset, inset),
                    size = Size(size.width - inset * 2, size.height - inset * 2),
                    cornerRadius = CornerRadius(cr, cr),
                    style = Stroke(width = 2.2.dp.toPx()),
                )
            }
            .border(
                1.2.dp,
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.85f),
                        Color.White.copy(alpha = 0.06f),
                        Color.White.copy(alpha = 0.20f),
                        Color.White.copy(alpha = 0.55f),
                    ),
                ),
                shape,
            ),
    ) {
        content()
    }
}
