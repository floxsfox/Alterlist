package com.alterlist.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.LocalState
import com.alterlist.app.data.Song
import com.alterlist.app.system.PermissionHelper
import kotlinx.coroutines.launch
import java.util.Locale

private enum class LocalTab(val label: String) { SONGS("Lagu"), ALBUMS("Album"), ARTISTS("Artis"), FOLDERS("Folder") }

private enum class LocalSort(val label: String) {
    RECENT("Terbaru"),
    TITLE("Judul A-Z"),
    ARTIST("Artis A-Z"),
    LONGEST("Terpanjang"),
}

private fun List<Song>.applySort(sort: LocalSort): List<Song> =
    when (sort) {
        LocalSort.RECENT -> this
        LocalSort.TITLE -> sortedBy { it.title.lowercase(Locale.ROOT) }
        LocalSort.ARTIST -> sortedWith(compareBy({ it.artist.lowercase(Locale.ROOT) }, { it.title.lowercase(Locale.ROOT) }))
        LocalSort.LONGEST -> sortedByDescending { it.durationSeconds ?: 0 }
    }

/** Kolom filter kecil dipakai di daftar lagu (musik lokal, playlist, dll). */
@Composable
fun FilterField(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(42.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(AlterColors.Surface2),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Ic(R.drawable.ic_search, tint = AlterColors.Sub, size = 20.dp, modifier = Modifier.padding(start = 12.dp))
        Box(Modifier.weight(1f).padding(horizontal = 10.dp)) {
            if (value.isEmpty()) Text(placeholder, style = T.body, color = AlterColors.Muted)
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = T.body.copy(color = Color.White),
                cursorBrush = SolidColor(AlterColors.Red),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (value.isNotEmpty()) IconBtn(R.drawable.ic_close, { onChange("") }, tint = AlterColors.Sub, size = 18.dp, box = 40.dp)
    }
}

/**
 * Tab "Perangkat": semua musik di penyimpanan HP (semua format audio yang didukung Android) dalam tab Lagu, Album, Artis, dan Folder.
 * Berkas yang tidak terdeteksi bisa ditambahkan manual lewat pemilih berkas.
 */
@Composable
fun LocalMusicScreen(padding: PaddingValues, onBack: () -> Unit) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val local by app.localMusic.state.collectAsState()
    val playerState by app.player.state.collectAsState()

    var hasPermission by remember { mutableStateOf(PermissionHelper.hasAudioAccess(context)) }
    var tab by rememberSaveable { mutableStateOf(LocalTab.SONGS) }
    var sort by rememberSaveable { mutableStateOf(LocalSort.RECENT) }
    var query by rememberSaveable { mutableStateOf("") }
    var openKind by rememberSaveable { mutableStateOf("") }
    var openKey by rememberSaveable { mutableStateOf("") }

    val permissionLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            hasPermission = granted
            if (granted) scope.launch { app.localMusic.refresh() }
        }
    val pickLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                scope.launch {
                    val n = app.localMusic.addPicked(uris)
                    context.toast(if (n > 0) "$n lagu ditambahkan" else "Tidak ada berkas audio yang bisa dibaca")
                }
            }
        }
    val pickTypes = arrayOf("audio/*", "application/ogg", "application/octet-stream")

    LaunchedEffect(hasPermission) {
        if (hasPermission) app.localMusic.refresh() else app.localMusic.refresh(withMediaStore = false)
    }

    BackHandler(enabled = openKind.isNotEmpty()) { openKind = "" }
    BackHandler(enabled = openKind.isEmpty(), onBack = onBack)

    val base = local.songs
    val q = query.trim().lowercase(Locale.ROOT)
    val songs =
        remember(base, q, sort) {
            val filtered =
                if (q.isEmpty()) {
                    base
                } else {
                    base.filter {
                        it.title.lowercase(Locale.ROOT).contains(q) ||
                            it.artist.lowercase(Locale.ROOT).contains(q) ||
                            (it.album?.lowercase(Locale.ROOT)?.contains(q) == true)
                    }
                }
            filtered.applySort(sort)
        }

    if (openKind.isNotEmpty()) {
        val title: String
        val sub: String
        val list: List<Song>
        when (openKind) {
            "album" -> {
                val a = local.albums.firstOrNull { it.name == openKey }
                title = a?.name ?: openKey
                sub = a?.artist.orEmpty()
                list = a?.songs.orEmpty()
            }
            "artist" -> {
                val a = local.artists.firstOrNull { it.name == openKey }
                title = a?.name ?: openKey
                sub = "Artis"
                list = a?.songs.orEmpty()
            }
            else -> {
                val f = local.folders.firstOrNull { it.path == openKey }
                title = f?.name ?: openKey
                sub = f?.path.orEmpty()
                list = f?.songs.orEmpty()
            }
        }
        LocalGroupPage(padding, title, sub, list) { openKind = "" }
        return
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = padding) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 6.dp, top = 10.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.ic_chevron_left, onBack)
                Text("Di perangkat", style = T.screen, modifier = Modifier.weight(1f))
                if (local.loading) {
                    CircularProgressIndicator(Modifier.size(22.dp).padding(end = 4.dp), color = AlterColors.Red, strokeWidth = 2.dp)
                }
                IconBtn(R.drawable.ic_plus, { pickLauncher.launch(pickTypes) })
                IconBtn(R.drawable.ic_refresh, { scope.launch { app.localMusic.refresh() } })
            }
        }

        if (!hasPermission && base.isEmpty()) {
            item { PermissionCard({ permissionLauncher.launch(PermissionHelper.audioPermission()) }, { pickLauncher.launch(pickTypes) }) }
            return@LazyColumn
        }

        item { SummaryCard(local) }

        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Putar", { if (songs.isNotEmpty()) app.player.playSongs(songs) }, Modifier.weight(1f), icon = R.drawable.ic_play)
                PillButton(
                    "Acak",
                    { if (songs.isNotEmpty()) app.player.playSongs(songs, songs.indices.random(), shuffle = true) },
                    Modifier.weight(1f),
                    container = AlterColors.Surface3,
                    icon = R.drawable.ic_shuffle,
                )
            }
        }
        item { FilterField(query, { query = it }, "Cari di musik perangkat", Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
        item {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                LocalTab.entries.forEach { t -> AlterChip(t.label, tab == t, { tab = t }) }
            }
        }

        if (local.scanned && base.isEmpty()) {
            item { EmptyText("Belum ada musik ditemukan") }
            return@LazyColumn
        }

        when (tab) {
            LocalTab.SONGS -> {
                item {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        LocalSort.entries.forEach { s ->
                            Text(
                                s.label,
                                style = T.small.copy(fontWeight = FontWeight.SemiBold),
                                color = if (sort == s) Color.White else AlterColors.Sub,
                                modifier =
                                    Modifier
                                        .clip(RoundedCornerShape(50))
                                        .background(if (sort == s) AlterColors.Surface3 else Color.Transparent)
                                        .clickable { sort = s }
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                            )
                        }
                    }
                }
                if (songs.isEmpty()) {
                    item { EmptyText("Tidak ada lagu yang cocok dengan \"$query\"") }
                } else {
                    itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                        val current = playerState.current?.id == s.id
                        SongRow(s, onClick = { app.player.playSongs(songs, i) }, isCurrent = current)
                    }
                }
            }
            LocalTab.ALBUMS -> {
                val albums = local.albums.filter { q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q) || it.artist.lowercase(Locale.ROOT).contains(q) }
                items(albums, key = { "album-" + it.name }) { a ->
                    LibraryTile(a.name, "${a.artist} • ${a.songs.size} lagu", a.thumbnail, RoundedCornerShape(6.dp), {
                        openKind = "album"
                        openKey = a.name
                    })
                }
            }
            LocalTab.ARTISTS -> {
                val artists = local.artists.filter { q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q) }
                items(artists, key = { "artist-" + it.name }) { a ->
                    LibraryTile(a.name, "${a.songs.size} lagu", a.thumbnail, CircleShape, {
                        openKind = "artist"
                        openKey = a.name
                    })
                }
            }
            LocalTab.FOLDERS -> {
                val folders = local.folders.filter { q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q) }
                items(folders, key = { "folder-" + it.path }) { f ->
                    LibraryTile(
                        f.name,
                        "${f.songs.size} lagu • ${f.path}",
                        null,
                        RoundedCornerShape(6.dp),
                        {
                            openKind = "folder"
                            openKey = f.path
                        },
                        leading = {
                            Box(Modifier.fillMaxSize().background(AlterColors.Surface2), contentAlignment = Alignment.Center) {
                                Ic(R.drawable.ic_music_folder, tint = AlterColors.Sub, size = 28.dp)
                            }
                        },
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun SummaryCard(local: LocalState) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF2A1A3A), Color(0xFF14202F))))
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                Ic(R.drawable.ic_phone, tint = Color.White, size = 24.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("${animatedCount(local.songs.size)} lagu", style = T.hero)
                Text("${formatBytes(local.totalBytes)} • ${local.albums.size} album • ${local.artists.size} artis", style = T.small, color = AlterColors.Sub)
            }
        }
        if (local.formats.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                local.formats.entries.take(10).forEach { (ext, n) ->
                    Text(
                        "${ext.uppercase(Locale.ROOT)} $n",
                        style = T.tiny.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.12f)).padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun PermissionCard(onGrant: () -> Unit, onPick: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(24.dp)).background(AlterColors.Surface).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Ic(R.drawable.ic_music_folder, tint = AlterColors.Red, size = 44.dp)
        Spacer(Modifier.height(12.dp))
        Text("Musik di perangkat", style = T.hero)
        Spacer(Modifier.height(6.dp))
        Text(
            "Izinkan akses musik untuk menampilkan lagu di penyimpanan.",
            style = T.small,
            color = AlterColors.Sub,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        PillButton("Izinkan akses musik", onGrant, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        PillButton("Pilih berkas manual", onPick, Modifier.fillMaxWidth(), container = AlterColors.Surface3, icon = R.drawable.ic_plus)
    }
}

@Composable
private fun LocalGroupPage(padding: PaddingValues, title: String, subtitle: String, songs: List<Song>, onBack: () -> Unit) {
    val app = AlterApp.instance
    LazyColumn(Modifier.fillMaxSize(), contentPadding = padding) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBtn(R.drawable.ic_chevron_left, onBack)
                Column(Modifier.weight(1f)) {
                    Text(title, style = T.hero, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (subtitle.isNotBlank()) Text(subtitle, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Putar", { if (songs.isNotEmpty()) app.player.playSongs(songs) }, Modifier.weight(1f), icon = R.drawable.ic_play)
                PillButton(
                    "Acak",
                    { if (songs.isNotEmpty()) app.player.playSongs(songs, songs.indices.random(), shuffle = true) },
                    Modifier.weight(1f),
                    container = AlterColors.Surface3,
                    icon = R.drawable.ic_shuffle,
                )
            }
        }
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s -> SongRow(s, onClick = { app.player.playSongs(songs, i) }) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
