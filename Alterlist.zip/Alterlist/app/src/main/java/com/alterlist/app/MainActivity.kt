package com.alterlist.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Modifier
import com.alterlist.app.data.LinkHandler
import com.alterlist.app.ui.AlterColors
import kotlinx.coroutines.launch
import com.alterlist.app.ui.AlterRoot
import com.alterlist.app.ui.AlterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // UI Alterlist selalu gelap: ikon status/navigasi harus terang walau HP memakai tema terang
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        AlterApp.instance.player.connect()
        handleLink(intent)
        setContent {
            AlterTheme {
                Box(Modifier.fillMaxSize().background(AlterColors.Bg)) {
                    AlterRoot()
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        handleLink(intent)
    }

    private fun handleLink(intent: android.content.Intent?) {
        val data = intent?.dataString ?: return
        if (!LinkHandler.isLink(data)) return
        val app = AlterApp.instance
        app.scope.launch(kotlinx.coroutines.Dispatchers.Main) { LinkHandler.play(app, data) }
    }

    override fun onResume() {
        super.onResume()
        // streak harian: setiap aplikasi dibuka, Library memutuskan naik / padam / tetap
        AlterApp.instance.library.touchStreak(java.time.LocalDate.now().toEpochDay())
        // mode game: nyalakan / matikan layanan sesuai pengaturan dan izin terbaru
        com.alterlist.app.system.GameModeController.sync(this)
    }

    override fun onPause() {
        super.onPause()
        AlterApp.instance.library.flush()
    }
}
