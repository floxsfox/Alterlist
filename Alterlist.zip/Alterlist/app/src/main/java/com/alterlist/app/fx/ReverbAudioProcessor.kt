package com.alterlist.app.fx

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer

/**
 * Memasang [ReverbEngine] ke jalur audio ExoPlayer (PCM 16-bit stereo).
 * Selalu aktif untuk format yang cocok; saat mix = 0 audio dilewatkan apa adanya.
 */
class ReverbAudioProcessor : BaseAudioProcessor() {
    private var engine: ReverbEngine? = null
    private var left = FloatArray(0)
    private var right = FloatArray(0)
    private var wasWet = false

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET // format lain: lewati saja, bukan error
        }
        engine = ReverbEngine(inputAudioFormat.sampleRate)
        wasWet = false
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val eng = engine
        val fx = AudioFx.state.value

        if (eng == null || fx.mix <= 0.001f) {
            if (wasWet) {
                eng?.reset()
                wasWet = false
            }
            out.put(inputBuffer)
            out.flip()
            return
        }
        wasWet = true
        eng.setParams(fx.room, fx.damp, fx.mix, fx.pre)

        val frames = size / 4
        if (left.size < frames) {
            left = FloatArray(frames)
            right = FloatArray(frames)
        }
        var pos = inputBuffer.position()
        for (i in 0 until frames) {
            left[i] = inputBuffer.getShort(pos) / 32768f
            right[i] = inputBuffer.getShort(pos + 2) / 32768f
            pos += 4
        }
        eng.process(left, right, frames)
        for (i in 0 until frames) {
            out.putShort((left[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            out.putShort((right[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        }
        inputBuffer.position(pos)
        // sisa byte (bila ada) disalin apa adanya supaya panjang keluaran = panjang masukan
        out.put(inputBuffer)
        out.flip()
    }

    override fun onFlush() {
        engine?.reset()
        wasWet = false
    }

    override fun onReset() {
        engine = null
        left = FloatArray(0)
        right = FloatArray(0)
        wasWet = false
    }
}
