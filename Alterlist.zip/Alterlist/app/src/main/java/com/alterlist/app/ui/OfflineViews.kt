package com.alterlist.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.alterlist.app.R

/** Pita tipis di atas layar saat tidak ada internet. */
@Composable
fun OfflineBanner(visible: Boolean, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
    ) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFF2B2B2F)).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Ic(R.drawable.ic_wifi_off, tint = Color.White, size = 16.dp)
            Spacer(Modifier.width(8.dp))
            Text("Offline", style = T.small, color = Color.White)
        }
    }
}

/** Pengganti isi Beranda saat offline: tidak ada pemuatan online sama sekali sampai internet kembali. */
@Composable
fun OfflineHomeCard(downloads: Int, localSongs: Int, onDownloads: () -> Unit, onLocal: () -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "offlinePulse")
    val pulse by t.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF26262A), AlterColors.Surface)))
            .padding(horizontal = 20.dp, vertical = 26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(72.dp)
                .graphicsLayer {
                    scaleX = pulse
                    scaleY = pulse
                }
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center,
        ) { Ic(R.drawable.ic_wifi_off, tint = Color.White, size = 34.dp) }
        Spacer(Modifier.height(16.dp))
        Text("Kamu sedang offline", style = T.hero)
        Spacer(Modifier.height(6.dp))
        Text("Beranda dijeda", style = T.body, color = AlterColors.Sub, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        PillButton(
            "Lagu unduhan ($downloads)",
            onDownloads,
            Modifier.fillMaxWidth(),
            icon = R.drawable.ic_downloaded,
        )
        Spacer(Modifier.height(10.dp))
        PillButton(
            "Musik di perangkat ($localSongs)",
            onLocal,
            Modifier.fillMaxWidth(),
            container = AlterColors.Surface3,
            icon = R.drawable.ic_phone,
        )
    }
}
