package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Pengaturan aplikasi yang bukan bagian dari pustaka (pemutaran, musik lokal, lirik, profil perangkat audio). */
data class AppSettingsState(
    /** Lama fade di awal/akhir lagu (ms). 0 = mati. */
    val fadeMs: Int = 0,
    /** Lewati bagian hening di dalam lagu. */
    val skipSilence: Boolean = false,
    /** Abaikan audio lokal yang lebih pendek dari ini (detik). */
    val localMinSeconds: Int = 20,
    /** Tampilkan notifikasi singkat saat speaker / earphone Bluetooth tersambung. */
    val outputToast: Boolean = true,
    /** Kode bahasa terjemahan lirik ("" = mati). */
    val translateLang: String = "",
    /** Geser waktu lirik (ms), negatif = lebih cepat. */
    val lyricOffsetMs: Int = 0,
    /** Unduh otomatis lagu yang disukai saat memakai Wi-Fi. */
    val autoDownloadLiked: Boolean = false,
    /** Profil audio otomatis per jenis perangkat (lihat [DeviceProfile]). */
    val profileBluetooth: String = DeviceProfile.NONE,
    val profileWired: String = DeviceProfile.NONE,
    val profilePhone: String = DeviceProfile.NONE,
    /** Client ID SoundCloud untuk impor playlist. Kosong = dicari otomatis dari situs SoundCloud. */
    val soundcloudClientId: String = "",
    /** Alamat dasar API SoundCloud (bisa diganti bila SoundCloud memindahkannya). */
    val soundcloudApiBase: String = SOUNDCLOUD_API_DEFAULT,
    /** Sumber lagu: YouTube Music (InnerTubeX) dan SoundCloud. Minimal satu harus aktif. */
    val useYoutube: Boolean = true,
    val useSoundcloud: Boolean = true,
    /** Mode game: panel musik melayang yang dipicu dari tepi kiri layar saat bermain game. */
    val gameMode: Boolean = false,
    /** Cara mengenali game: [GameDetect.AUTO], [GameDetect.MANUAL], atau [GameDetect.ALWAYS]. */
    val gameDetect: String = GameDetect.AUTO,
    /** Paket game pilihan sendiri (dipakai mode Manual, dan ikut dihitung di mode Otomatis). */
    val gameApps: Set<String> = emptySet(),
    /** Posisi vertikal pemicu di tepi kiri, 0..1 dari tinggi layar. */
    val gameTriggerY: Float = 0.25f,
    /** Mode game: animasi bola jatuh + pil kecil berisi judul lagu setiap kali lagu berganti. */
    val gameSongNotif: Boolean = true,
    /** Dynamic bar: pil musik melayang di sekitar kamera depan (ala Dynamic Island). */
    val dynamicBar: Boolean = false,
    /** Bentuk kamera untuk dynamic bar: "auto", "tompel" (lubang bulat), atau "menyatu" (poni / menyatu dengan tepi). */
    val dynamicBarCamera: String = "auto",
    /** Gaya tampilan (Visualy): kunci [UiStyle]. */
    val uiStyle: String = UiStyle.ALTERLIST.key,
    /** Fitur debug: Visual nada (cincin nada Do Re Mi) ikut dalam putaran ketuk sampul. */
    val debugNoteVisual: Boolean = false,
)

/** Pilihan cara mendeteksi game untuk mode game. */
object GameDetect {
    const val AUTO = "auto"
    const val MANUAL = "manual"
    const val ALWAYS = "always"
}

const val SOUNDCLOUD_API_DEFAULT = "https://api-v2.soundcloud.com"

/** Nilai profil audio per perangkat. */
object DeviceProfile {
    const val NONE = "none"
    const val NORMAL = "normal"
    const val WIDE_3D = "3d"
    const val ORBIT_8D = "8d"
    const val BASS = "bass"
    const val VOCAL = "vokal"

    val options: List<Pair<String, String>> =
        listOf(NONE to "Tidak diubah", NORMAL to "Normal", WIDE_3D to "3D", ORBIT_8D to "8D", BASS to "Bass", VOCAL to "Vokal")
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("alterlist_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppSettingsState> = _state.asStateFlow()

    init {
        // gaya tampilan sudah benar sejak frame pertama (sebelum layar apa pun digambar)
        UiStyleState.current = UiStyle.from(_state.value.uiStyle)
    }

    private fun read() =
        AppSettingsState(
            fadeMs = prefs.getInt("fadeMs", 0).coerceIn(0, 12_000),
            skipSilence = prefs.getBoolean("skipSilence", false),
            localMinSeconds = prefs.getInt("localMinSeconds", 20).coerceIn(0, 300),
            outputToast = prefs.getBoolean("outputToast", true),
            translateLang = prefs.getString("translateLang", "").orEmpty(),
            lyricOffsetMs = prefs.getInt("lyricOffsetMs", 0).coerceIn(-10_000, 10_000),
            autoDownloadLiked = prefs.getBoolean("autoDownloadLiked", false),
            profileBluetooth = prefs.getString("profileBluetooth", DeviceProfile.NONE).orEmpty(),
            profileWired = prefs.getString("profileWired", DeviceProfile.NONE).orEmpty(),
            profilePhone = prefs.getString("profilePhone", DeviceProfile.NONE).orEmpty(),
            soundcloudClientId = prefs.getString("soundcloudClientId", "").orEmpty(),
            soundcloudApiBase = prefs.getString("soundcloudApiBase", SOUNDCLOUD_API_DEFAULT).orEmpty().ifBlank { SOUNDCLOUD_API_DEFAULT },
            useYoutube = prefs.getBoolean("useYoutube", true),
            useSoundcloud = prefs.getBoolean("useSoundcloud", true),
            gameMode = prefs.getBoolean("gameMode", false),
            dynamicBar = prefs.getBoolean("dynamicBar", false),
            dynamicBarCamera = prefs.getString("dynamicBarCamera", "auto").orEmpty().ifBlank { "auto" },
            uiStyle = UiStyle.from(prefs.getString("uiStyle", UiStyle.ALTERLIST.key)).key,
            debugNoteVisual = prefs.getBoolean("debugNoteVisual", false),
            gameDetect = prefs.getString("gameDetect", GameDetect.AUTO).orEmpty().ifBlank { GameDetect.AUTO },
            gameApps = prefs.getStringSet("gameApps", emptySet())?.toSet().orEmpty(),
            gameTriggerY = prefs.getFloat("gameTriggerY", 0.25f).coerceIn(0.08f, 0.92f),
            gameSongNotif = prefs.getBoolean("gameSongNotif", true),
        )

    fun setFadeMs(ms: Int) {
        val v = ms.coerceIn(0, 12_000)
        prefs.edit().putInt("fadeMs", v).apply()
        _state.update { it.copy(fadeMs = v) }
    }

    fun setSkipSilence(on: Boolean) {
        prefs.edit().putBoolean("skipSilence", on).apply()
        _state.update { it.copy(skipSilence = on) }
    }

    fun setLocalMinSeconds(sec: Int) {
        val v = sec.coerceIn(0, 300)
        prefs.edit().putInt("localMinSeconds", v).apply()
        _state.update { it.copy(localMinSeconds = v) }
    }

    fun setOutputToast(on: Boolean) {
        prefs.edit().putBoolean("outputToast", on).apply()
        _state.update { it.copy(outputToast = on) }
    }

    fun setTranslateLang(code: String) {
        prefs.edit().putString("translateLang", code).apply()
        _state.update { it.copy(translateLang = code) }
    }

    fun setLyricOffsetMs(ms: Int) {
        val v = ms.coerceIn(-10_000, 10_000)
        prefs.edit().putInt("lyricOffsetMs", v).apply()
        _state.update { it.copy(lyricOffsetMs = v) }
    }

    fun setAutoDownloadLiked(on: Boolean) {
        prefs.edit().putBoolean("autoDownloadLiked", on).apply()
        _state.update { it.copy(autoDownloadLiked = on) }
    }

    fun setProfileBluetooth(v: String) {
        prefs.edit().putString("profileBluetooth", v).apply()
        _state.update { it.copy(profileBluetooth = v) }
    }

    fun setProfileWired(v: String) {
        prefs.edit().putString("profileWired", v).apply()
        _state.update { it.copy(profileWired = v) }
    }

    fun setProfilePhone(v: String) {
        prefs.edit().putString("profilePhone", v).apply()
        _state.update { it.copy(profilePhone = v) }
    }

    /** Client ID SoundCloud; kosong = otomatis. */
    fun setSoundcloudClientId(v: String) {
        val id = v.trim()
        prefs.edit().putString("soundcloudClientId", id).apply()
        _state.update { it.copy(soundcloudClientId = id) }
    }

    /** Alamat dasar API SoundCloud; kosong = bawaan. */
    fun setSoundcloudApiBase(v: String) {
        val base = v.trim().trimEnd('/').ifBlank { SOUNDCLOUD_API_DEFAULT }
        prefs.edit().putString("soundcloudApiBase", base).apply()
        _state.update { it.copy(soundcloudApiBase = base) }
    }

    /** Aktif/nonaktifkan YouTube Music. Mengembalikan false bila ditolak karena akan membuat tidak ada sumber tersisa. */
    fun setUseYoutube(on: Boolean): Boolean {
        if (!on && !_state.value.useSoundcloud) return false
        prefs.edit().putBoolean("useYoutube", on).apply()
        _state.update { it.copy(useYoutube = on) }
        return true
    }

    /** Aktif/nonaktifkan SoundCloud. Mengembalikan false bila ditolak karena akan membuat tidak ada sumber tersisa. */
    fun setUseSoundcloud(on: Boolean): Boolean {
        if (!on && !_state.value.useYoutube) return false
        prefs.edit().putBoolean("useSoundcloud", on).apply()
        _state.update { it.copy(useSoundcloud = on) }
        return true
    }

    fun setGameMode(on: Boolean) {
        prefs.edit().putBoolean("gameMode", on).apply()
        _state.update { it.copy(gameMode = on) }
    }

    fun setDynamicBar(on: Boolean) {
        prefs.edit().putBoolean("dynamicBar", on).apply()
        _state.update { it.copy(dynamicBar = on) }
    }

    fun setDebugNoteVisual(on: Boolean) {
        prefs.edit().putBoolean("debugNoteVisual", on).apply()
        _state.update { it.copy(debugNoteVisual = on) }
    }

    fun setUiStyle(style: UiStyle) {
        prefs.edit().putString("uiStyle", style.key).apply()
        _state.update { it.copy(uiStyle = style.key) }
        UiStyleState.current = style
    }

    fun setDynamicBarCamera(v: String) {
        prefs.edit().putString("dynamicBarCamera", v).apply()
        _state.update { it.copy(dynamicBarCamera = v) }
    }

    fun setGameDetect(v: String) {
        prefs.edit().putString("gameDetect", v).apply()
        _state.update { it.copy(gameDetect = v) }
    }

    fun setGameApps(apps: Set<String>) {
        prefs.edit().putStringSet("gameApps", apps.toSet()).apply()
        _state.update { it.copy(gameApps = apps.toSet()) }
    }

    fun setGameTriggerY(v: Float) {
        val y = v.coerceIn(0.08f, 0.92f)
        prefs.edit().putFloat("gameTriggerY", y).apply()
        _state.update { it.copy(gameTriggerY = y) }
    }

    fun setGameSongNotif(on: Boolean) {
        prefs.edit().putBoolean("gameSongNotif", on).apply()
        _state.update { it.copy(gameSongNotif = on) }
    }
}
