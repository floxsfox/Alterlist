package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Pengaturan aplikasi yang bukan bagian dari pustaka (pemutaran, musik lokal, notifikasi perangkat audio). */
data class AppSettingsState(
    /** Lama fade di awal/akhir lagu (ms). 0 = mati. */
    val fadeMs: Int = 0,
    /** Lewati bagian hening di dalam lagu. */
    val skipSilence: Boolean = false,
    /** Abaikan audio lokal yang lebih pendek dari ini (detik). */
    val localMinSeconds: Int = 20,
    /** Tampilkan notifikasi singkat saat speaker / earphone Bluetooth tersambung. */
    val outputToast: Boolean = true,
)

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("alterlist_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppSettingsState> = _state.asStateFlow()

    private fun read() =
        AppSettingsState(
            fadeMs = prefs.getInt("fadeMs", 0).coerceIn(0, 12_000),
            skipSilence = prefs.getBoolean("skipSilence", false),
            localMinSeconds = prefs.getInt("localMinSeconds", 20).coerceIn(0, 300),
            outputToast = prefs.getBoolean("outputToast", true),
        )

    fun setFadeMs(ms: Int) {
        val v = ms.coerceIn(0, 12_000)
        prefs.edit().putInt("fadeMs", v).apply()
        _state.update { it.copy(fadeMs = v) }
    }

    fun setSkipSilence(on: Boolean) {
        prefs.edit().putBoolean("skipSilence", on).apply()
        _state.update { it.copy(skipSilence = on) }
    }

    fun setLocalMinSeconds(sec: Int) {
        val v = sec.coerceIn(0, 300)
        prefs.edit().putInt("localMinSeconds", v).apply()
        _state.update { it.copy(localMinSeconds = v) }
    }

    fun setOutputToast(on: Boolean) {
        prefs.edit().putBoolean("outputToast", on).apply()
        _state.update { it.copy(outputToast = on) }
    }
}
