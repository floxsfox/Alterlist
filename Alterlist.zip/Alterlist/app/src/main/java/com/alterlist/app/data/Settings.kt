package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Pengaturan aplikasi yang bukan bagian dari pustaka (pemutaran, musik lokal, lirik, profil perangkat audio). */
data class AppSettingsState(
    /** Lama fade di awal/akhir lagu (ms). 0 = mati. */
    val fadeMs: Int = 0,
    /** Lewati bagian hening di dalam lagu. */
    val skipSilence: Boolean = false,
    /** Abaikan audio lokal yang lebih pendek dari ini (detik). */
    val localMinSeconds: Int = 20,
    /** Tampilkan notifikasi singkat saat speaker / earphone Bluetooth tersambung. */
    val outputToast: Boolean = true,
    /** Kode bahasa terjemahan lirik ("" = mati). */
    val translateLang: String = "",
    /** Geser waktu lirik (ms), negatif = lebih cepat. */
    val lyricOffsetMs: Int = 0,
    /** Unduh otomatis lagu yang disukai saat memakai Wi-Fi. */
    val autoDownloadLiked: Boolean = false,
    /** Profil audio otomatis per jenis perangkat (lihat [DeviceProfile]). */
    val profileBluetooth: String = DeviceProfile.NONE,
    val profileWired: String = DeviceProfile.NONE,
    val profilePhone: String = DeviceProfile.NONE,
)

/** Nilai profil audio per perangkat. */
object DeviceProfile {
    const val NONE = "none"
    const val NORMAL = "normal"
    const val WIDE_3D = "3d"
    const val ORBIT_8D = "8d"
    const val BASS = "bass"
    const val VOCAL = "vokal"

    val options: List<Pair<String, String>> =
        listOf(NONE to "Tidak diubah", NORMAL to "Normal", WIDE_3D to "3D", ORBIT_8D to "8D", BASS to "Bass", VOCAL to "Vokal")
}

class AppSettings(context: Context) {
    private val prefs = context.getSharedPreferences("alterlist_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AppSettingsState> = _state.asStateFlow()

    private fun read() =
        AppSettingsState(
            fadeMs = prefs.getInt("fadeMs", 0).coerceIn(0, 12_000),
            skipSilence = prefs.getBoolean("skipSilence", false),
            localMinSeconds = prefs.getInt("localMinSeconds", 20).coerceIn(0, 300),
            outputToast = prefs.getBoolean("outputToast", true),
            translateLang = prefs.getString("translateLang", "").orEmpty(),
            lyricOffsetMs = prefs.getInt("lyricOffsetMs", 0).coerceIn(-10_000, 10_000),
            autoDownloadLiked = prefs.getBoolean("autoDownloadLiked", false),
            profileBluetooth = prefs.getString("profileBluetooth", DeviceProfile.NONE).orEmpty(),
            profileWired = prefs.getString("profileWired", DeviceProfile.NONE).orEmpty(),
            profilePhone = prefs.getString("profilePhone", DeviceProfile.NONE).orEmpty(),
        )

    fun setFadeMs(ms: Int) {
        val v = ms.coerceIn(0, 12_000)
        prefs.edit().putInt("fadeMs", v).apply()
        _state.update { it.copy(fadeMs = v) }
    }

    fun setSkipSilence(on: Boolean) {
        prefs.edit().putBoolean("skipSilence", on).apply()
        _state.update { it.copy(skipSilence = on) }
    }

    fun setLocalMinSeconds(sec: Int) {
        val v = sec.coerceIn(0, 300)
        prefs.edit().putInt("localMinSeconds", v).apply()
        _state.update { it.copy(localMinSeconds = v) }
    }

    fun setOutputToast(on: Boolean) {
        prefs.edit().putBoolean("outputToast", on).apply()
        _state.update { it.copy(outputToast = on) }
    }

    fun setTranslateLang(code: String) {
        prefs.edit().putString("translateLang", code).apply()
        _state.update { it.copy(translateLang = code) }
    }

    fun setLyricOffsetMs(ms: Int) {
        val v = ms.coerceIn(-10_000, 10_000)
        prefs.edit().putInt("lyricOffsetMs", v).apply()
        _state.update { it.copy(lyricOffsetMs = v) }
    }

    fun setAutoDownloadLiked(on: Boolean) {
        prefs.edit().putBoolean("autoDownloadLiked", on).apply()
        _state.update { it.copy(autoDownloadLiked = on) }
    }

    fun setProfileBluetooth(v: String) {
        prefs.edit().putString("profileBluetooth", v).apply()
        _state.update { it.copy(profileBluetooth = v) }
    }

    fun setProfileWired(v: String) {
        prefs.edit().putString("profileWired", v).apply()
        _state.update { it.copy(profileWired = v) }
    }

    fun setProfilePhone(v: String) {
        prefs.edit().putString("profilePhone", v).apply()
        _state.update { it.copy(profilePhone = v) }
    }
}
