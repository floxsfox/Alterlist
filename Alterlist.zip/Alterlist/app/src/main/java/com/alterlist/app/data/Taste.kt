package com.alterlist.app.data

import java.util.Locale
import kotlin.math.pow

/** Seorang artis beserta bobot kesukaanmu padanya. */
data class WeightedArtist(
    val name: String,
    val id: String?,
    val thumbnail: String?,
    val weight: Double,
    val topSong: Song,
)

/**
 * Profil selera yang dibangun di HP dari kebiasaanmu: lagu yang sering diputar, yang disukai, riwayat terbaru,
 * artis yang diikuti, dan genre yang kamu pilih sendiri. Tidak ada data yang dikirim ke server mana pun.
 */
data class TasteProfile(
    val artists: List<WeightedArtist>,
    val tags: List<Pair<String, Double>>,
    val seeds: List<Song>,
    val seedWeights: Map<String, Double>,
    val picks: List<String>,
    val hasHistory: Boolean,
) {
    /** Tanda tangan singkat profil; kalau berubah banyak, rekomendasi dibangun ulang. */
    val key: String
        get() = seeds.take(6).joinToString(",") { it.id } + "|" + picks.sorted().joinToString(",")

    fun artistWeight(name: String): Double {
        val n = name.lowercase(Locale.ROOT)
        return artists.firstOrNull { it.name.lowercase(Locale.ROOT) == n }?.weight ?: 0.0
    }

    fun tagWeight(tag: String): Double = tags.firstOrNull { it.first == tag }?.second ?: 0.0
}

object Taste {
    private const val DAY_MS = 86_400_000.0

    fun build(lib: LibraryData, now: Long = System.currentTimeMillis()): TasteProfile {
        val songWeight = HashMap<String, Double>()
        val songRef = HashMap<String, Song>()

        fun add(song: Song, w: Double) {
            if (song.isLocal) return
            songRef[song.id] = song
            songWeight[song.id] = (songWeight[song.id] ?: 0.0) + w
        }

        // lagu yang sering diputar, makin baru makin berbobot
        for (stat in lib.stats.values) {
            val ageDays = ((now - stat.last).coerceAtLeast(0L)) / DAY_MS
            val decay = 0.5.pow(ageDays / 30.0).coerceAtLeast(0.25)
            add(stat.song, stat.count.toDouble().pow(0.7) * decay)
        }
        // lagu disukai
        lib.liked.forEachIndexed { i, s -> add(s, 3.0 * 0.985.pow(i.toDouble())) }
        // riwayat terbaru
        lib.recent.take(40).forEachIndexed { i, s -> add(s, 1.2 * 0.95.pow(i.toDouble())) }

        // bobot artis
        val artistAgg = HashMap<String, MutableList<Pair<Song, Double>>>()
        for ((id, w) in songWeight) {
            val song = songRef[id] ?: continue
            val name = primaryArtist(song.artist)
            if (name.isBlank()) continue
            artistAgg.getOrPut(name.lowercase(Locale.ROOT)) { ArrayList() }.add(song to w)
        }
        val followedIds = lib.artists.map { it.id }.toHashSet()
        val artists =
            artistAgg.values
                .map { list ->
                    val best = list.maxByOrNull { it.second }!!.first
                    val bonus = if (best.artistId != null && best.artistId in followedIds) 4.0 else 0.0
                    WeightedArtist(
                        name = primaryArtist(best.artist),
                        id = best.artistId,
                        thumbnail = best.thumbnail,
                        weight = list.sumOf { it.second } + bonus,
                        topSong = best,
                    )
                }
                .sortedByDescending { it.weight }

        // bobot genre
        val tagAgg = HashMap<String, Double>()
        for ((id, w) in songWeight) {
            val song = songRef[id] ?: continue
            for (t in GenreTags.infer(song)) tagAgg[t] = (tagAgg[t] ?: 0.0) + w
        }
        for (pick in lib.tastePicks) tagAgg[pick] = (tagAgg[pick] ?: 0.0) + 4.0
        val tags = tagAgg.entries.sortedByDescending { it.value }.map { it.key to it.value }

        // lagu benih: beragam artis, maksimal 2 per artis
        val perArtist = HashMap<String, Int>()
        val seeds = ArrayList<Song>()
        for ((id, _) in songWeight.entries.sortedByDescending { it.value }) {
            val song = songRef[id] ?: continue
            val a = primaryArtist(song.artist).lowercase(Locale.ROOT)
            val used = perArtist[a] ?: 0
            if (used >= 2) continue
            perArtist[a] = used + 1
            seeds.add(song)
            if (seeds.size >= 14) break
        }

        return TasteProfile(
            artists = artists,
            tags = tags,
            seeds = seeds,
            seedWeights = songWeight,
            picks = lib.tastePicks,
            hasHistory = songWeight.isNotEmpty(),
        )
    }
}
