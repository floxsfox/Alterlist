package com.alterlist.app.system

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.alterlist.app.AlterApp
import com.alterlist.app.MainActivity
import com.alterlist.app.R
import com.alterlist.app.data.GameDetect
import com.alterlist.app.data.Song
import com.alterlist.app.ui.AlterTheme
import com.alterlist.app.ui.GamePanel
import com.alterlist.app.ui.SongBallNotif
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Mode game: saat game berjalan di depan, tepi kiri layar diberi pemicu kecil (pil putih). Geser pemicu ke kanan
 * (atau ketuk) untuk membuka panel musik di atas game, tanpa membuka aplikasi Alterlist. Panel tidak merebut fokus
 * jendela, jadi game tetap berjalan; fokus hanya diminta sebentar saat mengetik di kolom pencarian.
 *
 * Layanan ini berjalan sebagai foreground service (notifikasi senyap) supaya tidak dimatikan sistem.
 */
class GameOverlayService : Service() {
    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val owner = OverlayOwner()

    private var tracker: ForegroundTracker? = null
    private var pollJob: Job? = null
    private var screenOn = true

    private var trigger: TriggerView? = null
    private var triggerParams: WindowManager.LayoutParams? = null
    private var triggerY = -1f

    private var panelRoot: PanelRoot? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panelVisible by mutableStateOf(false)
    private var closeJob: Job? = null

    // notifikasi lagu berikutnya (bola jatuh -> pil -> bola terlempar ke atas)
    private var songWatchJob: Job? = null
    private var songNotif: ComposeView? = null
    private var lastSongId: String? = null
    private var songBaselineSet = false

    private val screenReceiver =
        object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> {
                        screenOn = false
                        hideSongNotif()
                        hidePanelNow()
                        hideTrigger()
                    }
                    Intent.ACTION_SCREEN_ON -> screenOn = true
                }
            }
        }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        owner.create()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            AlterApp.instance.settings.setGameMode(false)
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!GameDetector.hasOverlayPermission(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        startPolling()
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // layar diputar: hitung ulang posisi pemicu; ukuran panel mengikuti jendela layar penuh
        triggerY = -1f
        if (trigger != null) layoutTrigger()
    }

    override fun onDestroy() {
        pollJob?.cancel()
        songWatchJob?.cancel()
        hideSongNotif()
        hidePanelNow()
        hideTrigger()
        runCatching { unregisterReceiver(screenReceiver) }
        scope.cancel()
        owner.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- foreground

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Mode game", NotificationManager.IMPORTANCE_MIN).apply { setShowBadge(false) },
        )
        val open =
            PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop =
            PendingIntent.getService(
                this,
                1,
                Intent(this, GameOverlayService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        val notification =
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_alterlist)
                .setContentTitle("Mode game aktif")
                .setContentText("Saat bermain, geser dari tepi kiri layar untuk membuka panel musik.")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), "Matikan", stop).build())
                .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // ---------------------------------------------------------------- deteksi game

    private fun startPolling() {
        if (pollJob?.isActive == true) return
        AlterApp.instance.player.connect()
        startSongWatch()
        tracker = ForegroundTracker(this)
        pollJob =
            scope.launch {
                while (isActive) {
                    if (screenOn) evaluate()
                    delay(POLL_MS)
                }
            }
    }

    private fun evaluate() {
        val app = AlterApp.instance
        val st = app.settings.state.value
        if (!st.gameMode) {
            stopSelf()
            return
        }
        val usage = GameDetector.hasUsageAccess(this)
        val pkg = if (usage) tracker?.poll() else null
        val show =
            when {
                st.gameDetect == GameDetect.ALWAYS -> pkg != packageName
                !usage -> false
                else -> GameDetector.shouldShow(this, pkg, st)
            }
        if (show) {
            if (trigger == null) showTrigger()
            if (abs(triggerY - st.gameTriggerY) > 0.001f) layoutTrigger()
        } else {
            hideSongNotif()
            hidePanelNow()
            hideTrigger()
        }
    }

    // ---------------------------------------------------------------- notifikasi lagu berikutnya

    /** Pantau pergantian lagu. Nilai pertama hanya dicatat sebagai acuan supaya tidak muncul saat mode game baru menyala. */
    private fun startSongWatch() {
        if (songWatchJob?.isActive == true) return
        songWatchJob =
            scope.launch {
                AlterApp.instance.player.state
                    .map { it.current }
                    .distinctUntilChangedBy { it?.id }
                    .collect { song -> onSongChanged(song) }
            }
    }

    private fun onSongChanged(song: Song?) {
        val previous = lastSongId
        lastSongId = song?.id
        if (!songBaselineSet) {
            songBaselineSet = true
            return
        }
        if (song == null || song.id == previous) return
        val st = AlterApp.instance.settings.state.value
        // hanya saat game di depan, layar menyala, dan panel tertutup (panel sudah menampilkan lagunya sendiri)
        if (!st.gameSongNotif || !screenOn || trigger == null || (panelRoot != null && panelVisible)) return
        showSongNotif(song)
    }

    private fun showSongNotif(song: Song) {
        hideSongNotif()
        val view =
            ComposeView(this).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
                setContent {
                    AlterTheme {
                        SongBallNotif(
                            song = song,
                            topOffsetDp = songBallTopDp(),
                            onFinished = { hideSongNotif(this) },
                        )
                    }
                }
            }
        val params =
            baseParams(WindowManager.LayoutParams.MATCH_PARENT, dp(NOTIF_H_DP)).apply {
                gravity = Gravity.TOP or Gravity.START
                // tidak bisa disentuh dan tidak merebut fokus: sentuhan tetap tembus ke game
                flags =
                    flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            }
        try {
            wm.addView(view, params)
            songNotif = view
        } catch (e: Exception) {
            songNotif = null
        }
    }

    /** Lepas jendela notifikasi. [only] diisi dari animasi yang selesai supaya tidak ikut melepas notifikasi yang lebih baru. */
    private fun hideSongNotif(only: ComposeView? = null) {
        val v = songNotif ?: return
        if (only != null && only !== v) return
        songNotif = null
        runCatching { wm.removeView(v) }
    }

    /** Bola mendarat di pita bilah status: tengahnya sejajar dengan tengah bilah status (minimal 4dp dari tepi atas). */
    private fun songBallTopDp(): Float {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val statusPx = if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
        val statusDp = statusPx / resources.displayMetrics.density
        return ((statusDp - BALL_DP) / 2f).coerceAtLeast(4f)
    }

    // ---------------------------------------------------------------- pemicu di tepi kiri

    private fun showTrigger() {
        if (trigger != null) return
        val view = TriggerView(this)
        val params =
            baseParams(dp(TRIGGER_W_DP), dp(TRIGGER_H_DP)).apply {
                gravity = Gravity.START or Gravity.TOP
                flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            }
        try {
            wm.addView(view, params)
            trigger = view
            triggerParams = params
            triggerY = -1f
            layoutTrigger()
        } catch (e: Exception) {
            // izin tampil di atas aplikasi lain dicabut / jendela ditolak: coba lagi di putaran berikutnya
            trigger = null
            triggerParams = null
        }
    }

    private fun layoutTrigger() {
        val view = trigger ?: return
        val params = triggerParams ?: return
        val st = AlterApp.instance.settings.state.value
        val (_, h) = screenSize()
        params.x = 0
        params.y = (h * st.gameTriggerY - params.height / 2f).toInt().coerceIn(0, (h - params.height).coerceAtLeast(0))
        triggerY = st.gameTriggerY
        runCatching { wm.updateViewLayout(view, params) }
    }

    private fun hideTrigger() {
        val v = trigger ?: return
        runCatching { wm.removeView(v) }
        trigger = null
        triggerParams = null
    }

    // ---------------------------------------------------------------- panel

    private fun openPanel() {
        hideSongNotif()
        closeJob?.cancel()
        if (panelRoot != null) {
            panelVisible = true
            return
        }
        val root = PanelRoot(this)
        root.setViewTreeLifecycleOwner(owner)
        root.setViewTreeSavedStateRegistryOwner(owner)
        root.setViewTreeViewModelStoreOwner(owner)
        val compose =
            ComposeView(this).apply {
                setViewTreeLifecycleOwner(owner)
                setViewTreeSavedStateRegistryOwner(owner)
                setViewTreeViewModelStoreOwner(owner)
                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
                setContent {
                    AlterTheme {
                        GamePanel(
                            visible = panelVisible,
                            onClose = { closePanel() },
                            onFocusable = { setPanelFocusable(it) },
                        )
                    }
                }
            }
        root.addView(compose, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val params =
            baseParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT).apply {
                // tidak fokus: game di belakang tetap berjalan. Fokus hanya diminta sementara saat mengetik.
                flags = flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            }
        try {
            wm.addView(root, params)
            panelRoot = root
            panelParams = params
            // satu frame setelah terpasang agar animasi masuk berjalan
            root.post { panelVisible = true }
        } catch (e: Exception) {
            panelRoot = null
            panelParams = null
        }
    }

    private fun closePanel() {
        panelVisible = false
        setPanelFocusable(false)
        closeJob?.cancel()
        closeJob =
            scope.launch {
                delay(300) // tunggu animasi keluar selesai
                if (!panelVisible) removePanel()
            }
    }

    private fun hidePanelNow() {
        closeJob?.cancel()
        panelVisible = false
        removePanel()
    }

    private fun removePanel() {
        val root = panelRoot ?: return
        runCatching { wm.removeView(root) }
        panelRoot = null
        panelParams = null
    }

    /** Beri/lepas fokus jendela panel (keyboard butuh fokus; game sebaiknya tidak kehilangan fokus). */
    private fun setPanelFocusable(focusable: Boolean) {
        val root = panelRoot ?: return
        val params = panelParams ?: return
        val notFocusable = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        params.flags = if (focusable) params.flags and notFocusable.inv() else params.flags or notFocusable
        runCatching { wm.updateViewLayout(root, params) }
    }

    // ---------------------------------------------------------------- util

    private fun baseParams(w: Int, h: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            layoutInDisplayCutoutMode =
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
        }

    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun dpf(v: Float): Float = v * resources.displayMetrics.density

    /**
     * Pil putih kecil di tepi kiri. Hanya GESERAN deliberat dari tepi ke arah dalam layar yang membuka panel; ketukan,
     * sentuhan singkat, dan gerakan miring/goyang diabaikan. Aman untuk pemain yang bermain dengan banyak jari dan cepat.
     */
    private inner class TriggerView(context: Context) : View(context) {
        private val pill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f
        private var downY = 0f
        private var fired = false
        private var cancelled = false

        override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
            super.onLayout(changed, left, top, right, bottom)
            // pemicu tidak boleh kalah oleh gestur kembali dari tepi layar
            if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(Rect(0, 0, right - left, bottom - top))
        }

        override fun onDraw(canvas: Canvas) {
            val h = height.toFloat()
            val pillH = h * 0.60f
            val top = (h - pillH) / 2f
            val x = dpf(3f)
            val w = dpf(5f)
            glow.color = 0x33FF3B30
            canvas.drawRoundRect(RectF(x - dpf(2f), top - dpf(3f), x + w + dpf(2f), top + pillH + dpf(3f)), dpf(5f), dpf(5f), glow)
            pill.color = 0xE6FFFFFF.toInt()
            canvas.drawRoundRect(RectF(x, top, x + w, top + pillH), w / 2f, w / 2f, pill)
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    fired = false
                    cancelled = false
                }
                // jari kedua menyentuh pemicu = bukan geseran yang disengaja
                MotionEvent.ACTION_POINTER_DOWN -> cancelled = true
                MotionEvent.ACTION_MOVE ->
                    if (!fired && !cancelled) {
                        val dx = e.rawX - downX
                        val dy = abs(e.rawY - downY)
                        // harus ke arah dalam layar, cukup jauh, dan dominan mendatar
                        if (dx > dpf(SWIPE_MIN_DP) && dx > dy * 1.3f) {
                            fired = true
                            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            openPanel()
                        } else if (dy > dpf(SWIPE_MIN_DP) * 1.5f && dy > abs(dx)) {
                            cancelled = true // geseran tegak: bukan untuk membuka panel
                        }
                    }
                MotionEvent.ACTION_CANCEL -> cancelled = true
            }
            return true
        }
    }

    /** Akar jendela panel: tombol Kembali menutup panel (hanya terkirim saat jendela sedang fokus, mis. saat mengetik). */
    private inner class PanelRoot(context: Context) : FrameLayout(context) {
        override fun dispatchKeyEvent(event: KeyEvent): Boolean {
            if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                if (event.action == KeyEvent.ACTION_UP) closePanel()
                return true
            }
            return super.dispatchKeyEvent(event)
        }
    }

    /** Pemilik lifecycle / saved state untuk ComposeView yang hidup di dalam Service (bukan Activity). */
    private class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
        private val registry = LifecycleRegistry(this)
        private val controller = SavedStateRegistryController.create(this)
        private val store = ViewModelStore()

        override val lifecycle: Lifecycle get() = registry
        override val savedStateRegistry: SavedStateRegistry get() = controller.savedStateRegistry
        override val viewModelStore: ViewModelStore get() = store

        fun create() {
            controller.performAttach()
            controller.performRestore(null)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        }

        fun destroy() {
            registry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
            registry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
            store.clear()
        }
    }

    companion object {
        const val ACTION_STOP = "com.alterlist.app.GAME_MODE_STOP"
        private const val CHANNEL_ID = "game_mode"
        private const val NOTIFICATION_ID = 7301
        private const val POLL_MS = 1200L
        private const val TRIGGER_W_DP = 24
        private const val TRIGGER_H_DP = 80
        private const val SWIPE_MIN_DP = 22f
        private const val NOTIF_H_DP = 110
        private const val BALL_DP = 30f
    }
}
