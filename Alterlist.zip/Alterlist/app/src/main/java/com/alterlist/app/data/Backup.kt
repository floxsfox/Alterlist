package com.alterlist.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
private class BackupFile(
    val app: String = "Alterlist",
    val version: Int = 1,
    val createdAt: Long = 0L,
    val library: LibraryData = LibraryData(),
)

/**
 * Cadangan pustaka ke satu berkas JSON (lagu disukai, playlist, riwayat, statistik, artis, genre pilihan).
 * Berkas lagu unduhan tidak ikut dicadangkan; daftar unduhan dikosongkan saat dipulihkan supaya tidak menunjuk berkas yang hilang.
 */
object Backup {
    private val json =
        Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
            prettyPrint = true
        }

    suspend fun exportTo(context: Context, library: Library, target: Uri): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val file = BackupFile(createdAt = System.currentTimeMillis(), library = library.snapshot())
                val text = json.encodeToString(BackupFile.serializer(), file)
                context.contentResolver.openOutputStream(target, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) } != null
            } catch (e: Exception) {
                false
            }
        }

    /** @return jumlah lagu disukai + playlist yang dipulihkan, atau null kalau berkas tidak valid */
    suspend fun restore(context: Context, library: Library, source: Uri): Int? =
        withContext(Dispatchers.IO) {
            try {
                val text = context.contentResolver.openInputStream(source)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return@withContext null
                val file = json.decodeFromString(BackupFile.serializer(), text)
                if (file.app != "Alterlist") return@withContext null
                val restored = file.library.copy(downloads = emptyList())
                // unduhan yang ada di HP ini dipertahankan
                library.replaceAll(restored.copy(downloads = library.snapshot().downloads))
                restored.liked.size + restored.playlists.size
            } catch (e: Exception) {
                null
            }
        }
}
