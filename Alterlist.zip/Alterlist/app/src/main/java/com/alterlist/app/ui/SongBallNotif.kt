package com.alterlist.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.data.Song
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Garis tengah bola (cover lagu). Kecil supaya tidak mengganggu permainan. */
private val BallSize = 30.dp

/**
 * Notifikasi lagu berikutnya untuk mode game.
 *
 * Urutan animasi:
 *  1. bola (cover lagu) jatuh dari atas layar dan mendarat di sisi atas ponsel (memantul sedikit, gepeng saat mendarat),
 *  2. bola memanjang menjadi pil kecil yang menampilkan judul lagu,
 *  3. setelah sebentar, pil mengerut kembali menjadi bola lalu terlempar ke atas dan keluar layar,
 *  4. [onFinished] dipanggil supaya jendela overlay dilepas.
 *
 * @param topOffsetDp jarak bola dari tepi atas layar saat mendarat.
 */
@Composable
fun SongBallNotif(song: Song, topOffsetDp: Float, onFinished: () -> Unit) {
    val density = LocalDensity.current
    val measurer = rememberTextMeasurer()
    val textStyle = T.small.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    val restY = topOffsetDp
    val startY = -(BallSize.value + 12f)

    // posisi tegak (dp), kemajuan pil 0..1, gepeng saat mendarat, keterlihatan teks
    val y = remember(song.id) { Animatable(startY) }
    val grow = remember(song.id) { Animatable(0f) }
    val squashX = remember(song.id) { Animatable(1f) }
    val squashY = remember(song.id) { Animatable(1f) }
    val textAlpha = remember(song.id) { Animatable(0f) }

    LaunchedEffect(song.id) {
        // 1) jatuh (makin cepat), lalu mendarat: gepeng + memantul kecil
        y.animateTo(restY, tween(380, easing = CubicBezierEasing(0.55f, 0f, 1f, 0.45f)))
        coroutineScope {
            launch {
                squashY.animateTo(0.70f, tween(70))
                squashY.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
            }
            launch {
                squashX.animateTo(1.24f, tween(70))
                squashX.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
            }
            launch {
                y.animateTo(restY - 12f, tween(120, easing = LinearOutSlowInEasing))
                y.animateTo(restY, tween(120, easing = FastOutLinearInEasing))
            }
        }
        // 2) memanjang menjadi pil, teks muncul menyusul
        coroutineScope {
            launch { grow.animateTo(1f, spring(dampingRatio = 0.75f, stiffness = 260f)) }
            launch {
                delay(150)
                textAlpha.animateTo(1f, tween(180))
            }
        }
        delay(2300)
        // 3) kembali menjadi bola, ancang-ancang sedikit ke bawah, lalu terlempar ke atas
        textAlpha.animateTo(0f, tween(110))
        grow.animateTo(0f, tween(300, easing = FastOutSlowInEasing))
        y.animateTo(restY + 6f, tween(90))
        y.animateTo(startY - 8f, tween(360, easing = CubicBezierEasing(0.5f, 0f, 1f, 1f)))
        onFinished()
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val textWidthDp =
            remember(song.title, density) {
                with(density) { measurer.measure(song.title, textStyle, softWrap = false, maxLines = 1).size.width.toDp() }
            }
        val gap = 8.dp
        val endPad = 14.dp
        val maxPill = (maxWidth - 24.dp).coerceAtLeast(BallSize)
        val fullWidth = (BallSize + gap + textWidthDp + endPad).coerceAtMost(maxPill)
        val textMax = (fullWidth - BallSize - gap - endPad).coerceAtLeast(0.dp)
        val width = BallSize + (fullWidth - BallSize) * grow.value.coerceAtLeast(0f)

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Row(
                Modifier
                    .offset(y = y.value.dp)
                    .graphicsLayer {
                        scaleX = squashX.value
                        scaleY = squashY.value
                        // gepeng dari alas bola, bukan dari tengah
                        transformOrigin = TransformOrigin(0.5f, 1f)
                    }
                    .width(width)
                    .height(BallSize)
                    .clip(CircleShape)
                    .background(Color(0xE60E0F12))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), CircleShape),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(song.thumbnail, Modifier.size(BallSize), CircleShape, px = 96)
                Box(
                    Modifier
                        .requiredWidth(textMax + gap)
                        .padding(start = gap)
                        .alpha(textAlpha.value),
                ) {
                    Text(
                        song.title,
                        style = textStyle,
                        color = Color.White,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}
