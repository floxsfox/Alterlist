package com.alterlist.app.download

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/**
 * Mengubah M4A "DASH" (fragmented MP4 yang dikirim YouTube: moov kosong + sidx + banyak moof/mdat)
 * menjadi M4A biasa (satu moov lengkap + satu mdat) supaya bisa diputar di semua aplikasi musik.
 * Audio tidak di-encode ulang, hanya dikemas ulang.
 */
object Mp4Defrag {
    private class Node(val type: String, val start: Int, val header: Int, val end: Int) {
        val payload: Int get() = start + header
    }

    private class Sample(val offset: Long, val size: Int, val duration: Long)

    /** @return false bila berkas bukan fragmented MP4 (tidak ada moof), true bila berhasil dikonversi ke [output]. */
    @Throws(IOException::class)
    fun defragment(input: File, output: File): Boolean {
        RandomAccessFile(input, "r").use { raf ->
            val top = topLevel(raf)
            val moofs = top.filter { it.type == "moof" }
            if (moofs.isEmpty()) return false
            val moovBox = top.firstOrNull { it.type == "moov" } ?: throw IOException("moov tidak ada")

            raf.seek(moovBox.start.toLong())
            val moov = ByteArray((moovBox.end - moovBox.start).toInt())
            raf.readFully(moov)
            val moovNodes = parse(moov, 8, moov.size)

            val mvhd = moovNodes.firstOrNull { it.type == "mvhd" } ?: throw IOException("mvhd tidak ada")
            val trak = moovNodes.firstOrNull { it.type == "trak" } ?: throw IOException("trak tidak ada")
            val trex = moovNodes.firstOrNull { it.type == "mvex" }?.let { parse(moov, it.payload, it.end).firstOrNull { n -> n.type == "trex" } }

            val trakNodes = parse(moov, trak.payload, trak.end)
            val tkhd = trakNodes.first { it.type == "tkhd" }
            val mdia = trakNodes.first { it.type == "mdia" }
            val mdiaNodes = parse(moov, mdia.payload, mdia.end)
            val mdhd = mdiaNodes.first { it.type == "mdhd" }
            val hdlr = mdiaNodes.first { it.type == "hdlr" }
            val minf = mdiaNodes.first { it.type == "minf" }
            val minfNodes = parse(moov, minf.payload, minf.end)
            val stbl = minfNodes.first { it.type == "stbl" }
            val stsd = parse(moov, stbl.payload, stbl.end).first { it.type == "stsd" }

            val trackId = u32(moov, tkhd.payload + (if (moov[tkhd.payload].toInt() == 1) 20 else 12)).toInt()
            val mediaTimescale = u32(moov, mdhd.payload + (if (moov[mdhd.payload].toInt() == 1) 20 else 12))
            val movieTimescale = u32(moov, mvhd.payload + (if (moov[mvhd.payload].toInt() == 1) 20 else 12))
            val trexDefaults = if (trex != null) {
                intArrayOf(
                    u32(moov, trex.payload + 8).toInt(), // sample description index (tidak dipakai)
                    u32(moov, trex.payload + 12).toInt(), // default duration
                    u32(moov, trex.payload + 16).toInt(), // default size
                )
            } else intArrayOf(1, 0, 0)

            // kumpulkan semua sampel dari setiap moof
            val samples = ArrayList<Sample>()
            for (moof in moofs) {
                raf.seek(moof.start.toLong())
                val mb = ByteArray((moof.end - moof.start).toInt())
                raf.readFully(mb)
                for (traf in parse(mb, 8, mb.size).filter { it.type == "traf" }) {
                    val tn = parse(mb, traf.payload, traf.end)
                    val tfhd = tn.firstOrNull { it.type == "tfhd" } ?: continue
                    val tfFlags = u32(mb, tfhd.payload) and 0xFFFFFF
                    if (u32(mb, tfhd.payload + 4).toInt() != trackId) continue
                    var p = tfhd.payload + 8
                    var base: Long = moof.start.toLong()
                    if (tfFlags and 0x1L != 0L) { base = u64(mb, p); p += 8 }
                    if (tfFlags and 0x2L != 0L) p += 4
                    var defDur = trexDefaults[1].toLong()
                    var defSize = trexDefaults[2]
                    if (tfFlags and 0x8L != 0L) { defDur = u32(mb, p); p += 4 }
                    if (tfFlags and 0x10L != 0L) { defSize = u32(mb, p).toInt(); p += 4 }
                    var cursor = base
                    for (trun in tn.filter { it.type == "trun" }) {
                        val flags = u32(mb, trun.payload) and 0xFFFFFF
                        val count = u32(mb, trun.payload + 4).toInt()
                        var q = trun.payload + 8
                        var dataStart = cursor
                        if (flags and 0x1L != 0L) { dataStart = base + mb.s32(q); q += 4 }
                        if (flags and 0x4L != 0L) q += 4 // first sample flags
                        var off = dataStart
                        for (i in 0 until count) {
                            var dur = defDur
                            var size = defSize
                            if (flags and 0x100L != 0L) { dur = u32(mb, q); q += 4 }
                            if (flags and 0x200L != 0L) { size = u32(mb, q).toInt(); q += 4 }
                            if (flags and 0x400L != 0L) q += 4
                            if (flags and 0x800L != 0L) q += 4
                            samples.add(Sample(off, size, dur))
                            off += size
                        }
                        cursor = off
                    }
                }
            }
            if (samples.isEmpty()) throw IOException("Tidak ada sampel audio")

            val totalDuration = samples.sumOf { it.duration }
            val movieDuration = if (mediaTimescale > 0) Math.round(totalDuration.toDouble() * movieTimescale / mediaTimescale) else totalDuration
            val totalBytes = samples.sumOf { it.size.toLong() }

            val ftyp = ByteArrayOutputStream().also {
                val d = DataOutputStream(it)
                d.writeInt(28); d.writeBytes("ftyp"); d.writeBytes("M4A "); d.writeInt(0)
                d.writeBytes("M4A "); d.writeBytes("mp42"); d.writeBytes("isom"); d.flush()
            }.toByteArray()

            fun buildMoov(chunkOffset: Long): ByteArray {
                val mvhdBytes = moov.copyOfRange(mvhd.start, mvhd.end)
                patchDuration(mvhdBytes, 8, movieDuration, "mvhd")
                val tkhdBytes = moov.copyOfRange(tkhd.start, tkhd.end)
                patchDuration(tkhdBytes, 8, movieDuration, "tkhd")
                val mdhdBytes = moov.copyOfRange(mdhd.start, mdhd.end)
                patchDuration(mdhdBytes, 8, totalDuration, "mdhd")

                val stts = ByteArrayOutputStream().also { o ->
                    val runs = ArrayList<Pair<Int, Long>>()
                    for (s in samples) {
                        if (runs.isNotEmpty() && runs.last().second == s.duration) runs[runs.size - 1] = Pair(runs.last().first + 1, s.duration)
                        else runs.add(Pair(1, s.duration))
                    }
                    val d = DataOutputStream(o)
                    d.writeInt(0); d.writeInt(runs.size)
                    for ((c, dur) in runs) { d.writeInt(c); d.writeInt(dur.toInt()) }
                    d.flush()
                }.toByteArray()
                val stsc = ByteArrayOutputStream().also { o ->
                    val d = DataOutputStream(o)
                    d.writeInt(0); d.writeInt(1); d.writeInt(1); d.writeInt(samples.size); d.writeInt(1); d.flush()
                }.toByteArray()
                val stsz = ByteArrayOutputStream().also { o ->
                    val d = DataOutputStream(o)
                    d.writeInt(0); d.writeInt(0); d.writeInt(samples.size)
                    for (s in samples) d.writeInt(s.size)
                    d.flush()
                }.toByteArray()
                val stco = ByteArrayOutputStream().also { o ->
                    val d = DataOutputStream(o)
                    d.writeInt(0); d.writeInt(1); d.writeInt(chunkOffset.toInt()); d.flush()
                }.toByteArray()

                val stblPayload = moov.copyOfRange(stsd.start, stsd.end) + box("stts", stts) + box("stsc", stsc) + box("stsz", stsz) + box("stco", stco)
                val minfPayload = ByteArrayOutputStream().also { o ->
                    for (n in minfNodes) {
                        if (n.type == "smhd" || n.type == "dinf") o.write(moov, n.start, n.end - n.start)
                    }
                    o.write(box("stbl", stblPayload))
                }.toByteArray()
                val mdiaPayload = mdhdBytes + moov.copyOfRange(hdlr.start, hdlr.end) + box("minf", minfPayload)
                val trakPayload = tkhdBytes + box("mdia", mdiaPayload)
                return box("moov", mvhdBytes + box("trak", trakPayload))
            }

            val sizeProbe = buildMoov(0).size
            val mdatPayloadStart = ftyp.size.toLong() + sizeProbe + 8
            val finalMoov = buildMoov(mdatPayloadStart)

            output.parentFile?.mkdirs()
            output.outputStream().buffered(256 * 1024).use { out ->
                out.write(ftyp)
                out.write(finalMoov)
                val hdr = ByteArray(8)
                val mdatSize = totalBytes + 8
                if (mdatSize > 0xFFFFFFFFL) throw IOException("Berkas terlalu besar")
                putU32(hdr, 0, mdatSize)
                hdr[4] = 'm'.code.toByte(); hdr[5] = 'd'.code.toByte(); hdr[6] = 'a'.code.toByte(); hdr[7] = 't'.code.toByte()
                out.write(hdr)
                // salin sampel (gabungkan rentang yang bersambung)
                var rangeStart = samples[0].offset
                var rangeLen = 0L
                val buf = ByteArray(256 * 1024)
                fun flushRange() {
                    if (rangeLen <= 0) return
                    raf.seek(rangeStart)
                    var left = rangeLen
                    while (left > 0) {
                        val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n <= 0) throw IOException("Berkas terpotong")
                        out.write(buf, 0, n)
                        left -= n
                    }
                }
                for (s in samples) {
                    if (rangeLen > 0 && s.offset == rangeStart + rangeLen) {
                        rangeLen += s.size
                    } else {
                        flushRange()
                        rangeStart = s.offset
                        rangeLen = s.size.toLong()
                    }
                }
                flushRange()
            }
            return true
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun topLevel(raf: RandomAccessFile): List<Node> {
        // hanya membaca header kotak tingkat atas (tanpa memuat isi)
        val list = ArrayList<Node>()
        var pos = 0L
        val len = raf.length()
        val head = ByteArray(16)
        while (pos + 8 <= len) {
            raf.seek(pos)
            raf.readFully(head, 0, 8)
            var size = u32(head, 0)
            val type = String(head, 4, 4, Charsets.ISO_8859_1)
            var header = 8
            if (size == 1L) { raf.readFully(head, 8, 8); size = u64(head, 8); header = 16 } else if (size == 0L) size = len - pos
            if (size < header || pos + size > len) break
            // Node memakai Int: cukup untuk berkas audio (< 2 GB)
            list.add(Node(type, pos.toInt(), header, (pos + size).toInt()))
            pos += size
        }
        return list
    }

    private fun parse(data: ByteArray, from: Int, to: Int): List<Node> {
        val list = ArrayList<Node>()
        var pos = from
        while (pos + 8 <= to) {
            var size = u32(data, pos)
            val type = String(data, pos + 4, 4, Charsets.ISO_8859_1)
            var header = 8
            if (size == 1L) { size = u64(data, pos + 8); header = 16 } else if (size == 0L) size = (to - pos).toLong()
            if (size < header || pos + size > to) break
            list.add(Node(type, pos, header, (pos + size).toInt()))
            pos += size.toInt()
        }
        return list
    }

    private fun patchDuration(box: ByteArray, headerSize: Int, duration: Long, kind: String) {
        val v1 = box[headerSize].toInt() == 1
        val off = headerSize + when (kind) {
            "tkhd" -> if (v1) 28 else 20
            else -> if (v1) 24 else 16
        }
        if (v1) putU64(box, off, duration) else putU32(box, off, duration)
    }

    private fun box(type: String, payload: ByteArray): ByteArray {
        val o = ByteArrayOutputStream(payload.size + 8)
        val d = DataOutputStream(o)
        d.writeInt(payload.size + 8)
        d.write(type.toByteArray(Charsets.ISO_8859_1))
        d.write(payload)
        d.flush()
        return o.toByteArray()
    }

    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun u64(b: ByteArray, o: Int): Long = (u32(b, o) shl 32) or u32(b, o + 4)

    private fun ByteArray.s32(o: Int): Int = u32(this, o).toInt()

    private fun putU32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v shr 24).toByte(); b[o + 1] = (v shr 16).toByte(); b[o + 2] = (v shr 8).toByte(); b[o + 3] = v.toByte()
    }

    private fun putU64(b: ByteArray, o: Int, v: Long) {
        putU32(b, o, v ushr 32); putU32(b, o + 4, v and 0xFFFFFFFFL)
    }
}
