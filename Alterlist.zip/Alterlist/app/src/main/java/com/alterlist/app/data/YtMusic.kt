package com.alterlist.app.data

import com.metrolist.innertubex.InnerTube
import com.metrolist.innertubex.cipher.PlayerConfigRepository
import com.metrolist.innertubex.cipher.RemotePlayerConfigStore
import com.metrolist.innertubex.cipher.YouTubeCipherService
import com.metrolist.innertubex.extraction.AudioQuality
import com.metrolist.innertubex.extraction.ContentHints
import com.metrolist.innertubex.extraction.InnerTubeExtractor
import com.metrolist.innertubex.extraction.PlayerConfig
import com.metrolist.innertubex.extraction.YtConfigParser
import com.metrolist.innertubex.extraction.YtConfigParserImpl
import com.metrolist.innertubex.models.YouTubeClient
import com.metrolist.innertubex.models.YouTubeLocale
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.compression.ContentEncoding
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.defaultRequest
import io.ktor.client.request.header
import io.ktor.client.request.url
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import java.io.IOException
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Hasil resolve stream audio dari YouTube (URL bertanda tangan + header yang wajib dikirim). */
data class ResolvedStream(
    val url: String,
    val headers: Map<String, String>,
    val expiresAtMs: Long,
    val bounded: Boolean,
    val chunkBytes: Long,
    val mimeType: String,
    val contentLength: Long?,
    val author: String?,
)

/**
 * Klien YouTube Music (InnerTube, client WEB_REMIX) - API privat yang sama dengan yang dipakai
 * Metrolist. Request dibangun oleh library InnerTubeX; di sini kita hanya memanggil dan mem-parse.
 */
class YtMusic {
    private val webRemix = YouTubeClient.WEB_REMIX

    private val http: HttpClient by lazy {
        HttpClient(OkHttp) {
            expectSuccess = false
            install(ContentNegotiation) {
                json(
                    Json {
                        ignoreUnknownKeys = true
                        explicitNulls = false
                        encodeDefaults = true
                    },
                )
            }
            install(ContentEncoding) {
                gzip(0.9F)
                deflate(0.8F)
            }
            install(HttpTimeout) {
                requestTimeoutMillis = 60_000
                connectTimeoutMillis = 30_000
                socketTimeoutMillis = 60_000
            }
            defaultRequest {
                url("https://music.youtube.com/youtubei/v1/")
                header("Accept", "application/json")
                header("Cache-Control", "no-cache")
            }
        }
    }

    @Volatile
    private var account: AccountSession? = null

    private val innerTubeLazy =
        lazy {
            InnerTube(http).also {
                val locale = Locale.getDefault()
                it.locale =
                    YouTubeLocale(
                        gl = locale.country.ifBlank { "US" },
                        hl = locale.language.ifBlank { "en" },
                    )
                account?.let { a -> applyAccount(it, a) }
            }
        }
    private val innerTube: InnerTube get() = innerTubeLazy.value

    private val extractor: InnerTubeExtractor by lazy {
        val configStore =
            RemotePlayerConfigStore(
                httpClient = http,
                repository = PlayerConfigRepository.disabled(),
            )
        val cipher = YouTubeCipherService(http, configStore)
        val parser = YtConfigParserImpl(http, innerTube, configStore, cipherService = cipher)
        InnerTubeExtractor(
            configParser = parser.withEmbeddedFallback(),
            cipherService = cipher,
            innerTube = innerTube,
        )
    }

    private val sessionMutex = Mutex()

    @Volatile
    private var sessionReady = false

    private val streamCache = ConcurrentHashMap<String, ResolvedStream>()

    @Volatile
    private var homeCache: Pair<Long, List<Shelf>>? = null

    @Volatile
    private var categoryCache: List<Category>? = null

    // ---------------------------------------------------------------- akun

    private fun applyAccount(it: InnerTube, a: AccountSession) {
        it.cookie = a.cookie
        a.visitorData?.takeIf { v -> v.isNotBlank() }?.let { v -> it.visitorData = v }
        it.dataSyncId = a.dataSyncId?.takeIf { v -> v.isNotBlank() }
        it.authUser = a.authUser
        it.useLoginForBrowse = true
    }

    /** Pasang (atau lepas dengan null) sesi login YouTube Music. */
    fun setAccount(session: AccountSession?) {
        account = session
        homeCache = null
        sessionReady = session?.visitorData?.isNotBlank() == true
        if (innerTubeLazy.isInitialized()) {
            val it = innerTube
            if (session != null) {
                applyAccount(it, session)
            } else {
                it.cookie = null
                it.dataSyncId = null
                it.authUser = "0"
                it.useLoginForBrowse = false
            }
        }
    }

    suspend fun accountInfo(): AccountInfo? {
        ensureSession()
        return runCatching { parseAccount(fetchJson { innerTube.accountMenu(webRemix) }) }.getOrNull()
    }

    suspend fun likeOnAccount(videoId: String, like: Boolean) {
        if (account == null) return
        ensureSession()
        runCatching {
            if (like) innerTube.likeVideo(webRemix, videoId) else innerTube.unlikeVideo(webRemix, videoId)
        }
    }

    /** Lagu yang disukai di akun YouTube Music (halaman pertama). */
    suspend fun accountLikedSongs(): List<Song> {
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = "VLLM", setLogin = true) }
        return parseBrowsePage(root, "Disukai", null).songs
    }

    /** Playlist di pustaka akun YouTube Music. */
    suspend fun accountPlaylists(): List<Entry> {
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = "FEmusic_liked_playlists", setLogin = true) }
        return root
            .findAll("musicTwoRowItemRenderer")
            .mapNotNull { parseTwoRow(it) }
            .filter { it.browseId != null && it.kind == EntryKind.PLAYLIST }
            .distinctBy { it.browseId }
    }

    // ---------------------------------------------------------------- internal

    private suspend fun ensureSession() {
        if (sessionReady) return
        sessionMutex.withLock {
            if (sessionReady) return
            val visitorData = runCatching { innerTube.fetchFreshVisitorData() }.getOrNull()
            if (visitorData != null) {
                innerTube.visitorData = visitorData
                sessionReady = true
            }
        }
    }

    private suspend fun fetchJson(call: suspend () -> HttpResponse): JsonElement =
        withContext(Dispatchers.IO) { Json.parseToJsonElement(call().bodyAsText()) }

    // ---------------------------------------------------------------- pencarian & beranda

    suspend fun search(query: String, filter: SearchFilter): List<Entry> {
        ensureSession()
        val root = fetchJson { innerTube.search(webRemix, query = query, params = filter.params) }
        return root
            .findAll("musicResponsiveListItemRenderer")
            .mapNotNull { parseListEntry(it) }
            .distinctBy { it.videoId ?: it.browseId ?: it.title }
    }

    suspend fun suggestions(input: String): List<String> {
        ensureSession()
        val root = fetchJson { innerTube.getSearchSuggestions(webRemix, input) }
        return root
            .findAll("searchSuggestionRenderer")
            .map { it.at("suggestion").runsText() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    suspend fun home(force: Boolean = false): List<Shelf> {
        val cached = homeCache
        if (!force && cached != null && System.currentTimeMillis() - cached.first < HOME_CACHE_MS) {
            return cached.second
        }
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = "FEmusic_home") }
        val shelves = parseShelves(root)
        homeCache = System.currentTimeMillis() to shelves
        return shelves
    }

    suspend fun moodsAndGenres(): List<Category> {
        categoryCache?.let { return it }
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = "FEmusic_moods_and_genres") }
        val list = parseCategories(root)
        if (list.isNotEmpty()) categoryCache = list
        return list
    }

    /** Album / playlist / artis / kategori. */
    suspend fun browsePage(
        browseId: String,
        params: String? = null,
        fallbackTitle: String = "",
        fallbackThumb: String? = null,
    ): BrowsePage {
        ensureSession()
        val root = fetchJson { innerTube.browse(webRemix, browseId = browseId, params = params) }
        return parseBrowsePage(root, fallbackTitle, fallbackThumb)
    }

    /** "Up next" / radio: lagu mirip dari sebuah lagu, atau isi sebuah mix (playlistId). */
    suspend fun upNext(videoId: String?, playlistId: String?): List<Song> {
        ensureSession()
        val root =
            fetchJson {
                innerTube.next(
                    webRemix,
                    videoId = videoId,
                    playlistId = playlistId ?: videoId?.let { "RDAMVM$it" },
                    params = if (playlistId == null) "wAEB" else null,
                )
            }
        return root
            .findAll("playlistPanelVideoRenderer")
            .mapNotNull { parsePanelSong(it) }
            .distinctBy { it.id }
    }

    // ---------------------------------------------------------------- stream audio

    /** Untuk diputar (opus/aac tercepat). URL di-cache sampai mendekati kedaluwarsa. */
    suspend fun resolveStream(videoId: String, forceRefresh: Boolean = false): ResolvedStream {
        if (!forceRefresh) {
            val cached = streamCache[videoId]
            if (cached != null && cached.expiresAtMs - 60_000L > System.currentTimeMillis()) return cached
        }
        val resolved = extract(videoId, AudioQuality.HIGH)
        streamCache[videoId] = resolved
        return resolved
    }

    /** Untuk diunduh: minta format MP4/AAC supaya bisa diberi tag + cover. */
    suspend fun resolveForDownload(videoId: String): ResolvedStream = extract(videoId, AudioQuality.MP4)

    private suspend fun extract(videoId: String, quality: AudioQuality): ResolvedStream =
        withContext(Dispatchers.IO) {
            ensureSession()
            val hints =
                ContentHints(wantVideo = false).withStreamCapabilities(
                    allowHls = false,
                    allowSabr = false,
                    allowBoundedRange = true,
                )
            val stream =
                extractor.extract(
                    videoId = videoId,
                    hints = hints,
                    audioQuality = quality,
                ) ?: throw IOException("Stream audio tidak ditemukan")
            if (stream.sabrBootstrap != null) throw IOException("Stream SABR belum didukung")
            ResolvedStream(
                url = stream.audioUrl,
                headers = stream.headers,
                expiresAtMs =
                    stream.expiresAt?.toEpochMilliseconds()
                        ?: (System.currentTimeMillis() + DEFAULT_STREAM_TTL_MS),
                bounded = stream.requireBoundedRange || stream.useRangeChunks,
                chunkBytes = stream.rangeChunkSizeBytes,
                mimeType = stream.mimeType.orEmpty(),
                contentLength = stream.contentLengthBytes,
                author = stream.mediaMetadata?.author,
            )
        }

    fun invalidateStream(videoId: String) {
        streamCache.remove(videoId)
    }

    private companion object {
        const val HOME_CACHE_MS = 5 * 60_000L
        const val DEFAULT_STREAM_TTL_MS = 5 * 60_000L
    }
}

/** Kalau config halaman watch gagal di-parse, coba config embed (sama seperti yang dilakukan Metrolist). */
private fun YtConfigParser.withEmbeddedFallback(): YtConfigParser {
    val delegate = this
    return object : YtConfigParser by delegate {
        override suspend fun fetchConfig(
            videoId: String,
            useLoginCookies: Boolean,
        ): PlayerConfig =
            try {
                delegate.fetchConfig(videoId, useLoginCookies)
            } catch (_: IllegalStateException) {
                delegate.fetchEmbeddedConfig(videoId, useLoginCookies = false)
            }
    }
}
