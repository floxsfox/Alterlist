package com.alterlist.app.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menyalakan lagi mode game setelah ponsel dihidupkan ulang (kalau fiturnya aktif di Pengaturan). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) GameModeController.sync(context)
    }
}
