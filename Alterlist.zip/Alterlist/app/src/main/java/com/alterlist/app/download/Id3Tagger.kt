package com.alterlist.app.download

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

/**
 * Penulis tag ID3v2.3 untuk MP3 (judul, artis, album, komentar, cover) tanpa library tambahan. Dipakai untuk lagu
 * SoundCloud yang diunduh sebagai MP3. Tag ID3v2 lama di berkas sumber dibuang lebih dulu.
 */
object Id3Tagger {
    @Throws(IOException::class)
    fun tag(
        input: File,
        output: File,
        title: String?,
        artist: String?,
        albumArtist: String?,
        album: String?,
        comment: String?,
        cover: ByteArray?,
    ) {
        val frames = ByteArrayOutputStream()
        title?.takeIf { it.isNotBlank() }?.let { frames.write(textFrame("TIT2", it)) }
        artist?.takeIf { it.isNotBlank() }?.let { frames.write(textFrame("TPE1", it)) }
        albumArtist?.takeIf { it.isNotBlank() }?.let { frames.write(textFrame("TPE2", it)) }
        album?.takeIf { it.isNotBlank() }?.let { frames.write(textFrame("TALB", it)) }
        comment?.takeIf { it.isNotBlank() }?.let {
            // COMM: encoding ISO-8859-1, bahasa "eng", deskripsi kosong, lalu teks
            frames.write(frame("COMM", byteArrayOf(0) + "eng".toByteArray(Charsets.US_ASCII) + byteArrayOf(0) + it.toByteArray(Charsets.ISO_8859_1)))
        }
        if (cover != null && cover.isNotEmpty()) {
            // APIC: encoding ISO-8859-1, MIME, tipe gambar 3 (cover depan), deskripsi kosong, lalu data JPEG
            val head = byteArrayOf(0) + "image/jpeg".toByteArray(Charsets.US_ASCII) + byteArrayOf(0, 3, 0)
            frames.write(frame("APIC", head + cover))
        }
        val body = frames.toByteArray()

        FileOutputStream(output).use { out ->
            out.write("ID3".toByteArray(Charsets.US_ASCII))
            out.write(byteArrayOf(3, 0, 0)) // versi 2.3.0, tanpa flag
            out.write(synchsafe(body.size))
            out.write(body)
            FileInputStream(input).use { ins ->
                val head = ByteArray(10)
                var n = 0
                while (n < 10) {
                    val r = ins.read(head, n, 10 - n)
                    if (r < 0) break
                    n += r
                }
                val hasOldTag = n == 10 && head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte()
                if (hasOldTag) {
                    var skip = unsynchsafe(head, 6).toLong()
                    if (head[5].toInt() and 0x10 != 0) skip += 10 // ada footer
                    while (skip > 0) {
                        val s = ins.skip(skip)
                        if (s > 0) {
                            skip -= s
                        } else {
                            if (ins.read() < 0) break
                            skip--
                        }
                    }
                } else {
                    out.write(head, 0, n)
                }
                ins.copyTo(out)
            }
        }
    }

    /** Frame teks: encoding 1 (UTF-16 dengan BOM) + teks + terminator. */
    private fun textFrame(id: String, text: String): ByteArray =
        frame(id, byteArrayOf(1) + text.toByteArray(Charsets.UTF_16) + byteArrayOf(0, 0))

    /** Frame ID3v2.3: id (4) + ukuran biasa (4, big-endian) + flag (2) + data. */
    private fun frame(id: String, data: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(id.toByteArray(Charsets.US_ASCII))
        out.write(byteArrayOf((data.size ushr 24).toByte(), (data.size ushr 16).toByte(), (data.size ushr 8).toByte(), data.size.toByte()))
        out.write(byteArrayOf(0, 0))
        out.write(data)
        return out.toByteArray()
    }

    private fun synchsafe(n: Int): ByteArray =
        byteArrayOf(((n shr 21) and 0x7F).toByte(), ((n shr 14) and 0x7F).toByte(), ((n shr 7) and 0x7F).toByte(), (n and 0x7F).toByte())

    private fun unsynchsafe(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0x7F) shl 21) or ((b[off + 1].toInt() and 0x7F) shl 14) or ((b[off + 2].toInt() and 0x7F) shl 7) or (b[off + 3].toInt() and 0x7F)
}
