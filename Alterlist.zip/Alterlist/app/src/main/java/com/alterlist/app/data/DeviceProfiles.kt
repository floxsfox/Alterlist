package com.alterlist.app.data

import com.alterlist.app.fx.AudioFx
import com.alterlist.app.fx.EqPreset
import com.alterlist.app.fx.EqualizerFx
import com.alterlist.app.fx.FxPreset
import com.alterlist.app.system.OutputKind

/**
 * Profil audio otomatis: saat keluaran audio berganti (mis. earphone Bluetooth tersambung),
 * efek suara langsung disesuaikan dengan profil yang dipilih untuk jenis perangkat itu.
 */
object DeviceProfiles {
    fun valueFor(settings: AppSettingsState, kind: OutputKind): String =
        when (kind) {
            OutputKind.BLUETOOTH -> settings.profileBluetooth
            OutputKind.WIRED, OutputKind.USB -> settings.profileWired
            OutputKind.PHONE -> settings.profilePhone
            else -> DeviceProfile.NONE
        }

    fun apply(settings: AppSettingsState, kind: OutputKind) {
        when (valueFor(settings, kind)) {
            DeviceProfile.NORMAL -> {
                AudioFx.applyPreset(FxPreset.NORMAL)
                EqualizerFx.setEnabled(false)
            }
            DeviceProfile.WIDE_3D -> {
                AudioFx.applyPreset(FxPreset.SURROUND_3D)
                EqualizerFx.setEnabled(false)
            }
            DeviceProfile.ORBIT_8D -> {
                AudioFx.applyPreset(FxPreset.AUDIO_8D)
                EqualizerFx.setEnabled(false)
            }
            DeviceProfile.BASS -> {
                AudioFx.applyPreset(FxPreset.NORMAL)
                EqualizerFx.applyPreset(EqPreset.BASS)
            }
            DeviceProfile.VOCAL -> {
                AudioFx.applyPreset(FxPreset.NORMAL)
                EqualizerFx.applyPreset(EqPreset.VOCAL)
            }
            else -> Unit
        }
    }
}
