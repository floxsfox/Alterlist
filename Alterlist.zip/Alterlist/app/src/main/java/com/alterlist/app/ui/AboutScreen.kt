package com.alterlist.app.ui

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R

private val FEATURES =
    listOf(
        "Beranda \"Untuk Kamu\" ala FYP: rekomendasi dari seleramu, Daily Mix, dan rak per genre",
        "Pencarian tanpa batas: hasil terus dimuat sampai habis",
        "Musik di perangkat: semua format audio yang didukung Android",
        "Efek 3D dan 8D, reverb, slowed, sped up, equalizer 5 pita, bass booster",
        "Deteksi speaker dan earphone Bluetooth otomatis",
        "Mode offline: Beranda berhenti memuat dan hanya menampilkan unduhan dan musik lokal",
        "Mini player dan bar navigasi kaca dengan warna dari cover lagu",
        "Unduhan, lirik sinkron, antrean, sleep timer, fade antar lagu, lewati keheningan",
        "Rekap musikmu, cadangan dan pemulihan pustaka, lanjut dari lagu terakhir",
    )

@Composable
fun AboutScreen(padding: PaddingValues, onBack: () -> Unit) {
    val app = AlterApp.instance
    val online by app.network.online.collectAsState()
    val output by app.audioOutput.active.collectAsState()
    val local by app.localMusic.state.collectAsState()
    val context = LocalContext.current
    val version = remember { runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "3.0.0" }
    BackHandler(onBack = onBack)

    LazyColumn(Modifier.fillMaxSize().background(AlterColors.Bg), contentPadding = padding) {
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF4A0A12), AlterColors.Bg))).padding(bottom = 20.dp)) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp)) { IconBtn(R.drawable.ic_chevron_left, onBack) }
                    Image(painterResource(R.drawable.logo_mark), contentDescription = null, modifier = Modifier.size(84.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Alterlist", style = T.screen)
                    Text("Versi $version", style = T.small, color = AlterColors.Sub)
                    Text("Musik tanpa batas, gratis, tanpa iklan.", style = T.body, color = Color.White.copy(alpha = 0.8f), modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        item { SectionTitle("Fitur") }
        FEATURES.forEach { f ->
            item(key = f) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Ic(R.drawable.ic_check, tint = AlterColors.Red, size = 18.dp, modifier = Modifier.padding(top = 2.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(f, style = T.body, color = Color.White.copy(alpha = 0.9f))
                }
            }
        }
        item { SectionTitle("Info sistem") }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(16.dp)).background(AlterColors.Surface).padding(16.dp)) {
                SysLine("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                SysLine("Perangkat", "${Build.MANUFACTURER} ${Build.MODEL}")
                SysLine("Internet", if (online) "Tersambung" else "Offline")
                SysLine("Keluaran audio", "${output.name} (${output.kind.label})")
                SysLine("Musik lokal", "${local.songs.size} lagu")
            }
        }
        item {
            Text(
                "Alterlist tidak berafiliasi dengan Google atau YouTube. Semua konten milik pemegang haknya. Lisensi: GPL-3.0. Font Figtree: SIL OFL 1.1.",
                style = T.tiny,
                color = AlterColors.Muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(24.dp),
            )
        }
    }
}

@Composable
private fun SysLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, style = T.small, color = AlterColors.Sub, modifier = Modifier.width(120.dp))
        Text(value, style = T.small, modifier = Modifier.weight(1f))
    }
}
