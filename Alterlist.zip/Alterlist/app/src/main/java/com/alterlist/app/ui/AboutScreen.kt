package com.alterlist.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.alterlist.app.R

/** Halaman Tentang: hanya nama, versi, dan kredit. */
@Composable
fun AboutScreen(padding: PaddingValues, onBack: () -> Unit) {
    val context = LocalContext.current
    val version = remember { runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "3.6.8" }
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().background(AlterColors.Bg).padding(padding)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp)) { IconBtn(R.drawable.ic_chevron_left, onBack) }
        Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo_mark), contentDescription = null, modifier = Modifier.size(96.dp))
            Spacer(Modifier.height(14.dp))
            Text("Alterlist", style = T.screen)
            Text("Versi $version", style = T.small, color = AlterColors.Sub)
        }
        Spacer(Modifier.height(32.dp))
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(16.dp)).background(AlterColors.Surface).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            CreditLine("Dibuat oleh", "eliojioDev")
            CreditLine("API", "InnerTubeX")
        }
    }
}

@Composable
private fun CreditLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = T.body, color = AlterColors.Sub, modifier = Modifier.weight(1f))
        Text(value, style = T.body.copy(color = Color.White))
    }
}
