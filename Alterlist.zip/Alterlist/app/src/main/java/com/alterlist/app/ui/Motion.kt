package com.alterlist.app.ui

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Ketuk = mengecil sedikit lalu membal. Dipakai di kartu dan tombol supaya terasa hidup. */
fun Modifier.bounceClick(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    composed {
        val source = remember { MutableInteractionSource() }
        val pressed by source.collectIsPressedAsState()
        val scale by animateFloatAsState(
            targetValue = if (pressed) 0.95f else 1f,
            animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
            label = "bounce",
        )
        this
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(interactionSource = source, indication = null, enabled = enabled, onClick = onClick)
    }

/** Muncul pelan dari bawah dengan jeda bertahap per urutan item ([index] besar tidak menunda lebih dari ~0,4 detik). */
fun Modifier.appear(index: Int = 0, offsetY: Dp = 16.dp): Modifier =
    composed {
        val progress = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            delay((index.coerceIn(0, 8) * 45).toLong())
            progress.animateTo(1f, tween(durationMillis = 420, easing = FastOutSlowInEasing))
        }
        val px = with(LocalDensity.current) { offsetY.toPx() }
        this.graphicsLayer {
            alpha = progress.value
            translationY = (1f - progress.value) * px
        }
    }

/** Angka yang berhitung naik dengan mulus. */
@Composable
fun animatedCount(target: Int): Int {
    val v by animateFloatAsState(target.toFloat(), tween(durationMillis = 900, easing = FastOutSlowInEasing), label = "count")
    return v.roundToInt()
}

/** Kerangka pemuatan berkilau (pengganti spinner) untuk Beranda dan pencarian. */
@Composable
fun ShimmerBox(modifier: Modifier = Modifier, shape: Shape = RoundedCornerShape(10.dp)) {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(durationMillis = 1300, easing = LinearEasing)),
        label = "shimmerX",
    )
    Box(
        modifier
            .clip(shape)
            .background(AlterColors.Surface2)
            .drawWithContent {
                drawContent()
                val w = size.width
                drawRect(
                    Brush.linearGradient(
                        colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.09f), Color.Transparent),
                        start = Offset(w * x, 0f),
                        end = Offset(w * x + w * 0.5f, size.height),
                    ),
                )
            },
    )
}

/** Tiga batang equalizer yang bergerak, penanda lagu yang sedang diputar. */
@Composable
fun PlayingBars(modifier: Modifier = Modifier, color: Color = AlterColors.Red, animate: Boolean = LocalIsPlaying.current) {
    // saat lagu di-pause batang diam dan tidak ada animasi yang berjalan (hemat baterai dan frame)
    val a: Float
    val b: Float
    val c: Float
    if (animate) {
        val t = rememberInfiniteTransition(label = "bars")
        a = t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "barA").value
        b = t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(430, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "barB").value
        c = t.animateFloat(0.2f, 0.9f, infiniteRepeatable(tween(610, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "barC").value
    } else {
        a = 0.4f
        b = 0.75f
        c = 0.5f
    }
    Canvas(modifier.size(16.dp)) {
        val bw = size.width / 5f
        val heights = listOf(a, b, c)
        heights.forEachIndexed { i, h ->
            drawRoundRect(
                color = color,
                topLeft = Offset(i * bw * 2f, size.height * (1f - h)),
                size = Size(bw, size.height * h),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}

/** True saat musik sedang diputar; dipakai indikator "sedang diputar" supaya berhenti bergerak saat pause. */
val LocalIsPlaying = androidx.compose.runtime.compositionLocalOf { true }

/** Tombol hati yang membal saat disukai. */
@Composable
fun LikeButton(
    liked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 24.dp,
    box: Dp = 44.dp,
    idleTint: Color = Color.White,
) {
    val scale = remember { Animatable(1f) }
    LaunchedEffect(liked) {
        if (liked) {
            scale.snapTo(0.65f)
            scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium))
        } else {
            scale.snapTo(1f)
        }
    }
    Box(
        modifier.size(box).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Ic(
            id = heartIcon(liked),
            tint = if (liked) AlterColors.Red else idleTint,
            size = size,
            modifier = Modifier.graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
        )
    }
}

@DrawableRes
private fun heartIcon(liked: Boolean): Int = if (liked) com.alterlist.app.R.drawable.ic_heart_fill else com.alterlist.app.R.drawable.ic_heart
