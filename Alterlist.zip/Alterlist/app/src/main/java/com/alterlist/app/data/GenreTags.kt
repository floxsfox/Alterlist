package com.alterlist.app.data

import java.util.Locale

/** Pilihan genre di layar "Pilih genre favoritmu" beserta kata kunci pencarian yang dipakai untuk rekomendasi awal. */
data class GenreChoice(val label: String, val query: String, val color: Int)

/**
 * Menebak genre / suasana lagu dari judul, artis, album, dan jenis huruf (tanpa internet, tanpa server).
 * Hasilnya dipakai untuk membentuk profil selera: semakin sering kamu memutar lagu ber-tag tertentu,
 * semakin besar bobot genre itu di rekomendasi Beranda.
 */
object GenreTags {
    val CHOICES: List<GenreChoice> =
        listOf(
            GenreChoice("Pop", "lagu pop terbaik", 0xFFE8115B.toInt()),
            GenreChoice("Pop Indonesia", "lagu pop indonesia populer", 0xFFB02897.toInt()),
            GenreChoice("Hip-hop", "hip hop hits", 0xFFBA5D07.toInt()),
            GenreChoice("Rock", "rock classic hits", 0xFFE13300.toInt()),
            GenreChoice("Indie", "indie pop favorit", 0xFF477D95.toInt()),
            GenreChoice("Akustik", "akustik santai", 0xFF8D6E3F.toInt()),
            GenreChoice("Lo-fi", "lofi chill beats", 0xFF4B6A88.toInt()),
            GenreChoice("Elektronik", "electronic dance hits", 0xFF1E3264.toInt()),
            GenreChoice("R&B", "r&b soul hits", 0xFF7358FF.toInt()),
            GenreChoice("Jazz", "jazz santai", 0xFF148A08.toInt()),
            GenreChoice("Klasik", "musik klasik piano", 0xFF503750.toInt()),
            GenreChoice("K-Pop", "kpop hits", 0xFFD84000.toInt()),
            GenreChoice("J-Pop", "jpop anime hits", 0xFFAF2896.toInt()),
            GenreChoice("Dangdut", "dangdut populer", 0xFF8C1932.toInt()),
            GenreChoice("Religi", "sholawat islami", 0xFF0D7377.toInt()),
            GenreChoice("Metal", "heavy metal klasik", 0xFF2D2D2D.toInt()),
            GenreChoice("Reggae", "reggae santai", 0xFF1E7B3A.toInt()),
            GenreChoice("Country", "country hits", 0xFF9C6B2C.toInt()),
            GenreChoice("Latin", "latin pop hits", 0xFFE65100.toInt()),
            GenreChoice("Galau", "lagu galau sedih", 0xFF39425E.toInt()),
        )

    private class Rule(val tag: String, val regex: Regex)

    private fun rule(tag: String, vararg words: String): Rule =
        Rule(tag, Regex("\\b(?:" + words.joinToString("|") { Regex.escape(it) } + ")\\b", RegexOption.IGNORE_CASE))

    private val RULES: List<Rule> =
        listOf(
            rule("Lo-fi", "lofi", "lo-fi", "lo fi", "chillhop", "study beats"),
            rule("Slowed", "slowed", "reverb", "sped up", "nightcore", "slowed down"),
            rule("Remix", "remix", "rmx", "bootleg", "mashup", "edit"),
            rule("Akustik", "acoustic", "akustik", "unplugged", "stripped"),
            rule("Cover", "cover", "covered by", "reggae version"),
            rule("Live", "live", "konser", "concert", "session"),
            rule("Instrumental", "instrumental", "karaoke", "piano version"),
            rule("Soundtrack", "ost", "soundtrack", "original score", "theme song"),
            rule("Anime", "anime", "naruto", "one piece", "attack on titan", "jujutsu", "demon slayer"),
            rule("Dangdut", "dangdut", "koplo", "campursari", "orkes", "pantura", "rhoma irama", "denny caknan", "happy asmara"),
            rule("Religi", "sholawat", "shalawat", "qasidah", "nasheed", "islami", "islamic", "quran", "murottal", "gospel", "worship", "rohani", "hymn"),
            rule("Hip-hop", "hip hop", "hip-hop", "rap", "trap", "drill", "freestyle"),
            rule("R&B", "r&b", "rnb", "soul", "neo soul"),
            rule("Rock", "rock", "grunge", "punk", "alternative rock", "hard rock"),
            rule("Metal", "metal", "metalcore", "deathcore", "thrash"),
            rule("Elektronik", "edm", "house", "techno", "trance", "dubstep", "electro", "synthwave", "future bass", "drum and bass", "dnb"),
            rule("Dance", "dance", "club", "disco", "eurodance"),
            rule("Jazz", "jazz", "bossa nova", "swing", "smooth jazz"),
            rule("Blues", "blues"),
            rule("Klasik", "classical", "klasik", "symphony", "sonata", "concerto", "orchestra", "beethoven", "mozart", "chopin"),
            rule("Reggae", "reggae", "ska"),
            rule("Country", "country", "bluegrass", "nashville"),
            rule("Folk", "folk", "keroncong", "gamelan", "tradisional", "daerah"),
            rule("Latin", "latin", "reggaeton", "salsa", "bachata", "cumbia"),
            rule("Indie", "indie", "bedroom pop", "dream pop", "shoegaze"),
            rule("Pop", "pop", "pop hits"),
            rule("Galau", "galau", "sad", "sedih", "patah hati", "broken", "heartbreak", "kehilangan", "rindu", "merindu"),
        )

    private val INDONESIAN =
        Regex(
            "\\b(?:aku|kamu|kau|cinta|rindu|hati|sayang|kita|dia|tak|tidak|untuk|yang|dengan|pergi|pulang|hujan|malam|bukan|jangan|sendiri|selamat|terbaru|sahabat|kasih|rasa|bahagia|mimpi|senja|lelaki|perempuan|bintang|ibu|bapak|rumah)\\b",
            RegexOption.IGNORE_CASE,
        )

    private fun hasScript(text: String, from: Int, to: Int): Boolean = text.any { it.code in from..to }

    /** Tag genre / suasana / bahasa untuk sebuah lagu (maksimal 5). */
    fun infer(song: Song): Set<String> {
        val text = buildString {
            append(song.title).append(' ').append(song.artist)
            song.album?.let { append(' ').append(it) }
        }
        val out = LinkedHashSet<String>()
        for (r in RULES) {
            if (r.regex.containsMatchIn(text)) out.add(r.tag)
            if (out.size >= 4) break
        }
        when {
            hasScript(text, 0xAC00, 0xD7AF) || hasScript(text, 0x1100, 0x11FF) -> out.add("K-Pop")
            hasScript(text, 0x3040, 0x30FF) -> out.add("J-Pop")
            hasScript(text, 0x4E00, 0x9FFF) -> out.add("Mandarin")
            hasScript(text, 0x0900, 0x097F) -> out.add("Bollywood")
            hasScript(text, 0x0600, 0x06FF) -> out.add("Arab")
            hasScript(text, 0x0E00, 0x0E7F) -> out.add("T-Pop")
            hasScript(text, 0x0400, 0x04FF) -> out.add("Rusia")
        }
        if (INDONESIAN.containsMatchIn(text)) out.add("Indonesia")
        return out.take(5).toSet()
    }

    /** Kata kunci pencarian untuk membangun mix dari sebuah tag. */
    fun queryFor(tag: String): String {
        CHOICES.firstOrNull { it.label.equals(tag, true) }?.let { return it.query }
        return when (tag.lowercase(Locale.ROOT)) {
            "lo-fi" -> "lofi chill beats"
            "slowed" -> "slowed reverb songs"
            "remix" -> "remix hits"
            "indonesia" -> "lagu indonesia hits"
            "mandarin" -> "mandarin pop songs"
            "arab" -> "arabic songs hits"
            "bollywood" -> "bollywood hits"
            "anime" -> "anime songs"
            "soundtrack" -> "movie soundtrack hits"
            "dance" -> "dance hits"
            else -> "$tag music hits"
        }
    }

    fun colorFor(tag: String): Int =
        CHOICES.firstOrNull { it.label.equals(tag, true) }?.color
            ?: (0xFF3A3A5C.toInt() + (tag.hashCode() and 0x00303030))
}
