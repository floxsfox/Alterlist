package com.alterlist.app.system

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Layanan Aksesibilitas kosong yang hanya dipakai untuk satu hal: menggerakkan jari "virtual" di layar
 * (dispatchGesture) supaya bidikan game ikut gerak ponsel. Tidak membaca isi layar dan tidak memantau aplikasi lain
 * (canRetrieveWindowContent = false). Diaktifkan sendiri oleh pengguna di Pengaturan > Aksesibilitas.
 */
class GyroAimService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _connected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        _connected.value = false
        GyroAim.onServiceLost()
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile var instance: GyroAimService? = null
            private set

        private val _connected = MutableStateFlow(false)

        /** True bila layanan aksesibilitas sedang aktif (izin sudah diberikan pengguna). */
        val connected: StateFlow<Boolean> = _connected
    }
}
