package com.alterlist.app.data

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

/** Jalan di dalam JSON: String = key objek, Int = index array. Aman terhadap null. */
internal fun JsonElement?.at(vararg path: Any): JsonElement? {
    var cur: JsonElement? = this
    for (key in path) {
        cur = when (key) {
            is String -> (cur as? JsonObject)?.get(key)
            is Int -> (cur as? JsonArray)?.getOrNull(key)
            else -> null
        }
        if (cur == null) return null
    }
    return cur
}

internal fun JsonElement?.text(): String? = (this as? JsonPrimitive)?.contentOrNull

/** Gabungkan teks dari objek `{ "runs": [ { "text": "..." }, ... ] }`. */
internal fun JsonElement?.runsText(): String {
    val runs = this.at("runs") as? JsonArray ?: return ""
    return runs.joinToString("") { it.at("text").text().orEmpty() }
}

/** Cari semua nilai dengan key tertentu di seluruh pohon JSON (tahan terhadap perubahan layout YouTube). */
internal fun JsonElement.findAll(
    key: String,
    out: MutableList<JsonElement> = mutableListOf(),
): MutableList<JsonElement> {
    when (this) {
        is JsonObject -> for ((k, v) in this) {
            if (k == key) out.add(v)
            v.findAll(key, out)
        }
        is JsonArray -> for (v in this) v.findAll(key, out)
        else -> Unit
    }
    return out
}
