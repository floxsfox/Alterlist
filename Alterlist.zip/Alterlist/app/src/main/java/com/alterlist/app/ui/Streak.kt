package com.alterlist.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import kotlinx.coroutines.delay
import kotlin.math.floor
import kotlin.math.sin

// ============================================================================================
// Tingkat api
// ============================================================================================

/** Tingkat api menurut jumlah hari beruntun. Warna berhenti di pelangi (500+), angka tetap bisa terus naik. */
enum class FlameTier(val from: Int, val title: String) {
    SPARK(1, "Percikan"),
    BLUE(50, "Api Biru"),
    PURPLE(100, "Api Ungu"),
    RED(200, "Api Merah"),
    GREEN(300, "Api Hijau"),
    WHITE(400, "Api Putih"),
    RAINBOW(500, "Api Pelangi"),
    ;

    /** Tingkat berikutnya, null bila sudah di puncak (pelangi). */
    val next: FlameTier? get() = entries.getOrNull(ordinal + 1)
}

fun flameTierFor(days: Int): FlameTier = FlameTier.entries.lastOrNull { days >= it.from } ?: FlameTier.SPARK

/** Warna satu api: tiap lapisan punya tiga warna (atas, tengah, bawah). */
@Immutable
class FlameStyle(
    val outer: List<Color>,
    val mid: List<Color>,
    val core: List<Color>,
    val outline: Color,
    val glow: Color,
    val ember: Color,
)

/** Tampilan api: [rainbow] = warna berputar, [smoke] 0..1 = seberapa banyak asap (api padam) menggantikan percikan. */
@Immutable
class FlameLook(val style: FlameStyle, val rainbow: Boolean = false, val smoke: Float = 0f)

private val StyleSpark =
    FlameStyle(
        outer = listOf(Color(0xFFFFA014), Color(0xFFFF6A00), Color(0xFFD63C00)),
        mid = listOf(Color(0xFFFFD650), Color(0xFFFFAA1E), Color(0xFFFF800A)),
        core = listOf(Color(0xFFFFFAC8), Color(0xFFFFEC8C), Color(0xFFFFD650)),
        outline = Color(0xFF962800),
        glow = Color(0xFFFF7A00),
        ember = Color(0xFFFFC94D),
    )

private val StyleBlue =
    FlameStyle(
        outer = listOf(Color(0xFF5AAAFF), Color(0xFF1E6BFF), Color(0xFF143CBE)),
        mid = listOf(Color(0xFFBEEBFF), Color(0xFF5AB4FF), Color(0xFF2882FF)),
        core = listOf(Color(0xFFF0FCFF), Color(0xFFC8F0FF), Color(0xFF96D7FF)),
        outline = Color(0xFF0A288C),
        glow = Color(0xFF2F80FF),
        ember = Color(0xFF9BDCFF),
    )

private val StylePurple =
    FlameStyle(
        outer = listOf(Color(0xFFBE78FF), Color(0xFF7B2FF7), Color(0xFF5014AA)),
        mid = listOf(Color(0xFFEBCDFF), Color(0xFFB06BFF), Color(0xFF8C46F0)),
        core = listOf(Color(0xFFFAF0FF), Color(0xFFEBD7FF), Color(0xFFD2AFFF)),
        outline = Color(0xFF3C0A78),
        glow = Color(0xFF9B4DFF),
        ember = Color(0xFFDDB5FF),
    )

private val StyleRed =
    FlameStyle(
        outer = listOf(Color(0xFFFF5A50), Color(0xFFD50000), Color(0xFF8C0000)),
        mid = listOf(Color(0xFFFFAA96), Color(0xFFFF4637), Color(0xFFE61414)),
        core = listOf(Color(0xFFFFEBE1), Color(0xFFFFBEAA), Color(0xFFFF8C78)),
        outline = Color(0xFF5A0000),
        glow = Color(0xFFFF2A2A),
        ember = Color(0xFFFF9A8A),
    )

private val StyleGreen =
    FlameStyle(
        outer = listOf(Color(0xFF6EEB96), Color(0xFF16A34A), Color(0xFF0A642D)),
        mid = listOf(Color(0xFFD2FFE1), Color(0xFF64E68C), Color(0xFF28BE5A)),
        core = listOf(Color(0xFFF5FFF8), Color(0xFFD7FFE4), Color(0xFFAAF5C3)),
        outline = Color(0xFF05461E),
        glow = Color(0xFF2EDB6E),
        ember = Color(0xFFA6F5C0),
    )

private val StyleWhite =
    FlameStyle(
        outer = listOf(Color(0xFFFFFFFF), Color(0xFFD6E0EE), Color(0xFFA0AFC8)),
        mid = listOf(Color(0xFFFFFFFF), Color(0xFFF5F8FF), Color(0xFFE1E8F5)),
        core = listOf(Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFF0F6FF)),
        outline = Color(0xFF6E7D9B),
        glow = Color(0xFFBFD4FF),
        ember = Color(0xFFFFFFFF),
    )

/** Api padam: hitam dengan tepi abu-abu terang (supaya tetap terlihat di latar gelap) dan cahaya ungu tipis. */
private val StyleBlack =
    FlameStyle(
        outer = listOf(Color(0xFF282834), Color(0xFF0E0E12), Color(0xFF040406)),
        mid = listOf(Color(0xFF3C3C4A), Color(0xFF1E1E26), Color(0xFF101016)),
        core = listOf(Color(0xFF545464), Color(0xFF343440), Color(0xFF22222C)),
        outline = Color(0xFF6E6E82),
        glow = Color(0xFF6B4EFF),
        ember = Color(0xFF8A7BFF),
    )

private fun styleFor(tier: FlameTier): FlameStyle =
    when (tier) {
        FlameTier.SPARK -> StyleSpark
        FlameTier.BLUE -> StyleBlue
        FlameTier.PURPLE -> StylePurple
        FlameTier.RED -> StyleRed
        FlameTier.GREEN -> StyleGreen
        FlameTier.WHITE -> StyleWhite
        FlameTier.RAINBOW -> StyleSpark // pelangi digambar lewat rainbowStyle(), ini hanya cadangan
    }

fun flameLookFor(tier: FlameTier): FlameLook = FlameLook(styleFor(tier), rainbow = tier == FlameTier.RAINBOW)

private val DeadLook = FlameLook(StyleBlack, smoke = 1f)

private fun lerpStyle(a: FlameStyle, b: FlameStyle, t: Float): FlameStyle {
    fun l(x: List<Color>, y: List<Color>) = x.indices.map { lerp(x[it], y[it], t) }
    return FlameStyle(
        outer = l(a.outer, b.outer),
        mid = l(a.mid, b.mid),
        core = l(a.core, b.core),
        outline = lerp(a.outline, b.outline, t),
        glow = lerp(a.glow, b.glow, t),
        ember = lerp(a.ember, b.ember, t),
    )
}

private fun hue(deg: Float, s: Float = 0.9f, v: Float = 1f): Color {
    val h = ((deg % 360f) + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
}

/** Pelangi: spektrum penuh dari atas ke bawah api, berputar pelan mengikuti [phase] (derajat). */
private fun rainbowStyle(phase: Float): FlameStyle =
    FlameStyle(
        outer = listOf(hue(phase), hue(phase + 120f), hue(phase + 240f)),
        mid = listOf(hue(phase + 30f, 0.5f), hue(phase + 150f, 0.5f), hue(phase + 270f, 0.5f)),
        core = listOf(Color.White, hue(phase + 60f, 0.2f), hue(phase + 180f, 0.3f)),
        outline = hue(phase + 200f, 0.8f, 0.5f),
        glow = hue(phase + 90f),
        ember = Color.White,
    )

private fun accentOf(look: FlameLook): Color = if (look.rainbow) Color(0xFFFF7AD9) else look.style.glow

// ============================================================================================
// Bentuk dan gambar api (Canvas, tanpa aset gambar)
// ============================================================================================

/**
 * Garis luar api kartun, dinormalkan: x -1..1, y 0..1 (naik). Tiap baris = satu kurva kubik
 * (kontrol1 x,y, kontrol2 x,y, titik akhir x,y); mulai dari (0,0) di dasar api.
 */
private val FLAME =
    floatArrayOf(
        -0.58f, 0.00f, -1.00f, 0.26f, -0.95f, 0.50f,
        -0.92f, 0.64f, -0.80f, 0.72f, -0.64f, 0.86f,
        -0.58f, 0.74f, -0.50f, 0.66f, -0.36f, 0.60f,
        -0.26f, 0.78f, -0.04f, 0.80f, 0.12f, 1.00f,
        0.26f, 0.84f, 0.60f, 0.74f, 0.78f, 0.60f,
        0.90f, 0.50f, 0.96f, 0.40f, 0.95f, 0.30f,
        0.90f, 0.10f, 0.50f, 0.00f, 0.00f, 0.00f,
    )

/** Susun ulang [path] untuk satu lapisan api; [sway] menggoyang bagian atas, [flick] meregangkan tinggi. */
private fun buildFlamePath(
    path: Path,
    cx: Float,
    bottom: Float,
    hw: Float,
    h: Float,
    sx: Float,
    sy: Float,
    sway: Float,
    flick: Float,
) {
    fun px(x: Float, y: Float) = cx + (x * sx + sway * y * y) * hw

    fun py(y: Float) = bottom - y * sy * (1f + flick * y) * h
    path.reset()
    path.moveTo(px(0f, 0f), py(0f))
    var i = 0
    while (i < FLAME.size) {
        path.cubicTo(
            px(FLAME[i], FLAME[i + 1]),
            py(FLAME[i + 1]),
            px(FLAME[i + 2], FLAME[i + 3]),
            py(FLAME[i + 3]),
            px(FLAME[i + 4], FLAME[i + 5]),
            py(FLAME[i + 5]),
        )
        i += 6
    }
    path.close()
}

private fun frac(x: Float): Float = x - floor(x)

/**
 * Api kartun: tiga lapisan (luar, tengah, inti) dengan garis tepi tebal dan kilau, bergoyang, berdenyut,
 * serta percikan yang naik dan memudar. Semua posisi partikel dihitung dari satu jam (tanpa status per partikel),
 * jadi tidak ada alokasi per frame dan hanya fase gambar yang digambar ulang.
 */
@Composable
fun FlameView(
    look: FlameLook,
    modifier: Modifier = Modifier,
    animated: Boolean = true,
    particles: Int = 12,
) {
    val clock: State<Float>? =
        if (animated) {
            rememberInfiniteTransition(label = "flame").animateFloat(
                initialValue = 0f,
                targetValue = 1000f,
                animationSpec = infiniteRepeatable(tween(1_000_000, easing = LinearEasing)),
                label = "flameTime",
            )
        } else {
            null
        }
    val path = remember { Path() }

    Canvas(modifier) {
        val t = clock?.value ?: 0f
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val bottom = h * 0.94f
        val fh = h * 0.70f
        val hw = minOf(w * 0.40f, fh * 0.55f)

        val sway = sin(t * 3.9f) * 0.10f + sin(t * 11f + 1.3f) * 0.03f
        val flick = sin(t * 7.8f) * 0.035f
        val style = if (look.rainbow) rainbowStyle(t * 60f) else look.style

        // cahaya di belakang api, berdenyut pelan
        val pulse = 0.85f + 0.15f * sin(t * 4.2f)
        val glowCenter = Offset(cx, bottom - fh * 0.42f)
        val glowR = fh * 0.85f
        drawCircle(
            Brush.radialGradient(
                listOf(style.glow.copy(alpha = (0.42f * pulse).coerceIn(0f, 1f)), Color.Transparent),
                center = glowCenter,
                radius = glowR,
            ),
            radius = glowR,
            center = glowCenter,
        )

        fun layer(sx: Float, sy: Float, swayK: Float, colors: List<Color>) {
            buildFlamePath(path, cx, bottom, hw, fh, sx, sy, sway * swayK, flick)
            drawPath(
                path,
                Brush.verticalGradient(
                    0f to colors[0],
                    0.5f to colors[1],
                    1f to colors[2],
                    startY = bottom - fh,
                    endY = bottom,
                ),
            )
        }

        // lapisan luar + garis tepi tebal (gaya kartun)
        layer(1f, 1f, 1f, style.outer)
        drawPath(path, style.outline, style = Stroke(width = hw * 0.085f, join = StrokeJoin.Round))
        // lapisan tengah dan inti
        layer(0.68f, 0.66f, 0.8f, style.mid)
        layer(0.40f, 0.40f, 0.6f, style.core)

        // kilau putih kecil di bahu kiri
        val gl = Offset(cx - hw * 0.62f, bottom - fh * 0.40f)
        rotate(-18f, pivot = gl) {
            drawOval(
                Color.White.copy(alpha = if (look.smoke > 0.5f) 0.12f else 0.30f),
                topLeft = Offset(gl.x - hw * 0.07f, gl.y - fh * 0.14f),
                size = Size(hw * 0.14f, fh * 0.28f),
            )
        }

        // percikan (api hidup) dan asap (api padam)
        val emberW = 1f - look.smoke
        val smokeW = look.smoke
        for (i in 0 until particles) {
            val s1 = frac(i * 0.7548777f)
            val s2 = frac(i * 0.5698403f + 0.31f)
            val s3 = frac(i * 0.3819660f + 0.17f)
            val life = 1.5f + s1 * 1.7f
            val p = frac(t / life + s2)
            val xr = (s3 - 0.5f) * 1.2f
            val x = cx + (xr * (1f - 0.55f * p) + sin((p * 2.5f + s1) * 6.2832f) * 0.10f + sway * p * 0.8f) * hw
            val y = bottom - (0.22f + p * 1.02f) * fh
            if (emberW > 0.02f) {
                val a = ((1f - p) * (1f - p) * minOf(1f, p * 10f) * emberW).coerceIn(0f, 1f)
                val r = hw * (0.045f + 0.075f * s2) * (1f - 0.75f * p)
                val c = if (look.rainbow) hue(t * 60f + i * 47f, 0.7f) else style.ember
                drawCircle(c.copy(alpha = a), r, Offset(x, y))
            }
            if (smokeW > 0.02f && i % 2 == 0) {
                val a = (0.22f * (1f - p) * minOf(1f, p * 6f) * smokeW).coerceIn(0f, 1f)
                val r = hw * (0.10f + 0.22f * p)
                drawCircle(Color(0xFF9A9AAE).copy(alpha = a), r, Offset(x, y - fh * 0.10f * p))
            }
        }
    }
}

// ============================================================================================
// Kartu Beranda + sheet detail
// ============================================================================================

private fun daysToNext(days: Int): Int? = flameTierFor(days).next?.let { it.from - days }

/**
 * Kartu streak di Beranda. Bila api baru saja padam (terlewat sehari atau lebih), kartu memperlihatkan api hitam
 * dengan angka lama, lalu api menyala lagi dari 1. Animasi itu hanya diputar sekali.
 */
@Composable
fun StreakCard(modifier: Modifier = Modifier) {
    val app = AlterApp.instance
    val lib by app.library.data.collectAsState()
    val days = lib.streak
    val lost = lib.streakLost
    var sheet by remember { mutableStateOf(false) }
    val ignite = remember { Animatable(if (lost > 0) 0f else 1f) }

    LaunchedEffect(lost) {
        if (lost > 0) {
            ignite.snapTo(0f)
            delay(1900)
            ignite.animateTo(1f, tween(1100))
            delay(700)
            app.library.clearStreakLost()
        } else {
            ignite.snapTo(1f)
        }
    }

    if (days <= 0 && lost <= 0) return

    val iv = ignite.value
    val relighting = lost > 0 && iv < 1f
    val tier = flameTierFor(days)
    val look =
        if (relighting) {
            FlameLook(lerpStyle(StyleBlack, styleFor(FlameTier.SPARK), iv), smoke = 1f - iv)
        } else {
            flameLookFor(tier)
        }
    val shownDays = if (lost > 0 && iv < 0.5f) lost else days
    val accent = accentOf(look)
    val toNext = daysToNext(days)

    val subtitle =
        when {
            lost > 0 && iv < 0.5f -> "Apimu padam. Terlewat satu hari atau lebih."
            lost > 0 -> "Menyala lagi dari 1"
            toNext != null -> "${tier.title} • $toNext hari lagi menuju ${tier.next?.title}"
            else -> "${tier.title} • puncak tertinggi"
        }

    Row(
        modifier
            .fillMaxWidth()
            .bounceClick { sheet = true }
            .clip(RoundedCornerShape(16.dp))
            .background(AlterColors.Surface)
            .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.24f), Color.Transparent)))
            .padding(start = 8.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FlameView(look, Modifier.size(84.dp), particles = 10)
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    shownDays.toString(),
                    style = T.screen.copy(fontSize = 40.sp, lineHeight = 44.sp),
                    color = Color.White,
                )
                Text(
                    "hari berturut-turut",
                    style = T.title.copy(fontWeight = FontWeight.Medium),
                    color = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.padding(start = 8.dp, bottom = 7.dp),
                )
            }
            Text(subtitle, style = T.small, color = AlterColors.Sub, maxLines = 2)
        }
    }

    if (sheet) StreakSheet { sheet = false }
}

/** Detail streak: api besar, kemajuan ke tingkat berikutnya, rekor, dan tangga warna. */
@Composable
fun StreakSheet(onDismiss: () -> Unit) {
    val app = AlterApp.instance
    val lib by app.library.data.collectAsState()
    val days = lib.streak.coerceAtLeast(1)
    val tier = flameTierFor(days)
    val look = flameLookFor(tier)
    val accent = accentOf(look)
    val next = tier.next
    val progress = if (next == null) 1f else ((days - tier.from).toFloat() / (next.from - tier.from)).coerceIn(0f, 1f)

    BottomSheetDialog(onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 620.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            FlameView(look, Modifier.size(170.dp), particles = 16)
            Text(days.toString(), style = T.screen.copy(fontSize = 48.sp, lineHeight = 52.sp), color = Color.White)
            Text("hari berturut-turut", style = T.body, color = AlterColors.Sub)
            Spacer(Modifier.height(10.dp))
            Text(tier.title, style = T.title.copy(fontWeight = FontWeight.Bold), color = accent)

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(AlterColors.Surface3),
            ) {
                Box(Modifier.fillMaxWidth(progress).height(8.dp).background(accent))
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (next != null) "${next.from - days} hari lagi menuju ${next.title}" else "Kamu sudah di puncak: Api Pelangi",
                style = T.small,
                color = AlterColors.Sub,
            )
            Text("Rekor terbaikmu: ${maxOf(lib.streakBest, days)} hari", style = T.small, color = AlterColors.Sub)

            Spacer(Modifier.height(14.dp))
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                FlameTier.entries.forEach { t ->
                    val reached = days >= t.from
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FlameView(flameLookFor(t), Modifier.size(36.dp).alpha(if (reached) 1f else 0.4f), animated = false, particles = 0)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                t.title,
                                style = T.body.copy(fontWeight = FontWeight.SemiBold),
                                color = if (reached) Color.White else AlterColors.Sub,
                            )
                            Text(if (t.from == 1) "Mulai" else "${t.from} hari", style = T.tiny, color = AlterColors.Muted)
                        }
                        if (reached) Ic(R.drawable.ic_check, tint = accentOf(flameLookFor(t)), size = 22.dp)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(
                "Buka Alterlist setiap hari supaya apimu tidak padam. Kalau terlewat sehari atau lebih, api padam menjadi api hitam dan mulai lagi dari 1.",
                style = T.small,
                color = AlterColors.Muted,
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}
