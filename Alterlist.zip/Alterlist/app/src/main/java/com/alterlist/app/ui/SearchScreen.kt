package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.Category
import com.alterlist.app.data.Entry
import com.alterlist.app.data.SearchFilter
import com.alterlist.app.data.UiLoad
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(padding: PaddingValues, onEntry: (Entry) -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val focus = LocalFocusManager.current
    val lib by app.library.data.collectAsState()

    var query by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(SearchFilter.SONG) }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    var results by remember { mutableStateOf<UiLoad<List<Entry>>>(UiLoad.Idle) }
    var categories by remember { mutableStateOf<UiLoad<List<Category>>>(UiLoad.Loading) }
    var attempt by remember { mutableIntStateOf(0) }

    fun submit(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        query = q
        submitted = q
        app.library.addSearch(q)
        focus.clearFocus()
    }

    LaunchedEffect(attempt) {
        categories =
            try {
                val list = app.yt.moodsAndGenres()
                if (list.isEmpty()) UiLoad.Idle else UiLoad.Data(list)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error("Kategori tidak bisa dimuat")
            }
    }

    LaunchedEffect(query, submitted) {
        val q = query.trim()
        if (q.isEmpty() || q == submitted) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(250)
        suggestions =
            try {
                app.yt.suggestions(q)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
    }

    LaunchedEffect(submitted, filter, attempt) {
        if (submitted.isBlank()) {
            results = UiLoad.Idle
            return@LaunchedEffect
        }
        results = UiLoad.Loading
        results =
            try {
                UiLoad.Data(app.yt.search(submitted, filter))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error(e.message ?: "Pencarian gagal")
            }
    }

    Column(Modifier.fillMaxSize().padding(padding)) {
        Text("Cari", style = T.screen, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 12.dp))

        // kolom pencarian putih ala Spotify
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ic(R.drawable.ic_search, tint = Color.Black, size = 24.dp, modifier = Modifier.padding(start = 12.dp))
            Box(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                if (query.isEmpty()) {
                    Text("Apa yang ingin kamu putar?", style = T.body.copy(fontSize = 16.sp), color = Color(0xFF6A6A6A))
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = T.body.copy(fontSize = 16.sp, color = Color.Black),
                    cursorBrush = SolidColor(AlterColors.Red),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { submit(query) }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                IconBtn(
                    R.drawable.ic_close,
                    {
                        query = ""
                        submitted = ""
                    },
                    tint = Color.Black,
                    size = 20.dp,
                    box = 44.dp,
                )
            }
        }

        if (submitted.isNotBlank()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SearchFilter.entries.forEach { f -> AlterChip(f.label, filter == f, { filter = f }) }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        val showSuggestions = suggestions.isNotEmpty() && query.trim() != submitted

        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
            if (showSuggestions) {
                items(suggestions) { s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { submit(s) }.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Ic(R.drawable.ic_search, tint = AlterColors.Sub, size = 20.dp)
                        Spacer(Modifier.width(16.dp))
                        Text(s, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } else if (submitted.isBlank()) {
                if (lib.searches.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            SectionTitle("Pencarian terakhir", Modifier.weight(1f))
                            Text(
                                "Hapus semua",
                                style = T.small,
                                color = AlterColors.Sub,
                                modifier = Modifier.clickable { app.library.clearSearches() }.padding(8.dp),
                            )
                        }
                    }
                    items(lib.searches) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { submit(s) }.padding(start = 16.dp, top = 2.dp, bottom = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Ic(R.drawable.ic_history, tint = AlterColors.Sub, size = 20.dp)
                            Spacer(Modifier.width(16.dp))
                            Text(s, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            IconBtn(R.drawable.ic_close, { app.library.removeSearch(s) }, tint = AlterColors.Sub, size = 18.dp)
                        }
                    }
                }
                item { SectionTitle("Jelajahi semua") }
                when (val c = categories) {
                    is UiLoad.Data ->
                        items(c.value.chunked(2)) { pair ->
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                pair.forEach { cat ->
                                    CategoryTile(cat, Modifier.weight(1f)) { ui.navigate(Route.CategoryPage(cat)) }
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    is UiLoad.Loading -> item { LoadingBox() }
                    is UiLoad.Error -> item { ErrorBox(c.message, onRetry = { attempt++ }) }
                    else -> Unit
                }
                item { Spacer(Modifier.height(16.dp)) }
            } else {
                when (val r = results) {
                    is UiLoad.Data ->
                        if (r.value.isEmpty()) {
                            item { EmptyText("Tidak ada hasil untuk \"$submitted\"") }
                        } else {
                            items(r.value) { entry -> EntryRow(entry, onClick = { onEntry(entry) }) }
                        }
                    is UiLoad.Loading -> item { LoadingBox() }
                    is UiLoad.Error -> item { ErrorBox(r.message, onRetry = { attempt++ }) }
                    is UiLoad.Idle -> Unit
                }
            }
        }
    }
}

@Composable
private fun CategoryTile(category: Category, modifier: Modifier, onClick: () -> Unit) {
    val color = Color(category.color or 0xFF000000.toInt())
    Box(
        modifier.height(92.dp).clip(RoundedCornerShape(8.dp)).background(color).clickable(onClick = onClick),
    ) {
        Text(
            category.title,
            style = T.title.copy(fontWeight = FontWeight.Bold, fontSize = 17.sp),
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(12.dp).fillMaxWidth(0.75f),
        )
        Ic(
            R.drawable.ic_music_note,
            tint = Color.Black.copy(alpha = 0.22f),
            size = 54.dp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 6.dp, bottom = 4.dp).rotate(22f),
        )
    }
}
