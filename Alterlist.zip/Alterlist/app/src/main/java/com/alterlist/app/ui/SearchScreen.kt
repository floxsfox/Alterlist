package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.Category
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import com.alterlist.app.data.LinkHandler
import com.alterlist.app.data.LyricHit
import com.alterlist.app.data.LyricSearch
import com.alterlist.app.data.SearchFilter
import com.alterlist.app.data.UiLoad
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

@Composable
fun SearchScreen(padding: PaddingValues, onEntry: (Entry) -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val focus = LocalFocusManager.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current
    val lib by app.library.data.collectAsState()

    var query by rememberSaveable { mutableStateOf("") }
    var submitted by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(SearchFilter.SONG) }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    var lyricMode by remember { mutableStateOf(false) }
    var lyricHits by remember { mutableStateOf<List<LyricHit>>(emptyList()) }
    var lyricBusy by remember { mutableStateOf(false) }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var next by remember { mutableStateOf<String?>(null) }
    var phase by remember { mutableStateOf(SearchPhase.IDLE) }
    var errorMsg by remember { mutableStateOf("") }
    var loadingMore by remember { mutableStateOf(false) }
    var moreError by remember { mutableStateOf(false) }
    var retryTick by remember { mutableIntStateOf(0) }
    val online by app.network.online.collectAsState()
    val local by app.localMusic.state.collectAsState()
    val listState = rememberLazyListState()
    val nearEnd by remember {
        derivedStateOf {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 5
        }
    }
    var categories by remember { mutableStateOf<UiLoad<List<Category>>>(UiLoad.Loading) }
    var attempt by remember { mutableIntStateOf(0) }

    fun submit(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        if (LinkHandler.isLink(q)) {
            // tautan YouTube langsung diputar
            focus.clearFocus()
            scope.launch {
                if (!LinkHandler.play(app, q)) context.toast("Tautan tidak dikenali")
            }
            return
        }
        query = q
        submitted = q
        app.library.addSearch(q)
        focus.clearFocus()
    }

    LaunchedEffect(attempt, online) {
        if (!online) return@LaunchedEffect
        categories =
            try {
                val list = app.yt.moodsAndGenres()
                if (list.isEmpty()) UiLoad.Idle else UiLoad.Data(list)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                UiLoad.Error("Kategori tidak bisa dimuat")
            }
    }

    LaunchedEffect(query, submitted) {
        val q = query.trim()
        if (q.isEmpty() || q == submitted) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        delay(250)
        if (!app.network.online.value) return@LaunchedEffect
        suggestions =
            try {
                app.yt.suggestions(q)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
    }

    // Pencarian tanpa batas: halaman pertama dimuat langsung, halaman berikutnya otomatis dimuat
    // setiap kali daftar hampir mentok, sampai YouTube Music tidak punya hasil lagi.
    LaunchedEffect(submitted, lyricMode, online) {
        lyricHits = emptyList()
        if (!lyricMode || submitted.isBlank() || !online) return@LaunchedEffect
        lyricBusy = true
        lyricHits = LyricSearch.search(submitted)
        lyricBusy = false
    }

    LaunchedEffect(submitted, filter, attempt, online, lyricMode) {
        entries = emptyList()
        next = null
        loadingMore = false
        moreError = false
        listState.scrollToItem(0)
        if (submitted.isBlank()) {
            phase = SearchPhase.IDLE
            return@LaunchedEffect
        }
        if (!online || lyricMode) {
            phase = SearchPhase.READY
            return@LaunchedEffect
        }
        phase = SearchPhase.LOADING
        val seen = HashSet<String>()
        try {
            val first = app.yt.searchPage(submitted, filter, null)
            entries = first.entries.filter { seen.add(entryKey(it)) }
            next = first.next
            phase = SearchPhase.READY
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            errorMsg = e.message ?: "Pencarian gagal"
            phase = SearchPhase.ERROR
            return@LaunchedEffect
        }
        var emptyPages = 0
        while (next != null) {
            snapshotFlow { nearEnd }.first { it }
            val token = next ?: break
            loadingMore = true
            try {
                val page = app.yt.searchPage(submitted, filter, token)
                val fresh = page.entries.filter { seen.add(entryKey(it)) }
                entries = entries + fresh
                next = if (page.next == token) null else page.next
                if (fresh.isEmpty()) {
                    emptyPages++
                    if (emptyPages >= 3) next = null
                } else {
                    emptyPages = 0
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                moreError = true
                loadingMore = false
                val tick = retryTick
                snapshotFlow { retryTick }.first { it != tick }
                moreError = false
                continue
            }
            loadingMore = false
        }
    }

    val localHits =
        remember(submitted, filter, local.songs) {
            if (filter == SearchFilter.SONG && submitted.isNotBlank()) app.localMusic.search(submitted, 20) else emptyList()
        }
    val downloadHits =
        remember(submitted, lib.downloads, online) {
            if (!online && submitted.isNotBlank()) {
                val q = submitted.lowercase()
                lib.downloads.map { it.song }.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
            } else {
                emptyList()
            }
        }

    Column(Modifier.fillMaxSize().padding(padding)) {
        Text("Cari", style = T.screen, modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 12.dp))

        // kolom pencarian putih ala Spotify
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color.White),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Ic(R.drawable.ic_search, tint = Color.Black, size = 24.dp, modifier = Modifier.padding(start = 12.dp))
            Box(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                if (query.isEmpty()) {
                    Text("Apa yang ingin kamu putar?", style = T.body.copy(fontSize = 16.sp), color = Color(0xFF6A6A6A))
                }
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = T.body.copy(fontSize = 16.sp, color = Color.Black),
                    cursorBrush = SolidColor(AlterColors.Red),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { submit(query) }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (query.isNotEmpty()) {
                IconBtn(
                    R.drawable.ic_close,
                    {
                        query = ""
                        submitted = ""
                    },
                    tint = Color.Black,
                    size = 20.dp,
                    box = 44.dp,
                )
            }
        }

        if (submitted.isNotBlank()) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                SearchFilter.entries.forEach { f -> AlterChip(f.label, !lyricMode && filter == f, { lyricMode = false; filter = f }) }
                AlterChip("Lirik", lyricMode, { lyricMode = true })
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }

        val showSuggestions = suggestions.isNotEmpty() && query.trim() != submitted

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
            if (showSuggestions) {
                items(suggestions) { s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { submit(s) }.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Ic(R.drawable.ic_search, tint = AlterColors.Sub, size = 20.dp)
                        Spacer(Modifier.width(16.dp))
                        Text(s, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            } else if (submitted.isBlank()) {
                if (lib.searches.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth().padding(end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            SectionTitle("Pencarian terakhir", Modifier.weight(1f))
                            Text(
                                "Hapus semua",
                                style = T.small,
                                color = AlterColors.Sub,
                                modifier = Modifier.clickable { app.library.clearSearches() }.padding(8.dp),
                            )
                        }
                    }
                    items(lib.searches) { s ->
                        Row(
                            Modifier.fillMaxWidth().clickable { submit(s) }.padding(start = 16.dp, top = 2.dp, bottom = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Ic(R.drawable.ic_history, tint = AlterColors.Sub, size = 20.dp)
                            Spacer(Modifier.width(16.dp))
                            Text(s, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            IconBtn(R.drawable.ic_close, { app.library.removeSearch(s) }, tint = AlterColors.Sub, size = 18.dp)
                        }
                    }
                }
                item { SectionTitle("Jelajahi semua") }
                if (!online) {
                    item { EmptyText("Offline") }
                }
                when (val c = if (online) categories else UiLoad.Idle) {
                    is UiLoad.Data ->
                        items(c.value.chunked(2)) { pair ->
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                pair.forEach { cat ->
                                    CategoryTile(cat, Modifier.weight(1f)) { ui.navigate(Route.CategoryPage(cat)) }
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                    is UiLoad.Loading -> item { LoadingBox() }
                    is UiLoad.Error -> item { ErrorBox(c.message, onRetry = { attempt++ }) }
                    else -> Unit
                }
                item { Spacer(Modifier.height(16.dp)) }
            } else {
                if (!online) {
                    item { EmptyText("Offline: hanya unduhan dan perangkat") }
                }
                if (localHits.isNotEmpty()) {
                    item(key = "local-title") { SectionTitle("Di perangkat") }
                    items(localHits, key = { "local-" + it.id }) { s ->
                        SongRow(s, onClick = { app.player.playSongs(localHits, localHits.indexOf(s)) })
                    }
                }
                if (downloadHits.isNotEmpty()) {
                    item(key = "dl-title") { SectionTitle("Unduhan") }
                    items(downloadHits, key = { "dl-" + it.id }) { s ->
                        SongRow(s, onClick = { app.player.playSongs(downloadHits, downloadHits.indexOf(s)) })
                    }
                }
                if (lyricMode) {
                    if (lyricBusy) {
                        items(5) { SkeletonRow() }
                    } else if (lyricHits.isEmpty()) {
                        if (online) item { EmptyText("Tidak ada lirik yang cocok") }
                    } else {
                        items(lyricHits) { h ->
                            Column(
                                Modifier.fillMaxWidth().clickable {
                                    scope.launch {
                                        val found = runCatching { app.yt.search(h.title + " " + h.artist, SearchFilter.SONG).firstNotNullOfOrNull { it.toSong() } }.getOrNull()
                                        if (found != null) app.player.playRadio(found) else context.toast("Lagu tidak ditemukan")
                                    }
                                }.padding(horizontal = 16.dp, vertical = 10.dp),
                            ) {
                                Text(h.title, style = T.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(h.artist, style = T.small, color = AlterColors.Sub, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (h.snippet.isNotBlank()) Text("\"${h.snippet}\"", style = T.small, color = AlterColors.RedSoft, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                } else when (phase) {
                    SearchPhase.LOADING -> items(7) { SkeletonRow() }
                    SearchPhase.ERROR -> item { ErrorBox(errorMsg, onRetry = { attempt++ }) }
                    SearchPhase.READY -> {
                        if (entries.isEmpty()) {
                            if (online && localHits.isEmpty()) item { EmptyText("Tidak ada hasil untuk \"$submitted\"") }
                        } else {
                            val songs = entries.mapNotNull { if (it.kind == EntryKind.SONG) it.toSong() else null }
                            if (filter == SearchFilter.SONG && songs.size > 1) {
                                item(key = "play-all") {
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Text("${entries.size}${if (next != null) "+" else ""} hasil", style = T.small, color = AlterColors.Sub, modifier = Modifier.weight(1f))
                                        PillButton("Putar semua", { app.player.playSongs(songs) }, icon = R.drawable.ic_play)
                                        PillButton("Acak", { app.player.playSongs(songs, songs.indices.random(), shuffle = true) }, container = AlterColors.Surface3, icon = R.drawable.ic_shuffle)
                                    }
                                }
                            }
                            itemsIndexed(entries, key = { _, e -> entryKey(e) }) { i, entry ->
                                EntryRow(entry, onClick = { onEntry(entry) }, modifier = Modifier.appear(if (i < 8) i else 0))
                            }
                            item(key = "footer") {
                                when {
                                    moreError ->
                                        Text(
                                            "Gagal memuat lagi. Ketuk untuk coba lagi.",
                                            style = T.small,
                                            color = AlterColors.RedSoft,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth().clickable { retryTick++ }.padding(20.dp),
                                        )
                                    loadingMore || next != null ->
                                        Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                                            CircularProgressIndicator(color = AlterColors.Red, strokeWidth = 2.5.dp, modifier = Modifier.size(24.dp))
                                        }
                                    else ->
                                        Text(
                                            "Itu semua hasil untuk \"$submitted\" (${entries.size})",
                                            style = T.small,
                                            color = AlterColors.Muted,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                                        )
                                }
                            }
                        }
                    }
                    SearchPhase.IDLE -> Unit
                }
            }
        }
    }
}

private enum class SearchPhase { IDLE, LOADING, READY, ERROR }

private fun entryKey(e: Entry): String = e.videoId ?: e.browseId ?: e.playlistId ?: (e.title + "|" + e.subtitle)

@Composable
private fun SkeletonRow() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        ShimmerBox(Modifier.size(50.dp), RoundedCornerShape(5.dp))
        Spacer(Modifier.width(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            ShimmerBox(Modifier.width(190.dp).height(13.dp))
            ShimmerBox(Modifier.width(120.dp).height(11.dp))
        }
    }
}

@Composable
private fun CategoryTile(category: Category, modifier: Modifier, onClick: () -> Unit) {
    val color = Color(category.color or 0xFF000000.toInt())
    Box(
        modifier.height(92.dp).clip(RoundedCornerShape(8.dp)).background(color).clickable(onClick = onClick),
    ) {
        Text(
            category.title,
            style = T.title.copy(fontWeight = FontWeight.Bold, fontSize = 17.sp),
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(12.dp).fillMaxWidth(0.75f),
        )
        Ic(
            R.drawable.ic_music_note,
            tint = Color.Black.copy(alpha = 0.22f),
            size = 54.dp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 6.dp, bottom = 4.dp).rotate(22f),
        )
    }
}
