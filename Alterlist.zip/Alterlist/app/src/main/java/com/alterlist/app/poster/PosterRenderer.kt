package com.alterlist.app.poster

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Menggambar adegan "playlist 3D": latar gradasi + sampul kabur, judul raksasa DI BELAKANG subjek, cincin sampul
 * yang berputar (separuh di belakang subjek, separuh di depannya), lalu subjek hasil potongan foto.
 * Satu kode untuk pratinjau di aplikasi, ekspor PNG, dan wallpaper hidup. [tx]/[ty] = kemiringan -1..1, [t] = detik.
 */
class PosterRenderer(private val data: PosterData) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(70, 255, 255, 255) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    private val cam = Camera()
    private val m = Matrix()
    private val sm = Matrix()
    private val rect = RectF()
    private val shaders = data.covers.map { BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
    private val blurSrc: Bitmap? = data.covers.firstOrNull()?.let { Bitmap.createScaledBitmap(it, 20, 20, true) }
    private val title = data.title.uppercase().let { if (it.length > 20) it.take(19) + "…" else it }

    private var bgW = -1
    private var bgH = -1
    private var bgShader: LinearGradient? = null

    private val top: Int = blend(data.accent, 0xFF0A0A0C.toInt(), 0.62f)

    fun draw(c: Canvas, w: Int, h: Int, tx: Float, ty: Float, t: Float) {
        val width = w.toFloat()
        val height = h.toFloat()
        drawBackground(c, w, h, width, height, tx, ty)

        val hasCutout = data.cutout != null
        val cx = width / 2f + tx * width * 0.05f
        val cy = height * (if (hasCutout) 0.57f else 0.5f) - ty * height * 0.02f
        drawTitle(c, width, height, tx, ty, hasCutout)

        val n = max(8, data.covers.size)
        val radius = width * (if (hasCutout) 0.41f else 0.36f)
        val size = width * (if (hasCutout) 0.27f else 0.32f)
        val phase = t * 0.2f + tx * 0.9f
        val order = (0 until n).sortedBy { cos(2.0 * PI * it / n + phase) }
        // cincin: yang jauh digambar sebelum subjek, yang dekat sesudahnya
        for (i in order) {
            val a = 2.0 * PI * i / n + phase
            if (hasCutout && cos(a) > 0.12) continue
            ring(c, i, a, cx, cy, radius, size, tx, ty, width)
        }
        if (hasCutout) {
            drawSubject(c, width, height, tx, ty)
            for (i in order) {
                val a = 2.0 * PI * i / n + phase
                if (cos(a) <= 0.12) continue
                ring(c, i, a, cx, cy, radius, size, tx, ty, width)
            }
        }
        drawFooter(c, width, height)
    }

    private fun drawBackground(c: Canvas, w: Int, h: Int, width: Float, height: Float, tx: Float, ty: Float) {
        if (bgShader == null || bgW != w || bgH != h) {
            bgShader = LinearGradient(0f, 0f, 0f, height, intArrayOf(top, 0xFF0B0B0D.toInt()), null, Shader.TileMode.CLAMP)
            bgW = w
            bgH = h
        }
        paint.shader = bgShader
        paint.alpha = 255
        c.drawRect(0f, 0f, width, height, paint)
        paint.shader = null
        blurSrc?.let {
            // 20x20 yang diperbesar dengan filter = latar kabur halus
            rect.set(-width * 0.2f - tx * width * 0.03f, -height * 0.1f, width * 1.2f - tx * width * 0.03f, height * 1.1f)
            paint.alpha = 95
            c.drawBitmap(it, null, rect, paint)
            paint.alpha = 255
        }
        val glow =
            RadialGradient(
                width / 2f - tx * width * 0.04f, height * 0.5f - ty * height * 0.02f, width * 0.9f,
                intArrayOf(withAlpha(data.accent, 90), withAlpha(data.accent, 0)), null, Shader.TileMode.CLAMP,
            )
        paint.shader = glow
        c.drawRect(0f, 0f, width, height, paint)
        paint.shader = null
    }

    private fun drawTitle(c: Canvas, width: Float, height: Float, tx: Float, ty: Float, hasCutout: Boolean) {
        var size = width * 0.24f
        textPaint.textSize = size
        val maxW = width * 0.92f
        val measured = textPaint.measureText(title)
        if (measured > maxW) {
            size *= maxW / measured
            textPaint.textSize = size
        }
        val x = width / 2f - textPaint.measureText(title) / 2f - tx * width * 0.035f
        val y = height * (if (hasCutout) 0.30f else 0.2f) - ty * height * 0.03f
        textPaint.shader = LinearGradient(x, y - size, x + textPaint.measureText(title), y, Color.WHITE, blend(data.accent, Color.WHITE, 0.35f), Shader.TileMode.CLAMP)
        textPaint.alpha = 235
        c.drawText(title, x, y, textPaint)
        textPaint.shader = null
    }

    private fun drawSubject(c: Canvas, width: Float, height: Float, tx: Float, ty: Float) {
        val bmp = data.cutout ?: return
        var sw = width * 0.98f
        var sh = sw * bmp.height / bmp.width
        val maxH = height * 0.8f
        if (sh > maxH) {
            sh = maxH
            sw = sh * bmp.width / bmp.height
        }
        val left = (width - sw) / 2f - tx * width * 0.025f
        val topY = height - sh + height * 0.012f - ty * height * 0.01f
        rect.set(left, topY, left + sw, topY + sh)
        paint.alpha = 255
        c.drawBitmap(bmp, null, rect, paint)
    }

    private fun drawFooter(c: Canvas, width: Float, height: Float) {
        textPaint.textSize = width * 0.036f
        textPaint.alpha = 150
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        val sub = data.subtitle
        c.drawText(sub, width / 2f - textPaint.measureText(sub) / 2f, height - height * 0.05f, textPaint)
        textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textPaint.alpha = 255
    }

    private fun ring(c: Canvas, i: Int, a: Double, cx: Float, cy: Float, radius: Float, size: Float, tx: Float, ty: Float, width: Float) {
        if (shaders.isEmpty()) return
        val sx = sin(a).toFloat()
        val cz = cos(a).toFloat() // 1 = paling dekat
        val near = cz * 0.5f + 0.5f
        val x = cx + radius * sx + tx * width * 0.06f * (near - 0.5f)
        val y = cy + cz * radius * (0.24f + 0.2f * ty)
        val s = 0.7f + 0.36f * near
        val alpha = (110 + 145 * near).toInt()
        card(c, i % shaders.size, x, y, size * s, -sx * 38f, ty * 12f, alpha, (1f - near) * 0.45f, width)
    }

    private fun card(c: Canvas, idx: Int, x: Float, y: Float, size: Float, rotY: Float, rotX: Float, alpha: Int, dim: Float, width: Float) {
        val bmp = data.covers[idx]
        cam.save()
        cam.setLocation(0f, 0f, -8f * (width / 1080f).coerceAtLeast(0.2f))
        cam.rotateY(rotY)
        cam.rotateX(rotX)
        cam.getMatrix(m)
        cam.restore()
        m.preTranslate(-size / 2f, -size / 2f)
        m.postTranslate(x, y)
        c.save()
        c.concat(m)
        sm.setScale(size / bmp.width, size / bmp.height)
        shaders[idx].setLocalMatrix(sm)
        cardPaint.shader = shaders[idx]
        cardPaint.alpha = alpha
        val r = size * 0.09f
        c.drawRoundRect(0f, 0f, size, size, r, r, cardPaint)
        if (dim > 0.01f) {
            shadePaint.color = Color.argb((dim * 255).toInt().coerceIn(0, 255), 0, 0, 0)
            c.drawRoundRect(0f, 0f, size, size, r, r, shadePaint)
        }
        strokePaint.strokeWidth = max(1f, size * 0.008f)
        c.drawRoundRect(0f, 0f, size, size, r, r, strokePaint)
        c.restore()
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun blend(a: Int, b: Int, t: Float): Int {
        val k = min(1f, max(0f, t))
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt(),
        )
    }
}
