package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.ArtistRef
import com.alterlist.app.data.BrowsePage
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import com.alterlist.app.data.Shelf
import com.alterlist.app.data.Song
import com.alterlist.app.data.UiLoad
import kotlinx.coroutines.CancellationException

private enum class DetailKind { ALBUM, ARTIST, PLAYLIST, LOCAL, LIKED, DOWNLOADS, RECENT, CATEGORY }

private class DetailModel(
    val title: String,
    val subtitle: String,
    val thumb: String?,
    val songs: List<Song>,
    val shelves: List<Shelf>,
    val kind: DetailKind,
    val localId: String? = null,
    val entryId: String? = null,
)

/** Halaman detail: album, playlist, artis, kategori, Lagu disukai, Unduhan, Riwayat, atau playlist lokal. */
@Composable
fun DetailScreen(route: Route, padding: PaddingValues, onBack: () -> Unit, onEntry: (Entry) -> Unit) {
    val app = AlterApp.instance
    val ui = LocalUi.current
    val context = LocalContext.current
    val lib by app.library.data.collectAsState()
    val player by app.player.state.collectAsState()

    val entry = (route as? Route.Browse)?.entry
    val category = (route as? Route.CategoryPage)?.category
    var page by remember(route) {
        mutableStateOf<UiLoad<BrowsePage>>(if (entry?.browseId != null || category != null) UiLoad.Loading else UiLoad.Idle)
    }
    var attempt by remember { mutableIntStateOf(0) }
    var renameOpen by remember { mutableStateOf(false) }
    var deleteOpen by remember { mutableStateOf(false) }

    LaunchedEffect(route, attempt) {
        val bid = entry?.browseId
        if (entry != null && bid != null) {
            page = UiLoad.Loading
            page =
                try {
                    UiLoad.Data(app.yt.browsePage(bid, entry.params, entry.title, entry.thumbnail))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    UiLoad.Error(e.message ?: "Gagal memuat halaman")
                }
        } else if (category != null) {
            page = UiLoad.Loading
            page =
                try {
                    UiLoad.Data(app.yt.browsePage(category.browseId, category.params, category.title, null))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    UiLoad.Error(e.message ?: "Gagal memuat halaman")
                }
        }
    }

    val loaded = page
    val model: DetailModel? =
        when (route) {
            is Route.Liked -> DetailModel("Lagu disukai", "${lib.liked.size} lagu", null, lib.liked, emptyList(), DetailKind.LIKED)
            is Route.Downloads -> {
                val songs = lib.downloads.map { it.song }
                DetailModel("Diunduh", "${songs.size} lagu • bisa diputar offline", null, songs, emptyList(), DetailKind.DOWNLOADS)
            }
            is Route.Recent -> DetailModel("Riwayat putar", "${lib.recent.size} lagu terakhir", null, lib.recent, emptyList(), DetailKind.RECENT)
            is Route.LocalPlaylist ->
                lib.playlists.firstOrNull { it.id == route.id }?.let {
                    DetailModel(it.name, "${it.songs.size} lagu", it.songs.firstOrNull()?.thumbnail, it.songs, emptyList(), DetailKind.LOCAL, localId = it.id)
                }
            is Route.Browse -> {
                val kind =
                    when (route.entry.kind) {
                        EntryKind.ARTIST -> DetailKind.ARTIST
                        EntryKind.ALBUM -> DetailKind.ALBUM
                        else -> DetailKind.PLAYLIST
                    }
                if (loaded is UiLoad.Data) {
                    val p = loaded.value
                    DetailModel(
                        p.title.ifBlank { route.entry.title },
                        p.subtitle.ifBlank { route.entry.subtitle },
                        p.thumbnail ?: route.entry.thumbnail,
                        p.songs,
                        p.shelves,
                        kind,
                        entryId = route.entry.browseId,
                    )
                } else {
                    DetailModel(route.entry.title, route.entry.subtitle, route.entry.thumbnail, emptyList(), emptyList(), kind, entryId = route.entry.browseId)
                }
            }
            is Route.CategoryPage -> {
                if (loaded is UiLoad.Data) {
                    DetailModel(route.category.title, "", null, loaded.value.songs, loaded.value.shelves, DetailKind.CATEGORY)
                } else {
                    DetailModel(route.category.title, "", null, emptyList(), emptyList(), DetailKind.CATEGORY)
                }
            }
            else -> null
        }

    if (model == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val headerFallback =
        when (model.kind) {
            DetailKind.LIKED -> Color(0xFF7A0004)
            DetailKind.DOWNLOADS -> Color(0xFF2C2C30)
            DetailKind.RECENT -> Color(0xFF3A2A2B)
            DetailKind.CATEGORY ->
                category?.let { Color(it.color or 0xFF000000.toInt()) } ?: AlterColors.Surface2
            else -> AlterColors.Surface2
        }
    val dominant by rememberDominantColor(model.thumb, headerFallback)
    val headerColor = if (model.thumb == null) headerFallback else dominant
    var sortMode by remember { mutableIntStateOf(0) }
    var filterText by remember { mutableStateOf("") }
    val canTool = model.songs.size > 6 && (model.localId != null || model.kind == DetailKind.LIKED || model.kind == DetailKind.DOWNLOADS || model.kind == DetailKind.RECENT)
    val songs =
        remember(model.songs, sortMode, filterText, canTool) {
            if (!canTool) {
                model.songs
            } else {
                val q = filterText.trim().lowercase()
                val filtered = if (q.isEmpty()) model.songs else model.songs.filter { it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) }
                when (sortMode) {
                    1 -> filtered.sortedBy { it.title.lowercase() }
                    2 -> filtered.sortedBy { it.artist.lowercase() }
                    3 -> filtered.sortedByDescending { it.durationSeconds ?: 0 }
                    else -> filtered
                }
            }
        }
    val allDownloaded = songs.isNotEmpty() && songs.all { app.downloader.isDownloaded(it.id) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = padding.calculateBottomPadding() + 16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(headerColor, AlterColors.Bg)))) {
                Column(Modifier.fillMaxWidth().statusBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                        IconBtnSolid(R.drawable.ic_chevron_left, onBack)
                    }
                    Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) {
                        when (model.kind) {
                            DetailKind.ARTIST -> Artwork(model.thumb, Modifier.size(190.dp).shadow(18.dp, CircleShape), CircleShape, px = 600)
                            DetailKind.LIKED ->
                                IconTile(R.drawable.ic_heart_fill, listOf(AlterColors.Red, Color(0xFF4A0003)))
                            DetailKind.DOWNLOADS -> IconTile(R.drawable.ic_download, listOf(Color(0xFF45454B), Color(0xFF1C1C1F)))
                            DetailKind.RECENT -> IconTile(R.drawable.ic_history, listOf(Color(0xFF5A4244), Color(0xFF1C1C1F)))
                            DetailKind.CATEGORY -> Spacer(Modifier.height(4.dp))
                            else -> Artwork(model.thumb, Modifier.size(200.dp).shadow(18.dp, RoundedCornerShape(4.dp)), RoundedCornerShape(4.dp), px = 600)
                        }
                    }
                    Text(
                        model.title,
                        style = T.hero.copy(fontSize = 26.sp),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
                    )
                    if (model.subtitle.isNotBlank()) {
                        Text(
                            model.subtitle,
                            style = T.small,
                            color = AlterColors.Sub,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp),
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }

        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                when (model.kind) {
                    DetailKind.ARTIST -> {
                        val id = model.entryId
                        if (id != null) {
                            val following = lib.artists.any { it.id == id }
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(50))
                                    .clickable { app.library.toggleArtist(ArtistRef(id, model.title, model.thumb)) }
                                    .padding(horizontal = 16.dp, vertical = 7.dp),
                            ) {
                                Text(if (following) "Mengikuti" else "Ikuti", style = T.small.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Bold))
                            }
                        }
                    }
                    DetailKind.ALBUM, DetailKind.PLAYLIST, DetailKind.LIKED, DetailKind.RECENT, DetailKind.LOCAL -> {
                        if (songs.isNotEmpty()) {
                            IconBtn(
                                if (allDownloaded) R.drawable.ic_downloaded else R.drawable.ic_download,
                                {
                                    if (allDownloaded) {
                                        context.toast("Semua lagu sudah diunduh")
                                    } else {
                                        app.downloader.enqueueAll(songs)
                                        context.toast("Mengunduh ${songs.size} lagu...")
                                    }
                                },
                                tint = if (allDownloaded) AlterColors.Red else AlterColors.Sub,
                                size = 26.dp,
                            )
                        }
                        if (model.kind == DetailKind.LOCAL) {
                            IconBtn(R.drawable.ic_edit, { renameOpen = true }, tint = AlterColors.Sub)
                            IconBtn(R.drawable.ic_trash, { deleteOpen = true }, tint = AlterColors.Sub)
                        }
                    }
                    else -> Unit
                }
                Spacer(Modifier.weight(1f))
                if (songs.isNotEmpty()) {
                    IconBtn(
                        R.drawable.ic_shuffle,
                        { app.player.playSongs(songs, startIndex = songs.indices.random(), shuffle = true) },
                        tint = Color.White,
                        size = 26.dp,
                    )
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(AlterColors.Red).clickable { app.player.playSongs(songs) },
                        contentAlignment = Alignment.Center,
                    ) { Ic(R.drawable.ic_play, tint = Color.White, size = 28.dp) }
                }
            }
        }

        when (loaded) {
            is UiLoad.Loading -> if (route is Route.Browse || route is Route.CategoryPage) item { LoadingBox() }
            is UiLoad.Error -> item { ErrorBox(loaded.message, onRetry = { attempt++ }) }
            else -> Unit
        }

        if (songs.isEmpty() && loaded !is UiLoad.Loading && loaded !is UiLoad.Error && model.shelves.isEmpty()) {
            item {
                EmptyText(
                    when (model.kind) {
                        DetailKind.LIKED -> "Ketuk ♥ pada lagu untuk menyimpannya di sini."
                        DetailKind.LOCAL -> "Playlist kosong"
                        DetailKind.RECENT -> "Belum ada riwayat putar."
                        DetailKind.DOWNLOADS -> "Belum ada lagu yang diunduh."
                        else -> "Tidak ada lagu yang bisa ditampilkan."
                    },
                )
            }
        }

        if (canTool) {
            item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    FilterField(filterText, { filterText = it }, "Cari di daftar")
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        listOf("Urutan awal", "Judul", "Artis", "Durasi").forEachIndexed { i, label -> AlterChip(label, sortMode == i, { sortMode = i }) }
                    }
                }
            }
        }
        if (songs.isNotEmpty()) {
            if (model.kind == DetailKind.ARTIST) item { SectionTitle("Populer") }
            itemsIndexed(songs) { i, s ->
                SongRow(
                    s,
                    onClick = { app.player.playSongs(songs, i) },
                    isCurrent = player.current?.id == s.id,
                    playlistId = model.localId,
                )
            }
        }

        items(model.shelves) { shelf ->
            ShelfSection(shelf.title) {
                items(shelf.entries) { e ->
                    MediaCard(
                        e.title,
                        e.subtitle,
                        e.thumbnail,
                        shape = if (e.kind == EntryKind.ARTIST) CircleShape else RoundedCornerShape(6.dp),
                    ) { onEntry(e) }
                }
            }
        }
    }

    val localId = model.localId
    if (renameOpen && localId != null) {
        TextInputDialog(
            title = "Ganti nama playlist",
            initial = model.title,
            confirmLabel = "Simpan",
            onDismiss = { renameOpen = false },
            onConfirm = {
                app.library.renamePlaylist(localId, it)
                renameOpen = false
            },
        )
    }
    if (deleteOpen && localId != null) {
        ConfirmDialog(
            title = "Hapus playlist?",
            message = "\"${model.title}\" akan dihapus.",
            confirmLabel = "Hapus",
            onDismiss = { deleteOpen = false },
            onConfirm = {
                deleteOpen = false
                app.library.deletePlaylist(localId) // layar ini menutup sendiri karena playlist sudah tidak ada
            },
        )
    }
}

@Composable
private fun IconTile(iconRes: Int, colors: List<Color>) {
    Box(
        Modifier
            .size(190.dp)
            .shadow(18.dp, RoundedCornerShape(4.dp))
            .clip(RoundedCornerShape(4.dp))
            .background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center,
    ) {
        Ic(iconRes, tint = Color.White, size = 72.dp)
    }
}
