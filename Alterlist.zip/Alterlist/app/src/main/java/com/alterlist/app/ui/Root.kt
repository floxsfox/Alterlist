package com.alterlist.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.PaddingValues
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import androidx.compose.animation.Crossfade
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Tab(val label: String, val icon: Int, val iconActive: Int) {
    HOME("Beranda", R.drawable.ic_home, R.drawable.ic_home_fill),
    SEARCH("Cari", R.drawable.ic_search, R.drawable.ic_search_fill),
    LIBRARY("Koleksi", R.drawable.ic_library, R.drawable.ic_library_fill),
}

@Composable
fun AlterRoot() {
    val app = AlterApp.instance
    val account by app.account.state.collectAsState()
    val ui = remember { UiController() }
    var loginOpen by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalUi provides ui) {
        if (account.mode == AccountMode.UNSET) {
            if (loginOpen) {
                LoginFlow(onDone = { loginOpen = false }, onBack = { loginOpen = false })
            } else {
                WelcomeScreen(onGoogle = { loginOpen = true }, onGuest = { app.account.chooseGuest() })
            }
        } else {
            MainShell(ui)
        }
    }
}

/** WebView login + layar "menyiapkan akun" saat cookie sudah didapat. */
@Composable
private fun LoginFlow(onDone: () -> Unit, onBack: () -> Unit) {
    val app = AlterApp.instance
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        LoginScreen(
            onSuccess = { session ->
                busy = true
                app.yt.setAccount(session)
                app.scope.launch {
                    val info = app.yt.accountInfo()
                    app.account.saveGoogle(session, info)
                    runCatching { app.library.mergeLiked(app.yt.accountLikedSongs()) }
                    withContext(Dispatchers.Main) { onDone() }
                }
            },
            onBack = onBack,
        )
        if (busy) {
            Box(Modifier.fillMaxSize().background(Color.Black).noRippleClickable {}, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AlterColors.Red, strokeWidth = 3.dp)
                    Spacer(Modifier.height(16.dp))
                    Text("Menyiapkan akunmu...", style = T.title)
                }
            }
        }
    }
}

@Composable
private fun MainShell(ui: UiController) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val playerState by app.player.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    val stack = remember { mutableStateListOf<Route>() }
    var expanded by rememberSaveable { mutableStateOf(false) }

    SideEffect {
        ui.navigate = { route -> stack.add(route) }
        ui.openPlayer = { expanded = true }
        ui.closePlayer = { expanded = false }
        ui.goLocal = {
            stack.clear()
            stack.add(Route.Local)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(Unit) { app.player.events.collect { context.toast(it) } }
    LaunchedEffect(Unit) { app.downloader.messages.collect { context.toast(it) } }
    // Beri tahu saat speaker / earphone Bluetooth tersambung atau terputus
    LaunchedEffect(Unit) {
        var last = app.audioOutput.active.value.id
        app.audioOutput.active.collect { o ->
            if (o.id != last) {
                last = o.id
                if (app.settings.state.value.outputToast) {
                    context.toast(if (o.isBluetooth) "Terhubung ke ${o.name}" else "Output audio: ${o.name}")
                }
            }
        }
    }
    val online by app.network.online.collectAsState()
    val backdrop = rememberBackdropState()
    val downloadedIds by remember {
        app.library.data
            .map { d -> d.downloads.mapTo(HashSet<String>()) { it.song.id } as Set<String> }
            .distinctUntilChanged()
    }.collectAsState(initial = emptySet<String>())
    val miniVisible = playerState.current != null

    // Saat pemutar penuh dibuka, fokus kolom Cari dilepas dan keyboard ditutup supaya tidak tertinggal
    // di belakang pemutar dan tidak ada ketukan yang nyasar ke kolom itu.
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(expanded) {
        if (expanded) {
            focusManager.clearFocus(force = true)
            keyboard?.hide()
        }
    }

    val onEntry: (Entry) -> Unit = { entry ->
        val song = entry.toSong()
        val playlistId = entry.playlistId
        if (song != null) {
            app.player.playRadio(song)
        } else if (entry.browseId != null) {
            stack.add(Route.Browse(entry))
        } else if (playlistId != null) {
            app.player.playPlaylistId(playlistId)
        }
    }

    BackHandler(enabled = expanded) { expanded = false }
    BackHandler(enabled = stack.isNotEmpty() && !expanded) { stack.removeAt(stack.lastIndex) }

    androidx.compose.runtime.CompositionLocalProvider(
        LocalDownloadedIds provides downloadedIds,
        LocalNowPlayingId provides playerState.current?.id,
        LocalIsPlaying provides playerState.isPlaying,
    ) {
    Box(Modifier.fillMaxSize().background(AlterColors.Bg)) {
        Scaffold(
            containerColor = AlterColors.Bg,
            bottomBar = {
                Column {
                    OfflineBanner(visible = !online)
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().height(58.dp)) {
                        Tab.entries.forEach { t ->
                            val selected = tab == t && stack.isEmpty()
                            Column(
                                Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .noRippleClickable {
                                        tab = t
                                        stack.clear()
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                            ) {
                                // diredupkan sedikit supaya menyatu dengan fade di belakangnya
                                val navTint = if (selected) Color.White.copy(alpha = 0.88f) else AlterColors.Sub.copy(alpha = 0.58f)
                                Ic(if (selected) t.iconActive else t.icon, tint = navTint, size = 25.dp)
                                Spacer(Modifier.height(3.dp))
                                Text(t.label, style = T.tiny, color = navTint)
                            }
                        }
                    }
                }
            },
        ) { scaffoldPadding ->
            // isi layar diberi ruang bawah seukuran mini player, jadi daftar bisa menggulir di belakang kaca
            val padding =
                PaddingValues(
                    top = scaffoldPadding.calculateTopPadding(),
                    bottom = scaffoldPadding.calculateBottomPadding() + if (miniVisible) 84.dp else 0.dp,
                )
            Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().backdropSource(backdrop)) {
                Crossfade(targetState = tab, animationSpec = tween(220), label = "tabs") { current ->
                    when (current) {
                        Tab.HOME -> HomeScreen(padding, onEntry)
                        Tab.SEARCH -> SearchScreen(padding, onEntry)
                        Tab.LIBRARY -> LibraryScreen(padding, onEntry)
                    }
                }
                val top = stack.lastOrNull()
                AnimatedContent(
                    targetState = top,
                    transitionSpec = {
                        if (targetState != null && initialState == null) {
                            (slideInHorizontally(animationSpec = tween(300, easing = FastOutSlowInEasing), initialOffsetX = { it / 4 }) + fadeIn(tween(300))) togetherWith fadeOut(tween(120))
                        } else if (targetState == null) {
                            fadeIn(tween(120)) togetherWith (slideOutHorizontally(animationSpec = tween(260, easing = FastOutSlowInEasing), targetOffsetX = { it / 4 }) + fadeOut(tween(220)))
                        } else {
                            fadeIn(tween(200)) togetherWith fadeOut(tween(160))
                        }
                    },
                    label = "routes",
                ) { route ->
                    if (route == null) {
                        Box(Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize().background(AlterColors.Bg).noRippleClickable {}) {
                            when (route) {
                                is Route.Settings ->
                                    SettingsScreen(padding, onBack = { stack.removeAt(stack.lastIndex) }, onLogin = { stack.add(Route.Login) })
                                is Route.Login ->
                                    LoginFlow(
                                        onDone = { stack.removeAll { it is Route.Login } },
                                        onBack = { stack.removeAt(stack.lastIndex) },
                                    )
                                is Route.Local -> LocalMusicScreen(padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) })
                                is Route.Stats -> StatsScreen(padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) })
                                is Route.About -> AboutScreen(padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) })
                                else -> DetailScreen(route, padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }, onEntry = onEntry)
                            }
                        }
                    }
                }
            }
            // Fade-out: isi layar memudar semakin gelap ke arah navigasi ponsel, lalu pekat penuh (kosong) tepat di
            // atas bar navigasi sistem. Overlay ini tidak ikut direkam ke backdrop, jadi kaca mini player tetap
            // melihat isi layar yang sebenarnya di belakangnya.
            val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
            val fadeHeight by animateDpAsState(
                targetValue = scaffoldPadding.calculateBottomPadding() + if (miniVisible) 96.dp else 40.dp,
                animationSpec = tween(300, easing = FastOutSlowInEasing),
                label = "navFade",
            )
            // posisi (0..1) di mana fade sudah pekat penuh: batas atas bar navigasi sistem
            val solidAt = ((fadeHeight - navInset) / fadeHeight).coerceIn(0.5f, 1f)
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(fadeHeight)
                    .background(
                        Brush.verticalGradient(
                            0.00f * solidAt to AlterColors.Bg.copy(alpha = 0.00f),
                            0.15f * solidAt to AlterColors.Bg.copy(alpha = 0.10f),
                            0.35f * solidAt to AlterColors.Bg.copy(alpha = 0.38f),
                            0.55f * solidAt to AlterColors.Bg.copy(alpha = 0.70f),
                            0.75f * solidAt to AlterColors.Bg.copy(alpha = 0.90f),
                            0.90f * solidAt to AlterColors.Bg.copy(alpha = 0.98f),
                            solidAt to AlterColors.Bg,
                            1.00f to AlterColors.Bg,
                        ),
                    ),
            )
            AnimatedVisibility(
                visible = miniVisible,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = slideInVertically(animationSpec = tween(350, easing = FastOutSlowInEasing), initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(animationSpec = tween(250), targetOffsetY = { it }) + fadeOut(),
            ) {
                // Konten Scaffold penuh layar dan bar navigasi digambar di atasnya, jadi mini player harus
                // diangkat setinggi bar bawah (scaffoldPadding.bottom) supaya melayang tepat di atas bar.
                MiniPlayer(
                    playerState,
                    backdrop,
                    onOpen = { expanded = true },
                    modifier = Modifier.padding(start = 10.dp, end = 10.dp, bottom = scaffoldPadding.calculateBottomPadding() + 8.dp),
                )
            }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = slideInVertically(animationSpec = tween(380, easing = FastOutSlowInEasing), initialOffsetY = { it }) + fadeIn(tween(200)),
            exit = slideOutVertically(animationSpec = tween(300, easing = FastOutSlowInEasing), targetOffsetY = { it }) + fadeOut(tween(200)),
        ) {
            NowPlayingScreen(playerState, onClose = { expanded = false })
        }
    }
    }

    ui.menuSong?.let { song -> SongMenuSheet(song, ui.menuPlaylistId) { ui.menuSong = null } }
    ui.addToPlaylistSong?.let { song -> AddToPlaylistSheet(song) { ui.addToPlaylistSong = null } }
    if (ui.createPlaylistOpen) {
        TextInputDialog(
            title = "Playlist baru",
            initial = "",
            confirmLabel = "Buat",
            placeholder = "Nama playlist",
            onDismiss = {
                ui.createPlaylistOpen = false
                ui.createPlaylistSong = null
            },
            onConfirm = { name ->
                val created = app.library.createPlaylist(name, ui.createPlaylistSong)
                context.toast("\"${created.name}\" dibuat")
                ui.createPlaylistOpen = false
                ui.createPlaylistSong = null
            },
        )
    }
    if (ui.sleepOpen) SleepTimerSheet { ui.sleepOpen = false }
    if (ui.fxOpen) EffectsSheet { ui.fxOpen = false }
    if (ui.outputOpen) OutputSheet { ui.outputOpen = false }
    ui.infoSong?.let { song -> SongInfoSheet(song) { ui.infoSong = null } }
    if (ui.queueSaveOpen) {
        TextInputDialog(
            title = "Simpan antrean sebagai playlist",
            initial = "Antreanku",
            confirmLabel = "Simpan",
            placeholder = "Nama playlist",
            onDismiss = { ui.queueSaveOpen = false },
            onConfirm = { name ->
                val created = app.library.createPlaylistWith(name, playerState.queue.filter { !it.isLocal })
                context.toast("\"${created.name}\" dibuat (${created.songs.size} lagu)")
                ui.queueSaveOpen = false
            },
        )
    }
}
