package com.alterlist.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Tab(val label: String, val icon: Int, val iconActive: Int) {
    HOME("Beranda", R.drawable.ic_home, R.drawable.ic_home_fill),
    SEARCH("Cari", R.drawable.ic_search, R.drawable.ic_search_fill),
    LOCAL("Perangkat", R.drawable.ic_phone, R.drawable.ic_phone_fill),
    LIBRARY("Koleksi", R.drawable.ic_library, R.drawable.ic_library_fill),
}

@Composable
fun AlterRoot() {
    val app = AlterApp.instance
    val account by app.account.state.collectAsState()
    val ui = remember { UiController() }
    var loginOpen by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalUi provides ui) {
        if (account.mode == AccountMode.UNSET) {
            if (loginOpen) {
                LoginFlow(onDone = { loginOpen = false }, onBack = { loginOpen = false })
            } else {
                WelcomeScreen(onGoogle = { loginOpen = true }, onGuest = { app.account.chooseGuest() })
            }
        } else {
            MainShell(ui)
        }
    }
}

/** WebView login + layar "menyiapkan akun" saat cookie sudah didapat. */
@Composable
private fun LoginFlow(onDone: () -> Unit, onBack: () -> Unit) {
    val app = AlterApp.instance
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        LoginScreen(
            onSuccess = { session ->
                busy = true
                app.yt.setAccount(session)
                app.scope.launch {
                    val info = app.yt.accountInfo()
                    app.account.saveGoogle(session, info)
                    runCatching { app.library.mergeLiked(app.yt.accountLikedSongs()) }
                    withContext(Dispatchers.Main) { onDone() }
                }
            },
            onBack = onBack,
        )
        if (busy) {
            Box(Modifier.fillMaxSize().background(Color.Black).noRippleClickable {}, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AlterColors.Red, strokeWidth = 3.dp)
                    Spacer(Modifier.height(16.dp))
                    Text("Menyiapkan akunmu...", style = T.title)
                }
            }
        }
    }
}

@Composable
private fun MainShell(ui: UiController) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val playerState by app.player.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    val stack = remember { mutableStateListOf<Route>() }
    var expanded by rememberSaveable { mutableStateOf(false) }

    SideEffect {
        ui.navigate = { route -> stack.add(route) }
        ui.openPlayer = { expanded = true }
        ui.closePlayer = { expanded = false }
        ui.goLocal = {
            tab = Tab.LOCAL
            stack.clear()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(Unit) { app.player.events.collect { context.toast(it) } }
    LaunchedEffect(Unit) { app.downloader.messages.collect { context.toast(it) } }
    // Beri tahu saat speaker / earphone Bluetooth tersambung atau terputus
    LaunchedEffect(Unit) {
        var last = app.audioOutput.active.value.id
        app.audioOutput.active.collect { o ->
            if (o.id != last) {
                last = o.id
                if (app.settings.state.value.outputToast) {
                    context.toast(if (o.isBluetooth) "Terhubung ke ${o.name}" else "Output audio: ${o.name}")
                }
            }
        }
    }
    val online by app.network.online.collectAsState()
    val navPalette = rememberCoverPalette(playerState.current?.thumbnail)
    val navItems = remember { Tab.entries.map { NavItem(it.icon, it.iconActive, it.label) } }

    val onEntry: (Entry) -> Unit = { entry ->
        val song = entry.toSong()
        val playlistId = entry.playlistId
        if (song != null) {
            app.player.playRadio(song)
        } else if (entry.browseId != null) {
            stack.add(Route.Browse(entry))
        } else if (playlistId != null) {
            app.player.playPlaylistId(playlistId)
        }
    }

    BackHandler(enabled = expanded) { expanded = false }
    BackHandler(enabled = stack.isNotEmpty() && !expanded) { stack.removeAt(stack.lastIndex) }

    Box(Modifier.fillMaxSize().background(AlterColors.Bg)) {
        Scaffold(
            containerColor = AlterColors.Bg,
            bottomBar = {
                Column(Modifier.background(AlterColors.Bg)) {
                    OfflineBanner(visible = !online)
                    AnimatedVisibility(
                        visible = playerState.current != null,
                        enter = slideInVertically(animationSpec = tween(350, easing = FastOutSlowInEasing), initialOffsetY = { it }) + fadeIn(),
                        exit = slideOutVertically(animationSpec = tween(250), targetOffsetY = { it }) + fadeOut(),
                    ) {
                        MiniPlayer(playerState, onOpen = { expanded = true }, modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 8.dp))
                    }
                    GlassNavBar(
                        items = navItems,
                        selected = tab.ordinal,
                        palette = navPalette,
                        art = playerState.current?.thumbnail,
                        onSelect = { i ->
                            tab = Tab.entries[i]
                            stack.clear()
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).navigationBarsPadding(),
                    )
                }
            },
        ) { padding ->
            Box(Modifier.fillMaxSize()) {
                Crossfade(targetState = tab, animationSpec = tween(220), label = "tabs") { current ->
                    when (current) {
                        Tab.HOME -> HomeScreen(padding, onEntry)
                        Tab.SEARCH -> SearchScreen(padding, onEntry)
                        Tab.LOCAL -> LocalMusicScreen(padding)
                        Tab.LIBRARY -> LibraryScreen(padding, onEntry)
                    }
                }
                val top = stack.lastOrNull()
                AnimatedContent(
                    targetState = top,
                    transitionSpec = {
                        if (targetState != null && initialState == null) {
                            (slideInHorizontally(animationSpec = tween(300, easing = FastOutSlowInEasing), initialOffsetX = { it / 4 }) + fadeIn(tween(300))) togetherWith fadeOut(tween(120))
                        } else if (targetState == null) {
                            fadeIn(tween(120)) togetherWith (slideOutHorizontally(animationSpec = tween(260, easing = FastOutSlowInEasing), targetOffsetX = { it / 4 }) + fadeOut(tween(220)))
                        } else {
                            fadeIn(tween(200)) togetherWith fadeOut(tween(160))
                        }
                    },
                    label = "routes",
                ) { route ->
                    if (route == null) {
                        Box(Modifier.fillMaxSize())
                    } else {
                        Box(Modifier.fillMaxSize().background(AlterColors.Bg).noRippleClickable {}) {
                            when (route) {
                                is Route.Settings ->
                                    SettingsScreen(padding, onBack = { stack.removeAt(stack.lastIndex) }, onLogin = { stack.add(Route.Login) })
                                is Route.Login ->
                                    LoginFlow(
                                        onDone = { stack.removeAll { it is Route.Login } },
                                        onBack = { stack.removeAt(stack.lastIndex) },
                                    )
                                is Route.Stats -> StatsScreen(padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) })
                                is Route.About -> AboutScreen(padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) })
                                else -> DetailScreen(route, padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }, onEntry = onEntry)
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = slideInVertically(animationSpec = tween(380, easing = FastOutSlowInEasing), initialOffsetY = { it }) + fadeIn(tween(200)),
            exit = slideOutVertically(animationSpec = tween(300, easing = FastOutSlowInEasing), targetOffsetY = { it }) + fadeOut(tween(200)),
        ) {
            NowPlayingScreen(playerState, onClose = { expanded = false })
        }
    }

    ui.menuSong?.let { song -> SongMenuSheet(song, ui.menuPlaylistId) { ui.menuSong = null } }
    ui.addToPlaylistSong?.let { song -> AddToPlaylistSheet(song) { ui.addToPlaylistSong = null } }
    if (ui.createPlaylistOpen) {
        TextInputDialog(
            title = "Playlist baru",
            initial = "",
            confirmLabel = "Buat",
            placeholder = "Nama playlist",
            onDismiss = {
                ui.createPlaylistOpen = false
                ui.createPlaylistSong = null
            },
            onConfirm = { name ->
                val created = app.library.createPlaylist(name, ui.createPlaylistSong)
                context.toast("\"${created.name}\" dibuat")
                ui.createPlaylistOpen = false
                ui.createPlaylistSong = null
            },
        )
    }
    if (ui.sleepOpen) SleepTimerSheet { ui.sleepOpen = false }
    if (ui.fxOpen) EffectsSheet { ui.fxOpen = false }
    if (ui.outputOpen) OutputSheet { ui.outputOpen = false }
    ui.infoSong?.let { song -> SongInfoSheet(song) { ui.infoSong = null } }
    if (ui.queueSaveOpen) {
        TextInputDialog(
            title = "Simpan antrean sebagai playlist",
            initial = "Antreanku",
            confirmLabel = "Simpan",
            placeholder = "Nama playlist",
            onDismiss = { ui.queueSaveOpen = false },
            onConfirm = { name ->
                val created = app.library.createPlaylistWith(name, playerState.queue.filter { !it.isLocal })
                context.toast("\"${created.name}\" dibuat (${created.songs.size} lagu)")
                ui.queueSaveOpen = false
            },
        )
    }
}
