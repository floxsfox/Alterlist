package com.alterlist.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.alterlist.app.AlterApp
import com.alterlist.app.R
import com.alterlist.app.data.AccountMode
import com.alterlist.app.data.Entry
import com.alterlist.app.data.EntryKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Tab(val label: String, val icon: Int, val iconActive: Int) {
    HOME("Beranda", R.drawable.ic_home, R.drawable.ic_home_fill),
    SEARCH("Cari", R.drawable.ic_search, R.drawable.ic_search_fill),
    LIBRARY("Koleksi", R.drawable.ic_library, R.drawable.ic_library_fill),
}

@Composable
fun AlterRoot() {
    val app = AlterApp.instance
    val account by app.account.state.collectAsState()
    val ui = remember { UiController() }
    var loginOpen by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalUi provides ui) {
        if (account.mode == AccountMode.UNSET) {
            if (loginOpen) {
                LoginFlow(onDone = { loginOpen = false }, onBack = { loginOpen = false })
            } else {
                WelcomeScreen(onGoogle = { loginOpen = true }, onGuest = { app.account.chooseGuest() })
            }
        } else {
            MainShell(ui)
        }
    }
}

/** WebView login + layar "menyiapkan akun" saat cookie sudah didapat. */
@Composable
private fun LoginFlow(onDone: () -> Unit, onBack: () -> Unit) {
    val app = AlterApp.instance
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        LoginScreen(
            onSuccess = { session ->
                busy = true
                app.yt.setAccount(session)
                app.scope.launch {
                    val info = app.yt.accountInfo()
                    app.account.saveGoogle(session, info)
                    runCatching { app.library.mergeLiked(app.yt.accountLikedSongs()) }
                    withContext(Dispatchers.Main) { onDone() }
                }
            },
            onBack = onBack,
        )
        if (busy) {
            Box(Modifier.fillMaxSize().background(Color.Black).noRippleClickable {}, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AlterColors.Red, strokeWidth = 3.dp)
                    Spacer(Modifier.height(16.dp))
                    Text("Menyiapkan akunmu...", style = T.title)
                }
            }
        }
    }
}

@Composable
private fun MainShell(ui: UiController) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val playerState by app.player.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    val stack = remember { mutableStateListOf<Route>() }
    var expanded by rememberSaveable { mutableStateOf(false) }

    SideEffect {
        ui.navigate = { route -> stack.add(route) }
        ui.openPlayer = { expanded = true }
        ui.closePlayer = { expanded = false }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(Unit) { app.player.events.collect { context.toast(it) } }
    LaunchedEffect(Unit) { app.downloader.messages.collect { context.toast(it) } }

    val onEntry: (Entry) -> Unit = { entry ->
        val song = entry.toSong()
        val playlistId = entry.playlistId
        if (song != null) {
            app.player.playRadio(song)
        } else if (entry.browseId != null) {
            stack.add(Route.Browse(entry))
        } else if (playlistId != null) {
            app.player.playPlaylistId(playlistId)
        }
    }

    BackHandler(enabled = expanded) { expanded = false }
    BackHandler(enabled = stack.isNotEmpty() && !expanded) { stack.removeAt(stack.lastIndex) }

    Box(Modifier.fillMaxSize().background(AlterColors.Bg)) {
        Scaffold(
            containerColor = AlterColors.Bg,
            bottomBar = {
                Column(Modifier.background(AlterColors.Bg)) {
                    if (playerState.current != null) {
                        MiniPlayer(playerState, onOpen = { expanded = true }, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                    }
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().height(58.dp)) {
                        Tab.entries.forEach { t ->
                            val selected = tab == t && stack.isEmpty()
                            Column(
                                Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .noRippleClickable {
                                        tab = t
                                        stack.clear()
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
                            ) {
                                Ic(if (selected) t.iconActive else t.icon, tint = if (selected) Color.White else AlterColors.Sub, size = 25.dp)
                                Spacer(Modifier.height(3.dp))
                                Text(t.label, style = T.tiny, color = if (selected) Color.White else AlterColors.Sub)
                            }
                        }
                    }
                }
            },
        ) { padding ->
            Box(Modifier.fillMaxSize()) {
                when (tab) {
                    Tab.HOME -> HomeScreen(padding, onEntry)
                    Tab.SEARCH -> SearchScreen(padding, onEntry)
                    Tab.LIBRARY -> LibraryScreen(padding, onEntry)
                }
                val top = stack.lastOrNull()
                if (top != null) {
                    Box(Modifier.fillMaxSize().background(AlterColors.Bg).noRippleClickable {}) {
                        when (top) {
                            is Route.Settings ->
                                SettingsScreen(padding, onBack = { stack.removeAt(stack.lastIndex) }, onLogin = { stack.add(Route.Login) })
                            is Route.Login ->
                                LoginFlow(
                                    onDone = { stack.removeAll { it is Route.Login } },
                                    onBack = { stack.removeAt(stack.lastIndex) },
                                )
                            else -> DetailScreen(top, padding, onBack = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }, onEntry = onEntry)
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
        ) {
            NowPlayingScreen(playerState, onClose = { expanded = false })
        }
    }

    ui.menuSong?.let { song -> SongMenuSheet(song, ui.menuPlaylistId) { ui.menuSong = null } }
    ui.addToPlaylistSong?.let { song -> AddToPlaylistSheet(song) { ui.addToPlaylistSong = null } }
    if (ui.createPlaylistOpen) {
        TextInputDialog(
            title = "Playlist baru",
            initial = "",
            confirmLabel = "Buat",
            placeholder = "Nama playlist",
            onDismiss = {
                ui.createPlaylistOpen = false
                ui.createPlaylistSong = null
            },
            onConfirm = { name ->
                val created = app.library.createPlaylist(name, ui.createPlaylistSong)
                context.toast("\"${created.name}\" dibuat")
                ui.createPlaylistOpen = false
                ui.createPlaylistSong = null
            },
        )
    }
    if (ui.sleepOpen) SleepTimerSheet { ui.sleepOpen = false }
}
