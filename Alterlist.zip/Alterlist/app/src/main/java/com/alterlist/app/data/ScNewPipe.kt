package com.alterlist.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.longOrNull
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.downloader.Downloader as NpDownloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

/** Satu stream audio SoundCloud yang siap diputar / diunduh. [hls] true = [url] adalah playlist .m3u8. */
class ScStream(val url: String, val hls: Boolean, val ext: String)

/**
 * SoundCloud TIDAK RESMI lewat NewPipeExtractor (JitPack), padanan InnerTubeX untuk SoundCloud.
 *
 * PENTING: file ini satu-satunya yang memakai NewPipeExtractor, dan hanya lewat [ServiceList.SoundCloud].
 * YouTube / PeerTube / Bandcamp / media.ccc.de di NewPipe sengaja tidak pernah dipanggil, jadi tidak bentrok
 * dengan InnerTubeX yang mengurus YouTube Music.
 *
 * Kelebihan dibanding API v2 publik yang dipakai sebelumnya: lagu diputar penuh (bukan cuplikan 30 detik),
 * stream HLS ikut didukung, dan lagunya bisa diunduh.
 */
object ScNewPipe {
    private val service get() = ServiceList.SoundCloud

    private class Cached(val stream: ScStream, val expiresAtMs: Long)

    private val streamCache = ConcurrentHashMap<String, Cached>()

    @Volatile private var ready = false

    @Synchronized
    private fun ensureInit() {
        if (ready) return
        // NewPipe memegang satu Downloader global. Kalau sudah ada yang memasang, jangan ditimpa.
        if (NewPipe.getDownloader() == null) NewPipe.init(ScHttp)
        ready = true
    }

    // ------------------------------------------------------------------ metadata dari respons API SoundCloud

    /** Data tambahan yang tidak diberikan NewPipe di hasil pencarian: id angka, tanda eksplisit, dan kebijakan putar. */
    private class Meta(val id: Long, val explicit: Boolean, val policy: String?)

    private val metaByUrl =
        object : LinkedHashMap<String, Meta>(256, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Meta>?): Boolean = size > 4000
        }

    private fun key(url: String): String = url.trim().trimEnd('/')

    private fun metaOf(url: String): Meta? = synchronized(metaByUrl) { metaByUrl[key(url)] }

    /**
     * Dipanggil [ScHttp] untuk setiap balasan api-v2.soundcloud.com yang sudah diambil NewPipe. Tidak ada permintaan
     * jaringan tambahan: balasan yang sama dibaca sekali lagi untuk mengambil `publisher_metadata.explicit` dan `policy`.
     */
    private fun sniff(url: String, body: String) {
        if (!url.contains("api-v2.soundcloud.com") || body.length < 2 || body.length > 4_000_000) return
        if (body[0] != '{' && body[0] != '[') return
        val root = runCatching { Json.parseToJsonElement(body) }.getOrNull() ?: return
        walk(root, 0)
    }

    private fun walk(el: JsonElement, depth: Int) {
        if (depth > 6) return
        when (el) {
            is JsonObject -> {
                val link = (el["permalink_url"] as? JsonPrimitive)?.contentOrNull
                val id = (el["id"] as? JsonPrimitive)?.longOrNull
                val kind = (el["kind"] as? JsonPrimitive)?.contentOrNull
                if (link != null && id != null && kind == "track") {
                    val explicit = ((el["publisher_metadata"] as? JsonObject)?.get("explicit") as? JsonPrimitive)?.booleanOrNull == true
                    val policy = (el["policy"] as? JsonPrimitive)?.contentOrNull
                    synchronized(metaByUrl) { metaByUrl[key(link)] = Meta(id, explicit, policy) }
                }
                for (v in el.values) if (v is JsonObject || v is JsonArray) walk(v, depth + 1)
            }
            is JsonArray -> for (v in el) if (v is JsonObject || v is JsonArray) walk(v, depth + 1)
            else -> Unit
        }
    }

    // ------------------------------------------------------------------ pencarian

    suspend fun search(query: String, limit: Int = 20): List<Entry> =
        withContext(Dispatchers.IO) {
            ensureInit()
            val svc = service
            val handler = svc.searchQHFactory.fromQuery(query, listOf("tracks"), "")
            val extractor = svc.getSearchExtractor(handler)
            extractor.fetchPage()
            extractor.initialPage.items
                .filterIsInstance<StreamInfoItem>()
                .mapNotNull { toEntry(it) }
                .distinctBy { it.videoId }
                .take(limit)
        }

    /** Lagu mirip untuk radio / putar otomatis. [hintUrl] = tautan halaman lagu bila ada. */
    suspend fun related(songId: String, hintUrl: String?, limit: Int = 25): List<Song> =
        withContext(Dispatchers.IO) {
            ensureInit()
            val info = StreamInfo.getInfo(service, pageUrlFor(songId, hintUrl))
            info.relatedItems
                .filterIsInstance<StreamInfoItem>()
                .mapNotNull { toEntry(it)?.toSong() }
                .distinctBy { it.id }
                .take(limit)
        }

    private fun toEntry(item: StreamInfoItem): Entry? {
        val title = item.name?.trim()
        val url = item.url
        if (title.isNullOrBlank() || url.isNullOrBlank()) return null
        val meta = metaOf(url)
        // SNIP = cuplikan SoundCloud Go+, BLOCK = diblokir: dua-duanya bukan lagu penuh
        val policy = meta?.policy
        if (policy != null && policy != "ALLOW" && policy != "MONETIZE") return null
        val art =
            item.thumbnails.maxByOrNull { it.height }?.url
                ?: item.thumbnails.lastOrNull()?.url
        val seconds = item.duration
        return Entry(
            title = title,
            subtitle = item.uploaderName.orEmpty(),
            thumbnail = art?.replace("-large.", "-t500x500."),
            // id angka bila terbaca (cocok dengan lagu lama yang tersimpan), kalau tidak pakai tautan halaman
            videoId = SC_PREFIX + (meta?.id?.toString() ?: url),
            durationText = if (seconds > 0) formatDurationText(seconds) else null,
            uri = url,
            explicit = meta?.explicit == true,
        )
    }

    // ------------------------------------------------------------------ stream

    private fun pageUrlFor(songId: String, hintUrl: String?): String {
        val ref = songId.removePrefix(SC_PREFIX)
        if (ref.startsWith("http")) return ref
        if (hintUrl != null && hintUrl.startsWith("http") && !hintUrl.contains("api-v2.soundcloud.com") && !hintUrl.contains("api.soundcloud.com")) {
            return hintUrl
        }
        // id angka tanpa tautan halaman (lagu lama): minta NewPipe memetakan ke tautan
        return service.streamLHFactory.getUrl(ref)
    }

    /** Stream terbaik: MP3 progresif > MP3 HLS > AAC HLS. Opus HLS dilewati (ExoPlayer tidak memutar Ogg di HLS). */
    suspend fun resolve(songId: String, hintUrl: String?): ScStream {
        streamCache[songId]?.let { if (it.expiresAtMs > System.currentTimeMillis()) return it.stream }
        val stream =
            withContext(Dispatchers.IO) {
                ensureInit()
                val info =
                    try {
                        StreamInfo.getInfo(service, pageUrlFor(songId, hintUrl))
                    } catch (e: Exception) {
                        throw IOException(friendly(e), e)
                    }
                pick(info.audioStreams) ?: throw IOException("Lagu SoundCloud ini tidak punya stream audio yang bisa diputar")
            }
        streamCache[songId] = Cached(stream, System.currentTimeMillis() + STREAM_TTL_MS)
        return stream
    }

    fun invalidate(songId: String) {
        streamCache.remove(songId)
    }

    /** Alamat playlist HLS yang sudah pernah di-resolve (null bila lagunya bukan HLS atau belum di-resolve). */
    fun cachedHls(songId: String): String? = streamCache[songId]?.stream?.takeIf { it.hls }?.url

    private fun codec(s: AudioStream): String {
        val tag = (s.id.orEmpty() + "|" + s.format?.suffix.orEmpty() + "|" + s.format?.mimeType.orEmpty()).lowercase()
        return when {
            "opus" in tag || "ogg" in tag -> "opus"
            "mp3" in tag || "mpeg" in tag -> "mp3"
            "aac" in tag || "m4a" in tag || "mp4" in tag -> "aac"
            else -> "?"
        }
    }

    private fun pick(streams: List<AudioStream>): ScStream? {
        val usable = streams.filter { it.isUrl && !it.content.isNullOrBlank() }
        val progressive = usable.filter { it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP }
        val hls = usable.filter { it.deliveryMethod == DeliveryMethod.HLS }

        progressive.firstOrNull { codec(it) == "mp3" }?.let { return ScStream(it.content, false, "mp3") }
        progressive.firstOrNull { codec(it) != "opus" }?.let { return ScStream(it.content, false, if (codec(it) == "aac") "m4a" else "mp3") }
        hls.firstOrNull { codec(it) == "mp3" }?.let { return ScStream(it.content, true, "mp3") }
        hls.filter { codec(it) == "aac" }.maxByOrNull { it.averageBitrate }?.let { return ScStream(it.content, true, "m4a") }
        hls.firstOrNull { codec(it) != "opus" }?.let { return ScStream(it.content, true, "?") }
        return null
    }

    private fun friendly(e: Throwable): String =
        when {
            e is java.net.UnknownHostException || e is java.net.ConnectException -> "Tidak ada koneksi internet"
            e.javaClass.simpleName == "PaidContentException" -> "Lagu SoundCloud Go+ (hanya cuplikan, tidak tersedia penuh)"
            e.javaClass.simpleName == "GeographicRestrictionException" -> "Lagu ini diblokir di wilayahmu"
            e.javaClass.simpleName == "ReCaptchaException" -> "SoundCloud meminta verifikasi, coba lagi nanti"
            e.javaClass.simpleName.contains("NotAvailable") || e.javaClass.simpleName.contains("NotFound") -> "Lagu SoundCloud tidak tersedia"
            else -> e.message ?: "Gagal mengambil stream SoundCloud"
        }

    private const val STREAM_TTL_MS = 10 * 60_000L

    // ------------------------------------------------------------------ HTTP untuk NewPipe

    /** Downloader NewPipe di atas HttpURLConnection (tanpa OkHttp). Juga mencatat metadata lewat [sniff]. */
    private object ScHttp : NpDownloader() {
        override fun execute(request: Request): Response {
            val url = request.url()
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 20_000
                conn.readTimeout = 25_000
                conn.requestMethod = request.httpMethod()
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", Net.USER_AGENT)
                request.headers().forEach { (name, values) ->
                    values.forEachIndexed { i, v -> if (i == 0) conn.setRequestProperty(name, v) else conn.addRequestProperty(name, v) }
                }
                val data = request.dataToSend()
                if (data != null) {
                    conn.doOutput = true
                    conn.setFixedLengthStreamingMode(data.size)
                    conn.outputStream.use { it.write(data) }
                }
                val code = conn.responseCode
                if (code == 429) throw ReCaptchaException("SoundCloud meminta verifikasi (HTTP 429)", url)
                var stream = if (code >= 400) conn.errorStream else conn.inputStream
                if (stream != null && conn.contentEncoding.equals("gzip", ignoreCase = true)) stream = GZIPInputStream(stream)
                val body = stream?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty()
                val headers: Map<String, List<String>> = conn.headerFields.filterKeys { it != null }
                if (code in 200..299) ScNewPipe.sniff(url, body)
                return Response(code, conn.responseMessage.orEmpty(), headers, body, conn.url.toString())
            } finally {
                conn.disconnect()
            }
        }
    }
}
