package com.alterlist.app.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.Locale
import kotlin.random.Random

/** Kumpulan lagu bergaya "Daily Mix". */
@Serializable
data class RecoMix(val name: String, val blurb: String, val songs: List<Song>, val color: Int)

/** Rak rekomendasi bertema, mis. "Karena kamu suka Tulus". */
@Serializable
data class RecoShelf(val title: String, val subtitle: String, val songs: List<Song>)

@Serializable
data class RecoResult(
    /** Daftar utama "Untuk Kamu" (mirip FYP): paling cocok dengan seleramu, sudah diacak antar artis. */
    val forYou: List<Song>,
    val mixes: List<RecoMix>,
    val shelves: List<RecoShelf>,
    val artists: List<ArtistRef>,
    val generatedAt: Long,
    val profileKey: String,
    /** id lagu -> alasan singkat ("Karena kamu suka ..."). */
    val reasons: Map<String, String> = emptyMap(),
    val basedOn: List<String> = emptyList(),
)

data class RecoState(
    val loading: Boolean = false,
    val result: RecoResult? = null,
    val error: String? = null,
)

/**
 * Mesin rekomendasi di HP (mirip "For You" / Daily Mix):
 *  1. Profil selera dari statistik putar, lagu disukai, riwayat, artis diikuti, dan genre pilihan ([Taste]).
 *  2. Tiap lagu benih diminta "lagu mirip"-nya ke YouTube Music (radio). Kalau sudah login, hasilnya ikut
 *     dipengaruhi cookie akunmu.
 *  3. Kandidat diberi skor (kemiripan x bobot benih x kecocokan artis & genre), lagu yang baru kamu putar disingkirkan,
 *     lalu hasil diacak antar artis supaya tidak monoton.
 * Hasil disimpan di berkas supaya Beranda langsung terisi saat aplikasi dibuka.
 */
class Recommender(context: Context, private val yt: YtMusic) {
    private val file = File(context.filesDir, "reco.json")
    private val json =
        Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }
    private val mutex = Mutex()

    private val _state = MutableStateFlow(RecoState(result = load()))
    val state: StateFlow<RecoState> = _state.asStateFlow()

    private fun load(): RecoResult? =
        try {
            if (file.exists()) json.decodeFromString(RecoResult.serializer(), file.readText()) else null
        } catch (e: Exception) {
            null
        }

    private fun save(r: RecoResult) {
        try {
            file.writeText(json.encodeToString(RecoResult.serializer(), r))
        } catch (e: Exception) {
            // cache gagal ditulis: tidak apa-apa
        }
    }

    fun clear() {
        file.delete()
        _state.value = RecoState()
    }

    suspend fun refresh(lib: LibraryData, force: Boolean = false) {
        val profile = Taste.build(lib)
        if (!profile.hasHistory && profile.picks.isEmpty()) {
            if (_state.value.result != null) clear()
            return
        }
        val now = System.currentTimeMillis()
        val cached = _state.value.result
        if (!force && cached != null) {
            val age = now - cached.generatedAt
            if (age < FRESH_MS && (cached.profileKey == profile.key || age < SETTLE_MS)) return
        }
        mutex.withLock {
            _state.value = _state.value.copy(loading = true, error = null)
            try {
                val variant = (now / 600_000L).toInt() + (if (force) Random.nextInt(1000) else 0)
                val recent = lib.recent.take(60).map { it.id }.toHashSet()
                val liked = lib.liked.map { it.id }.toHashSet()
                val result = withContext(Dispatchers.IO) { build(profile, recent, liked, variant) }
                if (result.forYou.isEmpty()) {
                    _state.value = _state.value.copy(loading = false, error = "Belum ada rekomendasi yang cocok. Coba lagi nanti.")
                } else {
                    save(result)
                    _state.value = RecoState(loading = false, result = result)
                }
            } catch (e: CancellationException) {
                _state.value = _state.value.copy(loading = false)
                throw e
            } catch (e: Exception) {
                _state.value = _state.value.copy(loading = false, error = e.message ?: "Gagal memuat rekomendasi")
            }
        }
    }

    // ---------------------------------------------------------------- pembangun

    private class Source(val label: String, val reason: String, val weight: Double, val songs: List<Song>, val seed: Song?)

    private class Cand(val song: Song) {
        var score = 0.0
        var bestPart = 0.0
        var reason: String = ""
    }

    private suspend fun build(profile: TasteProfile, recent: Set<String>, liked: Set<String>, variant: Int): RecoResult =
        coroutineScope {
            val rnd = Random(variant)
            val sem = Semaphore(3)
            val sources = ArrayList<Source>()

            // 1) radio dari lagu benih
            val seeds = (profile.seeds.take(3) + profile.seeds.drop(3).shuffled(rnd).take(4)).distinctBy { it.id }
            val maxSeedW = profile.seedWeights.values.maxOrNull() ?: 1.0
            val radios =
                seeds.map { seed ->
                    async {
                        sem.withPermit { seed to runCatching { yt.upNext(seed.id, null) }.getOrDefault(emptyList()) }
                    }
                }.awaitAll()
            for ((seed, songs) in radios) {
                if (songs.isEmpty()) continue
                val w = ((profile.seedWeights[seed.id] ?: 1.0) / maxSeedW).coerceIn(0.15, 1.0)
                val a = primaryArtist(seed.artist).ifBlank { seed.title }
                sources.add(Source("seed:${seed.id}", "Karena kamu suka $a", w, songs.filter { it.id != seed.id }, seed))
            }

            // 2) genre pilihan sendiri (utama untuk pengguna baru)
            val picks = profile.picks.shuffled(rnd).take(if (profile.seeds.isEmpty()) 5 else 2)
            val genreRuns =
                picks.map { g ->
                    async {
                        sem.withPermit {
                            g to
                                runCatching { yt.search(GenreTags.queryFor(g), SearchFilter.SONG).mapNotNull { it.toSong() } }
                                    .getOrDefault(emptyList())
                        }
                    }
                }.awaitAll()
            for ((g, songs) in genreRuns) {
                if (songs.isEmpty()) continue
                sources.add(Source("genre:$g", "Genre $g", if (profile.seeds.isEmpty()) 0.9 else 0.5, songs, null))
            }

            // 3) skor kandidat
            val seedIds = profile.seeds.map { it.id }.toHashSet()
            val cands = LinkedHashMap<String, Cand>()
            for (src in sources) {
                src.songs.forEachIndexed { pos, s ->
                    if (s.isLocal || s.id in seedIds) return@forEachIndexed
                    val c = cands.getOrPut(s.id) { Cand(s) }
                    val part = src.weight / (1.0 + 0.06 * pos)
                    c.score += part
                    if (part > c.bestPart) {
                        c.bestPart = part
                        c.reason = src.reason
                    }
                }
            }
            val maxArtistW = profile.artists.firstOrNull()?.weight ?: 1.0
            val maxTagW = profile.tags.firstOrNull()?.second ?: 1.0
            for (c in cands.values) {
                val a = primaryArtist(c.song.artist)
                c.score += 0.5 * (profile.artistWeight(a) / maxArtistW)
                c.score += 0.3 * GenreTags.infer(c.song).sumOf { profile.tagWeight(it) / maxTagW }.coerceAtMost(1.5)
                if (c.song.id in recent) c.score -= 10.0
                if (c.song.id in liked) c.score -= 1.2
                c.score += rnd.nextDouble() * 0.12 // sedikit acak supaya tiap penyegaran terasa segar
            }
            val ranked = cands.values.filter { it.score > 0.0 }.sortedByDescending { it.score }

            val forYou = diversify(ranked.map { it.song }, perArtist = 2, limit = 40)
            val reasons = HashMap<String, String>()
            for (c in ranked) if (c.reason.isNotBlank()) reasons[c.song.id] = c.reason

            // 4) Daily Mix: satu per benih dengan artis berbeda
            val mixColors = intArrayOf(0xFFB02897.toInt(), 0xFF1E3264.toInt(), 0xFFBA5D07.toInt(), 0xFF0D7377.toInt(), 0xFF8C1932.toInt())
            val usedArtists = HashSet<String>()
            val mixes = ArrayList<RecoMix>()
            for (src in sources) {
                if (mixes.size >= 3) break
                val seedSong = src.seed ?: continue
                val a = primaryArtist(seedSong.artist).lowercase(Locale.ROOT)
                if (!usedArtists.add(a)) continue
                val songs = diversify(src.songs.filter { it.id !in recent && !it.isLocal }, perArtist = 3, limit = 25)
                if (songs.size < 6) continue
                val names = songs.map { primaryArtist(it.artist) }.filter { it.isNotBlank() }.distinct().take(3)
                mixes.add(
                    RecoMix(
                        name = "Daily Mix ${mixes.size + 1}",
                        blurb = names.joinToString(", ") + " dan lainnya",
                        songs = listOf(seedSong) + songs,
                        color = mixColors[mixes.size % mixColors.size],
                    ),
                )
            }

            // 5) rak bertema
            val shelves = ArrayList<RecoShelf>()
            for (artist in profile.artists.take(3)) {
                val src = sources.firstOrNull { it.seed?.id == artist.topSong.id } ?: continue
                val songs = diversify(src.songs.filter { it.id !in recent && !it.isLocal }, perArtist = 4, limit = 15)
                if (songs.size >= 5) shelves.add(RecoShelf("Karena kamu suka ${artist.name}", "Lagu yang mirip dengan ${artist.topSong.title}", songs))
                if (shelves.size >= 2) break
            }
            val skipTags = setOf("Indonesia", "Cover", "Live", "Remix", "Slowed")
            for ((tag, _) in profile.tags.filter { it.first !in skipTags }.take(2)) {
                val songs = diversify(ranked.map { it.song }.filter { tag in GenreTags.infer(it) }, perArtist = 2, limit = 20)
                if (songs.size >= 6) shelves.add(RecoShelf("Mix $tag", "Paling cocok dengan genre favoritmu", songs))
            }
            for ((g, songs) in genreRuns) {
                if (shelves.size >= 5) break
                val list = diversify(songs.filter { it.id !in recent }, perArtist = 2, limit = 20)
                if (list.size >= 6) shelves.add(RecoShelf("Pilihan $g", "Dari genre yang kamu pilih", list))
            }

            // 6) artis baru yang mungkin kamu suka
            val known = profile.artists.map { it.name.lowercase(Locale.ROOT) }.toHashSet()
            val artists =
                forYou
                    .filter { it.artistId != null && primaryArtist(it.artist).lowercase(Locale.ROOT) !in known }
                    .distinctBy { it.artistId }
                    .take(10)
                    .map { ArtistRef(it.artistId.orEmpty(), primaryArtist(it.artist), it.thumbnail) }

            RecoResult(
                forYou = forYou,
                mixes = mixes,
                shelves = shelves,
                artists = artists,
                generatedAt = System.currentTimeMillis(),
                profileKey = profile.key,
                reasons = reasons,
                basedOn = profile.artists.take(3).map { it.name },
            )
        }

    /** Ambil lagu berurutan tetapi maksimal [perArtist] lagu per artis supaya daftar beragam. */
    private fun diversify(songs: List<Song>, perArtist: Int, limit: Int): List<Song> {
        val count = HashMap<String, Int>()
        val out = ArrayList<Song>()
        for (s in songs.distinctBy { it.id }) {
            val a = primaryArtist(s.artist).lowercase(Locale.ROOT).ifBlank { s.id }
            val used = count[a] ?: 0
            if (used >= perArtist) continue
            count[a] = used + 1
            out.add(s)
            if (out.size >= limit) break
        }
        return out
    }

    private companion object {
        const val FRESH_MS = 3L * 60L * 60L * 1000L
        const val SETTLE_MS = 10L * 60L * 1000L
    }
}
