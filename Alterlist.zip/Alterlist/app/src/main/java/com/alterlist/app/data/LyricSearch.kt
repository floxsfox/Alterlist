package com.alterlist.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Hasil pencarian lewat lirik: judul + artis + potongan lirik yang cocok. */
data class LyricHit(val title: String, val artist: String, val snippet: String)

/** Cari lagu dari potongan liriknya (basis data lirik terbuka LRCLIB). */
object LyricSearch {
    suspend fun search(query: String): List<LyricHit> =
        withContext(Dispatchers.IO) {
            try {
                val url = "https://lrclib.net/api/search?q=" + URLEncoder.encode(query, "UTF-8")
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 10000
                conn.setRequestProperty("User-Agent", "Alterlist")
                if (conn.responseCode != 200) return@withContext emptyList()
                val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
                val words = query.lowercase().split(Regex("\\s+")).filter { it.length > 2 }
                val out = ArrayList<LyricHit>()
                val seen = HashSet<String>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val title = o.optString("trackName", "")
                    val artist = o.optString("artistName", "")
                    if (title.isBlank() || !seen.add(title.lowercase() + "|" + artist.lowercase())) continue
                    val lyrics = o.optString("plainLyrics", "")
                    val lines = lyrics.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                    val line = lines.firstOrNull { l -> words.any { l.lowercase().contains(it) } } ?: lines.firstOrNull().orEmpty()
                    out.add(LyricHit(title, artist, line))
                    if (out.size >= 25) break
                }
                out
            } catch (e: Exception) {
                emptyList()
            }
        }
}
