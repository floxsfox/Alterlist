package com.alterlist.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.alterlist.app.AlterApp
import com.alterlist.app.system.GyroAimService
import com.alterlist.app.system.MotionSensor
import kotlin.math.roundToInt

/**
 * Tab Add-on mode game: fitur khusus game.
 *  - Gyro bidik: gerak ponsel menggeser bidikan game (gyro asli distabilkan; ponsel tanpa gyro memakai gyro virtual).
 *  - Motion blur stabil: blur yang ikut kecepatan putaran ponsel, tanpa garis panjang.
 */
@Composable
internal fun AddonTab(blurSupported: Boolean, onBlurTest: () -> Unit, onOpenAccessibility: () -> Unit) {
    val app = AlterApp.instance
    val context = LocalContext.current
    val st by app.settings.state.collectAsState()
    val serviceOn by GyroAimService.connected.collectAsState()
    val kind = remember { MotionSensor.detect(context) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // ------------------------------------------------ gyroscope
        GameLabel("Gyroscope")
        SwitchRow("Gyro bidik", st.gyroOn) { app.settings.setGyroOn(it) }
        Note(
            when (kind) {
                MotionSensor.Kind.GYRO -> "Gyro asli terdeteksi. Getaran tangan diredam dan gerakan dihaluskan agar bidikan presisi."
                MotionSensor.Kind.VIRTUAL -> "Ponsel tanpa gyro: memakai gyro virtual dari sensor kemiringan dan kompas. Tetap jalan, sedikit lebih lambat."
                MotionSensor.Kind.NONE -> "Sensor gerak tidak ditemukan di ponsel ini, jadi gyro bidik tidak bisa dipakai."
            },
        )
        if (!serviceOn) {
            Note("Perlu izin Aksesibilitas untuk menggeser bidikan (hanya dipakai menggeser layar, tidak membaca isi layar). Pilih \"Alterlist Gyro\" lalu aktifkan.")
            GameChip("Buka pengaturan Aksesibilitas", false, Modifier.fillMaxWidth(), onOpenAccessibility)
        } else {
            Note("Aksesibilitas aktif. Gyro hanya bekerja saat game terbuka dan panel ini tertutup; bidikan digeser di sisi kanan layar.")
        }
        SliderRow("Sensitivitas", st.gyroSensitivity) { app.settings.setGyroSensitivity(it) }
        SliderRow("Stabilisasi", st.gyroSmooth) { app.settings.setGyroSmooth(it) }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            GameChip("Balik kiri-kanan", st.gyroInvertX, Modifier.weight(1f)) { app.settings.setGyroInvertX(!st.gyroInvertX) }
            GameChip("Balik atas-bawah", st.gyroInvertY, Modifier.weight(1f)) { app.settings.setGyroInvertY(!st.gyroInvertY) }
        }

        // ------------------------------------------------ motion blur
        Spacer(Modifier.height(4.dp))
        GameLabel("Motion blur")
        SwitchRow("Motion blur stabil", st.blurOn) { app.settings.setBlurOn(it) }
        Note(
            if (blurSupported) {
                "Blur mengikuti kecepatan putaran ponsel. Dibatasi dan dihaluskan supaya tidak berkedip dan tidak ada garis panjang di layar."
            } else {
                "Tidak didukung di ponsel ini: butuh Android 12+ dengan blur jendela aktif (dimatikan oleh mode hemat daya / pengaturan pabrikan)."
            },
        )
        SliderRow("Kekuatan", st.blurStrength) { app.settings.setBlurStrength(it) }
        GameChip("Uji blur", false, Modifier.fillMaxWidth()) { onBlurTest() }
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val shape = CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, GameLine, shape)
            .padding(start = 12.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = T.body.copy(fontWeight = FontWeight.SemiBold, fontSize = 13.sp), color = Color.White, modifier = Modifier.weight(1f))
        AlterSwitch(checked, onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = T.tiny.copy(fontSize = 10.sp), color = Color.White.copy(alpha = 0.7f), modifier = Modifier.weight(1f))
            Text("${(value * 100).roundToInt()}%", style = T.tiny.copy(fontSize = 10.sp, fontWeight = FontWeight.SemiBold), color = GameAccent2)
        }
        SeekBar(
            value = value,
            onValueChange = onChange,
            onValueChangeFinished = {},
            activeColor = GameAccent2,
            trackColor = Color.White.copy(alpha = 0.16f),
            trackHeight = 3.dp,
            thumbRadius = 5.dp,
        )
    }
}

@Composable
private fun Note(text: String) {
    Text(text, style = T.tiny.copy(fontSize = 10.sp), color = Color.White.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 2.dp))
}
