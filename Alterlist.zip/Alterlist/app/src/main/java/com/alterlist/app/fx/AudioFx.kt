package com.alterlist.app.fx

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Preset efek. [speed] dipakai gaya "tape": kecepatan dan nada turun/naik bersama (PlaybackParameters(speed, speed)),
 * sehingga hasilnya halus tanpa patah-patah seperti time-stretch murahan.
 */
enum class FxPreset(
    val label: String,
    val speed: Float,
    val mix: Float,
    val room: Float,
    val damp: Float,
    val pre: Float,
) {
    NORMAL("Normal", 1f, 0f, 0.70f, 0.50f, 20f),
    SLOWED("Slowed", 0.85f, 0f, 0.70f, 0.50f, 20f),
    SLOWED_REVERB("Slowed + Reverb", 0.85f, 0.30f, 0.80f, 0.55f, 28f),
    REVERB("Reverb", 1f, 0.26f, 0.72f, 0.50f, 20f),
    SPED_UP("Sped up", 1.18f, 0f, 0.70f, 0.50f, 20f),
}

data class FxState(
    val preset: FxPreset?,
    val speed: Float,
    val mix: Float,
    val room: Float,
    val damp: Float,
    val pre: Float,
) {
    val isNormal: Boolean get() = speed == 1f && mix <= 0.001f
}

/** Pengaturan efek global. Dibaca oleh [ReverbAudioProcessor] dan layanan pemutar (satu proses yang sama). */
object AudioFx {
    const val SPEED_MIN = 0.60f
    const val SPEED_MAX = 1.30f
    const val MIX_MAX = 0.60f

    private val _state = MutableStateFlow(fromPreset(FxPreset.NORMAL))
    val state: StateFlow<FxState> = _state.asStateFlow()

    private var prefs: SharedPreferences? = null

    private fun fromPreset(p: FxPreset) = FxState(p, p.speed, p.mix, p.room, p.damp, p.pre)

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences("alterlist_fx", Context.MODE_PRIVATE)
        prefs = sp
        val presetName = sp.getString("preset", null)
        val preset = FxPreset.entries.firstOrNull { it.name == presetName }
        _state.value =
            if (preset != null) {
                fromPreset(preset)
            } else {
                FxState(
                    preset = null,
                    speed = sp.getFloat("speed", 1f).coerceIn(SPEED_MIN, SPEED_MAX),
                    mix = sp.getFloat("mix", 0f).coerceIn(0f, MIX_MAX),
                    room = sp.getFloat("room", 0.7f).coerceIn(0f, 1f),
                    damp = sp.getFloat("damp", 0.5f).coerceIn(0f, 1f),
                    pre = sp.getFloat("pre", 20f).coerceIn(0f, 60f),
                )
            }
    }

    fun applyPreset(p: FxPreset) {
        _state.value = fromPreset(p)
        persist()
    }

    fun setSpeed(v: Float) = custom { it.copy(speed = v.coerceIn(SPEED_MIN, SPEED_MAX)) }

    fun setMix(v: Float) = custom { it.copy(mix = v.coerceIn(0f, MIX_MAX)) }

    fun setRoom(v: Float) = custom { it.copy(room = v.coerceIn(0f, 1f)) }

    fun setDamp(v: Float) = custom { it.copy(damp = v.coerceIn(0f, 1f)) }

    private fun custom(block: (FxState) -> FxState) {
        _state.update { block(it).copy(preset = null) }
        persist()
    }

    private fun persist() {
        val sp = prefs ?: return
        val s = _state.value
        sp.edit()
            .putString("preset", s.preset?.name)
            .putFloat("speed", s.speed)
            .putFloat("mix", s.mix)
            .putFloat("room", s.room)
            .putFloat("damp", s.damp)
            .putFloat("pre", s.pre)
            .apply()
    }
}
