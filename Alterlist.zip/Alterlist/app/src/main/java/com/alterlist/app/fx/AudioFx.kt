package com.alterlist.app.fx

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Preset efek. [speed] dipakai gaya "tape": kecepatan dan nada turun/naik bersama (PlaybackParameters(speed, speed)),
 * sehingga hasilnya halus tanpa patah-patah seperti time-stretch murahan.
 */
enum class FxPreset(
    val label: String,
    val speed: Float,
    val mix: Float,
    val room: Float,
    val damp: Float,
    val pre: Float,
    val spatial: SpatialMode = SpatialMode.OFF,
    val depth: Float = 0.7f,
    val orbit: Float = 0.45f,
) {
    NORMAL("Normal", 1f, 0f, 0.70f, 0.50f, 20f),
    SLOWED("Slowed", 0.85f, 0f, 0.70f, 0.50f, 20f),
    SLOWED_REVERB("Slowed + Reverb", 0.85f, 0.30f, 0.80f, 0.55f, 28f),
    REVERB("Reverb", 1f, 0.26f, 0.72f, 0.50f, 20f),
    SPED_UP("Sped up", 1.18f, 0f, 0.70f, 0.50f, 20f),
    SURROUND_3D("3D Surround", 1f, 0.10f, 0.60f, 0.50f, 18f, SpatialMode.WIDE_3D, 0.75f),
    CONCERT_3D("Konser 3D", 1f, 0.22f, 0.85f, 0.45f, 30f, SpatialMode.WIDE_3D, 1.0f),
    AUDIO_8D("8D Audio", 1f, 0.14f, 0.70f, 0.50f, 24f, SpatialMode.ORBIT_8D, 0.90f, 0.45f),
    SLOWED_8D("Slowed 8D", 0.88f, 0.22f, 0.80f, 0.55f, 28f, SpatialMode.ORBIT_8D, 0.90f, 0.30f),
}

/** Mode audio spasial: 3D = melebar + pantulan ruang, 8D = suara berputar mengelilingi kepala. */
enum class SpatialMode(val label: String) {
    OFF("Mati"),
    WIDE_3D("3D"),
    ORBIT_8D("8D"),
}

data class FxState(
    val preset: FxPreset?,
    val speed: Float,
    val mix: Float,
    val room: Float,
    val damp: Float,
    val pre: Float,
    val spatial: SpatialMode = SpatialMode.OFF,
    /** Kekuatan efek spasial 0..1. */
    val depth: Float = 0.7f,
    /** Kecepatan putaran 8D 0..1 (0 = lambat ~14 detik, 1 = cepat ~3 detik per putaran). */
    val orbit: Float = 0.45f,
) {
    val isNormal: Boolean get() = speed == 1f && mix <= 0.001f && spatial == SpatialMode.OFF

    /** Lama satu putaran 8D dalam detik. */
    val orbitSeconds: Float get() = 14f - 11f * orbit.coerceIn(0f, 1f)
}

/** Pengaturan efek global. Dibaca oleh [ReverbAudioProcessor] dan layanan pemutar (satu proses yang sama). */
object AudioFx {
    const val SPEED_MIN = 0.60f
    const val SPEED_MAX = 1.30f
    const val MIX_MAX = 0.60f

    private val _state = MutableStateFlow(fromPreset(FxPreset.NORMAL))
    val state: StateFlow<FxState> = _state.asStateFlow()

    private var prefs: SharedPreferences? = null

    private fun fromPreset(p: FxPreset) = FxState(p, p.speed, p.mix, p.room, p.damp, p.pre, p.spatial, p.depth, p.orbit)

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val sp = context.applicationContext.getSharedPreferences("alterlist_fx", Context.MODE_PRIVATE)
        prefs = sp
        val presetName = sp.getString("preset", null)
        val preset = FxPreset.entries.firstOrNull { it.name == presetName }
        _state.value =
            if (preset != null) {
                fromPreset(preset)
            } else {
                FxState(
                    preset = null,
                    speed = sp.getFloat("speed", 1f).coerceIn(SPEED_MIN, SPEED_MAX),
                    mix = sp.getFloat("mix", 0f).coerceIn(0f, MIX_MAX),
                    room = sp.getFloat("room", 0.7f).coerceIn(0f, 1f),
                    damp = sp.getFloat("damp", 0.5f).coerceIn(0f, 1f),
                    pre = sp.getFloat("pre", 20f).coerceIn(0f, 60f),
                    spatial = SpatialMode.entries.firstOrNull { it.name == sp.getString("spatial", null) } ?: SpatialMode.OFF,
                    depth = sp.getFloat("depth", 0.7f).coerceIn(0f, 1f),
                    orbit = sp.getFloat("orbit", 0.45f).coerceIn(0f, 1f),
                )
            }
    }

    fun applyPreset(p: FxPreset) {
        _state.value = fromPreset(p)
        persist()
    }

    fun setSpeed(v: Float) = custom { it.copy(speed = v.coerceIn(SPEED_MIN, SPEED_MAX)) }

    fun setMix(v: Float) = custom { it.copy(mix = v.coerceIn(0f, MIX_MAX)) }

    fun setRoom(v: Float) = custom { it.copy(room = v.coerceIn(0f, 1f)) }

    fun setDamp(v: Float) = custom { it.copy(damp = v.coerceIn(0f, 1f)) }

    fun setSpatial(mode: SpatialMode) = custom { it.copy(spatial = mode) }

    fun setDepth(v: Float) = custom { it.copy(depth = v.coerceIn(0f, 1f)) }

    fun setOrbit(v: Float) = custom { it.copy(orbit = v.coerceIn(0f, 1f)) }

    fun setPre(v: Float) = custom { it.copy(pre = v.coerceIn(0f, 60f)) }

    /** Kembalikan semua efek ke Normal. */
    fun reset() = applyPreset(FxPreset.NORMAL)

    private fun custom(block: (FxState) -> FxState) {
        _state.update { block(it).copy(preset = null) }
        persist()
    }

    private fun persist() {
        val sp = prefs ?: return
        val s = _state.value
        sp.edit()
            .putString("preset", s.preset?.name)
            .putFloat("speed", s.speed)
            .putFloat("mix", s.mix)
            .putFloat("room", s.room)
            .putFloat("damp", s.damp)
            .putFloat("pre", s.pre)
            .putString("spatial", s.spatial.name)
            .putFloat("depth", s.depth)
            .putFloat("orbit", s.orbit)
            .apply()
    }
}
