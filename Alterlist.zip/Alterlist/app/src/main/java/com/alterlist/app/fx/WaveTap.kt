package com.alterlist.app.fx

import androidx.media3.exoplayer.audio.TeeAudioProcessor
import com.alterlist.app.ui.WaveCandyView
import java.nio.ByteBuffer

/**
 * Penyadap suara untuk visualizer Wave Candy. Dipasang di ujung rantai AudioProcessor pemutar, jadi yang digambar
 * adalah suara setelah efek (reverb, 3D/8D) - sama dengan yang terdengar. Tanpa izin RECORD_AUDIO.
 *
 * Saat tidak ada tampilan visualizer yang terbuka ([view] null), buffer langsung dilewati sehingga tidak ada beban.
 */
object WaveTap : TeeAudioProcessor.AudioBufferSink {
    /** Tampilan Wave Candy yang sedang tampil di Now Playing (diisi dan dikosongkan dari UI). */
    @Volatile var view: WaveCandyView? = null

    @Volatile var sampleRate: Int = 44100
        private set

    @Volatile private var channels: Int = 2

    @Volatile private var encoding: Int = 2

    override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
        sampleRate = sampleRateHz
        channels = channelCount
        this.encoding = encoding
        view?.let {
            it.sampleRate = sampleRateHz
            it.reset()
        }
    }

    override fun handleBuffer(buffer: ByteBuffer) {
        view?.feedPcm(buffer, channels, encoding)
    }
}
