package com.alterlist.app.island

import android.content.Intent
import android.os.Build
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.alterlist.app.AlterApp
import com.alterlist.app.MainActivity
import com.alterlist.app.R
import com.alterlist.app.data.Song
import com.alterlist.app.playback.PlayerUiState
import com.alterlist.app.ui.Artwork
import com.alterlist.app.ui.CoverPalette
import com.alterlist.app.ui.Ic
import com.alterlist.app.ui.LiquidGlass
import com.alterlist.app.ui.SeekBar
import com.alterlist.app.ui.T
import com.alterlist.app.ui.backdropSource
import com.alterlist.app.ui.bounceClick
import com.alterlist.app.ui.formatTime
import com.alterlist.app.ui.noRippleClickable
import com.alterlist.app.ui.rememberBackdropState
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

/** Isi jendela overlay dynamic bar. Tidak menggambar apa pun sampai kamera terbaca dan ada lagu. */
@Composable
fun DynamicBarRoot(controller: DynamicBarController) {
    val layout by controller.layout.collectAsState()
    val state by AlterApp.instance.player.state.collectAsState()
    val l = layout ?: return
    val song = state.current ?: return
    IslandHost(controller, l, state, song)
}

@Composable
private fun IslandHost(controller: DynamicBarController, l: BarLayout, state: PlayerUiState, song: Song) {
    val density = LocalDensity.current
    val expandedReq by controller.expanded.collectAsState()
    val winExpanded by controller.windowExpanded.collectAsState()
    val palette = rememberVividPalette(song.thumbnail)
    val accent1 = lerp(palette.primary, Color.White, 0.5f)
    val accent2 = lerp(palette.secondary, Color.White, 0.4f)

    // 0 = pil di sekitar kamera, 1 = kartu terbuka
    val t = remember { Animatable(0f) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(expandedReq) {
        if (expandedReq) {
            // jendela dibesarkan lebih dulu (di pesan yang sama), baru isinya dianimasikan
            controller.setWindowExpanded(true)
            t.animateTo(1f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 420f))
        } else {
            t.animateTo(0f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 520f))
            controller.setWindowExpanded(false)
        }
    }
    // kartu menutup sendiri bila tidak disentuh
    LaunchedEffect(expandedReq, tick) {
        if (expandedReq) {
            delay(7_000L)
            controller.setExpanded(false)
        }
    }

    val tv = t.value.coerceIn(0f, 1f)
    fun mix(a: Float, b: Float): Float = a + (b - a) * tv

    val c = l.collapsed
    val e = l.expanded
    val wPx = mix(c.width, e.width)
    val hPx = mix(c.height, e.height)
    val leftScreen = mix(c.left, e.left)
    val topScreen = mix(c.top, e.top)
    // posisi jendela di layar: pil = bingkai kecil, kartu = selebar layar dari tepi atas
    val winLeft = if (winExpanded) 0f else c.left
    val winTop = if (winExpanded) 0f else c.top

    val bottomR = mix(c.height / 2f, 28f * l.density)
    val cornerDp = with(density) { bottomR.toDp() }
    val shape: Shape =
        if (l.isDrop) DropShape(l.ear * (1f - tv), bottomR) else RoundedCornerShape(cornerDp)

    val backdrop = rememberBackdropState()

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .offset { IntOffset((leftScreen - winLeft).roundToInt(), (topScreen - winTop).roundToInt()) }
                .size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() })
                .pointerInput(expandedReq) {
                    if (!expandedReq) return@pointerInput
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -40f) controller.setExpanded(false) },
                        onDragCancel = {},
                    ) { _, dy -> total += dy }
                },
        ) {
            // "latar" kaca: cover diperbesar + di-blur + diwarnai palet. Kaca di atasnya membiaskan tepinya.
            Box(Modifier.matchParentSize().clip(shape).backdropSource(backdrop)) {
                CoverBackdrop(song.thumbnail, palette)
            }
            LiquidGlass(
                state = backdrop,
                palette = palette,
                modifier = Modifier.matchParentSize(),
                shape = shape,
                corner = cornerDp,
            ) {
                val collAlpha = (1f - tv * 2.2f).coerceIn(0f, 1f)
                val expAlpha = ((tv - 0.4f) / 0.6f).coerceIn(0f, 1f)
                if (collAlpha > 0f) {
                    CollapsedContent(
                        l = l,
                        song = song,
                        playing = state.isPlaying,
                        accent1 = accent1,
                        accent2 = accent2,
                        modifier =
                            Modifier
                                .align(Alignment.TopCenter)
                                .graphicsLayer { alpha = collAlpha }
                                .noRippleClickable { controller.setExpanded(true) },
                    )
                }
                if (tv > 0.05f) {
                    ExpandedContent(
                        controller = controller,
                        l = l,
                        state = state,
                        song = song,
                        accent1 = accent1,
                        accent2 = accent2,
                        onPoke = { tick++ },
                        modifier = Modifier.align(Alignment.TopCenter).graphicsLayer { alpha = expAlpha },
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ bentuk

/**
 * Bentuk waterdrop: menempel di tepi atas layar, sudut atasnya melebar ("telinga") seperti tetesan air,
 * lalu turun dan membulat di bawah kamera. [ear] mengecil ke 0 saat bar membuka menjadi kartu.
 */
private class DropShape(private val ear: Float, private val bottomR: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        val e = ear.coerceIn(0f, w / 3f)
        val r = bottomR.coerceIn(0f, minOf((w - 2f * e) / 2f, h))
        val f = minOf(e * 1.7f, (h - r).coerceAtLeast(0f))
        val p = Path()
        p.moveTo(0f, 0f)
        p.cubicTo(e * 0.62f, 0f, e, f * 0.38f, e, f)
        p.lineTo(e, h - r)
        p.arcTo(Rect(e, h - 2f * r, e + 2f * r, h), 180f, -90f, false)
        p.lineTo(w - e - r, h)
        p.arcTo(Rect(w - e - 2f * r, h - 2f * r, w - e, h), 90f, -90f, false)
        p.lineTo(w - e, f)
        p.cubicTo(w - e, f * 0.38f, w - e * 0.62f, 0f, w, 0f)
        p.close()
        return Outline.Generic(p)
    }
}

// ------------------------------------------------------------------ latar kaca

@Composable
private fun CoverBackdrop(url: String?, palette: CoverPalette) {
    Box(Modifier.fillMaxSize()) {
        Artwork(
            url,
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = 1.9f
                    scaleY = 1.9f
                }
                .then(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Modifier.blur(28.dp) else Modifier),
            RoundedCornerShape(0.dp),
            px = 96,
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(palette.primary.copy(alpha = 0.66f), palette.secondary.copy(alpha = 0.54f))),
            ),
        )
        // sedikit digelapkan supaya teks putih tetap jelas
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.16f)))
    }
}

// ------------------------------------------------------------------ pil (diciutkan)

@Composable
private fun CollapsedContent(
    l: BarLayout,
    song: Song,
    playing: Boolean,
    accent1: Color,
    accent2: Color,
    modifier: Modifier = Modifier,
) {
    val d = LocalDensity.current
    fun dp(px: Float): Dp = with(d) { px.toDp() }
    val artDp = (l.collapsed.height / l.density - 10f).coerceIn(18f, 24f).dp
    val artScale by animateFloatAsState(
        targetValue = if (playing) 1f else 0.88f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "islandArt",
    )

    @Composable
    fun Art() {
        Artwork(
            song.thumbnail,
            Modifier.size(artDp).graphicsLayer {
                scaleX = artScale
                scaleY = artScale
            },
            if (l.isDrop) RoundedCornerShape(7.dp) else CircleShape,
            px = 64,
        )
    }

    @Composable
    fun Viz() {
        IslandVisualizer(accent1, accent2, playing, Modifier.size(width = 20.dp, height = 16.dp))
    }

    Row(
        modifier.requiredSize(dp(l.collapsed.width), dp(l.collapsed.height)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.width(dp(l.ear)))
        Box(Modifier.width(dp(l.leftZone)).fillMaxHeight(), contentAlignment = Alignment.Center) {
            when (l.plan) {
                ZonePlan.BOTH -> Art()
                ZonePlan.LEFT_ONLY ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Art()
                        Viz()
                    }
                ZonePlan.RIGHT_ONLY -> {}
            }
        }
        Spacer(Modifier.width(dp(l.gap)))
        Box(Modifier.width(dp(l.rightZone)).fillMaxHeight(), contentAlignment = Alignment.Center) {
            when (l.plan) {
                ZonePlan.BOTH -> Viz()
                ZonePlan.RIGHT_ONLY ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Art()
                        Viz()
                    }
                ZonePlan.LEFT_ONLY -> {}
            }
        }
        Spacer(Modifier.width(dp(l.ear)))
    }
}

// ------------------------------------------------------------------ kartu (terbuka)

@Composable
private fun ExpandedContent(
    controller: DynamicBarController,
    l: BarLayout,
    state: PlayerUiState,
    song: Song,
    accent1: Color,
    accent2: Color,
    onPoke: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val app = AlterApp.instance
    val d = LocalDensity.current
    fun dp(px: Float): Dp = with(d) { px.toDp() }
    val dur = state.durationMs
    val progress = if (dur > 0L) (state.positionMs.toFloat() / dur).coerceIn(0f, 1f) else 0f
    var drag by remember { mutableStateOf<Float?>(null) }
    val shownPos = drag?.let { (it * dur).toLong() } ?: state.positionMs
    val dim = Color.White.copy(alpha = 0.78f)

    Column(
        modifier
            .requiredSize(dp(l.expanded.width), dp(l.expanded.height))
            .padding(start = 16.dp, end = 16.dp, top = dp(l.expandedContentTop), bottom = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Artwork(
                song.thumbnail,
                Modifier.size(52.dp).clickable {
                    openApp()
                    controller.setExpanded(false)
                },
                RoundedCornerShape(14.dp),
                px = 160,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    style = T.body.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp),
                    color = Color.White,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Clip,
                    modifier = Modifier.basicMarquee(),
                )
                Text(
                    song.artist,
                    style = T.small,
                    color = dim,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(10.dp))
            IslandVisualizer(accent1, accent2, state.isPlaying, Modifier.size(width = 30.dp, height = 24.dp))
        }

        Column {
            SeekBar(
                value = drag ?: progress,
                onValueChange = {
                    drag = it
                    onPoke()
                },
                onValueChangeFinished = {
                    val v = drag
                    if (v != null && dur > 0L) app.player.seekTo((v * dur).toLong())
                    drag = null
                },
                modifier = Modifier.fillMaxWidth(),
                activeColor = accent1,
                trackColor = Color.White.copy(alpha = 0.28f),
                trackHeight = 4.dp,
                thumbRadius = 5.dp,
                enabled = dur > 0L,
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(shownPos), style = T.tiny, color = dim)
                Text(if (dur > 0L) formatTime(dur) else "--:--", style = T.tiny, color = dim)
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            // acak
            CtrlButton(
                icon = R.drawable.ic_shuffle,
                tint = if (state.shuffle) accent1 else dim,
                size = 22.dp,
                active = state.shuffle,
            ) {
                onPoke()
                app.player.toggleShuffle()
            }
            CtrlButton(icon = R.drawable.ic_prev, tint = Color.White, size = 26.dp) {
                onPoke()
                app.player.previous()
            }
            Box(
                Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.34f), Color.White.copy(alpha = 0.14f))))
                    .border(1.dp, Color.White.copy(alpha = 0.42f), CircleShape)
                    .bounceClick {
                        onPoke()
                        app.player.togglePlay()
                    },
                contentAlignment = Alignment.Center,
            ) {
                if (state.isBuffering && !state.isPlaying) {
                    CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Ic(if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, tint = Color.White, size = 26.dp)
                }
            }
            CtrlButton(icon = R.drawable.ic_next, tint = Color.White, size = 26.dp) {
                onPoke()
                app.player.next()
            }
            // loop (semua) / loop 1 (satu lagu)
            val repeat = state.repeatMode
            CtrlButton(
                icon = if (repeat == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                tint = if (repeat != Player.REPEAT_MODE_OFF) accent1 else dim,
                size = 22.dp,
                active = repeat != Player.REPEAT_MODE_OFF,
            ) {
                onPoke()
                app.player.cycleRepeat()
            }
        }
    }
}

@Composable
private fun CtrlButton(
    @DrawableRes icon: Int,
    tint: Color,
    size: Dp,
    active: Boolean = false,
    onClick: () -> Unit,
) {
    Box(Modifier.size(44.dp).clip(CircleShape).bounceClick(onClick = onClick), contentAlignment = Alignment.Center) {
        Ic(icon, tint = tint, size = size)
        if (active) {
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp).size(4.dp).clip(CircleShape).background(tint))
        }
    }
}

private fun openApp() {
    val app = AlterApp.instance
    runCatching {
        app.startActivity(
            Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }
}

// ------------------------------------------------------------------ visualizer

/** Lima batang equalizer; warnanya gradasi dari warna album. Bergerak saat musik diputar, rata saat dijeda. */
@Composable
internal fun IslandVisualizer(top: Color, bottom: Color, playing: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "islandViz")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable<Float>(tween(1600, easing = LinearEasing), RepeatMode.Restart),
        label = "islandPhase",
    )
    val amp by animateFloatAsState(targetValue = if (playing) 1f else 0f, animationSpec = tween(350), label = "islandAmp")
    Canvas(modifier) {
        val n = 5
        val gapPx = size.width * 0.12f
        val bw = (size.width - gapPx * (n - 1)) / n
        val freqs = intArrayOf(2, 3, 1, 3, 2)
        val offs = floatArrayOf(0f, 0.21f, 0.43f, 0.67f, 0.88f)
        val brush = Brush.verticalGradient(listOf(top, bottom), startY = 0f, endY = size.height)
        for (i in 0 until n) {
            val wave = abs(sin((phase * freqs[i] + offs[i]) * 2f * PI.toFloat()))
            val target = 0.22f + 0.78f * wave
            val frac = 0.16f + (target - 0.16f) * amp
            val bh = size.height * frac
            drawRoundRect(
                brush = brush,
                topLeft = Offset(i * (bw + gapPx), (size.height - bh) / 2f),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}
