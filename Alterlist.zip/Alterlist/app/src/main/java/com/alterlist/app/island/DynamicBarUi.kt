package com.alterlist.app.island

import android.content.Intent
import android.os.Build
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.alterlist.app.AlterApp
import com.alterlist.app.MainActivity
import com.alterlist.app.R
import com.alterlist.app.data.Song
import com.alterlist.app.playback.PlayerUiState
import com.alterlist.app.ui.Artwork
import com.alterlist.app.ui.CoverPalette
import com.alterlist.app.ui.Ic
import com.alterlist.app.ui.LiquidGlass
import com.alterlist.app.ui.SeekBar
import com.alterlist.app.ui.T
import com.alterlist.app.ui.backdropSource
import com.alterlist.app.ui.bounceClick
import com.alterlist.app.ui.formatTime
import com.alterlist.app.ui.noRippleClickable
import com.alterlist.app.ui.rememberBackdropState
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Isi jendela overlay dynamic bar. Tidak menggambar apa pun sampai kamera terbaca dan ada lagu.
 *
 * Tampilan mengikuti dynamic bar resmi ponsel: pil hitam di sekitar kamera (gelombang di kiri, cover di kanan),
 * yang bila diketuk membesar menjadi kartu hitam selebar layar dari tepi atas (menutup status bar, jadi bersih
 * tanpa ikon notifikasi) berisi cover, judul, artis, gelombang, progres + waktu, dan tombol kontrol.
 */
@Composable
fun DynamicBarRoot(controller: DynamicBarController) {
    val layout by controller.layout.collectAsState()
    val state by AlterApp.instance.player.state.collectAsState()
    val l = layout ?: return
    val song = state.current ?: return
    IslandHost(controller, l, state, song)
}

/** Warna garis tepi kartu (sama dengan dynamic bar resmi: biru-putih pucat, tipis). */
private val IslandStroke = Color(0xFFC5DBFF)

@Composable
private fun IslandHost(controller: DynamicBarController, l: BarLayout, state: PlayerUiState, song: Song) {
    val density = LocalDensity.current
    val expandedReq by controller.expanded.collectAsState()
    val winExpanded by controller.windowExpanded.collectAsState()

    // 0 = pil di sekitar kamera, 1 = kartu terbuka
    val t = remember { Animatable(0f) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(expandedReq) {
        if (expandedReq) {
            // jendela dibesarkan lebih dulu (di pesan yang sama), baru isinya dianimasikan; sedikit membal seperti aslinya
            controller.setWindowExpanded(true)
            t.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 380f))
        } else {
            t.animateTo(0f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 520f))
            controller.setWindowExpanded(false)
        }
    }
    // kartu menutup sendiri bila tidak disentuh
    LaunchedEffect(expandedReq, tick) {
        if (expandedReq) {
            delay(6_000L)
            controller.setExpanded(false)
        }
    }

    val raw = t.value
    val tv = raw.coerceIn(0f, 1f)

    fun mix(a: Float, b: Float, k: Float): Float = a + (b - a) * k

    val c = l.collapsed
    val e = l.expanded
    val wPx = mix(c.width, e.width, tv)
    // tinggi boleh sedikit melampaui target (membal); jendela punya cadangan ruang untuk itu
    val hPx = mix(c.height, e.height, raw.coerceIn(0f, 1.06f))
    val leftScreen = mix(c.left, e.left, tv)
    val topScreen = mix(c.top, e.top, tv)
    // posisi jendela di layar: pil = bingkai kecil, kartu = selebar layar dari tepi atas
    val winLeft = if (winExpanded) 0f else c.left
    val winTop = if (winExpanded) 0f else c.top

    val bottomR = mix(c.height / 2f, 28f * l.density, tv)
    val shape: Shape =
        if (l.isDrop) {
            DropShape(l.ear * (1f - tv), bottomR)
        } else {
            val topDp = with(density) { mix(c.height / 2f, 0f, tv).toDp() }
            val botDp = with(density) { bottomR.toDp() }
            RoundedCornerShape(topStart = topDp, topEnd = topDp, bottomEnd = botDp, bottomStart = botDp)
        }

    Box(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .offset { IntOffset((leftScreen - winLeft).roundToInt(), (topScreen - winTop).roundToInt()) }
                .size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() })
                .clip(shape)
                .background(Color.Black)
                .border(0.7.dp, IslandStroke.copy(alpha = 0.34f * tv), shape)
                .pointerInput(expandedReq) {
                    if (!expandedReq) return@pointerInput
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragEnd = { if (total < -40f) controller.setExpanded(false) },
                        onDragCancel = {},
                    ) { _, dy -> total += dy }
                },
        ) {
            val collAlpha = (1f - tv * 2.2f).coerceIn(0f, 1f)
            val expAlpha = ((tv - 0.4f) / 0.6f).coerceIn(0f, 1f)
            if (collAlpha > 0f) {
                CollapsedContent(
                    l = l,
                    song = song,
                    playing = state.isPlaying,
                    modifier =
                        Modifier
                            .align(Alignment.TopCenter)
                            .graphicsLayer { alpha = collAlpha }
                            .noRippleClickable { controller.setExpanded(true) },
                )
            }
            if (tv > 0.05f) {
                ExpandedContent(
                    controller = controller,
                    l = l,
                    state = state,
                    song = song,
                    onPoke = { tick++ },
                    modifier = Modifier.align(Alignment.TopCenter).graphicsLayer { alpha = expAlpha },
                )
            }
        }
    }
}

// ------------------------------------------------------------------ bentuk

/**
 * Bentuk waterdrop: menempel di tepi atas layar, sudut atasnya melebar ("telinga") seperti tetesan air,
 * lalu turun dan membulat di bawah kamera. [ear] mengecil ke 0 saat bar membuka menjadi kartu.
 */
private class DropShape(private val ear: Float, private val bottomR: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        val e = ear.coerceIn(0f, w / 3f)
        val r = bottomR.coerceIn(0f, minOf((w - 2f * e) / 2f, h))
        val f = minOf(e * 1.7f, (h - r).coerceAtLeast(0f))
        val p = Path()
        p.moveTo(0f, 0f)
        p.cubicTo(e * 0.62f, 0f, e, f * 0.38f, e, f)
        p.lineTo(e, h - r)
        p.arcTo(Rect(e, h - 2f * r, e + 2f * r, h), 180f, -90f, false)
        p.lineTo(w - e - r, h)
        p.arcTo(Rect(w - e - 2f * r, h - 2f * r, w - e, h), 90f, -90f, false)
        p.lineTo(w - e, f)
        p.cubicTo(w - e, f * 0.38f, w - e * 0.62f, 0f, w, 0f)
        p.close()
        return Outline.Generic(p)
    }
}

// ------------------------------------------------------------------ pil (diciutkan)

@Composable
private fun CollapsedContent(
    l: BarLayout,
    song: Song,
    playing: Boolean,
    modifier: Modifier = Modifier,
) {
    val d = LocalDensity.current
    fun dp(px: Float): Dp = with(d) { px.toDp() }
    val artDp = (l.collapsed.height / l.density - 8f).coerceIn(18f, 25f).dp
    val artScale by animateFloatAsState(
        targetValue = if (playing) 1f else 0.9f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "islandArt",
    )

    @Composable
    fun Art() {
        Artwork(
            song.thumbnail,
            Modifier.size(artDp).graphicsLayer {
                scaleX = artScale
                scaleY = artScale
            },
            CircleShape,
            px = 64,
        )
    }

    @Composable
    fun Viz() {
        IslandVisualizer(Color.White.copy(alpha = 0.82f), playing, Modifier.size(width = 28.dp, height = 14.dp), bars = 7)
    }

    // gelombang di kiri kamera, cover di kanan (seperti dynamic bar resmi)
    Row(
        modifier.requiredSize(dp(l.collapsed.width), dp(l.collapsed.height)),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.width(dp(l.ear)))
        Box(Modifier.width(dp(l.leftZone)).fillMaxHeight(), contentAlignment = Alignment.Center) {
            when (l.plan) {
                ZonePlan.BOTH -> Viz()
                ZonePlan.LEFT_ONLY ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Viz()
                        Art()
                    }
                ZonePlan.RIGHT_ONLY -> {}
            }
        }
        Spacer(Modifier.width(dp(l.gap)))
        Box(Modifier.width(dp(l.rightZone)).fillMaxHeight(), contentAlignment = Alignment.Center) {
            when (l.plan) {
                ZonePlan.BOTH -> Art()
                ZonePlan.RIGHT_ONLY ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Art()
                        Viz()
                    }
                ZonePlan.LEFT_ONLY -> {}
            }
        }
        Spacer(Modifier.width(dp(l.ear)))
    }
}

// ------------------------------------------------------------------ kartu (terbuka)

/**
 * Tata letak kartu mengikuti dynamic bar resmi (dalam dp): padding 16, cover 58, judul 14 bold (jarak atas 10),
 * artis 12 (jarak atas 5), gelombang 36, progres setinggi 25 (jarak atas 4), waktu 10, tombol dengan area sentuh 44
 * dan ikon 20. Tinggi total 162.
 */
@Composable
private fun ExpandedContent(
    controller: DynamicBarController,
    l: BarLayout,
    state: PlayerUiState,
    song: Song,
    onPoke: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val app = AlterApp.instance
    val d = LocalDensity.current
    fun dp(px: Float): Dp = with(d) { px.toDp() }
    val dur = state.durationMs
    val progress = if (dur > 0L) (state.positionMs.toFloat() / dur).coerceIn(0f, 1f) else 0f
    var drag by remember { mutableStateOf<Float?>(null) }
    val shownPos = drag?.let { (it * dur).toLong() } ?: state.positionMs
    val timeColor = Color(0x99FFFFFF)
    val artistColor = Color(0xB2FFFFFF)
    val coverShape = RoundedCornerShape(10.dp)

    Column(modifier.requiredSize(dp(l.expanded.width), dp(l.expanded.height))) {
        // baris atas: cover, judul + artis, gelombang
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
            Artwork(
                song.thumbnail,
                Modifier
                    .size(58.dp)
                    .border(0.5.dp, Color.White.copy(alpha = 0.14f), coverShape)
                    .clickable {
                        openApp()
                        controller.setExpanded(false)
                    },
                coverShape,
                px = 160,
            )
            Column(Modifier.weight(1f).padding(start = 14.dp, end = 12.dp)) {
                Spacer(Modifier.height(10.dp))
                Text(
                    song.title,
                    style = T.body.copy(fontWeight = FontWeight.Bold, fontSize = 14.sp),
                    color = Color.White,
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Clip,
                    modifier = Modifier.basicMarquee(),
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    song.artist,
                    style = T.small.copy(fontSize = 12.sp),
                    color = artistColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) {
                IslandVisualizer(Color.White.copy(alpha = 0.8f), state.isPlaying, Modifier.size(width = 34.dp, height = 22.dp), bars = 7)
            }
        }

        // progres setinggi 25dp; lintasan sejajar dengan tepi isi (16dp), titik geser boleh keluar sedikit
        Box(
            Modifier.fillMaxWidth().padding(start = 11.dp, end = 11.dp, top = 4.dp).height(29.dp),
            contentAlignment = Alignment.Center,
        ) {
            SeekBar(
                value = drag ?: progress,
                onValueChange = {
                    drag = it
                    onPoke()
                },
                onValueChangeFinished = {
                    val v = drag
                    if (v != null && dur > 0L) app.player.seekTo((v * dur).toLong())
                    drag = null
                },
                modifier = Modifier.fillMaxWidth(),
                activeColor = Color.White,
                trackColor = Color.White.copy(alpha = 0.16f),
                trackHeight = 3.dp,
                thumbRadius = 5.dp,
                enabled = dur > 0L,
            )
        }

        // waktu (di tepi) dan tombol (tersebar rata) berbagi baris, seperti aslinya
        Box(Modifier.fillMaxWidth().height(44.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp).offset(y = (-9).dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(formatTime(shownPos), style = T.tiny.copy(fontSize = 10.sp), color = timeColor)
                Text(if (dur > 0L) formatTime(dur) else "--:--", style = T.tiny.copy(fontSize = 10.sp), color = timeColor)
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CtrlButton(icon = R.drawable.ic_prev, tint = Color.White, size = 20.dp) {
                    onPoke()
                    app.player.previous()
                }
                Box(Modifier.size(44.dp).bounceClick {
                    onPoke()
                    app.player.togglePlay()
                }, contentAlignment = Alignment.Center) {
                    if (state.isBuffering && !state.isPlaying) {
                        CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Ic(if (state.isPlaying) R.drawable.ic_pause else R.drawable.ic_play, tint = Color.White, size = 20.dp)
                    }
                }
                CtrlButton(icon = R.drawable.ic_next, tint = Color.White, size = 20.dp) {
                    onPoke()
                    app.player.next()
                }
            }
            // acak (kiri) dan loop (kanan): tambahan Alterlist, kecil dan redup supaya bentuk aslinya tetap bersih
            CtrlButton(
                icon = R.drawable.ic_shuffle,
                tint = if (state.shuffle) Color.White else Color.White.copy(alpha = 0.42f),
                size = 17.dp,
                active = state.shuffle,
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp),
            ) {
                onPoke()
                app.player.toggleShuffle()
            }
            val repeat = state.repeatMode
            CtrlButton(
                icon = if (repeat == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat,
                tint = if (repeat != Player.REPEAT_MODE_OFF) Color.White else Color.White.copy(alpha = 0.42f),
                size = 17.dp,
                active = repeat != Player.REPEAT_MODE_OFF,
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp),
            ) {
                onPoke()
                app.player.cycleRepeat()
            }
        }
    }
}

@Composable
private fun CtrlButton(
    @DrawableRes icon: Int,
    tint: Color,
    size: Dp,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onClick: () -> Unit,
) {
    Box(modifier.size(44.dp).clip(CircleShape).bounceClick(onClick = onClick), contentAlignment = Alignment.Center) {
        Ic(icon, tint = tint, size = size)
        if (active) {
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 5.dp).size(3.dp).clip(CircleShape).background(tint))
        }
    }
}

private fun openApp() {
    val app = AlterApp.instance
    runCatching {
        app.startActivity(
            Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        )
    }
}

// ------------------------------------------------------------------ visualizer

/**
 * Gelombang [bars] batang (bawaan 5) dengan satu warna. Tinggi tiap batang mengikuti pola tengah-tertinggi seperti
 * dynamic bar resmi; bergerak saat musik diputar, diam pada pola dasar saat dijeda.
 */
@Composable
internal fun IslandVisualizer(color: Color, playing: Boolean, modifier: Modifier = Modifier, bars: Int = 5) {
    val transition = rememberInfiniteTransition(label = "islandViz")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable<Float>(tween(1600, easing = LinearEasing), RepeatMode.Restart),
        label = "islandPhase",
    )
    val amp by animateFloatAsState(targetValue = if (playing) 1f else 0f, animationSpec = tween(350), label = "islandAmp")
    Canvas(modifier) {
        val n = bars.coerceAtLeast(1)
        val bw = size.width / (n + (n - 1) * 1.2f)
        val gapPx = bw * 1.2f
        val freqs = intArrayOf(2, 3, 1, 3, 2, 1, 3)
        val offs = floatArrayOf(0f, 0.21f, 0.43f, 0.67f, 0.88f, 0.31f, 0.55f)
        val mid = (n - 1) / 2f
        for (i in 0 until n) {
            // pola dasar: batang tengah paling tinggi, tepi paling pendek
            val shape = 1f - 0.6f * (abs(i - mid) / (mid + 0.5f))
            val wave = abs(sin((phase * freqs[i % freqs.size] + offs[i % offs.size]) * 2f * PI.toFloat()))
            val moving = shape * (0.35f + 0.65f * wave)
            val still = shape * 0.62f
            val frac = (still + (moving - still) * amp).coerceIn(0.12f, 1f)
            val bh = size.height * frac
            drawRoundRect(
                color = color,
                topLeft = Offset(i * (bw + gapPx), (size.height - bh) / 2f),
                size = Size(bw, bh),
                cornerRadius = CornerRadius(bw / 2f),
            )
        }
    }
}
