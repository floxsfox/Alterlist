package com.alterlist.app.system

import android.content.Context
import android.content.Intent
import com.alterlist.app.AlterApp
import com.alterlist.app.data.GameDetect

/** Satu pintu untuk menyalakan / mematikan layanan mode game sesuai pengaturan dan izin yang sudah diberikan. */
object GameModeController {
    /** Izin yang dibutuhkan sudah lengkap? Mode "Selalu tampil" tidak butuh Akses penggunaan. */
    fun permissionsReady(context: Context): Boolean {
        val st = AlterApp.instance.settings.state.value
        if (!GameDetector.hasOverlayPermission(context)) return false
        return st.gameDetect == GameDetect.ALWAYS || GameDetector.hasUsageAccess(context)
    }

    /** Dipanggil saat pengaturan berubah, aplikasi dibuka, dan setelah ponsel menyala. Aman dipanggil berulang. */
    fun sync(context: Context) {
        val st = AlterApp.instance.settings.state.value
        val intent = Intent(context, GameOverlayService::class.java)
        if (st.gameMode && permissionsReady(context)) {
            try {
                context.startForegroundService(intent)
            } catch (e: Exception) {
                // dilarang memulai foreground service dari latar belakang: akan dicoba lagi saat aplikasi dibuka
            }
        } else {
            context.stopService(intent)
        }
    }
}
