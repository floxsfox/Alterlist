import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
}

// Keystore rilis opsional (diisi lewat GitHub Secrets di workflow).
// Kalau tidak ada, APK rilis ditandatangani dengan debug key supaya tetap bisa di-install.
val keystorePath: String? = System.getenv("KEYSTORE_FILE")?.takeIf { it.isNotBlank() }
val hasReleaseKeystore: Boolean = keystorePath != null && file(keystorePath!!).exists()
// Keystore tetap (ada di repo). Dipakai bila keystore rilis dari Secrets tidak ada, supaya tanda tangan APK
// selalu sama dan pembaruan tidak bentrok. (Dulu: debug key yang dibuat ulang di tiap build GitHub Actions.)
val fixedKeystore = file("alterlist-fixed.jks")

android {
    namespace = "com.alterlist.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.alterlist.app"
        // Android 10 (API 29) sampai Android 17 (API 37)
        minSdk = 29
        targetSdk = 36
        // versionCode = mayor*10000 + minor*100 + patch (3.6.8 -> 30608): selalu naik, tidak pernah lebih kecil dari build lama
        versionCode = 30608
        versionName = "3.6.8"

        // Satu APK untuk ARM 64-bit (arm64-v8a) dan ARM 32-bit (armeabi-v7a)
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        if (hasReleaseKeystore) {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        } else if (fixedKeystore.exists()) {
            create("fixed") {
                storeFile = fixedKeystore
                storePassword = "alterlist"
                keyAlias = "alterlist"
                keyPassword = "alterlist"
            }
        }
    }

    buildTypes {
        release {
            // Minify dimatikan supaya library (ktor / innertubex / serialization) aman dari R8.
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig =
                when {
                    hasReleaseKeystore -> signingConfigs.getByName("release")
                    fixedKeystore.exists() -> signingConfigs.getByName("fixed")
                    else -> signingConfigs.getByName("debug")
                }
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlin {
        jvmToolchain(21)
        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_21)
            freeCompilerArgs.addAll(
                "-opt-in=kotlin.RequiresOptIn",
                "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
                "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
                "-opt-in=androidx.compose.ui.ExperimentalComposeUiApi",
                "-opt-in=androidx.media3.common.util.UnstableApi",
            )
        }
    }

    buildFeatures {
        compose = true
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/NOTICE.md"
            excludes += "META-INF/CONTRIBUTORS.md"
            excludes += "META-INF/LICENSE.md"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/io.netty.versions.properties"
        }
    }
}

// org.json bawaan Android dipakai; artefak org.json:json tidak diperlukan.
configurations.configureEach {
    exclude(group = "org.json", module = "json")
}

dependencies {
    coreLibraryDesugaring(libs.desugaring)

    // UI
    implementation(libs.activity)
    implementation(libs.compose.runtime)
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.animation)
    implementation(libs.material3)
    implementation(libs.coil)
    implementation(libs.coil.network.okhttp)

    // Pemutar
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.session)
    implementation(libs.guava)

    // YouTube Music API (InnerTubeX)
    implementation(libs.innertubex)
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.client.encoding)
    implementation(libs.ktor.serialization.json)
    implementation(libs.serialization.json)
    implementation(libs.coroutines.android)
}
