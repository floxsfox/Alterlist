pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // InnerTubeX + QuackJS ada di JitPack
        maven { setUrl("https://jitpack.io") }
    }
}

rootProject.name = "Alterlist"
include(":app")
